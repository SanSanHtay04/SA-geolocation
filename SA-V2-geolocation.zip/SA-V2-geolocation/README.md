# Sales App

Note that this project is only tested on Android.

## Install
Before run app, open terminal and run this command first
```bash
dart  run build_runner build  --delete-conflicting-outputs
```


# Environment Variables

| Name | Type | Value | Description |  
|--|--|--|--|  
| SERVER_URL | string | https://app-be.r2omm.xyz \| https://test-be.r2omm.xyz | Server URL mostly used as base URL. |
| LEGACY_URL | string | https://app.r2omm.info \| https://test.r2omm.info | Legacy URL mostly used as documentation files. |
| SA_MODULE | string | https://sa-api.r2omm.net \| https://staging-sa-api.r2omm.net | Module URL mostly used as SA applications. |
| SA_PASSPORT_URL | string | https://passport.r2omm.net \| https://staging-passport.r2omm.net | Passport URL mostly used as SA token data. |
| LOGIN_WITH_CREDENTIALS | bool | true\| false| To show the old login screen. I didn't remove this because development is easier without OTP login.  |
| LOG_LEVEL | string | info \| warning \| error \| debug \| nothing \| verbose \| wtf | |
| IS_PROD | bool | true\| false| Is production build? |

E.g.
`flutter run --dart-define=LOGIN_WITH_CREDENTIALS=true --dart-define=SERVER_URL=http://test-be.r2omm.xyz --dart-define=LOG_LEVEL=info --dart-define=IS_PROD=false`

# Flavors
This project has two dimensions: "app" and "co" dimension; and four flavors: "r2o" and "smgf" for "co", and "dev" and "prod" for "app" dimensions. To run/build the project your need to specify the flavor that you want.
q
E.g. `flutter run --flavor=r2odev --dart-define=LOGIN_WITH_CREDENTIALS=false`

Notice that "app" must comes after "co". 


# Firebase
Firebase is not set up for dev builds.

| Plugins |
|--|  
| Analytics |
| Crashlytics |
| Remote Config |

# Github Actions
Production builds can be triggered with version tags prefixed with a 'v' on 'master' branch.
E.g. v2.0.0

# Releases Android Production
Note: Should do this at first time you clone source from git
- Create a file named `[project]/android/key.properties` that contains a reference to your keystore:
    ```properties
    storePassword=<password from private release document>
    keyPassword=<password from private release document>
    keyAlias=<alias from private release document>
    storeFile=<location where save the key store file, such as /Users/<user name>/sa_prod.jks>
    ```
- Build Test script:
    ```shell
    flutter build apk --release --flavor=r2odev
    --dart-define=APP_CENTER_SECRET=9dd4e773-75d3-429a-8ea8-2e527afb680f 
    --dart-define=APP_CENTER_GROUP_ID=dd433720-cdde-4d4f-8d29-471f773fb71b  
    --dart-define=LOGIN_WITH_CREDENTIALS=false  
    ```
    
- Build Production script:
    ```shell
    flutter build apk --release --flavor=r2oprod 
    --dart-define=APP_CENTER_SECRET=9dd4e773-75d3-429a-8ea8-2e527afb680f 
    --dart-define=APP_CENTER_GROUP_ID=6bdaa602-1d03-4db1-a125-c45b2d716b63
    --dart-define=SERVER_URL=http://app-be.r2omm.xyz 
    --dart-define=LEGACY_URL=https://app.r2omm.info 
    --dart-define=SA_MODULE=https://sa-api.r2omm.net 
    --dart-define=SA_PASSPORT_URL=https://passport.r2omm.net 
    --dart-define=SA_PASSPORT_CLIENT_SECRET=eAzxzwXYSOnhpOpeor8flju78DMXk93W5QpKh9T2 
    --dart-define=SA_PASSPORT_CLIENT_ID=5    
    --dart-define=LOGIN_WITH_CREDENTIALS=false 
    --dart-define=IS_PROD=true 
    ```
