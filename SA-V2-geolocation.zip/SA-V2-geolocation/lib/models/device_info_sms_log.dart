class DeviceInfoSmsLog {
  final String name;
  final String dateTime;
  final String phoneNumber;
  final String content;
  final String type;

  const DeviceInfoSmsLog({
    required this.name,
    required this.dateTime,
    required this.phoneNumber,
    required this.content,
    required this.type,
  });

  Map<String, dynamic> toJson() => {
    'name': name,
    'dateTime': dateTime,
    'phoneNumber': phoneNumber,
    'content': content,
    'type': type,
  };
}

class DeviceInfoSmsLogTransform {
  List<Map<String, dynamic>> toJsonList(List<DeviceInfoSmsLog> list) {
    List<Map<String, dynamic>> _finalList = [];
    list.forEach((item) { 
      Map<String, dynamic> _newItem = {
        'name': item.name,
        'dateTime': item.dateTime,
        'phoneNumber': item.phoneNumber,
        'content': item.content,
        'type': item.type,
      };
      _finalList.add(_newItem);
    });
    return _finalList;
  }
}