
import 'package:freezed_annotation/freezed_annotation.dart';

part 'work_scaffold_state.freezed.dart';

@freezed
class WorkScaffoldState<T extends WorkScaffoldData> with _$WorkScaffoldState {
  factory WorkScaffoldState.idle(T data) = WorkScaffoldStateIdle<T>;

  factory WorkScaffoldState.busy() = WorkScaffoldStateBusy;

  factory WorkScaffoldState.error(String msg) = WorkScaffoldStateError;
}

abstract class WorkScaffoldData {}
