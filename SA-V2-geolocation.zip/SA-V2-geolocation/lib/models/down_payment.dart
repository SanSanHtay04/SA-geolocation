import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/data/remote/models/models.dart';

part 'down_payment.freezed.dart';

@freezed
class ZeroCostData with _$ZeroCostData {
  const ZeroCostData._();

  const factory ZeroCostData({
    num? zeroCostPmtTimes,
    num? zeroCostMonthlyPaymentAmount,
    num? zeroCostTotalInsCost,
    num? zeroCostTotalMaintCost,
  }) = _ZeroCostData;
}

@freezed
class DownPayment with _$DownPayment {
  const DownPayment._();

  const factory DownPayment({
    required num depositPercentage,
    required num depositAmount,
    required num adminFee,
    ZeroCostData? zeroCost,
    @Default([]) List<SimulationModel> tenures,
  }) = _DownPayment;

  String get depositeAmountText => ((((depositAmount + adminFee) / 1000).ceil()) * 1000).currencyFormat();

  @override
  String toString() => '$depositPercentage% ( $depositeAmountText )';
}
