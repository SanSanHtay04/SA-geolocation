class DeviceInfoDevice {
  final String? deviceModel;
  final String? deviceBrand;
  final String? deviceName;
  final String? softwareId;
  final String? operationSystemVersion;


  const DeviceInfoDevice({
    required this.deviceModel,
    required this.deviceBrand,
    required this.deviceName,
    required this.softwareId,
    required this.operationSystemVersion,
  });

  Map<String, dynamic> toJson() => {
    'deviceModel': deviceModel,
    'deviceBrand': deviceBrand,
    'deviceName': deviceName,
    'softwareId': softwareId,
    'operationSystemVersion': operationSystemVersion
  };
}

class DeviceInfoDeviceTransform {
  List<Map<String, dynamic>> toJsonList(List<DeviceInfoDevice> list) {
    List<Map<String, dynamic>> _finalList = [];
    list.forEach((item) { 
      Map<String, dynamic> _newItem = {
        'deviceModel': item.deviceModel,
        'deviceBrand': item.deviceBrand,
        'deviceName': item.deviceName,
        'operationSystemVersion': item.operationSystemVersion,
      };
      _finalList.add(_newItem);
    });
    return _finalList;
  }
}