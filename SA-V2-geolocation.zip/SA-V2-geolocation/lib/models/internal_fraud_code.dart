import 'package:flutter/widgets.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

enum InternalFraudCode {
  @JsonValue('APP_010')
  app_010,
  @JsonValue('APP_021')
  app_021,
  @JsonValue('APP_022')
  app_022,
  @JsonValue('APP_023')
  app_023,
  @JsonValue('APP_024')
  app_024,
  @JsonValue('APP_025')
  app_025,
  @JsonValue('APP_026')
  app_026,
  @JsonValue('APP_027')
  app_027,
  @JsonValue('APP_000')
  app_000,
}

extension InternalCodeX on InternalFraudCode {
  String getName(BuildContext context) {
    switch (this) {
      case InternalFraudCode.app_000:
        return 'APP_000';
      case InternalFraudCode.app_010:
        return 'APP_010';
      case InternalFraudCode.app_021:
        return 'APP_021';
      case InternalFraudCode.app_022:
        return 'APP_022';
      case InternalFraudCode.app_023:
        return 'APP_023';
      case InternalFraudCode.app_024:
        return 'APP_024';
      case InternalFraudCode.app_025:
        return 'APP_025';
      case InternalFraudCode.app_026:
        return 'APP_026';
      case InternalFraudCode.app_027:
        return 'APP_027';
    }
  }
}
