class DeviceInfoLiveLocation {
  final String latitude;
  final String? longitude;


  const DeviceInfoLiveLocation({
    required this.latitude,
    required this.longitude,
  });

  Map<String, dynamic> toJson() => {
    'latitude': latitude,
    'longitude': longitude
  };
}

class DeviceInfoLiveLocationTransform {
  List<Map<String, dynamic>> toJsonList(List<DeviceInfoLiveLocation> list) {
    List<Map<String, dynamic>> _finalList = [];
    list.forEach((item) { 
      Map<String, dynamic> _newItem = {
        'latitude': item.latitude,
        'longitude': item.longitude,
      };
      _finalList.add(_newItem);
    });
    return _finalList;
  }
}