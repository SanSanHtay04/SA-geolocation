import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/models/models.dart';

import '../screens/origination/prospects/create_prospect/presentation/notifiers/form/prospect_form_state.dart';

part 'prospect.freezed.dart';

@freezed
class Prospect with _$Prospect {
  Prospect._();

  factory Prospect({
    int? posId,
    int? prospectId,
    String? name,
    GenderType? gender,
    String? mobile,
    String? otherMobile,
    String? remark,
  }) = _Prospect;

  ProspectFormState toDomain() => ProspectFormState(
        loaded: true,
        prospectId: prospectId,
        posId: posId,
        name: name,
        gender: gender,
        mobile: mobile,
        otherMobile: otherMobile,
        remark: remark,
      );
}
