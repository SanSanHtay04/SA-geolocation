import 'package:freezed_annotation/freezed_annotation.dart';

part 'otp_data.freezed.dart';

@freezed
class OtpData with _$OtpData {
  factory OtpData({required String token}) = _OtpData;
}
