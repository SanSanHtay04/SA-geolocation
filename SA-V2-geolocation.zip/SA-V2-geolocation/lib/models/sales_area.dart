import 'package:freezed_annotation/freezed_annotation.dart';

part 'sales_area.freezed.dart';

@freezed
class SalesArea with _$SalesArea {
  const factory SalesArea({
    required int id,
    required int regionId,
    required String name,
  }) = _SalesArea;
}
