import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/data/remote/models/responses/auth/account_info_response.dart';

part 'account_info.freezed.dart';

@freezed
class AccountInfo with _$AccountInfo {
  AccountInfo._();

  factory AccountInfo({
    required int userId,
    int? userWorkplaceId,
    String? username,
    String? accessToken,
    String? saAccessToken,
  }) = _AccountInfo;

  static AccountInfo fromResponse(AuthResponse data) {
    var user = data.user;
    return AccountInfo(
      userId: user.userId,
      userWorkplaceId: user.workPlaceId,
      username: user.userName,
      accessToken: data.accessToken,
      saAccessToken: data.saAccessToken,
    );
  }
}
