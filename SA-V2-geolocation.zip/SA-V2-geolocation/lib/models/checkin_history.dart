import 'package:freezed_annotation/freezed_annotation.dart';

part 'checkin_history.freezed.dart';

@freezed
class CheckinHistory with _$CheckinHistory {
  //const CheckinHistory._();

  const factory CheckinHistory({
    @Default([]) List<Checkin> data,
  }) = _CheckinHistory;
}

@freezed
class Checkin with _$Checkin {
  const factory Checkin({
    required int id,
    required int posId,
    required String posName,
    required String type,
    required double lat,
    required double lng,
    required String dateTime,
  }) = _Checkin;
}
