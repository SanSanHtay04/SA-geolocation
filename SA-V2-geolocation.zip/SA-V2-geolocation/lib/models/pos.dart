import 'package:freezed_annotation/freezed_annotation.dart';

import '../data/local/tables/pos_table.dart' as POSTable;
import 'location.dart';

part 'pos.freezed.dart';

@freezed
class POS with _$POS {
  factory POS({
    required int id,
    required String name,
    String? address,
    Location? location,
    String? ph1,
    String? ph2,
    String? posProductType,
    String? posCategory,
    int? isMerchant,
    required int salesAreaId,
  }) = _POS;

  @override
  String toString() {
    return name;
  }

  static POS fromCache(POSTable.POSCache cache) {
    Location? location = null;
    if (cache.latitude != null && cache.longitude != null) {
      if (cache.latitude!.abs() <= 90.0) {
        location = Location(lat: cache.latitude!, lng: cache.longitude!);
      }
      // Number.truncate()
    }
    return POS(
      id: cache.id,
      name: cache.name,
      location: location,
      ph1: cache.ph1,
      ph2: cache.ph2,
      salesAreaId: cache.salesAreaId,
      posProductType: cache.posProductType,
      posCategory: cache.posCategory,
      isMerchant: cache.isMerchant??0 ,
    );
  }
}
