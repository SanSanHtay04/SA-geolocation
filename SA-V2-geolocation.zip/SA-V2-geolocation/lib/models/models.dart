export 'account_info.dart';
export 'competitor.dart';
export 'down_payment.dart';
export 'location.dart';
export 'merchandise.dart';
export 'otp_data.dart';
export 'pos.dart';
export 'product_category.dart';
export 'region.dart';
export 'sales_area.dart';
export 'sales_channel.dart';
export 'tenure_type.dart';


export 'gender_type.dart';
export 'prospect.dart';
export 'address.dart';
export 'checkin_history.dart';
export 'otp_method.dart';
export 'address_type.dart';
export 'phone_type.dart';
export 'internal_fraud_code.dart';
export 'household_number.dart';
