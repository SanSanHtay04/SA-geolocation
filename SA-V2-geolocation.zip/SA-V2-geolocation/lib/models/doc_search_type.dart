import 'package:flutter/cupertino.dart';

enum DocSearchType {
  contract,
  nrc,
}

extension GenderTypeExtensions on DocSearchType {
  int get value => this == DocSearchType.contract ? 0 : 1;

  String getName(BuildContext context) {
    switch (this) {
      case DocSearchType.contract:
        return 'Contract';
      case DocSearchType.nrc:
        return 'NRC';
    }
  }
}

/*

- query is searched string which can be CONTRACT NO or NRC NO
- contractNoOrNRC: search by Contract No or NRC NO (0 - Contract No; 1 - NRC)
*/
