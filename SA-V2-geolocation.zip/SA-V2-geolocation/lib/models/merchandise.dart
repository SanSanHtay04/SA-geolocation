import 'package:freezed_annotation/freezed_annotation.dart';

part "merchandise.freezed.dart";

@freezed
class Merchandise with _$Merchandise {
  factory Merchandise({
    required int id,
    required String name,
    required int limit,
  }) = _Merchandise;

// TODO: rather than manually provided data, need to replace with API depend on the param "productCategoryTypeId"

  static List<Merchandise> getAll() => [
        Merchandise(id: 1, name: "Leaflet", limit: 150),
        Merchandise(id: 2, name: "Vinyl", limit: 1),
        Merchandise(id: 6, name: "Tent Card", limit: 5),
        Merchandise(id: 8, name: "Leaflet Stand", limit: 1),
        Merchandise(id: 9, name: "Vinyl Stand", limit: 1),
      ];
}
