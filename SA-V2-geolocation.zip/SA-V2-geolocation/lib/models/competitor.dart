import 'package:freezed_annotation/freezed_annotation.dart';

part "competitor.freezed.dart";

@freezed
class Competitor with _$Competitor {
  factory Competitor({
    required int id,
    required String competitorName,
  }) = _Competitor;

// TODO : rather than manually supported data, need to request and replace with API.
  static List<Competitor> getAll() => [
        Competitor(id: 7, competitorName: "Cash Down"),
        Competitor(id: 14, competitorName: "Maha Bawga"),
        Competitor(id: 2, competitorName: "MoMo Venture"),
        Competitor(id: 1, competitorName: "GL-AMMK"),
        Competitor(id: 13, competitorName: "BNK"),
        Competitor(id: 10, competitorName: "AEON"),
        Competitor(id: 8, competitorName: "Vendor Credit"),
        Competitor(id: 5, competitorName: "Bank HPs"),
        Competitor(id: 15, competitorName: "AYA pay"),
        // Competitor(id: 3, competitorName: "Daung"),
        // Competitor(id: 4, competitorName: "EFF"),
        // Competitor(id: 11, competitorName: "Others"),
        // Competitor(id: 12, competitorName: "KPay"),
      ];
}
