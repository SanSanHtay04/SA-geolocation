
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:latlong2/latlong.dart';
import 'package:sales/data/remote/models/responses/responses.dart';
import 'package:latlong2/latlong.dart';
import 'package:sales/models/models.dart';

part 'address.freezed.dart';

@freezed
class Address with _$Address {
  const Address._();

  const factory Address({
    @Default(HomeStatus.owned) HomeStatus homeStatus,
    String? address,
    Region? region,
    District? district,
    Township? township,
    @Default(AddressType.urban) AddressType type,
    Town? town,
    Ward? ward,
    Town? villageTract,
    Village? village,
  }) = _Address;

  bool validate() => false;

  bool get isRegion => region?.geoRegionId != null;
  bool get isDistrict => district?.geoDistrictId != null;
  bool get isTownship => township?.geoTownShipId != null;
  bool get isTown => town?.geoTownId != null;
  bool get isWard => ward?.geoWardId != null;
  bool get isVillageTract => villageTract?.geoTownId != null;
  bool get isVillage => village?.geoVillageId != null;

  String get regionText => isRegion ? region?.geoRegionName ?? '' : '';
  String get districtText => isDistrict ? district?.geoDistrictName ?? '' : '';
  String get townshipText => isTownship ? township?.geoTownShipName ?? '' : '';
  String get townText => isTown ? town?.geoTownName ?? '' : '';
  String get wardText => isWard ? ward?.geoWardName ?? '' : '';
  String get villageTractText => isVillageTract ? villageTract?.geoTownName ?? '' : '';
  String get villageText => isVillage ? village?.geoVillageName ?? '' : '';

  String get UrbanTownText => [wardText, townText].join(',');
  String get RuralVillageTractText => [villageText, villageTractText].join(',');

  String get WardVillageText => (type == AddressType.urban) ? UrbanTownText : RuralVillageTractText;

  @override
  String toString() {
    return [WardVillageText, townshipText, districtText, regionText].join(',');
  }
}

extension AddressX on Address {
  LatLng? getLatlng() {
    LatLng? location;
    location = (type == AddressType.urban)
        ? (isWard && (ward?.isValidLocation ?? false))
        ? ward?.latLng
        : town?.latLng
        : (isVillage && (village?.isValidLocation ?? false))
        ? village?.latLng
        : villageTract?.latLng;

    location = location ??
        ((isTownship && (township?.isValidLocation ?? false))
            ? township?.latLng
            : (isDistrict && (district?.isValidLocation ?? false))
            ? district?.latLng
            : region?.latLng);
    return location;
  }

  String? getAddressName() {
    String? locName;
    locName = (type == AddressType.urban)
        ? (isWard && (ward?.isValidLocation ?? false))
        ? ward.toString()
        : (isTown && (town?.isValidLocation ?? false))
        ? township.toString()
        : null
        : (isVillage && (village?.isValidLocation ?? false))
        ? village?.toString()
        : (isVillageTract && (villageTract?.isValidLocation ?? false))
        ? villageTract.toString()
        : null;

    locName = locName ??
        ((isTownship && (township?.isValidLocation ?? false))
            ? township.toString()
            : (isDistrict && (district?.isValidLocation ?? false))
            ? district.toString()
            : region.toString());
    return locName;
  }
}
