import 'package:flutter/material.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

enum PhoneType {
  @JsonValue('mobile')
  mobile,
  @JsonValue('fixed')
  fixed;
}

extension PhoneTypeX on PhoneType {
  String getName(BuildContext context) {
    switch (this) {
      case PhoneType.mobile:
        return 'Mobile';
      case PhoneType.fixed:
        return 'Fixed Phone';
    }
  }
}

enum PhoneStatus {
  @JsonValue('correct')
  correct,
  @JsonValue('wrong')
  wrong,
  @JsonValue('sensitive')
  sensitive,
  @JsonValue('no-carrier')
  no_carrier,
  @JsonValue('no-rpc')
  no_rpc,
}

extension PhoneStatusX on PhoneStatus {
  String getName(BuildContext context) {
    switch (this) {
      case PhoneStatus.correct:
        return 'Correct';
      case PhoneStatus.wrong:
        return 'Wrong';
      case PhoneStatus.sensitive:
        return 'Sensitive';
      case PhoneStatus.no_carrier:
        return 'No-Carrier';
        case PhoneStatus.no_rpc:
        return 'No-RightPersonContact';
    }
  }
}
