import 'package:flutter/widgets.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

enum TenureType {
  @JsonValue('m')
  monthly,
  @JsonValue('q')
  quarterly;
}

extension TenureTypeX on TenureType {
  String getName(BuildContext context) {
    switch (this) {
      case TenureType.monthly:
        return 'MONTHLY';
      case TenureType.quarterly:
        return 'QUARTERLY';
    }
  }
}
