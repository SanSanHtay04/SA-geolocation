

enum OtpMethod {
  email,
  sms,
}

extension OtpMethodX on OtpMethod {
  String getName() {
    switch (this) {
      case OtpMethod.email:
        return 'Email';
      case OtpMethod.sms:
        return 'Sms';
    }
  }
}


enum LoginType {
  ONLINE,
  OFFLINE,
}
