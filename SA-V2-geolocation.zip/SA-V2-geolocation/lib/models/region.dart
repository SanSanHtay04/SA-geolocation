import 'package:freezed_annotation/freezed_annotation.dart';

part 'region.freezed.dart';

@freezed
class SalesRegion with _$SalesRegion {
  const factory SalesRegion({
    required int id,
    required String name,
  }) = _SalesRegion;
}
