import 'package:freezed_annotation/freezed_annotation.dart';

part 'household_number.freezed.dart';

part 'household_number.g.dart';

@freezed
class HouseholdNumber with _$HouseholdNumber {
  const HouseholdNumber._();

  const factory HouseholdNumber({
    @Default(0) int children,
    @Default(0) int relative,
    @Default(0) int other,
    // @Default(1) String totalHousehold,
  }) = _HouseholdNumber;

  factory HouseholdNumber.fromJson(Map<String, dynamic> json) =>
      _$HouseholdNumberFromJson(json);

  int get totalHouseHold => (children + relative + other + 1);

  String get totalHouseholdText => '$totalHouseHold';

  String get childrenText => '$children';

  String get relativeText => '$relative';

  String get otherText => '$other';
}
