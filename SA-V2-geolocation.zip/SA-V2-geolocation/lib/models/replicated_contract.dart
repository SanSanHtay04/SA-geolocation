import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/utils/utils.dart';

part 'replicated_contract.freezed.dart';
part 'replicated_contract.g.dart';

@freezed
class ReplicatedContract with _$ReplicatedContract {
  const ReplicatedContract._();
  factory ReplicatedContract({
    required int prospectId,
    required int customerId,
    required int contractId,
    required int applicationId,
    required String customerFullName,
    ContractInfo? contract,
    ProductInfo? product,
    @Default(false) bool canDuplicated,
    @Default('') String duplicatedReason,
  }) = _ReplicatedContract;

  factory ReplicatedContract.fromJson(Map<String, dynamic> json) => _$ReplicatedContractFromJson(json);

  String get priceText => product?.unitPrice.currencyFormat() ?? '';
  String get amountFinancedText => product?.amountFinanced?.currencyFormat() ?? '';
  String get installmentText => product?.followingPayment?.currencyFormat() ?? '';

  String get contractDateText => ' ${contract?.contractDate?.format()}';
  String get expiryDateText => '${contract?.expiryDate?.format()} ';
  String get terminationDateText => '${contract?.terminationDate?.format()}';

  num get duration => product?.duration ?? 0;
  String get durationText {
    if (duration > 1)
      return '$duration months';
    else
      return '$duration month';
  }
  
}

@freezed
class ContractInfo with _$ContractInfo {
  ContractInfo._();
  factory ContractInfo({
    @Default('') String number,
    @Default('') String type,
    int? statusId,
    String? statusName,
    DateTime? contractDate,
    DateTime? expiryDate,
    DateTime? terminationDate,
  }) = _ContractInfo;

  factory ContractInfo.fromJson(Map<String, dynamic> json) => _$ContractInfoFromJson(json);
}

@freezed
class ProductInfo with _$ProductInfo {
  ProductInfo._();
  factory ProductInfo({
    @Default('') String name,
    int? categoryId,
    String? categoryName,
    num? unitPrice,
    num? amountFinanced,
    num? followingPayment,
    int? duration,
  }) = _ProductInfo;

  factory ProductInfo.fromJson(Map<String, dynamic> json) => _$ProductInfoFromJson(json);
}
