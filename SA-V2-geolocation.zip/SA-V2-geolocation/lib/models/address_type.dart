import 'package:flutter/material.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

enum AddressType {
  urban,
  rural;
}

extension AddressTypeX on AddressType {
  String getName(BuildContext context) {
    switch (this) {
      case AddressType.urban:
        return 'Urban (Town)';
      case AddressType.rural:
        return 'Rural (VT)';
    }
  }
}

enum HomeStatus {
  @JsonValue('owned')
  owned,
  @JsonValue('rented')
  rented,
  @JsonValue('hosted')
  hosted,
}

extension HomeStatusX on HomeStatus {
  String getName(BuildContext context) {
    switch (this) {
      case HomeStatus.owned:
        return 'Owned';
      case HomeStatus.rented:
        return 'Rented';
      case HomeStatus.hosted:
        return 'Hosted';
    }
  }
}
