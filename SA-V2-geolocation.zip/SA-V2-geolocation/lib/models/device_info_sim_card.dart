class DeviceInfoSimCard {
  final String? simCardNo1;
  final String? simCardNo2;


  const DeviceInfoSimCard({
    required this.simCardNo1,
    required this.simCardNo2, 
  });

  Map<String, dynamic> toJson() => {
    'simCardNo1': simCardNo1,
    'simCardNo2': simCardNo2,
  };
}

class DeviceInfoSimCardTransform {
  List<Map<String, dynamic>> toJsonList(List<DeviceInfoSimCard> list) {
    List<Map<String, dynamic>> _finalList = [];
    list.forEach((item) { 
      Map<String, dynamic> _newItem = {
        'simCardNo1': item.simCardNo1,
        'simCardNo2': item.simCardNo2,
      };
      _finalList.add(_newItem);
    });
    return _finalList;
  }
}