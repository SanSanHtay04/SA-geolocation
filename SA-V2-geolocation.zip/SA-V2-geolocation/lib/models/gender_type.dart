import 'package:flutter/widgets.dart';
import 'package:json_annotation/json_annotation.dart';

enum GenderType {
  @JsonValue('m')
  male,
  @JsonValue('f')
  female,
}

extension GenderTypeExtensions on GenderType {
  String get value => this == GenderType.male ? "m" : "f";

   String getName(BuildContext context) {
    switch (this) {
      case GenderType.male:
        return 'Male';
      case GenderType.female:
        return 'Female';
    }
  }
}