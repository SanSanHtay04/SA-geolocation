import 'package:freezed_annotation/freezed_annotation.dart';

part 'sales_channel.freezed.dart';

@freezed
class SalesChannel with _$SalesChannel {
  const factory SalesChannel({
    required int id,
    required String name,
  }) = _SalesChannel;
}
