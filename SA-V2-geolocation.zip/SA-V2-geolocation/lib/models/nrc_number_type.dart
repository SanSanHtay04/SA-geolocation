import 'package:json_annotation/json_annotation.dart';


//'no_nrc', 'nrc', 'non_nrc'
enum NRCNumberType {
   @JsonValue('no_nrc')
  noNrc,
   @JsonValue('nrc')
  nrc,
   @JsonValue('non_nrc')
  frc;
}

extension NRCNumberTypeX on NRCNumberType {
  String getName() {
    switch (this) {
      case NRCNumberType.noNrc:
        return 'No Nrc';
      case NRCNumberType.nrc:
        return 'NRC';
      case NRCNumberType.frc:
        return 'FCR/NVC';
    }
  }
}