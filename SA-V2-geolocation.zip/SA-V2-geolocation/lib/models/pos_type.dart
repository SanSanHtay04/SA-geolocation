import 'package:flutter/widgets.dart';
import 'package:json_annotation/json_annotation.dart';

enum POSType {
  @JsonValue('SA')
  sa,
  @JsonValue('Merchant')
  merchant,
}

extension POSTypeX on POSType {
  String getName(BuildContext context) {
    switch (this) {
      case POSType.merchant:
        return 'Merchant';
      case POSType.sa:
        return 'SA/LSL';
    }
  }
}
