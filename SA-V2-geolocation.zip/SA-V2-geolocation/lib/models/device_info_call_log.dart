class DeviceInfoCallLog {
  final String name;
  final String dateTime;
  final String phoneNumber;
  final int duration;
  final String type;
  final String simDisplayName;


  const DeviceInfoCallLog({
    required this.name,
    required this.dateTime,
    required this.phoneNumber,
    required this.duration,
    required this.type, 
    required this.simDisplayName,
  });

  Map<String, dynamic> toJson() => {
    'name': name,
    'dateTime': dateTime,
    'phoneNumber': phoneNumber,
    'duration': duration,
    'type': type,
    'simDisplayName': simDisplayName,
  };
}

class DeviceInfoCallLogTransform {
  List<Map<String, dynamic>> toJsonList(List<DeviceInfoCallLog> list) {
    List<Map<String, dynamic>> _finalList = [];
    list.forEach((item) { 
      Map<String, dynamic> _newItem = {
        'name': item.name,
        'dateTime': item.dateTime,
        'phoneNumber': item.phoneNumber,
        'duration': item.duration,
        'type': item.type,
        'simDisplayName': item.simDisplayName,
      };
      _finalList.add(_newItem);
    });
    return _finalList;
  }
}