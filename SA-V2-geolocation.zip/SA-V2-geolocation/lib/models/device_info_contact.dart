class DeviceInfoContact {
  final String? name;
  final String? phoneNumber;
  final String? email; 


  const DeviceInfoContact({
    required this.name,
    required this.phoneNumber,
    required this.email,
  });

  Map<String, dynamic> toJson() => {
    'name': name,
    'phoneNumber': phoneNumber,
    'email': email,
  };
}

class DeviceInfoContactTransform {
  List<Map<String, dynamic>> toJsonList(List<DeviceInfoContact> list) {
    List<Map<String, dynamic>> _finalList = [];
    list.forEach((item) { 
      Map<String, dynamic> _newItem = {
        'name': item.name,
        'phoneNumber': item.phoneNumber,
        'email': item.email,
      };
      _finalList.add(_newItem);
    });
    return _finalList;
  }
}