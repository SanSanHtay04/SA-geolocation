import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';
import 'package:sales/screens/app_processing/app_processing_screen.dart';
import 'package:sales/screens/change_password/presentation/change_password_screen.dart';

import 'package:sales/screens/notification/fcm_notifications_screen.dart';
import 'package:sales/screens/origination/counter_proposal/counter_proposals_screen.dart';
import 'package:sales/screens/others/merchandise_request/presentation/merchandise_request_screen.dart';

import 'package:sales/screens/result/attached_product_detail/edit_attached_product_detail_screen.dart';
import 'package:sales/screens/result/contract/edit_contract_screen.dart';
import 'package:sales/screens/result/results_screen.dart';
import 'package:sales/utils/utils.dart';
import 'configs.dart';
import 'screens/choose_current_pos_screen.dart';

import 'screens/data_sync_screen.dart';
import 'screens/auth/login/login_screen.dart';
import 'screens/auth/otp_login/otp_login_screen.dart';
import 'screens/origination/prospects/create_prospect/presentation/prospect_screen.dart';
import 'screens/origination/prospects/customer/customer_screen.dart';
import 'screens/origination/prospects/customer_contact/edit_cust_contact_screen.dart';
import 'screens/origination/prospects/product/choose_product_screen.dart';
import 'screens/origination/prospects/prospect_info_screen.dart';
import 'screens/origination/prospects/prospects_screen.dart';
import 'screens/origination/prospects/simulation/choose_simulation_screen.dart';
import 'screens/others/checkup/presentation/checkup_screen.dart';
import 'screens/others/competitor_report/presentation/competitor_report_screen.dart';

import 'screens/others/contract_search/presentation/contract_search_screen.dart';

import 'screens/others/settings/settings_screen.dart';
import 'screens/shared/shared_screen.dart';
import 'screens/start/start_screen.dart';
import 'screens/start/start_viewmodel.dart';

class OthersBottomTab {
  OthersBottomTab._();
  static const String root = "/others";
  static const String competitorReport = "/others/competitor_report";
  static const String merchandiseRequest = "/others/merchandise_request";
  static const String contractDocsSearch = "/others/search_contract_doc";
  static const String imageUpload = "/others/image_upload";
  static const String settings = "/others/settings";

  static final Map<String, WidgetBuilder> routes = {
    settings: (_) => SettingsScreen.create(),
    competitorReport: (_) => CompetitorReportScreen.create(),
    contractDocsSearch: (_) => ContractSearchScreen.create(),
    imageUpload: (_) => CheckupScreen.create(),
    merchandiseRequest: (_) => MerchandiseRequestScreen.create(),
  };
}

class AcquisitionBottomTab {
  AcquisitionBottomTab._();

  static const String root = "/acquisition";
  static final Map<String, WidgetBuilder> routes = {};
}

class POSCheckinBottomTab {
  POSCheckinBottomTab._();

  static const String root = "/check-in";
  static final Map<String, WidgetBuilder> routes = {};
}

// TODO: we need to re-config  the origination routes to support deep-link,
// it won't be structured now, happy coding!
// the bigger project, the more complicated routes
class OriginationBottomTab {
  OriginationBottomTab._();

  static const String root = "/origination";
  static const String pos = "/origination/pos";
  static const String prospects = "/origination/prospects";
  static const String counerProposals = "/origination/counter_proposals";
  static const String results = "/origination/results";
  static const String appProcessings = "/origination/submitted_applications";
  static const String notifications = "/origination/fcm_notifications";
  static const String dataSync = "/origination/data-sync";

  static final Map<String, WidgetBuilder> routes = {
    pos: (ctx) => ChooseCurrentPosScreen(connectionType: null),
    prospects: (ctx) => ProspectsScreen(
          connectionType: null,
          userId: null,
          currentPosId: null,
          userWorkPlaceId: null,
        ),
    counerProposals: (ctx) => CounterProposalsScreen(
          connectionType: null,
          userId: null,
          currentPosId: null,
          userWorkPlaceId: null,
        ),
    results: (ctx) => ResultsScreen(),
    appProcessings: (ctx) => AppProcessingScreen(),
    notifications: (ctx) => FcmNotificationsScreen(),
    dataSync: (ctx) => DataSyncScreen(connectionType: null),
    ProspectScreen.routeName: (ctx) => ProspectScreen.create(
          posId: null,
          prospectId: null,
        ),
    CustomerScreen.routeName: (ctx) => CustomerScreen.create(prospect: {}),
    ProspectInfoScreen.routeName: (ctx) => ProspectInfoScreen(
          prospectId: null,
          currentPosId: null,
          userId: null,
          userWorkPlaceId: null,
          connectionType: null,
          applicationType: null,
        ),
    ChooseProductScreen.routeName: (ctx) => ChooseProductScreen(
          prospectId: null,
          prospectPosId: null,
          connectionType: null,
        ),
    ChooseSimulationScreen.routeName: (ctx) => ChooseSimulationScreen(
          prospectId: null,
          packageId: null,
        ),
    EditContractScreen.routeName: (ctx) => EditContractScreen(
          customerId: null,
          contractId: null,
          application: null,
        ),
    EditCustContactScreen.routeName: (ctx) => EditCustContactScreen(
          customerId: null,
          contactDetId: null,
          userId: null,
          connectionType: null,
        ),
    EditAttachedProductDetailScreen.routeName: (ctx) => EditAttachedProductDetailScreen(
          attachedProductId: null,
          attachedProductDetailId: null,
        ),
    DataSyncScreen.routeName: (ctx) => DataSyncScreen(connectionType: null),
  };
}

Map<String, WidgetBuilder> routes = {
  "/starter": (_) => ChangeNotifierProvider(
        create: (context) => StartViewModel(UpdatesChecker(context.read())),
        child: StartScreen(),
      ),
  "/login": (_) => Configs.loginWithCredential ? LoginScreen() : OTPLoginScreen(),
  // '/otp_verification' :(_) => OTPVerificationScreen(),
  SharedScreen.routeName: (_) => const SharedScreen(),
  ChangePasswordScreen.routeName: (ctx) => ChangePasswordScreen.create(),
}
  ..addAll(OriginationBottomTab.routes)
  ..addAll(OthersBottomTab.routes)
  ..addAll(AcquisitionBottomTab.routes);
