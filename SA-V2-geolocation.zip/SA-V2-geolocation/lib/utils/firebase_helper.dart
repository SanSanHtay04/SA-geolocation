import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_remote_config/firebase_remote_config.dart';

import '../configs.dart';
import '../firebase_options.dart';
import 'updates_checker.dart';

final remoteConfig = FirebaseRemoteConfig.instance;

class FirebaseHelper {
  static Future<void> init() async {
    if (Configs.isProd) {
      await Firebase.initializeApp(
        options: DefaultFirebaseOptions.currentPlatform,
      );
      // await setupRC();
    }
  }

  static Future<void> setupRC() async {
    await remoteConfig.setConfigSettings(RemoteConfigSettings(
      fetchTimeout: const Duration(minutes: 1),
      minimumFetchInterval: const Duration(seconds: 12),
    ));
    await remoteConfig.setDefaults(const {
      UpdatesChecker.MIN_VERSION: "2.0.0",
      UpdatesChecker.CURRENT_VERSION: "2.0.0",
      UpdatesChecker.DOWNLOAD_URL: ""
    });
    await remoteConfig.fetchAndActivate();
  }
}
