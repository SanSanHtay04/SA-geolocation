import 'package:package_info_plus/package_info_plus.dart';
import 'package:sales/configs.dart';
import 'package:sales/data/local/prefs_store.dart';
import 'package:sales/data/remote/api_client.dart';
import 'package:sales/data/remote/api_response.dart';
import 'package:sales/data/remote/models/responses/app_version_response.dart';
import 'package:version/version.dart';

import 'logging.dart';

enum Update { Optional, Mandatory, None }

class UpdatesChecker {
  static const MIN_VERSION = "min_version";
  static const CURRENT_VERSION = "current_version";
  static const DOWNLOAD_URL = "download_url";

  static const appSecret = String.fromEnvironment('APP_CENTER_SECRET');
  static const groupId = String.fromEnvironment('APP_CENTER_GROUP_ID');
  static const GET_LATEST_VERSION_API = '${Configs.baseUrl}/system/applist/7';

  // String get minVersion => remoteConfig.getString(MIN_VERSION);
  //
  // String get currentVersion => remoteConfig.getString(CURRENT_VERSION);
  //
  // String get downloadUrl => remoteConfig.getString(DOWNLOAD_URL);

  late String _downloadUrl;
  late String _latestVersion;

  String get downloadUrl => _downloadUrl ?? '';
  String get latestVersion => _latestVersion ?? '';

  late PrefsStore _prefsStore;

  UpdatesChecker(PrefsStore prefsStore) {
    _prefsStore = prefsStore;
  }

  Future<Update> checkForUpdates() async {
    final packageInfo = await PackageInfo.fromPlatform();
    final latestVersionData = await _getLatestVersion();
    // final skippedVersion = _prefsStore.skippedVersion;
    _downloadUrl = latestVersionData.appDownloadLink;
    _latestVersion = latestVersionData.appVersion.replaceAll('-test', '');

    final appVersion = Version.parse(
      packageInfo.version.replaceAll('-test', ''),
    );
    final latestVersion = Version.parse(_latestVersion);

    AppLogger.i('''
    Current version: ${appVersion}(${packageInfo.buildNumber}),
    Latest version: ${_latestVersion},
    Download URL: ${_downloadUrl},
    ''');

    if (latestVersion > appVersion) {
      if (latestVersionData.updateRequired != 1) {
        return Update.Optional;
      }
      return Update.Mandatory;
    } else {
      return Update.None;
    }
  }

  Future<AppVersionResponse> _getLatestVersion() async {
    final res = await ApiClient.client.get(GET_LATEST_VERSION_API);
    final apiResponse = ApiResponse.fromJson(
      res.data,
      (json) => AppVersionResponse.fromJson(
        (json as Map<String, dynamic>?) ?? {},
      ),
    );
    return apiResponse.data;
  }

  void skipUpdate() {
    _prefsStore.setSkippedVersion(latestVersion);
  }
}
