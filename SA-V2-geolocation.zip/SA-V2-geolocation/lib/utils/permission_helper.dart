import 'package:device_info_plus/device_info_plus.dart';
import 'package:permission_handler/permission_handler.dart';

class PermissionHelper {
  Future<void> requestLocationPermission({
    required Function() onGranted,
    required Future Function() onNotGranted,
  }) async {
    var permission = await Permission.location.status;
    if (!permission.isGranted) {
      permission = await Permission.location.request();
      if (!permission.isGranted) {
        await onNotGranted();
        await requestLocationPermission(onGranted: onGranted, onNotGranted: onNotGranted);
      } else {
        onGranted();
      }
    } else {
      onGranted();
    }
  }

  Future<void> requestContactsPermission({
    required Function() onGranted,
    required Future Function() onNotGranted,
  }) async {
    var permission = await Permission.contacts.status;
    if (!permission.isGranted) {
      permission = await Permission.contacts.request();
      if (!permission.isGranted) {
        await onNotGranted();
        await requestContactsPermission(onGranted: onGranted, onNotGranted: onNotGranted);
      } else {
        onGranted();
      }
    } else {
      onGranted();
    }
  }

  Future<void> requestPhonePermission({
    required Function() onGranted,
    required Future Function() onNotGranted,
  }) async {
    var permission = await Permission.phone.status;
    if (!permission.isGranted) {
      permission = await Permission.phone.request();
      if (!permission.isGranted) {
        await onNotGranted();
        await requestPhonePermission(onGranted: onGranted, onNotGranted: onNotGranted);
      } else {
        onGranted();
      }
    } else {
      onGranted();
    }
  }

  Future<void> requestSMSPermission({
    required Function() onGranted,
    required Future Function() onNotGranted,
  }) async {
    var permission = await Permission.sms.status;
    if (!permission.isGranted) {
      permission = await Permission.sms.request();
      if (!permission.isGranted) {
        await onNotGranted();
        await requestSMSPermission(onGranted: onGranted, onNotGranted: onNotGranted);
      } else {
        onGranted();
      }
    } else {
      onGranted();
    }
  }

  Future<void> requestStoragePermission({
    required Function() onGranted,
    required Future Function() onNotGranted,
  }) async {
    final AndroidDeviceInfo androidInfo = await DeviceInfoPlugin().androidInfo;
    final int androidVersion = int.parse(androidInfo.version.release);

    bool havePermission = false;
     if (androidVersion >= 13) {
        final request = await [
          //Permission.videos,
          Permission.photos,
          //..... as needed
        ].request();

        havePermission = request.values.every((status) => status == PermissionStatus.granted);
      } else {
        final status = await Permission.storage.request();
        havePermission = status.isGranted;
      }

    if (!havePermission) {
      onNotGranted();
     // await requestStoragePermission(onGranted: onGranted, onNotGranted: onNotGranted);
    } else {
      onGranted();
    }
  }

}
