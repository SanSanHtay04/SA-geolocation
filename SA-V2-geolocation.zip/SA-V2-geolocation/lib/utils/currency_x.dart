import 'package:intl/intl.dart';

extension CurrencyX on num? {
  String? simpleCurrencyFormat({bool nullable = false}) {
    if (this == null) return nullable ? null : '0';
    final formatter = NumberFormat.simpleCurrency(name: '', decimalDigits: 0);
    return formatter.format(this);
  }

  String currencyFormat() {
    if (this == null) return '0 MMK';
    final formatter = NumberFormat.currency(name: '', decimalDigits: 0);
    return '${formatter.format(this)} MMK';
  }
}

