export 'currency_x.dart';
export 'datetime_x.dart';
export 'string_x.dart';
export 'logging.dart';
export 'string_x.dart';
export 'location_helper.dart';
export 'firebase_helper.dart';
export 'updates_checker.dart';
export 'pos_x.dart';
export 'http_overrides_x.dart';
export 'custom_date_time_converter.dart';
export 'custom_bool_converter.dart';
export 'bool_x.dart';

import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

saveToFile(anything, filename) async {
  final Directory directory = await getApplicationDocumentsDirectory();
  final File file = File("${directory.path}/$filename.json");
  await file.writeAsString(json.encode(anything));
}

Future<XFile?> takePhoto({
  int? imageQuality,
  ImageSource imageSource = ImageSource.camera,
}) async {
  if (kDebugMode && Platform.isIOS) {
    imageSource = ImageSource.gallery;
  }
  final imageFile = await ImagePicker().pickImage(
    source: imageSource,
    imageQuality: imageQuality ?? 50,
  );
  return imageFile;
}


extension ContextX on BuildContext {
  MediaQueryData getMediaQuery() => MediaQuery.of(this);

  Size getScreenSize() => getMediaQuery().size;

  Orientation getOrientation() => getMediaQuery().orientation;

  ThemeData getTheme() => Theme.of(this);

  ColorScheme getColorScheme() => getTheme().colorScheme;

  TextTheme getTextTheme() => getTheme().textTheme;
}
