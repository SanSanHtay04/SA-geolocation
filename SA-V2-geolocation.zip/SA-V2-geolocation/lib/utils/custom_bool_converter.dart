import 'package:json_annotation/json_annotation.dart';

class CustomBoolConverter implements JsonConverter<bool, int?> {
  const CustomBoolConverter();

  @override
  bool fromJson(int? json) => (json ?? 0) > 0;

  @override
  int toJson(bool json) => json ? 1 : 0;
}
