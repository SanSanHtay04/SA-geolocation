import 'package:flutter/foundation.dart';
import 'package:logger/logger.dart';
import 'package:sales/configs.dart';

final _logLevels = {
  "info": Level.info,
  "warning": Level.warning,
  "error": Level.error,
  "debug": Level.debug,
};

class AppLogger {
  static final _log = Logger(
    printer: PrettyPrinter(
      methodCount: 10,
      errorMethodCount: 20,
      colors: false,
    ),
    level: _logLevels[Configs.logLevel],
  );

  static e(String message, [error, StackTrace? stackTrace]) {
    if (!kDebugMode) {
      // FirebaseCrashlytics.instance.recordError(
      //   message,
      //   stackTrace ?? StackTrace.current,
      //   fatal: false,
      // );
      return;
    }
    _log.e(message, error: error, stackTrace:  stackTrace);
  }

  static i(String message) {
    _log.i(message);
  }

  static d(String message) {
    _log.d(message);
  }

  static w(String message, [error, StackTrace? stackTrace]) {
    if (!kDebugMode) {
      // FirebaseCrashlytics.instance.recordError(
      //   message,
      //   StackTrace.current,
      //   fatal: true,
      // );
      return;
    }
    _log.w(message,error:  error, stackTrace:  stackTrace);
  }
}
