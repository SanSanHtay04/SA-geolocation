
import 'dart:convert';
import 'package:geocoding/geocoding.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

// alternates:
//   Mapbox - mapbox://styles/mapbox/streets-v12?access_token={key}
//   Maptiler - https://api.maptiler.com/maps/outdoor/style.json?key={key}
//   Stadia Maps - https://tiles.stadiamaps.com/styles/outdoors.json?api_key={key}
const MAP_STYLE_URL = "https://tiles.stadiamaps.com/styles/osm_bright.json";
const STADIA_MAPS_API_KEY = "211fc249-f0fa-4704-a510-e731f368488e";

const GOOGLE_API_KEY = 'AIzaSyATgoPrkLX_NdCN1eRT8wSp_KXDdsVCPIA';
class LocationHelper {
  static String generateLocationPreviewImage({double? latitude, double? longitude}) {
    return 'https://maps.googleapis.com/maps/api/staticmap?center=&$latitude,$longitude&zoom=16&size=600x300&maptype=roadmap&markers=color:red%7Clabel:A%7C$latitude,$longitude&key=$GOOGLE_API_KEY';
  }

  static Future<String?> getPlaceAddress(double lat, double lng) async {
    final url = 'https://maps.googleapis.com/maps/api/geocode/json?latlng=$lat,$lng&key=$GOOGLE_API_KEY';
    final response = await http.get(Uri.parse(url));
    final resResults = json.decode(response.body)['results'];
    String? formattedAddress;
    if (resResults.length > 0) {
      formattedAddress = resResults[0]['formatted_address'];
    }

    return formattedAddress;
  }

  static Future<String?> geLocationLog(double lat, double lng) async {
    final url = 'https://maps.googleapis.com/maps/api/geocode/json?latlng=$lat,$lng&key=$GOOGLE_API_KEY';
    final response = await http.get(Uri.parse(url));
    final resResults = json.decode(response.body)['results'];
    String? addressComponents;
    if (resResults.length > 0) {
      addressComponents = json.decode(response.body)['results'][0].toString();
    }

    return addressComponents;
  }

  static void requestPermission({
    required Function() onGranted,
    required Future Function() onNotGranted,
  }) async {
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission != LocationPermission.always) {
      permission = await Geolocator.requestPermission();
      if (permission != LocationPermission.always) {
        await onNotGranted();
        requestPermission(onGranted: onGranted, onNotGranted: onNotGranted);
      } else {
        onGranted();
      }
    } else {
      onGranted();
    }
  }

  static bool isValidLatLang(String? latitude, String? longitude) {
    try {
      if (latitude == null || latitude.isEmpty || longitude == null || longitude.isEmpty) return false;

      final geoLatitude = double.parse(latitude);
      final geoLongitude = double.parse(longitude);

      if (geoLatitude < -90 || geoLatitude > 90 || geoLongitude < -180 || geoLongitude > 180) {
        return false;
      }

      return true;
    } catch (exception) {
      return false;
    }
  }

  static LatLng? parseLatLng(String? latitude, String? longitude) {
    if (isValidLatLang(latitude, longitude)) {
      return LatLng(double.parse(latitude!), double.parse(longitude!));
    }
    return null;
  }
}

extension LatLngX on LatLng? {
  String format() {
    if (this == null) return 'No GeoLocation';
    return '${this!.latitude.toStringAsFixed(6)},${this!.longitude.toStringAsFixed(6)}';
  }
}

extension PlacemarkX on Placemark? {
  String toAddress() {
    if (this == null) return 'No Placemark';
    return '${this!.street},${this!.subAdministrativeArea},${this!.administrativeArea},${this!.name}';
  }
}
