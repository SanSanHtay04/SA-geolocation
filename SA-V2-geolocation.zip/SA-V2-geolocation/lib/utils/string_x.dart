extension StringX on String {
  String getLanguageName() {
    if (startsWith('en') || startsWith('en_')) {
      return 'English';
    }
    if (this == 'my' || this == 'my_MM') {
      return 'မြန်မာဘာသာ (Burmese)';
    }
    return '';
  }

  String capitalize() {
    if (this == '') return '';
    return '${substring(0, 1).toUpperCase()}${substring(1)}';
  }

  bool deepContains(Object? other) => other != null && other is String && toLowerCase().contains(other.toLowerCase());
}

extension StringExtensions on String? {
  bool get isNullOrEmpty => this == null || this!.isEmpty;

  double parseDouble() {
    if (this == null || this!.isEmpty)
      return 0.0;
    else
      return double.parse(this!);
  }


}


