
extension BoolX on bool {
  int get toApiInt => this == true ? 1 : 0;

  String toYesNo() =>
      (this ? 'Yes' : 'No').toUpperCase();
}

extension BoolNullableX on bool? {
  int get toApiInt => this == true ? 1 : 0;

  String toYesNo() =>
      ((!(this ?? true)) ? 'Yes' : 'No')
          .toUpperCase();
}

extension BoolIntX on int? {
  bool get toBool => this == null ? false : this == 1;

  String toYesNo() =>
      (this == 1 ? 'Yes' : 'No').toUpperCase();
}




