
import 'dart:collection';

import 'package:geolocator/geolocator.dart';
import 'package:sales/models/pos.dart';

const int NEARBY_POS_DISTANCE = 50;
List<POS> filterPOS(Position currentPosition, List<POS> posList) {
  final nearPOS = SplayTreeMap<num, POS>();
  for (var pos in posList) {
    if (pos.location != null) {
      final distance = Geolocator.distanceBetween(
        pos.location!.lat,
        pos.location!.lng,
        currentPosition.latitude,
        currentPosition.longitude,
      );
      if (distance <= NEARBY_POS_DISTANCE) {
        nearPOS[distance] = pos;
      }
    }
  }

  return nearPOS.values.toList();
}
