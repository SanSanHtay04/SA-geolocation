
import 'package:intl/intl.dart';

const String DATETIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
const String DATE_FORMAT = "yyyy-MM-dd";

extension DateTimeX on DateTime {
  String format({String formatPattern = 'dd-MM-yyyy'}) {
    final dtf = DateFormat(formatPattern);
    return dtf.format(this);
  }

  String get getDateString => DateFormat(DATE_FORMAT).format(this);

  String get getMyPaymentDateString {
    final DateFormat dateFormat = DateFormat('dd/MM/yyyy');
    return dateFormat.format(this);
  }
}

extension DateTimeIntX on DateTime? {
  String? format({String formatPattern = 'dd-MM-yyyy'}) {
    if (this == null) return null;
    final dtf = DateFormat(formatPattern);
    return dtf.format(this!);
  }

  int daysInDifference(DateTime date) {
    if (this == null) return 0;
    final diff = this!.difference(date);
    return diff.inDays;
  }

  // String getTimeAgo() {
  //   if (this == null) return "";
  //   final difDuration = this!.difference(DateTime.now());
  //   final dateTime = DateTime.now().subtract(difDuration);

  //   AppLogger.i("timeAgo : (${timeago.format(dateTime)})");

  //   return GetTimeAgo.parse(dateTime);
  // }

  bool isToday() {
    if (this == null) return false;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final dateCheck = DateTime(this!.year, this!.month, this!.day);
    return dateCheck == today;
  }
}
