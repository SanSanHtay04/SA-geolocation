import 'dart:async';

import 'package:connectivity/connectivity.dart';

class CheckInternetConnection {
  bool isAvailable = true;

  Future<bool> checkConnectivity() async {
    var connectivityResult = await (Connectivity().checkConnectivity());
    if (connectivityResult == ConnectivityResult.mobile) {
      isAvailable = true;
      print('connectivityResult: I am connected to a mobile network.');
    } else if (connectivityResult == ConnectivityResult.wifi) {
      isAvailable = true;
      print('connectivityResult: I am connected to a wifi network.');
    } else {
      isAvailable = false;
      print('connectivityResult: No internet connection.');
    }
    return isAvailable;
  }
}
