import 'dart:convert';
import 'dart:core';
import 'dart:math';

import 'package:finance/finance.dart';
import 'package:intl/intl.dart';

class CalculateSimulationShared {
  loadSimDataForApp(params) {
    var returnedData = {
      "head": {"m": [], "q": []},
      "simulation": {"m": [], "q": []}
    };

    var paymentAtEnd = params["paymentAtEnd"] != null
        ? int.parse(params["paymentAtEnd"].toString())
        : 0;
    var durMin = params["allowedDurationMin"];
    var durInterval =
        max(1, int.parse(params["allowedDurationInterval"].toString()));
    var durMax = int.parse(params["allowedDurationMax"].toString());
    var pmtPeriodicity = params["allowedPmtPeriodicity"];
    var packageTotalPrice = int.parse(params["packageTotalPrice"].toString());

    for (var dur = durMin; dur <= durMax; dur += durInterval) {
      returnedData["head"]!["m"]!.add({"title": dur}); // push
    }
    var rowDefault = {
      "paymentAtEnd": paymentAtEnd,
      "durMin": durMin,
      "durMax": durMax,
      "durInterval": durInterval,
      "minAmountFinanced": int.parse(params["minAmountFinanced"].toString()),
      "minInstallmentAmount":
          int.parse(params["minInstallmentAmount"].toString()),
      "otpFeePercentage": int.parse(params["otpFeePercentage"].toString()),
      "merchantDiscountRate":
          int.parse(params["merchantDiscountRate"].toString()),
      "pmtPeriodicity": pmtPeriodicity,
      "totalPrice": packageTotalPrice,
      "totalMonthlyMaintCostPerVisit":
          params["totalMonthlyMaintCostPerVisit"] * 1,
      "totalInsFixedCost": int.parse(params["totalInsFixedCost"].toString()),
      "totalInsVariableCostEV": params["totalInsVariableCostEV"] * 1,
      "totalInsVariableCostCV": params["totalInsVariableCostCV"] * 1,
      "totalInsVariableCostAF": params["totalInsVariableCostAF"] * 1,
      "posId": params["posId"],
      "salesAreaId": params["salesAreaId"],
      "productId": params["productId"],
      "assetPrice": packageTotalPrice,
      "insuranceCovered": params["insuranceCovered"],
      "maintenanceCovered": params["maintenanceCovered"],
      "maintSchemeId": params["maintSchemeId"],
      "maintSchemeName": params["maintSchemeName"],
      "costPerVisit": params["costPerVisit"],
      "intervalOfVisit": params["intervalOfVisit"],
      "financialSchemeId": params["financialSchemeId"],
      "financialSchemeName": params["financialSchemeName"],
      "isZeroCost": params["isZeroCost"],
      "zeroCostPmtTimes": params["zeroCostPmtTimes"],
      "productCategoryType": params["productCategoryType"],
    };

    var finSchemeDets = params["fin_scheme_det"];
    for (var item in finSchemeDets) {
      if (item["paymentAtEnd"] == paymentAtEnd) {
        var varItemAmountFinanced = packageTotalPrice *
            (100 - int.parse(item["depositPercentage"].toString())) /
            100;
        if (params["minAmountFinanced"] == 0 ||
            (params["minAmountFinanced"] > 0 &&
                params["minAmountFinanced"] <= varItemAmountFinanced)) {
          var row = _generateSimRowForApp(
              Map<String, dynamic>.from(rowDefault)
                ..addAll({
                  //
                  "dep": item["depositPercentage"],
                  "annualRate": (item["interestRate"]) * 1,
                  "adminFeePercentage": (item["adminFeePercentage"]) * 1,
                  "annualFixedEnvironmentalCost":
                      item["annualFixedEnvironmentalCost"],
                  "tenureExclusion": json.decode(item["tenureExclusion"])
                }),
              1);
          returnedData["simulation"]!["m"]!.add(row);
        }
      }
    }

    if (pmtPeriodicity == 'a' || pmtPeriodicity == 'q') {
      if ((durMin % 3 + durMax % 3) == 0) {
        for (var dur = durMin; dur <= durMax; dur += 3) {
          returnedData["head"]!["q"]!.add({"title": dur});
        }
        for (var item in finSchemeDets) {
          if (item["paymentAtEnd"] == paymentAtEnd) {
            var varItemAmountFinanced = packageTotalPrice *
                (100 - int.parse(item["depositPercentage"].toString())) /
                100;
            if (params["minAmountFinanced"] == 0 ||
                (params["minAmountFinanced"] > 0 &&
                    params["minAmountFinanced"] <= varItemAmountFinanced)) {
              var row = _generateSimRowForApp(
                  Map<String, dynamic>.from(rowDefault)
                    ..addAll({
                      "dep": item["depositPercentage"],
                      "annualRate": (item["interestRate"]) * 1,
                      "adminFeePercentage": (item["adminFeePercentage"]) * 1,
                      "annualFixedEnvironmentalCost":
                          item["annualFixedEnvironmentalCost"],
                      "tenureExclusion": json.decode(item["tenureExclusion"])
                    }),
                  3);
              returnedData["simulation"]!["q"]!.add(row);
            }
          }
        }
      }
    }

    return returnedData;
  }

  _generateSimRowForApp(params, periodicityNum) {
    var pv = params["totalPrice"] * (100 - params["dep"]) / 100;
    var adminFeePercentage = params["adminFeePercentage"];
    var adminFee = (adminFeePercentage / 100) * pv;

    var totalMonthlyInsCost;
    if (params["insuranceCovered"] > 0) {
      if (params["productCategoryType"] == "consumer") {
        totalMonthlyInsCost = params["totalInsFixedCost"] / 12;
      } else {
        totalMonthlyInsCost = (params["totalInsFixedCost"] +
                params["totalInsVariableCostEV"] +
                params["totalInsVariableCostCV"] +
                ((params["totalInsVariableCostAF"] / 100) * pv)) /
            12;
      }
    } else {
      totalMonthlyInsCost = 0;
    }

    var varRentalFeeMaintCostAddUp = params["maintenanceCovered"] > 0
        ? (params["totalMonthlyMaintCostPerVisit"] * periodicityNum)
        : 0;
    var varRentalFeeInsCostAddUp = params["insuranceCovered"] > 0
        ? (totalMonthlyInsCost * periodicityNum)
        : 0;
    var varMonthlyFixedEnvironmentalCost =
        params["annualFixedEnvironmentalCost"] / 12;
    var rentalPaymentAddUp = params["totalMonthlyMaintCostPerVisit"] +
        totalMonthlyInsCost +
        varMonthlyFixedEnvironmentalCost;
    var annualRate = params["annualRate"];
    var rate = (annualRate / 100) / 12;
    var depositAmount = (params["dep"] / 100) * params["totalPrice"];
    var firstPaymentDeposit =
        depositAmount; //(upgrading == 1 ? 0 : depositAmount);

    var merchantDiscountAmount = params["assetPrice"] *
        int.parse(params["merchantDiscountRate"].toString()) /
        100;
    var effectiveAssetPrice = params["assetPrice"] - merchantDiscountAmount;
    var effectiveAmountFinanced = effectiveAssetPrice - depositAmount;

    var totalInsCost;
    if (params["insuranceCovered"] > 0) {
      if (params["productCategoryType"] == "consumer") {
        totalInsCost = params["totalInsFixedCost"];
      } else {
        totalInsCost = params["insuranceCovered"] > 0
            ? ((params["totalInsFixedCost"] +
                params["totalInsVariableCostEV"] +
                params["totalInsVariableCostCV"] +
                ((params["totalInsVariableCostAF"] / 100) * pv)))
            : 0;
      }
    } else {
      totalInsCost = 0;
    }

    var zeroCostTotalInsCost =
        (params["isZeroCost"] > 0 && params["insuranceCovered"] > 0)
            ? (((totalInsCost * params['zeroCostPmtTimes'] / 12) / 100).ceil() *
                100)
            : 0;
    var zeroCostTotalMaintCost =
        (params['isZeroCost'] > 0 && params['maintenanceCovered'] > 0)
            ? (((params['totalMonthlyMaintCostPerVisit'] *
                            params['zeroCostPmtTimes']) /
                        100)
                    .ceil() *
                100)
            : 0;
    var zeroCostMonthlyPaymentAmount = 0;
    if (params["isZeroCost"] > 0) {
      zeroCostMonthlyPaymentAmount = max(
          int.parse((((pv / params['zeroCostPmtTimes']) / 1000).ceil() * 1000)
              .toString()),
          0);
    }

    var now = new DateTime.now();
    var dateFormatter = new DateFormat('yyyy-MM-dd');
    var itemDefault = {
      "prospectId": params["prospectId"],
      "productId": params["productId"],
      "posId": params["posId"],
      "salesAreaId": params["salesAreaId"],
      "simulationDate": dateFormatter.format(now), // current date
      "adminFeePercentage": adminFeePercentage,
      "adminFee": adminFee,
      "minAmountFinanced": params["minAmountFinanced"],
      "minInstallmentAmount": params["minInstallmentAmount"],
      "otpFeePercentage": params["otpFeePercentage"],
      "merchantDiscountRate": params["merchantDiscountRate"],
      "merchantDiscountAmount": merchantDiscountAmount,
      "assetPrice": params["assetPrice"],
      "effectiveAssetPrice": effectiveAssetPrice,
      "depositPercentage": params["dep"],
      "depositAmount": depositAmount,
      "amountFinanced": pv,
      "effectiveAmountFinanced": effectiveAmountFinanced,
      "interestRate": annualRate,
      "rentalFeeMaintCostAddUp": varRentalFeeMaintCostAddUp,
      "rentalFeeInsCostAddUp": varRentalFeeInsCostAddUp,
      "rentalFeeEnvCostAddUp": varMonthlyFixedEnvironmentalCost,
      "paymentAtEnd": params["paymentAtEnd"],
      "insuranceCovered": params["insuranceCovered"],
      "maintenanceCovered": params["maintenanceCovered"],
      "maintSchemeId": params["maintSchemeId"],
      "maintSchemeName": params["maintSchemeName"],
      "costPerVisit": params["costPerVisit"],
      "intervalOfVisit": params["intervalOfVisit"],
      "financialSchemeId": params["financialSchemeId"],
      "financialSchemeName": params["financialSchemeName"],

      "durationMin": params["durMin"],
      "durationMax": params["durMax"],
      "durationInterval": params["durInterval"],
      "totalMonthlyMaintCostPerVisit": params["totalMonthlyMaintCostPerVisit"],
      "totalInsFixedCost": params["totalInsFixedCost"],
      "totalInsVariableCostCV": params["totalInsVariableCostCV"],
      "totalInsVariableCostEV": params["totalInsVariableCostEV"],
      "totalInsVariableCostAF": params["totalInsVariableCostAF"],

      "isZeroCost": params["isZeroCost"],
      "zeroCostPmtTimes": params["zeroCostPmtTimes"],
      "zeroCostMonthlyPaymentAmount":
          params['isZeroCost'] > 0 ? zeroCostMonthlyPaymentAmount : null,
      "zeroCostTotalInsCost": zeroCostTotalInsCost,
      "zeroCostTotalMaintCost": zeroCostTotalMaintCost,
    };
    var row = [];
    if (periodicityNum > 1) {
      for (var dur = params["durMin"]; dur <= params["durMax"]; dur += 3) {
        var pmt = Finance.pmt(rate: rate, nper: dur, pv: pv).abs();
        var effectiveAnnualRate = Finance.rate(
                nper: dur, pmt: -pmt, pv: effectiveAmountFinanced, fv: 0) *
            12 *
            100;
        var followingPayment =
            (((pmt + rentalPaymentAddUp) / 1000).ceil() * 1000) * 3;
        if (params["tenureExclusion"].indexOf(dur) >= 0 ||
            followingPayment < params["minInstallmentAmount"]) {
          row.add({});
        } else {
          var firstPaymentMinusRental =
              ((adminFee + firstPaymentDeposit) / 1000).ceil() * 1000;
          var firstPayment = firstPaymentMinusRental + followingPayment;
          var accFigures = _calcAccFigures(followingPayment, dur, 3);

          row.add(Map<String, dynamic>.from(itemDefault)
            ..addAll({
              "effectiveInterestRate": effectiveAnnualRate,
              "pmtPeriodicity": 'q',
              "duration": dur,
              "followingPayment": followingPayment,
              "netRentalFee": pmt * 3,
              "firstPayment": firstPayment,
              "actualFirstPayment": params["paymentAtEnd"] > 0
                  ? firstPaymentMinusRental
                  : firstPayment,

              // accounting figures
              "accPmtShare": accFigures["accPmtShare"],
              "accPmtMonthlyShare": accFigures["accPmtMonthlyShare"],
              "accMonthlyPaymentAmount": accFigures["accMonthlyPaymentAmount"],
              "accMonthlyLastPaymentAmount":
                  accFigures["accMonthlyLastPaymentAmount"],
              "accPaymentAmount": accFigures["accPaymentAmount"],
              "accLastPaymentAmount": accFigures["accLastPaymentAmount"],
              /////
            }));
        }
      }
      return row;
    } else {
      for (var dur = params["durMin"];
          dur <= params["durMax"];
          dur += params["durInterval"]) {
        var pmt = Finance.pmt(rate: rate, nper: dur, pv: pv).abs();
        var effectiveAnnualRate = Finance.rate(
                nper: dur, pmt: -pmt, pv: effectiveAmountFinanced, fv: 0) *
            12 *
            100;
        var followingPayment =
            ((pmt + rentalPaymentAddUp) / 1000).ceil() * 1000;
        if (params["tenureExclusion"].indexOf(dur) >= 0 ||
            followingPayment < params["minInstallmentAmount"]) {
          row.add({});
        } else {
          var accFigures = _calcAccFigures(followingPayment, dur, 1);
          var firstPaymentMinusRental =
              ((adminFee + firstPaymentDeposit) / 1000).ceil() * 1000;
          var firstPayment = firstPaymentMinusRental + followingPayment;
          row.add(Map<String, dynamic>.from(itemDefault)
            ..addAll({
              "effectiveInterestRate": effectiveAnnualRate,
              "pmtPeriodicity": 'm',
              "duration": dur,
              "followingPayment": followingPayment,
              "netRentalFee": pmt,
              "firstPayment": firstPayment,
              "actualFirstPayment": params["paymentAtEnd"] > 0
                  ? firstPaymentMinusRental
                  : firstPayment,

              // accounting figures
              "accPmtShare": accFigures["accPmtShare"],
              "accPmtMonthlyShare": accFigures["accPmtMonthlyShare"],
              "accMonthlyPaymentAmount": accFigures["accMonthlyPaymentAmount"],
              "accMonthlyLastPaymentAmount":
                  accFigures["accMonthlyLastPaymentAmount"],
              "accPaymentAmount": accFigures["accPaymentAmount"],
              "accLastPaymentAmount": accFigures["accLastPaymentAmount"],
              /////
            }));
        }
      }
      return row;
    }
  }

  _calcAccFigures(followingPayment, duration, periodicity) {
    var totalContractAmount = followingPayment * duration / periodicity;
    var accPmtMonthlyShare = ((1 / duration) * 10000000).round() / 10000000;
    var accMonthlyPaymentAmount =
        (totalContractAmount * accPmtMonthlyShare * 100).round() / 100;
    var accMonthlyLastPaymentAmount =
        ((totalContractAmount - ((duration - 1) * accMonthlyPaymentAmount)) *
                    100)
                .round() /
            100;

    var accPmtShare = periodicity == 3
        ? (((1 / (duration / periodicity)) * 10000000).round() / 10000000)
        : accPmtMonthlyShare;
    var accPaymentAmount = periodicity == 3
        ? ((totalContractAmount * accPmtShare * 100).round() / 100)
        : accMonthlyPaymentAmount;
    var accLastPaymentAmount = periodicity == 3
        ? (((totalContractAmount -
                        ((duration / periodicity - 1) * accPaymentAmount)) *
                    100)
                .round() /
            100)
        : accMonthlyLastPaymentAmount;

    var accFigures = {
      "accPmtShare": accPmtShare,
      "accPmtMonthlyShare": accPmtMonthlyShare,
      "accMonthlyPaymentAmount": accMonthlyPaymentAmount,
      "accMonthlyLastPaymentAmount": accMonthlyLastPaymentAmount,
      "accPaymentAmount": accPaymentAmount,
      "accLastPaymentAmount": accLastPaymentAmount
    };
    return accFigures;
  }

  calcPaymentScheduleForApp(selectedSim, simulationId) {
    print('selectedSim $selectedSim');
    var schedule = [];
    var varDuration = selectedSim["duration"];
    var varPeriodicity = selectedSim["pmtPeriodicity"] == 'm' ? 1 : 3;
    var varMonthlyInterestRate = (selectedSim["interestRate"] / 100) / 12;
    var varEffectiveMonthlyInterestRate =
        (selectedSim["effectiveInterestRate"] / 100) / 12;
    var varNetRentalFee = selectedSim["netRentalFee"];
    var varAmountFinanced = selectedSim["amountFinanced"];
    var varEffectiveAmtFinanced = selectedSim["effectiveAmountFinanced"];
    var varFirstPayment = selectedSim["firstPayment"];
    var varFollowingPayment = selectedSim["followingPayment"];
    var varAccPmtShare =
        selectedSim["accPmtShare"] != null ? selectedSim["accPmtShare"] : 0;
    var fv = 0;
    var type = 0;
    var varPreviousRemainingProductValue = varAmountFinanced;
    var varEffectivePreviousRemainingProductValue = varEffectiveAmtFinanced;
    ////
    var paymentCount = varDuration / varPeriodicity;
    var totalPaymentAmount = varFollowingPayment * paymentCount;
    var accPaymentAmount =
        ((varAccPmtShare * (totalPaymentAmount)) * 100).round() / 100;

    var accLastPaymentAmount =
        ((totalPaymentAmount - accPaymentAmount * (paymentCount - 1)) * 100)
                .round() /
            100;
    var varLockedPeriod = 3;

    var now = new DateTime.now();
    var dateFormatter = new DateFormat('yyyy-MM-dd');

    ////
    if (selectedSim["paymentAtEnd"] > 0) {
      for (var per = varPeriodicity, pmtNo = 1;
          per <= varDuration;
          per += varPeriodicity, pmtNo++) {
        var item = {};
        item["paymentNo"] = pmtNo;
        item["paymentAmount"] =
            (pmtNo == 1) ? varFirstPayment : varFollowingPayment;
        item["totalAmount"] = item["paymentAmount"];
        item["principalPayment"] = 0;
        item["interestPayment"] = 0;
        item["effectivePrincipalPayment"] = 0;
        item["effectiveInterestPayment"] = 0;

        if (per <= varLockedPeriod) {
          item["lockedPeriod"] = 1;
        }
        for (var x = 1; x <= varPeriodicity; x++) {
          var principalPaid = Finance.ppmt(
              rate: varMonthlyInterestRate,
              per: per - varPeriodicity + x,
              nper: varDuration,
              pv: varAmountFinanced);
          varPreviousRemainingProductValue += principalPaid;
          item["principalPayment"] += principalPaid.abs();

          var effectivePrincipalPaid = Finance.ppmt(
              rate: varEffectiveMonthlyInterestRate,
              per: per - varPeriodicity + x,
              nper: varDuration,
              pv: varEffectiveAmtFinanced);
          varEffectivePreviousRemainingProductValue += effectivePrincipalPaid;
          item["effectivePrincipalPayment"] += effectivePrincipalPaid.abs();
        }

        item["remainingProductValue"] = varPreviousRemainingProductValue;
        item["effectiveRemainingProductValue"] =
            varEffectivePreviousRemainingProductValue;
        item["interestPayment"] = varNetRentalFee - item["principalPayment"];
        item["effectiveInterestPayment"] =
            varNetRentalFee - item["effectivePrincipalPayment"];
        item["addedCost"] = selectedSim["rentalFeeInsCostAddUp"] +
            selectedSim["rentalFeeMaintCostAddUp"] +
            selectedSim["rentalFeeEnvCostAddUp"];

        if (per == varDuration) {
          item["lastPayment"] = 1;
          item["otpFeeAmount"] = 0;
          item["otpAmount"] = varFollowingPayment;
        } else {
          item["otpFeeAmount"] = item["effectiveRemainingProductValue"] *
              selectedSim["otpFeePercentage"] /
              100;
          item["otpAmount"] = max(
                  0,
                  int.parse((((item["effectiveRemainingProductValue"] +
                                  item["otpFeeAmount"]) /
                              1000) *
                          1000)
                      .ceil()
                      .toString())) +
              varFollowingPayment;
          // item["otpAmount"] = max(0, int.parse((((item["effectiveRemainingProductValue"] + item["otpFeeAmount"]) / 1000) * 1000)).ceil().toString()) + varFollowingPayment;
          if(selectedSim['isZeroCost'] > 0 && pmtNo <= selectedSim['zeroCostPmtTimes']) {
              item['partialZeroCostOtpAmount'] = max(0, int.parse(((varAmountFinanced / selectedSim['zeroCostPmtTimes']) / 1000).ceil().toString()) * 1000);
          }
        }

        item["dueDate"] =
            dateFormatter.format(DateTime(now.year, now.month + per, now.day));
        item["expiredDate"] = item["dueDate"];
        item["pmtPeriodicity"] = varPeriodicity;
        item["paymentAtEnd"] = selectedSim["paymentAtEnd"];
        item["accPaymentAmount"] = (pmtNo == varDuration / varPeriodicity)
            ? accLastPaymentAmount
            : accPaymentAmount;
        item["simulationId"] = simulationId > 0 ? simulationId : null;

        schedule.add(item);
      }
      return schedule;
    } else {
      for (var per = 1, pmtNo = 1;
          per <= varDuration;
          per += varPeriodicity, pmtNo++) {
        var item = {};
        item["paymentNo"] = pmtNo;
        item["paymentAmount"] =
            (per == 1) ? varFirstPayment : varFollowingPayment;
        item["totalAmount"] = item["paymentAmount"];
        item["principalPayment"] = 0;
        item["interestPayment"] = 0;
        item["effectivePrincipalPayment"] = 0;
        item["effectiveInterestPayment"] = 0;

        item["remainingProductValue"] = varPreviousRemainingProductValue +
            Finance.ppmt(
                rate: varMonthlyInterestRate,
                per: per,
                nper: varDuration,
                pv: varAmountFinanced);
        item["effectiveRemainingProductValue"] =
            varEffectivePreviousRemainingProductValue +
                Finance.ppmt(
                    rate: varEffectiveMonthlyInterestRate,
                    per: per,
                    nper: varDuration,
                    pv: varEffectiveAmtFinanced);

        if (varPeriodicity == 1) {
          item["otpFeeAmount"] = item["effectiveRemainingProductValue"] *
              selectedSim["otpFeePercentage"] /
              100;

          item["otpAmount"] = (((item["effectiveRemainingProductValue"] +
                                  item["otpFeeAmount"]) /
                              1000)
                          .ceil() *
                      1000)
                  .reduce(max) +
              varFollowingPayment;
        } else {
          if ((per + varPeriodicity) >= varDuration) {
            item["otpFeeAmount"] = 0;
            item["otpAmount"] = varFollowingPayment;
          } else {
            item["otpFeeAmount"] = varEffectivePreviousRemainingProductValue *
                selectedSim["otpFeePercentage"] /
                100;
            item["otpAmount"] = (((varEffectivePreviousRemainingProductValue +
                            item["otpFeeAmount"]) /
                        1000)
                    .ceil() *
                1000);
          }
        }
        if (per <= varLockedPeriod) {
          item["lockedPeriod"] = 1;
        }
        if (per + varPeriodicity > varDuration) {
          item["lastPayment"] = 1;
        }

        for (var x = 0; x < varPeriodicity; x++) {
          var principalPaid = Finance.ppmt(
              rate: varMonthlyInterestRate,
              per: per + x,
              nper: varDuration,
              pv: varAmountFinanced);
          varPreviousRemainingProductValue += principalPaid;
          item["principalPayment"] += principalPaid.abs();

          var effectivePrincipalPaid = Finance.ppmt(
              rate: varEffectiveMonthlyInterestRate,
              per: per + x,
              nper: varDuration,
              pv: varEffectiveAmtFinanced);
          varEffectivePreviousRemainingProductValue += effectivePrincipalPaid;
          item["effectivePrincipalPayment"] += effectivePrincipalPaid.abs();
        }

        item["interestPayment"] = varNetRentalFee - item["principalPayment"];
        item["effectiveInterestPayment"] =
            varNetRentalFee - item["effectivePrincipalPayment"];

        item["addedCost"] = selectedSim["rentalFeeInsCostAddUp"] +
            selectedSim["rentalFeeMaintCostAddUp"] +
            selectedSim["rentalFeeEnvCostAddUp"];
        item["dueDate"] = dateFormatter
            .format(DateTime(now.year, now.month + (per - 1), now.day));

        var nextDueDate = dateFormatter
            .format(DateTime(now.year, now.month + varPeriodicity, now.day));
        item["expiredDate"] =
            dateFormatter.format(DateTime(now.year, now.month, now.day - 1));

        item["pmtPeriodicity"] = varPeriodicity;
        item["paymentAtEnd"] = selectedSim["paymentAtEnd"];
        item["accPaymentAmount"] = (pmtNo == varDuration / varPeriodicity)
            ? accLastPaymentAmount
            : accPaymentAmount;

        item["simulationId"] = simulationId > 0 ? simulationId : null;

        schedule.add(item);
      }
      return schedule;
    }
  }
}
