import 'package:flutter/material.dart';

class ConfirmationModalBottomSheet extends StatefulWidget {
  final String message;
  final VoidCallback onYes;

  ConfirmationModalBottomSheet(
    this.message,
    this.onYes,
  );

  @override
  _ConfirmationModalBottomSheetState createState() =>
      _ConfirmationModalBottomSheetState();
}

class _ConfirmationModalBottomSheetState
    extends State<ConfirmationModalBottomSheet> {
  @override
  Widget build(BuildContext context) {
    return StatefulBuilder(builder: (BuildContext context,
        StateSetter setModalState /*You can rename this!*/) {
      return Container(
        height: 160,
        decoration: BoxDecoration(
          color: Colors.lightBlue[50],
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(20),
            topRight: Radius.circular(20),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(10, 10, 10, 5),
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text("CONFIRMATION",
                    style: TextStyle(
                        color: Theme.of(context).primaryColor,
                        fontWeight: FontWeight.bold,
                        fontSize: 16)),
                Divider(
                  color: Theme.of(context).primaryColor,
                ),
                Expanded(
                  child: Center(
                    child: Text(
                    widget.message,
                    textAlign: TextAlign.center,
                  )),
                ),
                // SizedBox(height: 20),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    // NO //
                    OutlinedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            'NO',
                            style: TextStyle(
                                color: Theme.of(context).primaryColor,
                                fontSize: 12,
                                fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 5,
                    ),
                    // YES //
                    ElevatedButton(
                      onPressed: widget.onYes,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            'YES',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ]),
        ),
      );
    });
  }
}

void showConfirmation(
    {required context, required message, required VoidCallback onYes}) {
  showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      isDismissible: false,
      enableDrag: false,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return ConfirmationModalBottomSheet(message, () {
          Navigator.pop(context);
          onYes();
        });
      });
}