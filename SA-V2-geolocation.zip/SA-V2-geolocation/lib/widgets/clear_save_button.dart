import 'package:flutter/material.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/utils/utils.dart';

class ClearSaveButton extends StatelessWidget {
  final String? buttonLabel;
  final String? secondaryButtonLabel;
  final Widget? buttonIcon;
  final Widget? secondaryButtonIcon;
  final VoidCallback? onButtonTapped;
  final VoidCallback? onSecondaryButtonTapped;

  ClearSaveButton({
    this.buttonLabel,
    this.secondaryButtonLabel,
    this.buttonIcon,
    this.secondaryButtonIcon,
    this.onButtonTapped,
    this.onSecondaryButtonTapped,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        if (onSecondaryButtonTapped != null) ...[
          Expanded(
            child: OutlinedButton(
              style: ButtonStyle(
                side: MaterialStateProperty.resolveWith((state) {
                  if (state.contains(MaterialState.disabled)) {
                    return const BorderSide(color: Colors.grey);
                  }
                  return BorderSide(color: context.getColorScheme().primary);
                }),
              ),
              onPressed: onSecondaryButtonTapped,
              child: Text(secondaryButtonLabel ?? 'Clear'),
            ),
          ),
          kSpaceHorizontal16,
        ],
        Expanded(
          child: ElevatedButton(
            onPressed: onButtonTapped,
            child: Text(buttonLabel ?? 'Save Changes'),
          ),
        ),
      ],
    );
  }
}
