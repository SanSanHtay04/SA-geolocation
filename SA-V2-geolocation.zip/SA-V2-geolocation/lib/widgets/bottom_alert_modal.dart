import 'package:flutter/material.dart';

class BottomAlertModal extends StatelessWidget {
  final String? message;
  final Function? onDismiss;

  const BottomAlertModal({Key? key, this.message, this.onDismiss})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 160,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: const Radius.circular(20),
          topRight: Radius.circular(20),
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(10, 10, 10, 5),
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _title(context),
              Divider(
                color: Theme.of(context).primaryColor,
              ),
              _message(message), // SizedBox(height: 20),
              _closeButton(context),
            ]),
      ),
    );
  }

  Widget _title(context) => Text(
        "ALERT",
        style: TextStyle(
            color: Theme.of(context).primaryColor,
            fontWeight: FontWeight.bold,
            fontSize: 20),
      );

  Widget _message(message) => Expanded(
        child: Center(
          child: Text(
            message,
            textAlign: TextAlign.center,
          ),
        ),
      );

  Widget _closeButton(context) => SizedBox(
        width: 80,
        child: OutlinedButton(
          onPressed: () {
            Navigator.pop(context);
            onDismiss!();
          },
          child: Text(
            'CLOSE',
            style: TextStyle(
                color: Theme.of(context).primaryColor,
                fontSize: 14,
                fontWeight: FontWeight.bold),
          ),
        ),
      );
}

void showAlert({required context, required message, Function? onDismiss}) {
  showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) {
        return BottomAlertModal(
          message: message,
          onDismiss: onDismiss,
        );
      });
}
