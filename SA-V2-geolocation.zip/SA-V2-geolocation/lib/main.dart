import 'dart:io';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_downloader/flutter_downloader.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:provider/provider.dart';
import 'package:provider/single_child_widget.dart';
import 'package:sales/firebase_options.dart';
import 'package:sales/providers/providers.dart';
import 'package:sales/utils/permission_helper.dart';
import 'package:sales/widgets/permission_required_widget.dart';
import 'data/local/Database.dart';
import 'utils/utils.dart';
import 'routes.dart';
import 'themes/theme.dart';
import 'widgets/fullscreen_progress_indicator.dart';

@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  await setupFlutterNotifications();
  showFlutterNotification(message);
  // If you're going to use other Firebase services in the background, such as Firestore,
  // make sure you call `initializeApp` before using other Firebase services.
  print('Handling a background message ${message.messageId}');
}

/// Create a [AndroidNotificationChannel] for heads up notifications
late AndroidNotificationChannel channel;

bool isFlutterLocalNotificationsInitialized = false;

Future<void> setupFlutterNotifications() async {
  if (isFlutterLocalNotificationsInitialized) {
    return;
  }
  channel = const AndroidNotificationChannel(
    'high_importance_channel', // id
    'High Importance Notifications', // title
    description: 'This channel is used for important notifications.', // description
    importance: Importance.high,
  );

  flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

  /// Create an Android Notification Channel.
  ///
  /// We use this channel in the `AndroidManifest.xml` file to override the
  /// default FCM channel to enable heads up notifications.
  await flutterLocalNotificationsPlugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.createNotificationChannel(channel);

  /// Update the iOS foreground notification presentation options to allow
  /// heads up notifications.
  await FirebaseMessaging.instance.setForegroundNotificationPresentationOptions(
    alert: true,
    badge: true,
    sound: true,
  );
  isFlutterLocalNotificationsInitialized = true;
}

void showFlutterNotification(RemoteMessage message) {
  print(message.notification!.body);
  RemoteNotification? notification = message.notification;
  AndroidNotification? android = message.notification?.android;
  if (notification != null && android != null && !kIsWeb) {
    flutterLocalNotificationsPlugin.show(
      notification.hashCode,
      notification.title,
      notification.body,
      NotificationDetails(
        android: AndroidNotificationDetails(channel.id, channel.name,
            channelDescription: channel.description,
            // TODO add a proper drawable resource to android, for now using
            //      one that already exists in example app.
            icon: '@mipmap/ic_launcher',
            playSound: true,
            color: Color.fromARGB(255, 17, 96, 214)),
      ),
    );
  }
}

/// Initialize the [FlutterLocalNotificationsPlugin] package.
late FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // LINH //
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  // Set the background messaging handler early on, as a named top-level function
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  FirebaseMessaging.instance.isAutoInitEnabled;

  if (!kIsWeb) {
    await setupFlutterNotifications();
  }
  // LINH //

  await FirebaseHelper.init();
  await FlutterDownloader.initialize();

  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]).then((_) {
    HttpOverrides.global = MyHttpOverrides();
    runApp(MyApp());
  });
}

class MyApp extends StatefulWidget {
  const MyApp({
    Key? key,
  }) : super(key: key);

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final platform = const MethodChannel('com.r2omm.sales/location_service_channel');

  final GlobalKey<NavigatorState> _key = GlobalKey();

  late final Future<List<SingleChildWidget>> providers = globalProviders(AppDatabase.db);

  bool _firstOpen = true;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<SingleChildWidget>>(
      future: providers,
      builder: (_, snapShot) {
        if (!snapShot.hasData) {
          return FullscreenProgressIndicator();
        } else {
          return MultiProvider(
            providers: snapShot.data!,
            child: Consumer<LocalAuthProvider>(
              builder: (context, provider, widget) {
                if (!_firstOpen && !provider.isLoggedIn) {
                  _firstOpen = false;
                  SchedulerBinding.instance.addPostFrameCallback((_) {
                    _key.currentState?.pushNamedAndRemoveUntil(
                      "/login",
                      (_) => false,
                    );
                  });
                }

                return GlobalLoaderOverlay(
                  child: MaterialApp(
                    title: 'Sales App',
                    debugShowCheckedModeBanner: false,
                    navigatorKey: _key,
                    theme: Themes.lightTheme,
                    darkTheme: Themes.darkTheme,
                    routes: routes,
                    builder: EasyLoading.init(),
                    initialRoute: !kDebugMode ? "/starter" : "/login",
                  ),
                  useDefaultLoading: false,
                  overlayWidgetBuilder: (_) {
                    return Center(
                      child: CircularProgressIndicator(
                        color:Colors.amber,
                      ),
                    );
                  },
                );
              },
            ),
          );
        }
      },
    );
  }

  

  @override
  void initState() {
    super.initState();
    FirebaseMessaging.onMessage.listen(showFlutterNotification);

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      print('A new onMessageOpenedApp event was published!');
      Navigator.pushNamed(
        context,
        '/fcm-notification',
      );
    });
  }

  @override
  void dispose() {
    AppDatabase.close().then((value) => AppLogger.i("db closed"));
    super.dispose();
  }
}
