class Configs {
  static final int appId = 7;
  static const String serverUrl = const String.fromEnvironment(
    "SERVER_URL",
    defaultValue: "http://test-be.r2omm.xyz",
  );
  static const String baseUrl = '${serverUrl}/api';

  static const String clientSecret = const String.fromEnvironment(
    "CLIENT_SECRET",
    defaultValue: "o5r3ahrCgCvHf23dcxl3s0XbnqIQe8dEZFo2mpRY",
  );


  static const String legacyUrl = const String.fromEnvironment(
    "LEGACY_URL",
    defaultValue: "https://test.r2omm.info",
  );

  static const String saModuleUrl = const String.fromEnvironment(
    "SA_MODULE",
    defaultValue: "https://staging-sa-api.r2omm.net",
  );
  static const String saPassportUrl = const String.fromEnvironment(
    "SA_PASSPORT_URL",
    defaultValue: "https://staging-passport.r2omm.net",
  );
  static const String saPassportClientSecret = const String.fromEnvironment(
    "SA_PASSPORT_CLIENT_SECRET",
    defaultValue: "7RAxCoxS8jDWPLMbtqwIcCUtt4Ej4yARLhYjWu8C",
  );
  static const String saPassportClientId = const String.fromEnvironment(
    "SA_PASSPORT_CLIENT_ID",
    defaultValue: "6",
  );

  static const imageUrl = String.fromEnvironment(
    'IMG_URL',
    defaultValue: 'https://test.r2omm.info',
  );

  static const bool loginWithCredential = const bool.fromEnvironment(
    "LOGIN_WITH_CREDENTIALS",
    defaultValue: true,
  );
  static const String logLevel = const String.fromEnvironment(
    "LOG_LEVEL",
    defaultValue: "info",
  );
  static const bool isProd = const bool.fromEnvironment(
    "IS_PROD",
    defaultValue: false,
  );


  // static const String clientSecret = 'o5r3ahrCgCvHf23dcxl3s0XbnqIQe8dEZFo2mpRY';
  // static const String saModuleUrl = const String.fromEnvironment("SA_MODULE", defaultValue: "https://sa-api.r2omm.net");
  // static const String saPassportUrl = const String.fromEnvironment("SA_PASSPORT_URL", defaultValue: "https://passport.r2omm.net");
  // static const String saPassportClientSecret = const String.fromEnvironment("SA_PASSPORT_CLIENT_SECRET", defaultValue: "eAzxzwXYSOnhpOpeor8flju78DMXk93W5QpKh9T2");
  // static const String saPassportClientId = const String.fromEnvironment("SA_PASSPORT_CLIENT_ID", defaultValue: "5");

}
