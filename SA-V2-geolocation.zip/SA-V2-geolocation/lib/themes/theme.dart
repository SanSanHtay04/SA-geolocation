import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'dimensions.dart';

class Themes {
  const Themes._internal();

  static const primaryColor = Color(0xFF00897B);
  static const secondaryColor = Color(0xFF607D8B);


  static ThemeData lightTheme = _createTheme(
    colorScheme: ColorScheme.fromSeed(
      seedColor: primaryColor,
      secondary: secondaryColor,
      brightness: Brightness.light,
    ),
    brightness: Brightness.light,
  );
  static ThemeData darkTheme = _createTheme(
    colorScheme: ColorScheme.fromSeed(
      seedColor: primaryColor,
      secondary: secondaryColor,
      brightness: Brightness.dark,
    ),
    brightness: Brightness.dark,
  );

  static ThemeData _createTheme({
    required ColorScheme colorScheme,
    required Brightness brightness,
  }) {
    return ThemeData(
      brightness: brightness,
      colorScheme: colorScheme,
      useMaterial3: true,
      scaffoldBackgroundColor: colorScheme.background,
      textTheme: GoogleFonts.robotoTextTheme().apply(
        displayColor: colorScheme.onSecondaryContainer,
        bodyColor: colorScheme.onSecondaryContainer,
      ),
      appBarTheme: AppBarTheme(
        elevation: 0.0,
        scrolledUnderElevation: 0.0,
        titleSpacing: 4,
        color: colorScheme.secondaryContainer,
        centerTitle: false,
      ),
      cardTheme: const CardTheme(shape: kRoundedRectangleBorder28),
      inputDecorationTheme: InputDecorationTheme(
        isDense: true,
        contentPadding: kPaddingHorizontal16 + kPaddingVertical12,
        border: OutlineInputBorder(
          borderSide: BorderSide(color: colorScheme.outline),
          borderRadius: kBorderRadius16,
        ),
        errorStyle: const TextStyle(color: Colors.red),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: colorScheme.primary,
          foregroundColor: colorScheme.onPrimary,
        ),
      ),
      // switchTheme:
      //     SwitchThemeData(thumbIcon: MaterialStateProperty.resolveWith((state) {
      //   if (state.contains(MaterialState.selected)) {
      //     return const Icon(Icons.check);
      //   }
      //   return null;
      // })),
      listTileTheme: const ListTileThemeData(
        dense: true,
        shape: RoundedRectangleBorder(borderRadius: kBorderRadius28),
        minLeadingWidth: 16,
      ),
      dividerTheme: const DividerThemeData(thickness: 1),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: ButtonStyle(
        side: MaterialStateProperty.resolveWith((state) {
          if (state.contains(MaterialState.disabled)) {
            return const BorderSide(color: Colors.grey);
          }
          return BorderSide(color: colorScheme.primary);
        }),
      )),
      bottomSheetTheme: const BottomSheetThemeData(
        elevation: 0.0,
        modalElevation: 0.0,
      ),
    );
  }
}

// final _primary = Color(0xFF607D8B); //0xFF607D8B
// final _background = Color(0xFFFAFAFA);
// final _secondary = Color(0xFF00897B);
// final _surface = Colors.white;
// final _onSurface = Colors.grey[900]!;

// final theme = ThemeData(
//   primaryColor: _primary, colorScheme: ColorScheme(
//       onError: Colors.white,
//       surface: _surface,
//       onSurface: _onSurface,
//       error: Colors.red,
//       onPrimary: Colors.white,
//       primary: _primary,
//       background: _background,
//       brightness: Brightness.light,
//       secondary: _secondary,
//       onBackground: Colors.white,
//       onSecondary: Colors.white).copyWith(background: _background),
// );
