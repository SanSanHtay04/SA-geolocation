import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:sales/configs.dart';
import 'package:sales/utils/utils.dart';

class CustomerContactDetailProvider with ChangeNotifier {
  final String? accessToken;
  List<Map<String, dynamic>> _items = [];
  Map<String, dynamic>? _item;
  String? _responseMessage = "";

  CustomerContactDetailProvider(this.accessToken, this._items);

  List<Map<String, dynamic>> get items {
    return [..._items];
  }

  Map<String, dynamic>? get item {
    return _item;
  }

  String? get responseMessage {
    return _responseMessage;
  }

  Future<void> createRecord(int? customerId, Map<String, dynamic> data) async {
    final url = Configs.baseUrl + '/contract/customer/$customerId/contact/create';
    if (accessToken != '') {
      await http
          .post(
        Uri.parse(url),
        headers: {HttpHeaders.contentTypeHeader: 'application/json', HttpHeaders.acceptHeader: 'application/json', HttpHeaders.authorizationHeader: 'Bearer $accessToken'},
        body: json.encode(data),
      )
          .then((http.Response response) {
        Map<String, dynamic> _response = json.decode(response.body) as Map<String, dynamic>;
        _item = _response['data'];
        _responseMessage = _response['messages'];
      });
      notifyListeners();
    }
  }

  Future<void> editRecord(int? customerId, int? recordId, Map<String, dynamic> editData) async {
    final url = Configs.baseUrl + '/contract/customer/$customerId/contact/$recordId/edit';
    if (accessToken != '') {
      await http
          .post(
        Uri.parse(url),
        headers: {HttpHeaders.contentTypeHeader: 'application/json', HttpHeaders.acceptHeader: 'application/json', HttpHeaders.authorizationHeader: 'Bearer $accessToken'},
        body: json.encode(editData),
      )
          .then((http.Response response) {
        Map<String, dynamic> _response = json.decode(response.body) as Map<String, dynamic>;
        _item = _response['data'];
        _responseMessage = _response['messages'];
      });
      notifyListeners();
    }
  }

  Future<void> deleteRecord(int? customerId, int recordId, Map<String, dynamic> editData) async {
    final url = Configs.baseUrl + '/contract/customer/$customerId/contact/$recordId';
    if (accessToken != '') {
      await http
          .delete(
        Uri.parse(url),
        headers: {HttpHeaders.contentTypeHeader: 'application/json', HttpHeaders.acceptHeader: 'application/json', HttpHeaders.authorizationHeader: 'Bearer $accessToken'},
        body: json.encode(editData),
      )
          .then((http.Response response) {
        Map<String, dynamic> _response = json.decode(response.body) as Map<String, dynamic>;
        _item = _response['data'];
        _responseMessage = _response['messages'];
      });
      notifyListeners();
    }
  }

  Future<void> getRecord(int? customerId, int? recordId) async {
    final url = Configs.baseUrl + '/contract/customer/$customerId/contact/$recordId';
    if (accessToken != '') {
      final response = await http.get(
        Uri.parse(url),
        headers: {HttpHeaders.contentTypeHeader: 'application/json', HttpHeaders.acceptHeader: 'application/json', HttpHeaders.authorizationHeader: 'Bearer $accessToken'},
      );

      final _response = json.decode(response.body) as Map<String, dynamic>?;
      if (_response == null) {
        return;
      }
      _item = _response['data'];
      _responseMessage = _response['messages'];

      notifyListeners();
    }
  }

  Future<void> getRecords(int? customerId) async {
    final url = Configs.baseUrl + '/contract/customer/$customerId/contact';
    try {
      if (accessToken != '') {
        final response = await http.get(
          Uri.parse(url),
          headers: {HttpHeaders.contentTypeHeader: 'application/json', HttpHeaders.acceptHeader: 'application/json', HttpHeaders.authorizationHeader: 'Bearer $accessToken'},
        );

        final extractedResult = json.decode(response.body) as Map<String, dynamic>?;
        if (extractedResult == null) {
          return;
        }
        print('extractedResult: $extractedResult');
        final extractedData = extractedResult['data'];

        List<Map<String, dynamic>> items = List.from(extractedData);
        _items = items;
        notifyListeners();
      }
    } catch (error) {
      throw error;
    }
  }

  Future<void> getReferees(int? customerId) async {
    final url = Configs.baseUrl + '/contract/customer/$customerId/referee/list';
    try {
      if (accessToken != '') {
        final response = await http.get(
          Uri.parse(url),
          headers: {HttpHeaders.contentTypeHeader: 'application/json', HttpHeaders.acceptHeader: 'application/json', HttpHeaders.authorizationHeader: 'Bearer $accessToken'},
        );

        final extractedResult = json.decode(response.body) as Map<String, dynamic>?;
        if (extractedResult == null) {
          return;
        }
        print('extractedResult: $extractedResult');
        final extractedData = extractedResult['data'];

        List<Map<String, dynamic>> items = List.from(extractedData);
        _items = items;
        notifyListeners();
      }
    } catch (error) {
      throw error;
    }
  }

  Future<void> updateContactDetailESignature(int? customerId, int? contactDetId, Map<String, dynamic>? eSignatureData) async {
    final url = Configs.baseUrl + '/contract/customer/$customerId/contact/$contactDetId/update_signature';
    AppLogger.i("URL : $url");
    if (accessToken != '') {
      await http
          .post(
        Uri.parse(url),
        headers: {HttpHeaders.contentTypeHeader: 'application/json', HttpHeaders.acceptHeader: 'application/json', HttpHeaders.authorizationHeader: 'Bearer $accessToken'},
        body: json.encode(eSignatureData),
      )
          .then((http.Response response) {
        Map<String, dynamic> _response = json.decode(response.body) as Map<String, dynamic>;
        _item = _response['data'];
        _responseMessage = _response['messages'];
        print('_response $_response');
      });
      notifyListeners();
    }
  }
}
