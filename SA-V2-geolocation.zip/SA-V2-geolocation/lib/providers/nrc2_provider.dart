import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:sales/configs.dart';

class Nrc2Provider with ChangeNotifier {
  final String? accessToken;
  List<Map<String, dynamic>> _items = [];
  Map<String, dynamic> _item = {};

  Nrc2Provider(this.accessToken, this._items);

  List<Map<String, dynamic>> get items {
    return [..._items];
  }

  Map<String, dynamic> get item {
    return _item;
  }

  Future<void> getAllNrc2s() async {
    final url = Configs.baseUrl + '/shared/nrc1/nrc2/all';
    try {
      if (accessToken != '') {
        final response = await http.get(
          Uri.parse(url),
          headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.acceptHeader: 'application/json',
            HttpHeaders.authorizationHeader: 'Bearer $accessToken'
          },
        );

        final extractedResult =
            json.decode(response.body) as Map<String, dynamic>?;
        if (extractedResult == null) {
          return;
        }
        print('extractedResult: $extractedResult');
        final extractedData = extractedResult['data'];

        List<Map<String, dynamic>> nrc2Items = List.from(extractedData);
        _items = nrc2Items;
        notifyListeners();
      }
    } catch (error) {
      throw error;
    }
  }

  Future<void> getRecords(int? nrc1Id) async {
    final url = Configs.baseUrl + '/shared/nrc1/$nrc1Id/nrc2';
    try {
      if (accessToken != '') {
        final response = await http.get(
          Uri.parse(url),
          headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.acceptHeader: 'application/json',
            HttpHeaders.authorizationHeader: 'Bearer $accessToken'
          },
        );

        final extractedResult =
            json.decode(response.body) as Map<String, dynamic>?;
        if (extractedResult == null) {
          return;
        }
        print('extractedResult: $extractedResult');
        final extractedData = extractedResult['data'];

        List<Map<String, dynamic>> brandItems = List.from(extractedData);
        _items = brandItems;
        notifyListeners();
      }
    } catch (error) {
      throw error;
    }
  }
}
