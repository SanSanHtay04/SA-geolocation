import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:sales/configs.dart';

class AppUploadProvider with ChangeNotifier {
  final String? accessToken;
  List<Map<String, dynamic>> _items = [];
  Map<String, dynamic>? _item;
  String? _responseMessage = "";

  AppUploadProvider(this.accessToken, this._items);

  List<Map<String, dynamic>> get items {
    return [..._items];
  }

  Map<String, dynamic>? get item {
    return _item;
  }

  String? get responseMessage {
    return _responseMessage;
  }

  Future<void> createRecord(
      int? applicationId, Map<String, dynamic> data) async {
    final url = Configs.baseUrl +
        '/contract/application/$applicationId/upload/create';
    if (accessToken != '') {
      await http
          .post(
        Uri.parse(url),
        headers: {
          HttpHeaders.contentTypeHeader: 'application/json',
          HttpHeaders.acceptHeader: 'application/json',
          HttpHeaders.authorizationHeader: 'Bearer $accessToken'
        },
        body: json.encode(data),
      )
          .then((http.Response response) {
        Map<String, dynamic> _response =
            json.decode(response.body) as Map<String, dynamic>;
        _item = _response['data'];
        _responseMessage = _response['messages'];
        print('sales_regions_response $_response');
      });
      notifyListeners();
    }
  }

  Future<void> editRecord(
      int? applicationId, int? recordId, Map<String, dynamic> editData) async {
    final url = Configs.baseUrl +
        '/contract/application/$applicationId/upload/$recordId/edit';
    if (accessToken != '') {
      await http
          .post(
        Uri.parse(url),
        headers: {
          HttpHeaders.contentTypeHeader: 'application/json',
          HttpHeaders.acceptHeader: 'application/json',
          HttpHeaders.authorizationHeader: 'Bearer $accessToken'
        },
        body: json.encode(editData),
      )
          .then((http.Response response) {
        Map<String, dynamic> _response =
            json.decode(response.body) as Map<String, dynamic>;
        _item = _response['data'];
        _responseMessage = _response['messages'];
        print('sales_regions_response $_response');
      });
      notifyListeners();
    }
  }

  Future<void> deleteRecord(
      int? applicationId, int recordId) async {
    final url = Configs.baseUrl +
        '/contract/application/$applicationId/upload/$recordId';
    if (accessToken != '') {
      await http
          .delete(
        Uri.parse(url),
        headers: {
          HttpHeaders.contentTypeHeader: 'application/json',
          HttpHeaders.acceptHeader: 'application/json',
          HttpHeaders.authorizationHeader: 'Bearer $accessToken'
        },
      )
          .then((http.Response response) {
        Map<String, dynamic> _response =
            json.decode(response.body) as Map<String, dynamic>;
        _item = _response['data'];
        _responseMessage = _response['messages'];
        print('sales_regions_response $_response');
      });
      notifyListeners();
    }
  }

  Future<void> getRecord(int? applicationId, int? recordId) async {
    final url = Configs.baseUrl +
        '/contract/application/$applicationId/upload/$recordId';
    if (accessToken != '') {
      final response = await http.get(
        Uri.parse(url),
        headers: {
          HttpHeaders.contentTypeHeader: 'application/json',
          HttpHeaders.acceptHeader: 'application/json',
          HttpHeaders.authorizationHeader: 'Bearer $accessToken'
        },
      );

      final _response = json.decode(response.body) as Map<String, dynamic>?;
      if (_response == null) {
        return;
      }
      print('sales_regions_response: ${response.body}');
      _item = _response['data'];
      _responseMessage = _response['messages'];

      notifyListeners();
    }
  }

  Future<void> getRecords(int? applicationId) async {
    final url =
        Configs.baseUrl + '/contract/application/$applicationId/upload';
    try {
      if (accessToken != '') {
        final response = await http.get(
          Uri.parse(url),
          headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.acceptHeader: 'application/json',
            HttpHeaders.authorizationHeader: 'Bearer $accessToken'
          },
        );

        final extractedResult =
            json.decode(response.body) as Map<String, dynamic>?;
        if (extractedResult == null) {
          return;
        }
        print('extractedResult: $extractedResult');
        final extractedData = extractedResult['data'];

        List<Map<String, dynamic>> items = List.from(extractedData);
        _items = items;
        notifyListeners();
      }
    } catch (error) {
      throw error;
    }
  }

  Future<void> getAppUploadList(int? applicationId, int? packageId) async {
    final url =
        Configs.baseUrl + '/contract/application/$applicationId/product_package/$packageId/upload/list';
    try {
      if (accessToken != '') {
        final response = await http.get(
          Uri.parse(url),
          headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.acceptHeader: 'application/json',
            HttpHeaders.authorizationHeader: 'Bearer $accessToken'
          },
        );

        final extractedResult = json.decode(response.body) as Map<String, dynamic>?;
        if (extractedResult == null) {
          return;
        }
        final extractedData = extractedResult['data'];

        List<Map<String, dynamic>> items = List.from(extractedData);
        _items = items;
        notifyListeners();
      }
    } catch (error) {
      throw error;
    }
  }
}
