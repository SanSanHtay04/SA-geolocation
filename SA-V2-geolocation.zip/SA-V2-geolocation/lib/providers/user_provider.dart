import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:sales/configs.dart';

class UserProvider with ChangeNotifier {
  final String? accessToken;
  List<Map<String, dynamic>> _items = [];

  UserProvider(this.accessToken, this._items);

  List<Map<String, dynamic>> get items {
    return [..._items];
  }

  Future<void> getRecords() async {
    final url = Configs.baseUrl + '/system/user';
    try {
      if (accessToken != '') {
        final response = await http.get(
          Uri.parse(url),
          headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.acceptHeader: 'application/json',
            HttpHeaders.authorizationHeader: 'Bearer $accessToken'
          },
        );

        final extractedResult =
            json.decode(response.body) as Map<String, dynamic>?;
        if (extractedResult == null) {
          return;
        }
        print('extractedResult: $extractedResult');
        final extractedData = extractedResult['data'];

        List<Map<String, dynamic>> userItems = List.from(extractedData);
        _items = userItems;
        notifyListeners();
      }
    } catch (error) {
      throw error;
    }
  }

  Future<void> changePassword(
      Map<String, dynamic> userChangePasswordData) async {
    final url = Configs.baseUrl + '/system/user/change_password';

    try {
      await http
          .post(
        Uri.parse(url),
        headers: {
          HttpHeaders.contentTypeHeader: 'application/json',
          HttpHeaders.acceptHeader: 'application/json',
        },
        body: json.encode(userChangePasswordData),
      )
          .then((http.Response response) {
        Map<String, dynamic> _response =
            json.decode(response.body) as Map<String, dynamic>;
        print('sales_regions_response $_response');
        throw HttpException(_response['messages']);
      });
      notifyListeners();
    } catch (error) {
      throw (HttpException(error.toString()));
      // throw (error);
    }
  }

  Future<void> updateFcmToken(Map<String, dynamic> fcmToken) async {
    final url = Configs.baseUrl + '/system/user/update_fcm_token';

    try {
      await http
          .post(
        Uri.parse(url),
        headers: {
          HttpHeaders.contentTypeHeader: 'application/json',
          HttpHeaders.acceptHeader: 'application/json',
          HttpHeaders.authorizationHeader: 'Bearer $accessToken'
        },
        body: json.encode(fcmToken),
      )
          .then((http.Response response) {
        Map<String, dynamic> _response =
            json.decode(response.body) as Map<String, dynamic>;
        print('FCM Token update: $_response');
      });
      notifyListeners();
    } catch (error) {
      throw (HttpException(error.toString()));
      // throw (error);
    }
  }

  Future<void> getUserAssignedToPOS(int posId) async {
    final url = Configs.baseUrl + '/system/user/pos/${posId}/assigned_to_pos';
    try {
      if (accessToken != '') {
        final response = await http.get(
          Uri.parse(url),
          headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.acceptHeader: 'application/json',
            HttpHeaders.authorizationHeader: 'Bearer $accessToken'
          },
        );

        final extractedResult =
            json.decode(response.body) as Map<String, dynamic>?;
        if (extractedResult == null) {
          return;
        }
        print('extractedResult: $extractedResult');
        final extractedData = extractedResult['data'];

        List<Map<String, dynamic>> userItems = List.from(extractedData);
        _items = userItems;
        notifyListeners();
      }
    } catch (error) {
      throw error;
    }
  }
}
