import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:sales/configs.dart';

class AssetProvider with ChangeNotifier {
  final String? accessToken;
  List<Map<String, dynamic>> _items = [];
  Map<String, dynamic>? _item;
  String? _responseMessage = "";
  String? _responseCode = "";

  AssetProvider(this.accessToken, this._items);

  List<Map<String, dynamic>> get items {
    return [..._items];
  }

  Map<String, dynamic>? get item {
    return _item;
  }

  String? get responseMessage {
    return _responseMessage;
  }

  String? get responseCode {
    return _responseCode;
  }

  Future<void> updateAsset(
      int? contractId, int? assetId, Map<String, dynamic> editData) async {
    final url = Configs.baseUrl +
        '/contract/$contractId/asset/$assetId/update_asset';
    if (accessToken != '') {
      await http
          .post(
        Uri.parse(url),
        headers: {
          HttpHeaders.contentTypeHeader: 'application/json',
          HttpHeaders.acceptHeader: 'application/json',
          HttpHeaders.authorizationHeader: 'Bearer $accessToken'
        },
        body: json.encode(editData),
      )
          .then((http.Response response) {
        Map<String, dynamic> _response =
            json.decode(response.body) as Map<String, dynamic>;
        _item = _response['data'];
        _responseMessage = _response['messages'];
        _responseCode = _response['code'];
      });
      notifyListeners();
    }
  }

  Future<void> confirmDelivery(
      int? contractId, int? assetId) async {
    final url = Configs.baseUrl +
        '/contract/$contractId/asset/$assetId/confirm_delivery';
    if (accessToken != '') {
      await http
          .post(
        Uri.parse(url),
        headers: {
          HttpHeaders.contentTypeHeader: 'application/json',
          HttpHeaders.acceptHeader: 'application/json',
          HttpHeaders.authorizationHeader: 'Bearer $accessToken'
        },
      )
          .then((http.Response response) {
        Map<String, dynamic> _response =
            json.decode(response.body) as Map<String, dynamic>;
        _item = _response['data'];
        _responseMessage = _response['messages'];
        
      });
      notifyListeners();
    }
  }
}
