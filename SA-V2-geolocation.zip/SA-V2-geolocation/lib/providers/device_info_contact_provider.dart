import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:sales/configs.dart';
import 'package:sales/models/device_info_contact.dart';

class DeviceInfoContactProvider with ChangeNotifier {
  final String? accessToken;
  List<Map<String, dynamic>> _items = [];
  Map<String, dynamic>? _item;
  String? _responseMessage;
  int? _responseStatus;

  DeviceInfoContactProvider(this.accessToken, this._items);
  
  List<Map<String, dynamic>> get items {
    return [..._items];
  }

  Map<String, dynamic> get item {
    return _item!;
  }

  String get responseMessage {
    return _responseMessage!;
  }

  int get responseStatus {
    return _responseStatus!;
  }

  Future<void> storeContacts(List<DeviceInfoContact> contacts, String imeiNo) async {
    final data = {
      'data': DeviceInfoContactTransform().toJsonList(contacts),
    };

    final url = Configs.baseUrl + '/ref/device_info/store_contacts';
    await http.post(Uri.parse(url),
      headers: {
        HttpHeaders.contentTypeHeader: 'application/json',
        HttpHeaders.acceptHeader: 'application/json',
        HttpHeaders.authorizationHeader: 'Bearer $accessToken',
        'access-token': this.accessToken!,
        'x-device-id': imeiNo,
        'app-id': '${Configs.appId}',
      },
      body: json.encode(data),)
      .then((http.Response response) {
        Map<String, dynamic> _response = json.decode(response.body) as Map<String, dynamic>;
        // _item = _response['data'] != null ? Map<String, dynamic>.from(_response['data']) : null;
        _responseMessage = _response['status_message'];
        log('contact log: $_responseMessage');
      });
    notifyListeners();
  }

}
