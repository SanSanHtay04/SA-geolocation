import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:sales/configs.dart';
import 'package:sales/utils/utils.dart';

class ApplicationProvider with ChangeNotifier {
  final String? accessToken;
  List<Map<String, dynamic>> _items = [];
  Map<String, dynamic>? _item;
  String? _responseMessage = "";

  ApplicationProvider(this.accessToken, this._items);

  List<Map<String, dynamic>> get items {
    return [..._items];
  }

  Map<String, dynamic>? get item {
    return _item;
  }

  String? get responseMessage {
    return _responseMessage;
  }

  Future<void> createRecord(int? prospectId, Map<String, dynamic> applicationData) async {
    final url = Configs.baseUrl + '/origination/prospect/$prospectId/application';
    AppLogger.i("URL : $url");
    if (accessToken != '') {
      await http
          .post(
        Uri.parse(url),
        headers: {HttpHeaders.contentTypeHeader: 'application/json', HttpHeaders.acceptHeader: 'application/json', HttpHeaders.authorizationHeader: 'Bearer $accessToken'},
        body: json.encode(applicationData),
      )
          .then((http.Response response) {
        Map<String, dynamic> _response = json.decode(response.body) as Map<String, dynamic>;
        _item = _response['data'];
        _responseMessage = _response['messages'];
        print('sales_regions_response $_response');
      });
      notifyListeners();
    }
  }

  Future<void> getApplication(int? prospectId, int? applicationId) async {
    final url = Configs.baseUrl + '/origination/prospect/$prospectId/application/$applicationId';

    AppLogger.i('Prospect URL : $url');
    if (accessToken != '') {
      final response = await http.get(
        Uri.parse(url),
        headers: {HttpHeaders.contentTypeHeader: 'application/json', HttpHeaders.acceptHeader: 'application/json', HttpHeaders.authorizationHeader: 'Bearer $accessToken'},
      );

      final _response = json.decode(response.body) as Map<String, dynamic>?;
      if (_response == null) {
        return;
      }
      _item = _response['data'];
      _responseMessage = _response['messages'];

      notifyListeners();
    }
  }

  Future<void> submit(int? prospectId, int? applicationId, Map<String, dynamic> applicationData) async {
    final url = Configs.baseUrl + '/origination/prospect/$prospectId/application/$applicationId/submit';
    AppLogger.i("URL : $url");
    if (accessToken != '') {
      await http
          .post(
        Uri.parse(url),
        headers: {HttpHeaders.contentTypeHeader: 'application/json', HttpHeaders.acceptHeader: 'application/json', HttpHeaders.authorizationHeader: 'Bearer $accessToken'},
        body: json.encode(applicationData),
      )
          .then((http.Response response) {
        Map<String, dynamic> _response = json.decode(response.body) as Map<String, dynamic>;
        _item = _response['data'];
        _responseMessage = _response['messages'];
        AppLogger.i('RESPONSE : $_response');
      });
      notifyListeners();
    }
  }

  Future<void> getCounterProposals() async {
    _items = [];
    final url = Configs.baseUrl + '/origination/prospect/application/counter_proposals';
    if (accessToken != '') {
      final response = await http.get(
        Uri.parse(url),
        headers: {HttpHeaders.contentTypeHeader: 'application/json', HttpHeaders.acceptHeader: 'application/json', HttpHeaders.authorizationHeader: 'Bearer $accessToken'},
      );

      final extractedResult = json.decode(response.body) as Map<String, dynamic>?;
      if (extractedResult == null) {
        return;
      }
      Map<String, dynamic> _response = json.decode(response.body) as Map<String, dynamic>;
      // _items = List.from(_response['data']);
      _responseMessage = _response['messages'];
      List<Map<String, dynamic>> prospectItems = List.from(_response['data']);
      if (prospectItems.length > 0) {
        prospectItems.forEach((element) {
          _items.add(element);
        });
      }

      notifyListeners();
    }
  }

  Future<void> resubmit(int? prospectId, int? applicationId, Map<String, dynamic> applicationData) async {
    final url = Configs.baseUrl + '/origination/prospect/$prospectId/application/$applicationId/resubmit';
    if (accessToken != '') {
      await http
          .post(
        Uri.parse(url),
        headers: {HttpHeaders.contentTypeHeader: 'application/json', HttpHeaders.acceptHeader: 'application/json', HttpHeaders.authorizationHeader: 'Bearer $accessToken'},
        body: json.encode(applicationData),
      )
          .then((http.Response response) {
        Map<String, dynamic> _response = json.decode(response.body) as Map<String, dynamic>;
        _item = _response['data'];
        _responseMessage = _response['messages'];
        print('sales_regions_response $_response');
      });
      notifyListeners();
    }
  }

  Future<void> updatePersonDesignatedTo(int? applicationId, Map<String, dynamic> applicationData) async {
    final url = Configs.baseUrl + '/origination/prospect/application/$applicationId/update_person_designated';
    if (accessToken != '') {
      await http
          .post(
        Uri.parse(url),
        headers: {HttpHeaders.contentTypeHeader: 'application/json', HttpHeaders.acceptHeader: 'application/json', HttpHeaders.authorizationHeader: 'Bearer $accessToken'},
        body: json.encode(applicationData),
      )
          .then((http.Response response) {
        Map<String, dynamic> _response = json.decode(response.body) as Map<String, dynamic>;
        _item = _response['data'];
        _responseMessage = _response['messages'];
      });
      notifyListeners();
    }
  }

  Future<void> getApprovedApplications() async {
    _items = [];
    final url = Configs.baseUrl + '/origination/prospect/application/approved_applications';
    if (accessToken != '') {
      final response = await http.get(
        Uri.parse(url),
        headers: {HttpHeaders.contentTypeHeader: 'application/json', HttpHeaders.acceptHeader: 'application/json', HttpHeaders.authorizationHeader: 'Bearer $accessToken'},
      );

      final extractedResult = json.decode(response.body) as Map<String, dynamic>?;
      if (extractedResult == null) {
        return;
      }
      Map<String, dynamic> _response = json.decode(response.body) as Map<String, dynamic>;
      _responseMessage = _response['messages'];
      List<Map<String, dynamic>> items = List.from(_response['data']);
      if (items.length > 0) {
        items.forEach((element) {
          _items.add(element);
        });
      }

      notifyListeners();
    }
  }

  Future<void> getSubmittedApplications() async {
    _items = [];
    final url = Configs.baseUrl + '/origination/prospect/application/app_processing';
    if (accessToken != '') {
      final response = await http.get(
        Uri.parse(url),
        headers: {HttpHeaders.contentTypeHeader: 'application/json', HttpHeaders.acceptHeader: 'application/json', HttpHeaders.authorizationHeader: 'Bearer $accessToken'},
      );

      final extractedResult = json.decode(response.body) as Map<String, dynamic>?;
      if (extractedResult == null) {
        return;
      }
      Map<String, dynamic> _response = json.decode(response.body) as Map<String, dynamic>;
      _responseMessage = _response['messages'];
      List<Map<String, dynamic>> items = List.from(_response['data']);
      if (items.length > 0) {
        items.forEach((element) {
          _items.add(element);
        });
      }

      notifyListeners();
    }
  }
}
