import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:sales/configs.dart';

class CustomerProvider with ChangeNotifier {
  final String? accessToken;
  List<Map<String, dynamic>> _items = [];
  Map<String, dynamic>? _item;
  String? _responseMessage = "";

  CustomerProvider(this.accessToken, this._items);

  List<Map<String, dynamic>> get items {
    return [..._items];
  }

  Map<String, dynamic>? get item {
    return _item;
  }

  String? get responseMessage {
    return _responseMessage;
  }

  Future<void> getRecord(int? recordId) async {
    final url = Configs.baseUrl + '/contract/customer/$recordId';
    if (accessToken != '') {
      final response = await http.get(
        Uri.parse(url),
        headers: {
          HttpHeaders.contentTypeHeader: 'application/json',
          HttpHeaders.acceptHeader: 'application/json',
          HttpHeaders.authorizationHeader: 'Bearer $accessToken'
        },
      );

      final _response = json.decode(response.body) as Map<String, dynamic>?;
      if (_response == null) {
        return;
      }
      print('sales_regions_response: ${response.body}');
      _item = _response['data'];
      _responseMessage = _response['messages'];

      notifyListeners();
    }
  }

  Future<void> createRecord(Map<String, dynamic> data) async {
    final url = Configs.baseUrl + '/contract/customer';
    if (accessToken != '') {
      await http
          .post(
        Uri.parse(url),
        headers: {
          HttpHeaders.contentTypeHeader: 'application/json',
          HttpHeaders.acceptHeader: 'application/json',
          HttpHeaders.authorizationHeader: 'Bearer $accessToken'
        },
        body: json.encode(data),
      )
          .then((http.Response response) {
        Map<String, dynamic> _response =
            json.decode(response.body) as Map<String, dynamic>;
        _item = _response['data'];
        _responseMessage = _response['messages'];
        print('sales_regions_response $_response');
      });
      notifyListeners();
    }
  }

  Future<void> editRecord(int? recordId, Map<String, dynamic> editData) async {
    final url =
        Configs.baseUrl + '/contract/customer/sa_mobileapp/$recordId/edit';
    if (accessToken != '') {
      await http
          .post(
        Uri.parse(url),
        headers: {
          HttpHeaders.contentTypeHeader: 'application/json',
          HttpHeaders.acceptHeader: 'application/json',
          HttpHeaders.authorizationHeader: 'Bearer $accessToken'
        },
        body: json.encode(editData),
      )
          .then((http.Response response) {
        Map<String, dynamic> _response =
            json.decode(response.body) as Map<String, dynamic>;
        _item = _response['data'];
        _responseMessage = _response['messages'];
        print('sales_regions_response $_response');
      });
      notifyListeners();
    }
  }
}
