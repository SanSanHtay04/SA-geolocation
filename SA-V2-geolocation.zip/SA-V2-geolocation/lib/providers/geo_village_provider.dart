import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:sales/configs.dart';

class GeoVillageProvider with ChangeNotifier {
  final String? accessToken;
  List<Map<String, dynamic>> _items = [];
  Map<String, dynamic> _item = {};

  GeoVillageProvider(this.accessToken, this._items);

  List<Map<String, dynamic>> get items {
    return [..._items];
  }

  Map<String, dynamic> get item {
    return _item;
  }

  Future<void> getAllVillages() async {
    final url = Configs.baseUrl + '/geo/town/village/all';
    try {
      if (accessToken != '') {
        final response = await http.get(
          Uri.parse(url),
          headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.acceptHeader: 'application/json',
            HttpHeaders.authorizationHeader: 'Bearer $accessToken'
          },
        );

        final extractedResult =
            json.decode(response.body) as Map<String, dynamic>?;
        if (extractedResult == null) {
          return;
        }
        print('extractedResult: $extractedResult');
        final extractedData = extractedResult['data'];

        List<Map<String, dynamic>> villageItems = List.from(extractedData);
        _items = villageItems;
        notifyListeners();
      }
    } catch (error) {
      throw error;
    }
  }

  Future<void> getRecords(int? geoTownId) async {
    final url = Configs.baseUrl + '/geo/town/$geoTownId/village';
    try {
      if (accessToken != '') {
        final response = await http.get(
          Uri.parse(url),
          headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.acceptHeader: 'application/json',
            HttpHeaders.authorizationHeader: 'Bearer $accessToken'
          },
        );

        final extractedResult =
            json.decode(response.body) as Map<String, dynamic>?;
        if (extractedResult == null) {
          return;
        }
        print('extractedResult: $extractedResult');
        final extractedData = extractedResult['data'];

        List<Map<String, dynamic>> brandItems = List.from(extractedData);
        _items = brandItems;
        notifyListeners();
      }
    } catch (error) {
      throw error;
    }
  }
}
