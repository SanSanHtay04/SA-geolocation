import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:sales/configs.dart';
import 'package:sales/data/local/models/models.dart';


class OriginationPosProvider with ChangeNotifier {
  final String? accessToken;
  List<Map<String, dynamic>>? _items = [];
  OriginationPOS? _item;

  OriginationPosProvider(this.accessToken, this._items);

  List<Map<String, dynamic>> get items {
    return [..._items!];
  }

  OriginationPOS? get item {
    return _item;
  }

  Future<void> getAllAssignedPoses() async {
    final url = Configs.baseUrl + '/ref/pos/all_assigned_pos';
    try {
      if (accessToken != '') {
        final response = await http.get(
          Uri.parse(url),
          headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.acceptHeader: 'application/json',
            HttpHeaders.authorizationHeader: 'Bearer $accessToken'
          },
        );

        final extractedResult =
            json.decode(response.body) as Map<String, dynamic>?;
        if (extractedResult == null) {
          return;
        }
        print(
            'headers:${response.headers}\nsales_regions_response: ${response.body}');
        final extractedData = extractedResult['data'];

        List<Map<String, dynamic>> posItems = List.from(extractedData);

        _items = posItems;
        notifyListeners();
      }
    } catch (error) {
      throw error;
    }
  }
}
