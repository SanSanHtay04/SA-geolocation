import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:sales/configs.dart';

class CustomerIncomeSourceProvider with ChangeNotifier {
  final String? accessToken;
  List<Map<String, dynamic>> _items = [];
  Map<String, dynamic>? _item;
  String? _responseMessage = "";

  CustomerIncomeSourceProvider(this.accessToken, this._items);

  List<Map<String, dynamic>> get items {
    return [..._items];
  }

  Map<String, dynamic>? get item {
    return _item;
  }

  String? get responseMessage {
    return _responseMessage;
  }

  Future<void> createRecord(int? customerId, Map<String, dynamic> data) async {
    final url = Configs.baseUrl + '/contract/customer/$customerId/incomesource';
    if (accessToken != '') {
      await http
          .post(
        Uri.parse(url),
        headers: {HttpHeaders.contentTypeHeader: 'application/json', HttpHeaders.acceptHeader: 'application/json', HttpHeaders.authorizationHeader: 'Bearer $accessToken'},
        body: json.encode(data),
      )
          .then((http.Response response) {
        Map<String, dynamic> _response = json.decode(response.body) as Map<String, dynamic>;
        _item = _response['data'];
        _responseMessage = _response['messages'];
      });
      notifyListeners();
    }
  }

  Future<void> editRecord(int? customerId, int? recordId, Map<String, dynamic> editData) async {
    final url = Configs.baseUrl + '/contract/customer/$customerId/incomesource/$recordId/edit';
    if (accessToken != '') {
      await http
          .post(
        Uri.parse(url),
        headers: {HttpHeaders.contentTypeHeader: 'application/json', HttpHeaders.acceptHeader: 'application/json', HttpHeaders.authorizationHeader: 'Bearer $accessToken'},
        body: json.encode(editData),
      )
          .then((http.Response response) {
        Map<String, dynamic> _response = json.decode(response.body) as Map<String, dynamic>;
        _item = _response['data'];
        _responseMessage = _response['messages'];
        print('sales_regions_response $_response');
      });
      notifyListeners();
    }
  }

  Future<void> deleteRecord(int? customerId, int recordId, Map<String, dynamic> editData) async {
    final url = Configs.baseUrl + '/contract/customer/$customerId/incomesource/$recordId';
    if (accessToken != '') {
      await http
          .delete(
        Uri.parse(url),
        headers: {HttpHeaders.contentTypeHeader: 'application/json', HttpHeaders.acceptHeader: 'application/json', HttpHeaders.authorizationHeader: 'Bearer $accessToken'},
        body: json.encode(editData),
      )
          .then((http.Response response) {
        Map<String, dynamic> _response = json.decode(response.body) as Map<String, dynamic>;
        _item = _response['data'];
        _responseMessage = _response['messages'];
        print('sales_regions_response $_response');
      });
      notifyListeners();
    }
  }

  Future<void> getRecord(int? customerId, int? recordId) async {
    final url = Configs.baseUrl + '/contract/customer/$customerId/incomesource/$recordId';
    if (accessToken != '') {
      final response = await http.get(
        Uri.parse(url),
        headers: {HttpHeaders.contentTypeHeader: 'application/json', HttpHeaders.acceptHeader: 'application/json', HttpHeaders.authorizationHeader: 'Bearer $accessToken'},
      );

      final _response = json.decode(response.body) as Map<String, dynamic>?;
      if (_response == null) {
        return;
      }
      print('sales_regions_response: ${response.body}');
      _item = _response['data'];
      _responseMessage = _response['messages'];

      notifyListeners();
    }
  }

  Future<void> getRecords(int? customerId) async {
    final url = Configs.baseUrl + '/contract/customer/$customerId/incomesource';
    try {
      if (accessToken != '') {
        final response = await http.get(
          Uri.parse(url),
          headers: {HttpHeaders.contentTypeHeader: 'application/json', HttpHeaders.acceptHeader: 'application/json', HttpHeaders.authorizationHeader: 'Bearer $accessToken'},
        );

        final extractedResult = json.decode(response.body) as Map<String, dynamic>?;
        if (extractedResult == null) {
          return;
        }
        print('extractedResult: $extractedResult');
        final extractedData = extractedResult['data'];

        List<Map<String, dynamic>> brandItems = List.from(extractedData);
        _items = brandItems;
        notifyListeners();
      }
    } catch (error) {
      throw error;
    }
  }
}
