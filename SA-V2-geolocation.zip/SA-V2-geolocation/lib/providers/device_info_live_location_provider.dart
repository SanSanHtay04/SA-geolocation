import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:sales/configs.dart';
import 'package:sales/models/device_info_live_location.dart';
import 'package:sales/utils/logging.dart';

class DeviceInfoLiveLocationProvider with ChangeNotifier {
  final String? accessToken;
  List<Map<String, dynamic>> _items = [];
  Map<String, dynamic>? _item;
  String? _responseMessage;
  int? _responseStatus;

  DeviceInfoLiveLocationProvider(this.accessToken, this._items);
  
  List<Map<String, dynamic>> get items {
    return [..._items];
  }

  Map<String, dynamic> get item {
    return _item!;
  }

  String get responseMessage {
    return _responseMessage!;
  }

  int get responseStatus {
    return _responseStatus!;
  }

  Future<void> storeLocation(DeviceInfoLiveLocation location, String imeiNo) async {
    final url = Configs.baseUrl + '/ref/device_info/store_live_location';
    AppLogger.i("URL : $url");
    await http.post(Uri.parse(url),
      headers: {
        HttpHeaders.contentTypeHeader: 'application/json',
        HttpHeaders.acceptHeader: 'application/json',
        HttpHeaders.authorizationHeader: 'Bearer $accessToken',
        'access-token': this.accessToken!,
        'x-device-id': imeiNo,
        'app-id': '${Configs.appId}',
      },
      body: json.encode(location.toJson()),)
      .then((http.Response response) {
        Map<String, dynamic> _response = json.decode(response.body) as Map<String, dynamic>;
        _item = _response['data'] != null ? Map<String, dynamic>.from(_response['data']) : null;
        _responseMessage = _response['status_message'];

        AppLogger.i("_response : $_response");
      });
    notifyListeners();
  }

}
