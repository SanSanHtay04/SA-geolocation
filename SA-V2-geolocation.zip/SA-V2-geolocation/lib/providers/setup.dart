import 'package:nested/nested.dart';
import 'package:provider/provider.dart';
import 'package:sales/data/local/tables/checkin_table.dart';
import 'package:sales/data/local/tables/pos_table.dart';
import 'package:sales/data/remote/api_client.dart';
import 'package:sales/data/remote/services/services.dart';
import 'package:sales/data/repositories/repositories.dart';
import 'package:sales/providers/attached_product_detail_provider.dart';
import 'package:sales/providers/device_info_call_log_provider.dart';
import 'package:sales/providers/device_info_contact_provider.dart';
import 'package:sales/providers/device_info_device_provider.dart';
import 'package:sales/providers/device_info_live_location_provider.dart';
import 'package:sales/providers/device_info_sim_card_provider.dart';
import 'package:sales/providers/device_info_sms_log_provider.dart';
import 'package:sales/providers/providers.dart';
import 'package:sales/screens/checkin/data/check_pos_repository.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import '../data/local/prefs_store.dart';
import '../screens/auth/data/auth_repository.dart';

Future<List<SingleChildWidget>> globalProviders(Future<Database> db) async {
  final _db = await db;

  final sharedPrefs = await SharedPreferences.getInstance();
  final prefsStore = PrefsStore(sharedPrefs);
  final localAuthProvider = LocalAuthProvider(prefsStore);

  ApiClient.initialize(localAuthProvider);
  final authService = AuthService();
  final commonService = CommonService();
  final addressService = AddressService();

  final posDao = POSDao(db: _db);
  final checkInDao = CheckinDao(db: _db);

  final authRepo = AuthRepository(
    api: authService,
    prefsStore: prefsStore,
    posDao: posDao
  );

  final posRepo = POSRepository(
    commonService,
    posDao: posDao,
    checkinDao: checkInDao,
    prefsStore: prefsStore,
  );

  final checkPosRepo = CheckPosRepository(
    api: commonService,
    dao: checkInDao,
  );

  final categoryRepo = ProductCategoryRepository(commonService);
  final simulationRepo = SimulationRepository(commonService);

  return [
    Provider.value(value: _db),
    Provider.value(value: prefsStore),
    Provider.value(value: authService),
    Provider.value(value: commonService),
    Provider.value(value: addressService),
    Provider.value(value: authRepo),
    Provider.value(value: posRepo),
    Provider.value(value: checkPosRepo),
    Provider.value(value: categoryRepo),
    Provider.value(value: simulationRepo),
    ChangeNotifierProvider.value(value: localAuthProvider),
    ChangeNotifierProvider(create: (context) => AuthProvider(repo: authRepo)),
    ...originationProviders,
  ];
}

// TODO : no longer using providers for calling network APIs, need to update later
List<SingleChildWidget> originationProviders = [
  ChangeNotifierProxyProvider<AuthProvider, OriginationPosProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => OriginationPosProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, UserProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => UserProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, AppLoginJournalProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => AppLoginJournalProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, ProspectProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => ProspectProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, BrandProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => BrandProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, ProductProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => ProductProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, ProductPackageProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => ProductPackageProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, SimulationProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => SimulationProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, ApplicationProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => ApplicationProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, EducationProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => EducationProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, Nrc1Provider?>(
    create: (_) => null,
    update: (_, auth, previous) => Nrc1Provider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, Nrc2Provider?>(
    create: (_) => null,
    update: (_, auth, previous) => Nrc2Provider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, MaritalStatusProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => MaritalStatusProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, GeoRegionProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => GeoRegionProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, GeoDistrictProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => GeoDistrictProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, GeoTownshipProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => GeoTownshipProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, GeoTownProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => GeoTownProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, GeoWardProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => GeoWardProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, GeoVillageProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => GeoVillageProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, CustomerProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => CustomerProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, BusinessTypeProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => BusinessTypeProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, JobCategoryProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => JobCategoryProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, CustomerIncomeSourceProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => CustomerIncomeSourceProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, CustomerHouseholdProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => CustomerHouseholdProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, CustomerContactDetailProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => CustomerContactDetailProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, AppDocumentProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => AppDocumentProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, AppDocDetProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => AppDocDetProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, OriAppDataSyncProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => OriAppDataSyncProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, MerchantProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => MerchantProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, ProductCategoryProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => ProductCategoryProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, InsSchemeProductDetailProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => InsSchemeProductDetailProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, AppDocTypeProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => AppDocTypeProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, AppDocumentProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => AppDocumentProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, AppUploadProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => AppUploadProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, SecondaryProductProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => SecondaryProductProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, SupplierBankAccountProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => SupplierBankAccountProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, AttachedProductProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => AttachedProductProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, ContractProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => ContractProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, AssetProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => AssetProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, PaymentScheduleProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => PaymentScheduleProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, AssetPaymentProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => AssetPaymentProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, ApplicationDocumentProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => ApplicationDocumentProvider(
      auth.saAccessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, DocumentTypeProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => DocumentTypeProvider(
      auth.saAccessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, FcmPushNotificationProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => FcmPushNotificationProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, AttachedProductDetailProvider?>(
    create: (_) => null,
    update: (_, auth, previous) => AttachedProductDetailProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, DeviceInfoCallLogProvider?>(
    create: (_) => null,
    update: (_, AuthProvider auth, previous) => DeviceInfoCallLogProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, DeviceInfoSmsLogProvider?>(
    create: (_) => null,
    update: (_, AuthProvider auth, previous) => DeviceInfoSmsLogProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, DeviceInfoContactProvider?>(
    create: (_) => null,
    update: (_, AuthProvider auth, previous) => DeviceInfoContactProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, DeviceInfoLiveLocationProvider?>(
    create: (_) => null,
    update: (_, AuthProvider auth, previous) => DeviceInfoLiveLocationProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, DeviceInfoSimCardProvider?>(
    create: (_) => null,
    update: (_, AuthProvider auth, previous) => DeviceInfoSimCardProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
  ChangeNotifierProxyProvider<AuthProvider, DeviceInfoDeviceProvider?>(
    create: (_) => null,
    update: (_, AuthProvider auth, previous) => DeviceInfoDeviceProvider(
      auth.accessToken,
      previous == null ? [] : previous.items,
    ),
  ),
];
