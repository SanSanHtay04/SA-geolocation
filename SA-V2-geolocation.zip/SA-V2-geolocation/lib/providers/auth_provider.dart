import 'dart:async';
import 'package:flutter/material.dart';

import 'package:sales/models/models.dart';

import '../screens/auth/data/auth_repository.dart';

class AuthProvider with ChangeNotifier {
  late AuthRepository repo;

  AuthProvider({required AuthRepository this.repo});

  bool get isAuthenticated => repo.isLoggedIn;

  String? get accessToken => repo.accountInfo?.accessToken;

  String? get saAccessToken => repo.accountInfo?.saAccessToken;

  AccountInfo? get accountInfo => repo.accountInfo;

  Future<void> logout() async {
    await repo.logout();
    refresh();
  }

  void refresh() {
    notifyListeners();
  }
}
