import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:sales/configs.dart';
import 'package:sales/utils/utils.dart';

class ProspectProvider with ChangeNotifier {
  final String? accessToken;
  List<Map<String, dynamic>> _items = [];
  Map<String, dynamic>? _item;
  String? _responseMessage = "";

  ProspectProvider(this.accessToken, this._items);

  List<Map<String, dynamic>> get items {
    return [..._items];
  }

  Map<String, dynamic>? get item {
    return _item;
  }

  String? get responseMessage {
    return _responseMessage;
  }

  Future<void> getProspects() async {
    _items = [];
    final url = Configs.baseUrl + '/contract/prospect/sa_mobileapp/index';
    if (accessToken != '') {
      final response = await http.get(
        Uri.parse(url),
        headers: {
          HttpHeaders.contentTypeHeader: 'application/json',
          HttpHeaders.acceptHeader: 'application/json',
          HttpHeaders.authorizationHeader: 'Bearer $accessToken'
        },
      );

      final extractedResult =
          json.decode(response.body) as Map<String, dynamic>?;
      if (extractedResult == null) {
        return;
      }
      print('sales_regions_response: ${response.body}');
      Map<String, dynamic> _response =
          json.decode(response.body) as Map<String, dynamic>;
      // _items = List.from(_response['data']);
      _responseMessage = _response['messages'];
      List<Map<String, dynamic>> prospectItems = List.from(_response['data']);
      if (prospectItems.length > 0) {
        prospectItems.forEach((element) {
          _items.add(element);
        });
      }

      notifyListeners();
    }
  }

  Future<void> getProspect(int? prospectId) async {
    final url = Configs.baseUrl + '/contract/prospect/$prospectId';

    AppLogger.i('Prospect URL : $url');
    if (accessToken != '') {
      final response = await http.get(
        Uri.parse(url),
        headers: {
          HttpHeaders.contentTypeHeader: 'application/json',
          HttpHeaders.acceptHeader: 'application/json',
          HttpHeaders.authorizationHeader: 'Bearer $accessToken'
        },
      );

      final _response = json.decode(response.body) as Map<String, dynamic>?;
      if (_response == null) {
        return;
      }
      print('sales_regions_response: ${response.body}');
      _item = _response['data'];
      _responseMessage = _response['messages'];

      notifyListeners();
    }
  }

  Future<void> pushLocalDataToServer(Map<String, dynamic> locaData) async {
    final url =
        Configs.baseUrl + '/contract/prospect/sa_mobileapp/pushdata';
    if (accessToken != '') {
      await http
          .post(
        Uri.parse(url),
        headers: {
          HttpHeaders.contentTypeHeader: 'application/json',
          HttpHeaders.acceptHeader: 'application/json',
          HttpHeaders.authorizationHeader: 'Bearer $accessToken'
        },
        body: json.encode(locaData),
      )
          .then((http.Response response) {
        Map<String, dynamic> _response =
            json.decode(response.body) as Map<String, dynamic>;
        _item = _response['data'];
        _responseMessage = _response['messages'];
        print('sales_regions_response $_response');
      });
      notifyListeners();
    }
  }

  Future<void> createProspect(Map<String, dynamic> prospectData) async {
    final url = Configs.baseUrl + '/contract/prospect/sa_mobileapp/create';
    if (accessToken != '') {
      await http
          .post(
        Uri.parse(url),
        headers: {
          HttpHeaders.contentTypeHeader: 'application/json',
          HttpHeaders.acceptHeader: 'application/json',
          HttpHeaders.authorizationHeader: 'Bearer $accessToken'
        },
        body: json.encode(prospectData),
      )
          .then((http.Response response) {
        Map<String, dynamic> _response =
            json.decode(response.body) as Map<String, dynamic>;
        _item = _response['data'];
        _responseMessage = _response['messages'];
        print('sales_regions_response $_response');
      });
      notifyListeners();
    }
  }

  Future<void> editProspect(
      Map<String, dynamic> prospectData, int? prospectId) async {
    final url = Configs.baseUrl +
        '/contract/prospect/sa_mobileapp/$prospectId/edit';
    if (accessToken != '') {
      await http
          .post(
        Uri.parse(url),
        headers: {
          HttpHeaders.contentTypeHeader: 'application/json',
          HttpHeaders.acceptHeader: 'application/json',
          HttpHeaders.authorizationHeader: 'Bearer $accessToken'
        },
        body: json.encode(prospectData),
      )
          .then((http.Response response) {
        Map<String, dynamic> _response =
            json.decode(response.body) as Map<String, dynamic>;
        _item = _response['data'];
        _responseMessage = _response['messages'];
        print('sales_regions_response $_response');
      });
      notifyListeners();
    }
  }

  Future<void> deleteProspect(int? prospectId) async {
    final url = Configs.baseUrl + '/contract/prospect/$prospectId';
    if (accessToken != '') {
      await http.delete(Uri.parse(url),
        headers: {
          HttpHeaders.contentTypeHeader: 'application/json',
          HttpHeaders.acceptHeader: 'application/json',
          HttpHeaders.authorizationHeader: 'Bearer $accessToken'
        },
      )
          .then((http.Response response) {
        Map<String, dynamic> _response =
            json.decode(response.body) as Map<String, dynamic>;
        _item = _response['data'];
        _responseMessage = _response['messages'];
      });
      notifyListeners();
    }
  }
}
