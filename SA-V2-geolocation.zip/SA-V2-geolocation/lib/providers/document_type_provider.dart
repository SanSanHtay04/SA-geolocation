import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:sales/configs.dart';

class DocumentTypeProvider with ChangeNotifier {
  final String? accessToken;
  Map<String, dynamic>? _item;
  List<dynamic> _items = [];

  DocumentTypeProvider(this.accessToken, this._items);

  List<dynamic> get items {
    return [..._items];
  }

  Future<void> getDocumentTypes() async {
    final url = Configs.saModuleUrl + '/document-types?saAppApplied=1';
    try {
      final response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.contentTypeHeader: 'application/json',
        HttpHeaders.acceptHeader: 'application/json',
        HttpHeaders.authorizationHeader: 'Bearer ${accessToken.toString()}'
      });

      final extractedResult =
          json.decode(response.body) as Map<String, dynamic>;

      _items = extractedResult['data'];
      notifyListeners();
      
    } catch (error) {
      print(error.toString());
    }
  }

 
  notifyListeners();
}