import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:sales/configs.dart';

class ApplicationDocumentProvider with ChangeNotifier {
  final String? saAPIAccessToken;
  List<dynamic> _items = [];
  Map<String, dynamic>? _item;
  String? _responseMessage = "";

  ApplicationDocumentProvider(this.saAPIAccessToken, this._items);

  List<Map<String, dynamic>> get items {
    return [..._items];
  }

  Map<String, dynamic>? get item {
    return _item;
  }

  String? get responseMessage {
    return _responseMessage;
  }

  Future<void> getApplicationDocumentFiles(int applicationId) async {
    final url = Configs.saModuleUrl + '/applications/$applicationId';
    try {
      final response = await http.get(Uri.parse(url), headers: {
        HttpHeaders.contentTypeHeader: 'application/json',
        HttpHeaders.acceptHeader: 'application/json',
        HttpHeaders.authorizationHeader: 'Bearer ${saAPIAccessToken.toString()}'
      });

      final extractedResult = json.decode(response.body) as Map<String, dynamic>;
      final extractedData = extractedResult['data'];
      

      _item = Map<String, dynamic>.from(extractedData);
      _items = List<dynamic>.from(_item?['application']['files']);
      notifyListeners();

    } catch (error) {
      throw error;
    }
  }

  Future<void> createApplicationDocumentFile(int applicationId, Map<String, dynamic> documentInfo) async {
    var headers = {
      'Authorization': 'Bearer JWT token',
      HttpHeaders.authorizationHeader: 'Bearer $saAPIAccessToken'
    };
    final url = Configs.saModuleUrl + '/applications/$applicationId/files';
    var request = http.MultipartRequest(
      'POST', Uri.parse(url)
    );
    request.fields.addAll({
      'document_type_id': documentInfo['document_type_id'],
      'remark': documentInfo['remark']
    });
    request.files.add(await http.MultipartFile.fromPath('file', documentInfo['file']));

    request.headers.addAll(headers);
    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      String message = await response.stream.bytesToString();
      _responseMessage = json.decode(message)['message'];
    }
    else {
      _responseMessage = response.reasonPhrase;
    }

    print('response: ${response.toString()}');

    notifyListeners();
  }

  Future<void> deleteApplicationDocumentFile(int applicationId, int fileId) async {
    var headers = {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer JWT token',
      HttpHeaders.authorizationHeader: 'Bearer $saAPIAccessToken'
    };
    final url = Configs.saModuleUrl + '/applications/$applicationId/files/$fileId';
    var request = http.Request('DELETE', Uri.parse(url));

    request.headers.addAll(headers);
    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      String message = await response.stream.bytesToString();
      _responseMessage = json.decode(message)['message'];
    }
    else {
      _responseMessage = response.reasonPhrase;
      print(response.reasonPhrase);
    }

    notifyListeners();
  }
  
}
