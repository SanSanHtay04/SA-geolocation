export 'app_doc_det_provider.dart';
export 'app_doc_type_provider.dart';
export 'app_document_provider.dart';
export 'app_login_journal_provider.dart';
export 'app_upload_provider.dart';
export 'application_document_provider.dart';
export 'application_provider.dart';

export 'asset_provider.dart';
export 'asset_payment_provider.dart';
export 'auth_provider.dart';
export 'attached_product_provider.dart';

export 'brand_provider.dart';
export 'business_type_provider.dart';
export 'contract_provider.dart';

export 'customer_provider.dart';
export 'customer_household_provider.dart';
export 'customer_income_source_provider.dart';
export 'customer_contact_detail_provider.dart';

export 'document_type_provider.dart';
export 'education_provider.dart';
export 'fcm_push_notification_provider.dart';

export 'geo_district_provider.dart';
export 'geo_region_provider.dart';
export 'geo_town_provider.dart';
export 'geo_township_provider.dart';
export 'geo_village_provider.dart';
export 'geo_ward_provider.dart';

export 'ins_scheme_product_detail_provider.dart';
export 'job_category_provider.dart';
export 'local_auth_provider.dart';

export 'marital_status_provider.dart';
export 'merchant_provider.dart';
export 'nrc1_provider.dart';
export 'nrc2_provider.dart';
export 'ori_app_data_sync_provider.dart';
export 'origination_pos_provider.dart';

export 'payment_schedule_provider.dart';
export 'product_provider.dart';
export 'product_package_provider.dart';
export 'product_category_provider.dart';
export 'prospect_provider.dart';

export 'secondary_product_provider.dart';
export 'setup.dart';
export 'simulation_provider.dart';
export 'supplier_bank_account_provider.dart';
export 'user_provider.dart';
