import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:sales/configs.dart';
import 'package:sales/utils/utils.dart';

class ProductProvider with ChangeNotifier {
  final String? accessToken;
  List<Map<String, dynamic>> _items = [];
  Map<String, dynamic> _item = {};

  ProductProvider(this.accessToken, this._items);

  List<Map<String, dynamic>> get items {
    return [..._items];
  }

  Map<String, dynamic> get item {
    return _item;
  }

  Future<void> getAssignedProducts(int isZeroCost) async {
    final url = Configs.baseUrl +
        '/ref/merchant/product/is_zero_cost/$isZeroCost/all';
    try {
      if (accessToken != '') {
        final response = await http.get(
          Uri.parse(url),
          headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.acceptHeader: 'application/json',
            HttpHeaders.authorizationHeader: 'Bearer $accessToken'
          },
        );

        final extractedResult =
            json.decode(response.body) as Map<String, dynamic>?;
        if (extractedResult == null) {
          return;
        }
        debugPrint(extractedResult.toString());
        print('extractedResult: $extractedResult');
        final extractedData = extractedResult['data'];

        List<Map<String, dynamic>> productItems = List.from(extractedData);
        _items = productItems;
        notifyListeners();
      }
    } catch (error) {
      throw error;
    }
  }

  Future<void> getProducts(
      int? merchantId, int? posId, int? brandId, int? isZeroCost) async {
    final url = Configs.baseUrl +
        '/ref/merchant/$merchantId/pos/$posId/brand/$brandId/is_zero_cost/$isZeroCost';
    AppLogger.i('GET Products URL : $url');
    try {
      if (accessToken != '') {
        final response = await http.get(
          Uri.parse(url),
          headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.acceptHeader: 'application/json',
            HttpHeaders.authorizationHeader: 'Bearer $accessToken'
          },
        );

        final extractedResult =
            json.decode(response.body) as Map<String, dynamic>?;
        if (extractedResult == null) {
          return;
        }
        debugPrint(extractedResult.toString());
        print('extractedResult: $extractedResult');
        final extractedData = extractedResult['data'];

        List<Map<String, dynamic>> productItems = List.from(extractedData);
        _items = productItems;
        notifyListeners();
      }
    } catch (error) {
      throw error;
    }
  }
}
