import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:sales/configs.dart';

class AppDocumentProvider with ChangeNotifier {
  final String? accessToken;
  List<Map<String, dynamic>> _items = [];
  Map<String, dynamic> _item = {};

  AppDocumentProvider(this.accessToken, this._items);

  List<Map<String, dynamic>> get items {
    return [..._items];
  }

  Map<String, dynamic> get item {
    return _item;
  }

  Future<void> getAppDocsByProductType(
      String? strProductType, int? applicationId) async {
    final url = Configs.baseUrl +
        '/origination/app_doc/application/$applicationId/prod_type/$strProductType';
    try {
      if (accessToken != '') {
        final response = await http.get(
          Uri.parse(url),
          headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.acceptHeader: 'application/json',
            HttpHeaders.authorizationHeader: 'Bearer $accessToken'
          },
        );

        final extractedResult =
            json.decode(response.body) as Map<String, dynamic>?;
        if (extractedResult == null) {
          return;
        }
        print('extractedResult: $extractedResult');
        final extractedData = extractedResult['data'];

        List<Map<String, dynamic>> brandItems = List.from(extractedData);
        _items = brandItems;
        notifyListeners();
      }
    } catch (error) {
      throw error;
    }
  }

  Future<void> getAllAppDocsByProductType(String? strProductType) async {
    final url =
        Configs.baseUrl + '/origination/app_doc/prod_type/$strProductType';
    try {
      if (accessToken != '') {
        final response = await http.get(
          Uri.parse(url),
          headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.acceptHeader: 'application/json',
            HttpHeaders.authorizationHeader: 'Bearer $accessToken'
          },
        );

        final extractedResult =
            json.decode(response.body) as Map<String, dynamic>?;
        if (extractedResult == null) {
          return;
        }
        print('extractedResult: $extractedResult');
        final extractedData = extractedResult['data'];

        List<Map<String, dynamic>> brandItems = List.from(extractedData);
        _items = brandItems;
        notifyListeners();
      }
    } catch (error) {
      throw error;
    }
  }

  Future<void> getRecords() async {
    final url = Configs.baseUrl + '/origination/app_doc';
    try {
      if (accessToken != '') {
        final response = await http.get(
          Uri.parse(url),
          headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.acceptHeader: 'application/json',
            HttpHeaders.authorizationHeader: 'Bearer $accessToken'
          },
        );

        final extractedResult =
            json.decode(response.body) as Map<String, dynamic>?;
        if (extractedResult == null) {
          return;
        }
        print('extractedResult: $extractedResult');
        final extractedData = extractedResult['data'];

        List<Map<String, dynamic>> appDocs = List.from(extractedData);
        _items = appDocs;
        notifyListeners();
      }
    } catch (error) {
      throw error;
    }
  }
}
