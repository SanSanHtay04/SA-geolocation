import 'dart:async';

import 'package:flutter/material.dart';
import 'package:sales/data/local/prefs_store.dart';

class LocalAuthProvider with ChangeNotifier {
  final PrefsStore _prefsStore;
  late bool isLoggedIn;

  LocalAuthProvider(this._prefsStore) {
    isLoggedIn = _prefsStore.accessToken != null;
  }

  Future<void> logout() async {
    await _prefsStore.clearAccountInfo();
    isLoggedIn = false;
    refresh();
  }

  refresh() => notifyListeners();
}
