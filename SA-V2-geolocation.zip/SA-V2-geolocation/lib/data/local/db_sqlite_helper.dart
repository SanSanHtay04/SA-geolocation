import 'dart:async';
import 'dart:io' as io;

import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sales/data/local/models/models.dart';

class DBSqliteHelper {
  static Database? _db;

  // APP DATA SYNC //
  static const String SYNC_ID = 'syncId';
  static const String SYNC_FREQUENCY = 'frequency';
  static const String SYNC_NAME = 'syncName';
  static const String SYNC_VERSION = 'syncVersion';
  static const String SYNC_ONLINE_VERSION = 'onlineSyncVersion';
  static const String SYNC_REMARK = 'syncRemark';
  static const String SYNC_TABLE = 'APP_DATA_SYNC';

  // MARITAL STATUS //
  static const String MARITAL_STATUS_ID = 'maritalStatusId';
  static const String MARITAL_STATUS_NAME = 'maritalStatusName';
  static const String MARITAL_STATUS_ACTIVE = 'maritalStatusActive';
  static const String MARITAL_STATUS_TABLE = 'MARITAL_STATUS';

  // EDUCATION //
  static const String EDUCATION_ID = 'educationId';
  static const String EDUCATION_ORDER = 'educationOrder';
  static const String EDUCATION_NAME = 'educationName';
  static const String EDUCATION_TABLE = 'EDUCATION';

  // BUSINESS TYPE //
  static const String BUSINESS_TYPE_ID = 'businessTypeId';
  static const String BUSINESS_TYPE_NAME = 'businessTypeName';
  static const String BUSINESS_TYPE_ACTIVE = 'businessTypeActive';
  static const String SELF_EMPLOYED_APPLIED = 'selfEmployedApplied';
  static const String EMPLOYED_APPLIED = 'employedApplied';
  static const String UNEMPLOYED_APPLIED = 'unemployedApplied';
  static const String BUSINESS_TYPE_TABLE = 'BUSINESS_TYPE';

  // JOB CATEGORY //
  static const String JOB_CATEGORY_ID = 'jobCategoryId';
  static const String JOB_CATEGORY_NAME = 'jobCategoryName';
  static const String JOB_CATEGORY_ACTIVE = 'jobCategoryActive';
  static const String SELF_EMPLOYED = 'selfemployed';
  static const String JOB_CATEGORY_TABLE = 'JOB_CATEGORY';

  // GEO REGION //
  static const String GEO_REGION_ID = 'geoRegionId';
  static const String GEO_REGION_NAME = 'geoRegionName';
  static const String GEO_REGION_TABLE = 'GEO_REGION';

  // GEO DISTRICT //
  static const String GEO_DISTRICT_ID = 'geoDistrictId';
  static const String GEO_DISTRICT_NAME = 'geoDistrictName';
  static const String GEO_DISTRICT_TABLE = 'GEO_DISTRICT';

  // GEO TOWN SHIP //
  static const String GEO_TOWN_SHIP_ID = 'geoTownShipId';
  static const String GEO_TOWN_SHIP_NAME = 'geoTownShipName';
  static const String GEO_TOWN_SHIP_TABLE = 'GEO_TOWN_SHIP';

  // GEO TOWN //
  static const String GEO_TOWN_ID = 'geoTownId';
  static const String GEO_TOWN_NAME = 'geoTownName';
  static const String GEO_TOWN_IS_VILLAGE = 'isVillage';
  static const String GEO_TOWN_TABLE = 'GEO_TOWN';

  // GEO WARD //
  static const String GEO_WARD_ID = 'geoWardId';
  static const String GEO_WARD_NAME = 'geoWardName';
  static const String GEO_WARD_TABLE = 'GEO_WARD';

  // GEO VILLAGE //
  static const String GEO_VILLAGE_ID = 'geoVillageId';
  static const String GEO_VILLAGE_NAME = 'geoVillageName';
  static const String GEO_VILLAGE_TABLE = 'GEO_VILLAGE';

  // MERCHANT //
  static const String MERCHANT_ID = 'merchantId';
  static const String MERCHANT_NAME = 'merchantName';
  static const String MERCHANT_ADDRESS = 'merchantAddress';
  static const String MERCHANT_TABLE = 'MERCHANT';

  // POS //
  static const String POS_ID = 'posId';
  static const String POS_CATEGORY = 'posCategory';
  static const String POS_PRODUCT_TYPE = 'posProductType';
  static const String POS_NAME = 'posName';
  static const String POS_ADDRESS = 'posAddress';
  static const String POS_TABLE = 'POS';

  // BRAND //
  static const String BRAND_DET_ID = 'brandDetId';
  static const String BRAND_ID = 'brandId';
  static const String BRAND_CODE = 'brandCode';
  static const String BRAND_NAME = 'brandName';
  static const String BRAND_CATEGORY = 'brandCategory';
  static const String BRAND_IS_ZERO_COST = 'isZeroCost';
  static const String BRAND_TABLE = 'BRAND';

  // BRAND ZC //
  static const String BRAND_ZC_TABLE = 'BRAND_ZC';

  // PRODUCT //
  static const String PRODUCT_DET_ID = 'productDetId';
  static const String PRODUCT_ID = 'productId';
  static const String PRODUCT_CODE = 'productCode';
  static const String PRODUCT_NAME = 'productName';
  static const String PRODUCT_MODEL_NAME = 'modelName';
  static const String PRODUCT_PRICE = 'productPrice';
  static const String PRODUCT_CATEGORY_ID = "productCategoryId";
  static const String PRODUCT_PMT_TYPE = 'pmtType';
  static const String PRODUCT_INTEREST_RATE = 'interestRate';
  static const String PRODUCT_PMT_PERIODICITY = 'pmtPeriodicity';
  static const String PRODUCT_ADMIN_FEE_PERCENTAGE = 'adminFeePercentage';
  static const String PRODUCT_END_DURATION_MIN = 'endDurationMin';
  static const String PRODUCT_END_DURATION_MAX = 'endDurationMax';
  static const String PRODUCT_END_DURATION_INTERVAL = 'endDurationInterval';
  static const String PRODUCT_END_DEPOSIT_PERCENTAGE_MIN = 'endDepositPercentageMin';
  static const String PRODUCT_END_DEPOSIT_PERCENTAGE_MAX = 'endDepositPercentageMax';
  static const String PRODUCT_END_DEPOSIT_PERCENTAGE_INTERVAL = 'endDepositPercentageInterval';
  static const String PRODUCT_DURATION_MIN = 'durationMin';
  static const String PRODUCT_DURATION_INTERVAL = 'durationInterval';
  static const String PRODUCT_MIN_AMOUNT_FINANCED = 'minAmountFinanced';
  static const String PRODUCT_MIN_INSTALLMENT_AMOUNT = 'minInstallmentAmount';
  static const String PRODUCT_OTP_FEE_PERCENTAGE = 'otpFeePercentage';
  static const String PRODUCT_MERCHANT_DISCOUNT_RATE = 'merchantDiscountRate';
  static const String PRODUCT_IS_PRICE_LOCKED = 'isPriceLocked';
  static const String PRODUCT_FINANCIAL_SCHEME_ID = 'financialSchemeId';
  static const String PRODUCT_FINANCIAL_SCHEME_CODE = 'financialSchemeCode';
  static const String PRODUCT_FINANCIAL_SCHEME_NAME = 'financialSchemeName';
  static const String PRODUCT_IS_ZERO_COST = 'isZeroCost';
  static const String PRODUCT_ZERO_COST_PMT_TIMES = 'zeroCostPmtTimes';
  static const String PRODUCT_MAINT_SCHEME_ID = 'maintSchemeId';
  static const String PRODUCT_MAINT_SCHEME_CODE = 'maintSchemeCode';
  static const String PRODUCT_MAINT_SCHEME_NAME = 'maintSchemeName';
  static const String PRODUCT_COST_PER_VISIT = 'costPerVisit';
  static const String PRODUCT_INTERVAL_OF_VISIT = 'intervalOfVisit';
  static const String PRODUCT_INS_SCHEME_ID = 'insSchemeId';
  static const String PRODUCT_INS_SCHEME_CODE = 'insSchemeCode';
  static const String PRODUCT_INS_SCHEME_NAME = 'insSchemeName';
  static const String PRODUCT_INS_FIXED_COST = 'insFixedCost';
  static const String PRODUCT_INS_VARIABLE_COST = 'insVariableCost';
  static const String PRODUCT_INS_VARIABLE_COST_APPLIED = 'insVariableCostApplied';
  static const String PRODUCT_INS_VARIABLE_CUSTOM_VALUE_APPLIED = 'insVariableCustomValueApplied';
  static const String PRODUCT_TABLE = 'PRODUCT';

  // PRODUCT ZC //
  static const String PRODUCT_ZC_TABLE = 'PRODUCT_ZC';

  // INSURANCE SCHEME DETAIL ZC//
  static const String INS_SCHEME_DET_ZC_TABLE = "INS_SCHEME_DET_ZC";

  // NRC1 //
  static const String NRC1_ID = 'nrc1Id';
  static const String NRC1_NAME = 'nrc1Name';
  static const String NRC1_TABLE = 'NRC1';

  // NRC2 //
  static const String NRC2_ID = 'nrc2Id';
  static const String NRC2_NAME = 'nrc2Name';
  static const String NRC2_TABLE = 'NRC2';

  // PROSPECT //
  static const String PROSPECT_ID = 'prospectId';
  static const String PROSPECT_POS_ID = 'posId';
  static const String PROSPECT_NAME = 'prospectName';
  static const String PROSPECT_GENDER = 'prospectGender';
  static const String PROSPECT_MOBILE = 'prospectMobile';
  static const String PROSPECT_OTHER_MOBILE = 'prospectOtherMobile';
  static const String PROSPECT_REMARK = 'prospectRemark';
  static const String PROSPECT_CREATED_CUST_ID = 'createdCustId';
  static const String PROSPECT_SUBMITTED_APP_ID = 'submittedAppId';
  static const String PROSPECT_AWARENESS_CODE = 'awarenessCode';
  static const String PROSPECT_DIRECT_SALES = 'directSales';
  static const String PROSPECT_TABLE = "PROSPECT";

  // TABLE NAME //
  static const String PRODUCT_PACKAGE_TABLE = "PRODUCT_PACKAGE";
  static const String PRODUCT_CATEGORY_TABLE = "PRODUCT_CATEGORY";
  static const String FIN_SCHEME_PRODUCT_TABLE = "FIN_SCHEME_PRODUCT";
  static const String INS_SCHEME_PRODUCT_TABLE = "INS_SCHEME_PRODUCT";
  static const String SIMULATION_TABLE = "SIMULATION";
  static const String PAYMENT_SCHEDULE_TABLE = "PAYMENT_SCHEDULE";
  static const String USER_TABLE = "USER";
  static const String APPLICATION_TABLE = "APPLICATION";
  static const String CUSTOMER_TABLE = "CUSTOMER";
  static const String CUSTOMER_INCOME_SOURCE_TABLE = "CUSTOMER_INCOME_SOURCE";
  static const String CUSTOMER_HOUSEHOLD_TABLE = "CUSTOMER_HOUSEHOLD";
  static const String CUSTOMER_CONTACT_DETAIL_TABLE = "CUSTOMER_CONTACT_DETAIL";
  static const String APP_DOC_TYPE_TABLE = "APP_DOC_TYPE";
  static const String APP_DOCUMENT_TABLE = "APP_DOCUMENT";
  static const String APP_DOC_DETAIL_TABLE = "APP_DOC_DETAIL";
  static const String APP_UPLOAD_TABLE = "APP_UPLOAD";
  static const String SECONDARY_PRODUCT_TABLE = "SECONDARY_PRODUCT";
  static const String SUPPLIER_BANK_ACCOUNT_TABLE = "SUPPLIER_BANK_ACCOUNT";
  static const String ATTACHED_PRODUCT_TABLE = "ATTACHED_PRODUCT";
  static const String SYNC_DETAIL_TABLE = 'APP_DATA_DETAIL_SYNC';

  Future<Database> get db async {
    if (_db == null) {
      _db = await initDb();
    }
    return _db!;
  }

  Future<Database> initDb() async {
    io.Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, "originations.db");
    var db = await openDatabase(path, version: 1, onCreate: _onCreate);
    return db;
  }

  _onCreate(Database db, int version) async {
    // CATEGORIES //
    await db.execute("CREATE TABLE $SYNC_TABLE ($SYNC_ID INTEGER PRIMARY KEY, $SYNC_FREQUENCY TEXT, $SYNC_NAME TEXT, $SYNC_VERSION TEXT, $SYNC_ONLINE_VERSION TEXT, $SYNC_REMARK TEXT)");
    await db.execute("CREATE TABLE $SYNC_DETAIL_TABLE (syncDetId INTEGER PRIMARY KEY, syncId INTEGER, tableName TEXT, syncVersion TEXT)");
    await db.execute("CREATE TABLE $MARITAL_STATUS_TABLE ($MARITAL_STATUS_ID INTEGER PRIMARY KEY, $MARITAL_STATUS_NAME TEXT, $MARITAL_STATUS_ACTIVE INTEGER)");
    await db.execute("CREATE TABLE $EDUCATION_TABLE ($EDUCATION_ID INTEGER PRIMARY KEY, $EDUCATION_ORDER INTEGER, $EDUCATION_NAME TEXT)");
    await db.execute("CREATE TABLE $BUSINESS_TYPE_TABLE ($BUSINESS_TYPE_ID INTEGER PRIMARY KEY, $BUSINESS_TYPE_NAME TEXT, $BUSINESS_TYPE_ACTIVE INTEGER, $SELF_EMPLOYED_APPLIED INTEGER, $EMPLOYED_APPLIED INTEGER, $UNEMPLOYED_APPLIED INTEGER)");
    await db.execute("CREATE TABLE $JOB_CATEGORY_TABLE ($JOB_CATEGORY_ID INTEGER PRIMARY KEY, $BUSINESS_TYPE_ID INTEGER, $JOB_CATEGORY_NAME TEXT, $JOB_CATEGORY_ACTIVE INTEGER, $SELF_EMPLOYED INTEGER)");
    await db.execute("CREATE TABLE $GEO_REGION_TABLE ($GEO_REGION_ID INTEGER PRIMARY KEY, $GEO_REGION_NAME TEXT)");
    await db.execute("CREATE TABLE $GEO_DISTRICT_TABLE ($GEO_DISTRICT_ID INTEGER PRIMARY KEY, $GEO_REGION_ID INTEGER, $GEO_DISTRICT_NAME TEXT)");
    await db.execute("CREATE TABLE $GEO_TOWN_SHIP_TABLE ($GEO_TOWN_SHIP_ID INTEGER PRIMARY KEY, $GEO_DISTRICT_ID INTEGER, $GEO_TOWN_SHIP_NAME TEXT)");
    await db.execute("CREATE TABLE $GEO_TOWN_TABLE ($GEO_TOWN_ID INTEGER PRIMARY KEY, $GEO_TOWN_SHIP_ID INTEGER, $GEO_TOWN_NAME TEXT, $GEO_TOWN_IS_VILLAGE INTEGER)");
    await db.execute("CREATE TABLE $GEO_WARD_TABLE ($GEO_WARD_ID INTEGER PRIMARY KEY, $GEO_TOWN_ID INTEGER, $GEO_WARD_NAME TEXT)");
    await db.execute("CREATE TABLE $GEO_VILLAGE_TABLE ($GEO_VILLAGE_ID INTEGER PRIMARY KEY, $GEO_TOWN_ID INTEGER, $GEO_VILLAGE_NAME TEXT)");
    await db.execute("CREATE TABLE $MERCHANT_TABLE ($MERCHANT_ID INTEGER PRIMARY KEY, $MERCHANT_NAME TEXT, $MERCHANT_ADDRESS TEXT)");
    await db.execute("CREATE TABLE $POS_TABLE ($POS_ID INTEGER PRIMARY KEY, $MERCHANT_ID INTEGER, $POS_CATEGORY TEXT, $POS_PRODUCT_TYPE TEXT, $POS_NAME TEXT, $POS_ADDRESS TEXT)");
    await db.execute("CREATE TABLE $BRAND_TABLE ($BRAND_DET_ID INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, $BRAND_ID INTEGER, $POS_ID INTEGER, $BRAND_IS_ZERO_COST INTEGER, $BRAND_CODE TEXT, $BRAND_NAME TEXT, $BRAND_CATEGORY TEXT)");
    await db.execute("CREATE TABLE $PRODUCT_TABLE ($PRODUCT_DET_ID INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, $PRODUCT_ID INTEGER, $BRAND_ID INTEGER, $POS_ID INTEGER, $MERCHANT_ID INTEGER, $PRODUCT_CODE TEXT, $PRODUCT_NAME TEXT, $PRODUCT_MODEL_NAME TEXT, $PRODUCT_PRICE INTEGER, $PRODUCT_CATEGORY_ID INTEGER, $PRODUCT_PMT_TYPE TEXT, $PRODUCT_INTEREST_RATE INTEGER, $PRODUCT_PMT_PERIODICITY INTEGER, " +
        "$PRODUCT_ADMIN_FEE_PERCENTAGE INTEGER, $PRODUCT_END_DURATION_MIN INTEGER, $PRODUCT_END_DURATION_MAX INTEGER, $PRODUCT_END_DURATION_INTERVAL INTEGER, $PRODUCT_END_DEPOSIT_PERCENTAGE_MIN INTEGER, $PRODUCT_END_DEPOSIT_PERCENTAGE_MAX INTEGER, " +
        "$PRODUCT_END_DEPOSIT_PERCENTAGE_INTERVAL INTEGER, $PRODUCT_DURATION_MIN INTEGER, $PRODUCT_DURATION_INTERVAL INTEGER, $PRODUCT_MIN_AMOUNT_FINANCED INTEGER, $PRODUCT_MIN_INSTALLMENT_AMOUNT INTEGER, $PRODUCT_OTP_FEE_PERCENTAGE INTEGER, $PRODUCT_MERCHANT_DISCOUNT_RATE INTEGER, " +
        "$PRODUCT_IS_PRICE_LOCKED INTEGER, $PRODUCT_FINANCIAL_SCHEME_ID INTEGER, $PRODUCT_FINANCIAL_SCHEME_CODE TEXT, $PRODUCT_FINANCIAL_SCHEME_NAME TEXT, $PRODUCT_IS_ZERO_COST INTEGER, $PRODUCT_ZERO_COST_PMT_TIMES INTEGER, " +
        "$PRODUCT_MAINT_SCHEME_ID INTEGER, $PRODUCT_MAINT_SCHEME_CODE TEXT, $PRODUCT_MAINT_SCHEME_NAME TEXT, $PRODUCT_COST_PER_VISIT INTEGER, $PRODUCT_INTERVAL_OF_VISIT INTEGER, $PRODUCT_INS_SCHEME_ID INTEGER, $PRODUCT_INS_SCHEME_CODE TEXT, $PRODUCT_INS_SCHEME_NAME TEXT, " +
        "$PRODUCT_INS_FIXED_COST INTEGER, $PRODUCT_INS_VARIABLE_COST TEXT, $PRODUCT_INS_VARIABLE_COST_APPLIED TEXT, $PRODUCT_INS_VARIABLE_CUSTOM_VALUE_APPLIED TEXT, earlyPrepaymentPercentage INTEGER)");
    await db.execute("CREATE TABLE $NRC1_TABLE ($NRC1_ID INTEGER PRIMARY KEY, $NRC1_NAME TEXT)");
    await db.execute("CREATE TABLE $NRC2_TABLE ($NRC2_ID INTEGER PRIMARY KEY, $NRC1_ID INTEGER, $NRC2_NAME TEXT)");
    await db.execute("CREATE TABLE $APP_DOC_TYPE_TABLE (docTypeId INTEGER PRIMARY KEY, docTypeName TEXT)");
    await db.execute("CREATE TABLE $APP_DOCUMENT_TABLE (documentId INTEGER PRIMARY KEY, docTypeId INTEGER, docProductType TEXT, documentCode TEXT, documentName TEXT, documentRemark TEXT)");

    // PROSPECT //
    await db.execute("CREATE TABLE $PROSPECT_TABLE ($PROSPECT_ID INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, $PROSPECT_POS_ID INTEGER, $PROSPECT_NAME TEXT, $PROSPECT_GENDER TEXT, $PROSPECT_MOBILE TEXT, $PROSPECT_OTHER_MOBILE TEXT, $PROSPECT_REMARK TEXT, " + "$PROSPECT_CREATED_CUST_ID INTEGER, $PROSPECT_SUBMITTED_APP_ID INTEGER, $PROSPECT_AWARENESS_CODE TEXT, $PROSPECT_DIRECT_SALES INTEGER)");
    // PRODUCT PACKAGE //
    await db.execute("CREATE TABLE $PRODUCT_PACKAGE_TABLE (packageId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, productId INTEGER, isBundle INTEGER, quantity INTEGER, primaryUnitPrice INTEGER, primaryTotalPrice INTEGER, packageTotalPrice INTEGER, financialSchemeId INTEGER, " +
        "financialSchemeName TEXT, insuranceCovered INTEGER, maintenanceCovered INTEGER, prospectId INTEGER, lockedContractId INTEGER, isMultiProduct INTEGER, paymentAtEnd INTEGER, minAmountFinanced INTEGER, minInstallmentAmount INTEGER, otpFeePercentage INTEGER, " +
        "earlyPrepaymentPercentage INTEGER, merchantDiscountRate INTEGER, isZeroCost INTEGER, zeroCostPmtTimes INTEGER, zeroCostTotalInsCost INTEGER, zeroCostTotalMaintCost INTEGER, isPriceLocked INTEGER, allowedInterestRate REAL, allowedDurationMin INTEGER, " +
        "allowedDurationMax INTEGER, allowedDurationInterval INTEGER, allowedDepositPercentageMin INTEGER, allowedDepositPercentageMax INTEGER, allowedDepositPercentageInterval INTEGER, allowedPmtPeriodicity TEXT, allowedAdminFeePercentage INTEGER, " +
        "totalMonthlyMaintCostPerVisit INTEGER, totalInsFixedCost INTEGER, totalInsVariableCostCV INTEGER, totalInsVariableCostEV INTEGER, totalInsVariableCostAF REAL, packageRemark TEXT, maintSchemeId INTEGER, maintSchemeName TEXT, costPerVisit INTEGER, " +
        "intervalOfVisit INTEGER)");
    // PRODUCT CATEGORY //
    await db.execute("CREATE TABLE $PRODUCT_CATEGORY_TABLE (productCategoryId INTEGER PRIMARY KEY, productCategoryType TEXT, productCategoryCode TEXT, productCategoryName TEXT)");
    await db.execute("CREATE TABLE $FIN_SCHEME_PRODUCT_TABLE (finSchemeProductDetId INTEGER PRIMARY KEY, financialSchemeId INTEGER, productId INTEGER, paymentAtEnd INTEGER, depositPercentage INTEGER, interestRate REAL, tenureExclusion TEXT, adminFeePercentage REAL, annualFixedEnvironmentalCost INTEGER, loyaltyInterestRate REAL, loyaltyAdminFeePercentage REAL)");
    await db.execute("CREATE TABLE $INS_SCHEME_PRODUCT_TABLE (insSchemeProductDetId INTEGER PRIMARY KEY, insSchemeId INTEGER, insSchemeName TEXT, productId INTEGER, insFixedCost INTEGER, insVariableCost INTEGER, insVariableCostApplied TEXT, insVariableCustomValueApplied INTEGER, isZeroCost INTEGER)");
    await db.execute("CREATE TABLE $SIMULATION_TABLE (simulationId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, isZeroCost INTEGER, zeroCostPmtTimes INTEGER, zeroCostTotalInsCost INTEGER, zeroCostTotalMaintCost INTEGER, zeroCostMonthlyPaymentAmount INTEGER, " +
        "insuranceCovered INTEGER, maintenanceCovered INTEGER, applicationId INTEGER, packageId INTEGER, prospectId INTEGER, posId INTEGER, salesAreaId INTEGER, simulationDate TEXT, adminFee INTEGER, adminFeePercentage REAL, assetPrice INTEGER, totalPrice INTEGER, " +
        "merchantDiscountRate INTEGER, merchantDiscountAmount INTEGER, effectiveAssetPrice INTEGER, effectiveAmountFinanced INTEGER, effectiveInterestRate REAL, depositAmount INTEGER, depositPercentage INTEGER, amountFinanced INTEGER, " +
        "duration INTEGER, interestRate REAL, pmtPeriodicity TEXT, paymentAtEnd INTEGER, minAmountFinanced INTEGER, minInstallmentAmount INTEGER, otpFeePercentage INTEGER, earlyPrepaymentPercentage INTEGER DEFAULT 0, earlyPrepaymentAmount INTEGER DEFAULT 0, " +
        "accPmtShare REAL, accPmtMonthlyShare REAL, firstPayment INTEGER, actualFirstPayment INTEGER, followingPayment INTEGER, accMonthlyPaymentAmount REAL, accMonthlyLastPaymentAmount REAL, accPaymentAmount REAL, accLastPaymentAmount REAL, " +
        "netRentalFee INTEGER, rentalFeeInsCostAddUp INTEGER, rentalFeeMaintCostAddUp INTEGER, rentalFeeEnvCostAddUp INTEGER, amountPayable INTEGER, amountFinancedAdminFeeAddUp INTEGER DEFAULT 0, simDuration INTEGER)");
    await db.execute("CREATE TABLE $PAYMENT_SCHEDULE_TABLE (paymentId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, simulationId INTEGER, lockedContractId INTEGER, paymentNo TEXT, " +
        "pmtPeriodicity INTEGER, paymentAtEnd INTEGER, originalDueDate TEXT, dueDate TEXT, expiredDate TEXT, lockedPeriod INTEGER, lastPayment INTEGER, paymentAmount INTEGER, accPaymentAmount REAL, totalAmount INTEGER, " +
        "remainingPrincipal INTEGER, remainingInterest INTEGER, effectivePrincipalPayment INTEGER, effectiveInterestPayment INTEGER, addedCost INTEGER, remainingProductValue INTEGER, effectiveRemainingProductValue INTEGER, " +
        "otpFeeAmount INTEGER, otpAmount INTEGER, partialZeroCostOtpAmount INTEGER)");
    await db.execute("CREATE TABLE $USER_TABLE (userId INTEGER PRIMARY KEY, userName TEXT, userFullName TEXT, noticeMobile TEXT, noticeMobile2 TEXT, noticeEmail TEXT, noticeEmail2 TEXT)");
    await db.execute("CREATE TABLE $APPLICATION_TABLE (applicationId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, applicationPlaceId INTEGER, prospectId INTEGER, customerId INTEGER, personDesignatedTo INTEGER)");
    await db.execute("CREATE TABLE $CUSTOMER_TABLE (customerId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, firstName TEXT, middleName TEXT, lastName TEXT, customerFullName TEXT, birthDate TEXT," +
        " gender TEXT, homeStatus TEXT, drivingLicenseNo TEXT, fatherName TEXT, fatherBirthDate TEXT, educationId INTEGER, nrc2Id INTEGER, nrcType TEXT, nonNrcPrefix TEXT, nrcDetail TEXT, natRegCardNo TEXT, natRegCardIssDate TEXT," +
        " maritalStatusId INTEGER, spouseName TEXT, spouseMobileNo TEXT, spouseMobileStatus TEXT, spouseNrc2Id INTEGER, spouseNrcType TEXT, spouseNonNrcPrefix TEXT, spouseNrcDetail TEXT, spouseNatRegCardNo TEXT," +
        " homeAddress TEXT, geoTownShipId INTEGER, geoTownId INTEGER, geoWardId INTEGER, geoVillageId INTEGER, childrenHousehold INTEGER, relativeHousehold INTEGER, otherHousehold INTEGER, totalHousehold INTEGER," +
        " phoneNo1 TEXXT, phoneStatus1 TEXT, phoneType1 TEXT, phoneRemark1 TEXT, phoneNo2 TEXT, phoneNo3 TEXT, emailAddress TEXT, hasViberAccount INTEGER, isViberAccountSameNo INTEGER, viberAccountNo TEXT," +
        " internalFraudCode TEXT, ownedMotorcycle INTEGER, takenHirePurchaseContract INTEGER, takenMicroFinanceLoan INTEGER, motoFinancingRemark TEXT, customerRemark TEXT)");
    await db.execute("CREATE TABLE $CUSTOMER_INCOME_SOURCE_TABLE (incomeSourceId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, customerId INTEGER, selfemployed INTEGER, businessTypeId INTEGER, jobCategoryId INTEGER, workplaceName TEXT," + " workplaceFixedTel TEXT, workplaceAddress TEXT, incomePeriodicity INTEGER, incomeAmount INTEGER, incomeSourceRemark TEXT, exclusionList INTEGER, exclusionListRemark TEXT)");
    await db.execute("CREATE TABLE $CUSTOMER_HOUSEHOLD_TABLE (householdId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, customerId INTEGER, householdName TEXT, householdMobileNo TEXT, otherMobileNo TEXT, incomeEarner INTEGER," + " incomePeriodicity TEXT, incomeAmount INTEGER, nrc2Id INTEGER, nrcType TEXT, nonNrcPrefix TEXT, nrcDetail TEXT, natRegCardNo TEXT, natRegCardIssDate TEXT, householdRemark TEXT)");
    await db.execute("CREATE TABLE $CUSTOMER_CONTACT_DETAIL_TABLE (contactDetId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, customerId INTEGER," +
        " relationFullName TEXT, relationDetail TEXT, relationGender TEXT, contactValue TEXT, contactTypeId INTEGER, otherContactValue TEXT, homeAddress TEXT, contactDetRemark TEXT," +
        " nrc2Id INTEGER, nrcType TEXT, nonNrcPrefix TEXT, nrcDetail TEXT, natRegCardNo TEXT, natRegCardIssDate TEXT," +
        " contactRole TEXT, selfemployed INTEGER, businessTypeId INTEGER, jobCategoryId INTEGER, workplaceName TEXT, workplaceFixedTel TEXT, workplaceAddress TEXT, incomePeriodicity INTEGER, incomeAmount INTEGER, incomeSourceRemark TEXT)");
    await db.execute("CREATE TABLE $APP_DOC_DETAIL_TABLE (docDetId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, applicationId INTEGER, documentId INTEGER, docDetRemark TEXT)");
    await db.execute("CREATE TABLE $APP_UPLOAD_TABLE (uploadId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, applicationId INTEGER, documentId INTEGER, uploadName TEXT, uploadDesc TEXT, fileData TEXT)");
    await db.execute("CREATE TABLE $SECONDARY_PRODUCT_TABLE (secProductId INTEGER PRIMARY KEY, secProductName TEXT, secProductType TEXT, secProductRetalPrice INTEGER, secProductMerchantDiscountRate INTEGER, secProductRemark TEXT, bankAccountId INTEGER)");
    await db.execute("CREATE TABLE $SUPPLIER_BANK_ACCOUNT_TABLE (bankAccountId INTEGER PRIMARY KEY, supplierName TEXT, bankName TEXT, beneficiary TEXT, accountNo TEXT, accountRemark TEXT)");
    await db.execute("CREATE TABLE $ATTACHED_PRODUCT_TABLE (attachedProductId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, packageId INTEGER, assetId INTEGER, contractId INTEGER, secProductId INTEGER," +
        " productName TEXT, productType TEXT, productTypeDetail TEXT, productRemark TEXT," +
        " quantity INTEGER, productPrice INTEGER, totalPrice INTEGER, merchantDiscountRate INTEGER, merchantDiscountAmount INTEGER, merchantPaymentAmount INTEGER, merchantId INTEGER, bankAccountId INTEGER," +
        " supplierName TEXT, bankName TEXT, beneficiary TEXT, accountNo TEXT, accountRemark TEXT)");
  }

  // _onOpen(Database db) async {
  //   await db.execute("DROP TABLE $SYNC_TABLE");
  //   await db.execute("CREATE TABLE IF NOT EXISTS $SYNC_TABLE ($SYNC_ID INTEGER PRIMARY KEY, $SYNC_FREQUENCY TEXT, $SYNC_NAME TEXT, $SYNC_VERSION TEXT, $SYNC_REMARK TEXT)");
  // }

  Future<void> create(Database db, int version) async {
    await db.execute("CREATE TABLE IF NOT EXISTS $SYNC_TABLE ($SYNC_ID INTEGER PRIMARY KEY, $SYNC_FREQUENCY TEXT, $SYNC_NAME TEXT, $SYNC_VERSION TEXT, $SYNC_REMARK TEXT)");
  }

  //
  // APP DATA SYNC Functions //
  //
  Future<List<AppDataSync>> syncAppData(List<AppDataSync> appDataList) async {
    var dbClient = await db;
    dbClient.delete(SYNC_TABLE);
    appDataList.forEach((element) async {
      element.syncId = await dbClient.insert(SYNC_TABLE, element.toMap());
    });
    return appDataList;
  }

  Future<AppDataSync> createDataSync(AppDataSync dataSync) async {
    var dbClient = await db;
    dataSync.syncId = await dbClient.insert(SYNC_TABLE, dataSync.toMap());
    return dataSync;
  }

  Future<List<AppDataSync>> createDataSyncs(List<AppDataSync> dataSyncList) async {
    var dbClient = await db;
    dbClient.delete(SYNC_TABLE);
    dataSyncList.forEach((element) async {
      element.syncId = await dbClient.insert(SYNC_TABLE, element.toMap());
    });
    return dataSyncList;
  }

  Future<List<AppDataSync>> getDataSyncs() async {
    var dbClient = await db;
    List<Map> maps = await dbClient.query(SYNC_TABLE, columns: [SYNC_ID, SYNC_FREQUENCY, SYNC_NAME, SYNC_VERSION, SYNC_ONLINE_VERSION, SYNC_REMARK]);
    List<AppDataSync> dataSyncs = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        dataSyncs.add(AppDataSync.fromMap(maps[i] as Map<String, dynamic>));
      }
    }
    return dataSyncs;
  }

  Future<int> deleteDataSync(int id) async {
    var dbClient = await db;
    return await dbClient.delete(SYNC_TABLE, where: '$SYNC_ID = ?', whereArgs: [id]);
  }

  Future<int> updateDataSync(AppDataSync item) async {
    var dbClient = await db;
    return await dbClient.update(SYNC_TABLE, item.toMap(), where: '$SYNC_ID = ?', whereArgs: [item.syncId]);
  }

  //
  // APP DATA DETAIL SYNC Functions //
  //
  Future<List<AppDataDetailSync>> syncAppDataDetail(List<AppDataDetailSync> appDataDetailList) async {
    var dbClient = await db;
    dbClient.delete(SYNC_DETAIL_TABLE);
    appDataDetailList.forEach((element) async {
      element.syncDetId = await dbClient.insert(SYNC_DETAIL_TABLE, element.toMap());
    });
    return appDataDetailList;
  }

  Future<List<AppDataDetailSync>> getAllDataDetailSyncs() async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $SYNC_DETAIL_TABLE.*" + " FROM $SYNC_DETAIL_TABLE");
    List<AppDataDetailSync> dataSyncs = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        dataSyncs.add(AppDataDetailSync.fromMap(maps[i] as Map<String, dynamic>));
      }
    }
    print('dataSyncs, $dataSyncs');
    return dataSyncs;
  }

  Future<List<AppDataDetailSync>> getDataDetailSyncs(int syncId) async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $SYNC_DETAIL_TABLE.*" + " FROM $SYNC_DETAIL_TABLE" + " WHERE $SYNC_DETAIL_TABLE.syncId = $syncId");
    List<AppDataDetailSync> dataSyncs = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        dataSyncs.add(AppDataDetailSync.fromMap(maps[i] as Map<String, dynamic>));
      }
    }
    return dataSyncs;
  }

  Future<int> updateDataDetailSync(AppDataDetailSync item) async {
    var dbClient = await db;
    return await dbClient.update(SYNC_DETAIL_TABLE, item.toMap(), where: 'syncDetId = ?', whereArgs: [item.syncDetId]);
  }

  //
  // MARITIAL STATUS Functions //
  //
  Future<List<MaritalStatus>> syncMaritalStatus(List<MaritalStatus> mstatList) async {
    var dbClient = await db;
    dbClient.delete(MARITAL_STATUS_TABLE);
    mstatList.forEach((element) async {
      element.maritalStatusId = await dbClient.insert(MARITAL_STATUS_TABLE, element.toMap());
    });
    return mstatList;
  }

  Future<List<Map<String, dynamic>>> getMaritalStatuses() async {
    var dbClient = await db;
    List<Map> maps = await dbClient.query(MARITAL_STATUS_TABLE, columns: [MARITAL_STATUS_ID, MARITAL_STATUS_NAME], where: '$MARITAL_STATUS_ACTIVE = ?', whereArgs: [1], orderBy: "$MARITAL_STATUS_NAME ASC");
    List<Map<String, dynamic>> maritalStatuses = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        maritalStatuses.add(maps[i] as Map<String, dynamic>);
      }
    }
    return maritalStatuses;
  }

  //
  // EDUCATION Functions //
  //
  Future<List<Education>> syncEducation(List<Education> eduList) async {
    var dbClient = await db;
    dbClient.delete(EDUCATION_TABLE);
    eduList.forEach((element) async {
      element.educationId = await dbClient.insert(EDUCATION_TABLE, element.toMap());
    });
    return eduList;
  }

  Future<List<Map<String, dynamic>>> getEducations() async {
    var dbClient = await db;
    List<Map> maps = await dbClient.query(EDUCATION_TABLE, columns: [EDUCATION_ID, EDUCATION_NAME], orderBy: "$EDUCATION_ORDER ASC");
    List<Map<String, dynamic>> educations = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        educations.add(maps[i] as Map<String, dynamic>);
      }
    }
    return educations;
  }

  //
  // BUSINESS TYPE Functions //
  //
  Future<List<BusinessType>> syncBusinessType(List<BusinessType> btypeList) async {
    var dbClient = await db;
    dbClient.delete(BUSINESS_TYPE_TABLE);
    btypeList.forEach((element) async {
      element.businessTypeId = await dbClient.insert(BUSINESS_TYPE_TABLE, element.toMap());
    });
    return btypeList;
  }

  Future<List<Map<String, dynamic>>> getBusinessTypesByEmpStatus(int? selfEmployed) async {
    var dbClient = await db;
    var condColumn = "$EMPLOYED_APPLIED";
    if (selfEmployed == 1) {
      condColumn = "$SELF_EMPLOYED_APPLIED";
    } else if (selfEmployed == 0) {
      condColumn = "$EMPLOYED_APPLIED";
    } else if (selfEmployed == 2) {
      condColumn = "$UNEMPLOYED_APPLIED";
    }
    List<Map> maps = await dbClient.query(BUSINESS_TYPE_TABLE, columns: [BUSINESS_TYPE_ID, BUSINESS_TYPE_NAME], where: '$condColumn = ?', whereArgs: [1], orderBy: "$BUSINESS_TYPE_NAME ASC");
    List<Map<String, dynamic>> businessTypes = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        businessTypes.add(maps[i] as Map<String, dynamic>);
      }
    }
    return businessTypes;
  }

  //
  // JOB CATEGORY Functions //
  //
  Future<List<JobCategory>> syncJobCategory(List<JobCategory> jobCateList) async {
    var dbClient = await db;
    dbClient.delete(JOB_CATEGORY_TABLE);
    jobCateList.forEach((element) async {
      element.jobCategoryId = await dbClient.insert(JOB_CATEGORY_TABLE, element.toMap());
    });
    return jobCateList;
  }

  Future<List<Map<String, dynamic>>> getJobCategoriesByEmpStatus(int? businessTypeId, int? selfEmployed) async {
    var dbClient = await db;
    List<Map> maps = await dbClient.query(JOB_CATEGORY_TABLE, columns: [JOB_CATEGORY_ID, JOB_CATEGORY_NAME], where: '$JOB_CATEGORY_ACTIVE = ? AND businessTypeId = ? AND selfemployed = ?', whereArgs: [1, businessTypeId, selfEmployed], orderBy: "$JOB_CATEGORY_NAME ASC");
    List<Map<String, dynamic>> jobCategories = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        jobCategories.add(maps[i] as Map<String, dynamic>);
      }
    }
    print('jobCategories: $jobCategories');
    return jobCategories;
  }

  //
  // GEO REGION Functions //
  //
  Future<List<GeoRegion>> syncGeoRegion(List<GeoRegion> geoRegionList) async {
    var dbClient = await db;
    dbClient.delete(GEO_REGION_TABLE);
    geoRegionList.forEach((element) async {
      element.geoRegionId = await dbClient.insert(GEO_REGION_TABLE, element.toMap());
    });
    return geoRegionList;
  }

  Future<List<Map<String, dynamic>>> getGeoRegions() async {
    var dbClient = await db;
    List<Map> maps = await dbClient.query(GEO_REGION_TABLE, columns: [GEO_REGION_ID, GEO_REGION_NAME], orderBy: "$GEO_REGION_NAME ASC");
    List<Map<String, dynamic>> geoRegions = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        geoRegions.add(maps[i] as Map<String, dynamic>);
      }
    }
    return geoRegions;
  }

  //
  // GEO DISTRICT Functions //
  //
  Future<List<GeoDistrict>> syncGeoDistrict(List<GeoDistrict> geoDistrictList) async {
    var dbClient = await db;
    dbClient.delete(GEO_DISTRICT_TABLE);
    geoDistrictList.forEach((element) async {
      element.geoDistrictId = await dbClient.insert(GEO_DISTRICT_TABLE, element.toMap());
    });
    return geoDistrictList;
  }

  Future<List<Map<String, dynamic>>> getGeoDistrict(int? geoRegionId) async {
    var dbClient = await db;
    List<Map> maps = await dbClient.query(GEO_DISTRICT_TABLE, columns: [GEO_DISTRICT_ID, GEO_DISTRICT_NAME], where: '$GEO_REGION_ID = ?', whereArgs: [geoRegionId], orderBy: "$GEO_DISTRICT_NAME ASC");
    List<Map<String, dynamic>> geoDistricts = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        geoDistricts.add(maps[i] as Map<String, dynamic>);
      }
    }
    return geoDistricts;
  }

  //
  // GEO TOWN SHIP Functions //
  //
  Future<List<GeoTownShip>> syncGeoTownShip(List<GeoTownShip> geoTownShipList) async {
    var dbClient = await db;
    dbClient.delete(GEO_TOWN_SHIP_TABLE);
    geoTownShipList.forEach((element) async {
      element.geoTownShipId = await dbClient.insert(GEO_TOWN_SHIP_TABLE, element.toMap());
    });
    return geoTownShipList;
  }

  Future<List<Map<String, dynamic>>> getTownShips(int? geoDistrictId) async {
    var dbClient = await db;
    List<Map> maps = await dbClient.query(GEO_TOWN_SHIP_TABLE, columns: [GEO_TOWN_SHIP_ID, GEO_TOWN_SHIP_NAME], where: '$GEO_DISTRICT_ID = ?', whereArgs: [geoDistrictId], orderBy: "$GEO_TOWN_SHIP_NAME ASC");
    List<Map<String, dynamic>> geoTownShips = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        geoTownShips.add(maps[i] as Map<String, dynamic>);
      }
    }
    return geoTownShips;
  }

  //
  // GEO TOWN Functions //
  //
  Future<List<GeoTown>> syncGeoTown(List<GeoTown> geoTownList) async {
    var dbClient = await db;
    dbClient.delete(GEO_TOWN_TABLE);
    var batch = dbClient.batch();
    geoTownList.forEach((element) async {
      batch.insert(GEO_TOWN_TABLE, element.toMap());
      // element.geoTownId = await dbClient.insert(GEO_TOWN_TABLE, element.toMap());
    });
    await batch.commit();
    return geoTownList;
  }

  Future<List<Map<String, dynamic>>> getTowns(int? geoTownShipId, int isVillage) async {
    var dbClient = await db;
    List<Map> maps = await dbClient.query(GEO_TOWN_TABLE, columns: [GEO_TOWN_ID, GEO_TOWN_NAME], where: '$GEO_TOWN_SHIP_ID = ? AND $GEO_TOWN_IS_VILLAGE = ?', whereArgs: [geoTownShipId, 0], orderBy: "$GEO_TOWN_NAME ASC");
    List<Map<String, dynamic>> geoTowns = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        geoTowns.add(maps[i] as Map<String, dynamic>);
      }
    }
    return geoTowns;
  }

  Future<List<Map<String, dynamic>>> getTownVillages(int? geoTownShipId, int isVillage) async {
    var dbClient = await db;
    List<Map> maps = await dbClient.query(GEO_TOWN_TABLE, columns: [GEO_TOWN_ID, GEO_TOWN_NAME], where: '$GEO_TOWN_SHIP_ID = ? AND $GEO_TOWN_IS_VILLAGE = ?', whereArgs: [geoTownShipId, 1], orderBy: "$GEO_TOWN_NAME ASC");
    List<Map<String, dynamic>> geoVillages = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        geoVillages.add(maps[i] as Map<String, dynamic>);
      }
    }
    return geoVillages;
  }

  //
  // GEO WARD Functions //
  //
  Future<List<GeoWard>> syncGeoWard(List<GeoWard> geoWardList) async {
    var dbClient = await db;
    dbClient.delete(GEO_WARD_TABLE);
    var batch = dbClient.batch();
    geoWardList.forEach((element) async {
      batch.insert(GEO_WARD_TABLE, element.toMap());
      // element.geoWardId = await dbClient.insert(GEO_WARD_TABLE, element.toMap());
    });
    await batch.commit();
    return geoWardList;
  }

  Future<List<Map<String, dynamic>>> getWards(int? geoTownId) async {
    var dbClient = await db;
    List<Map> maps = await dbClient.query(GEO_WARD_TABLE, columns: [GEO_WARD_ID, GEO_WARD_NAME], where: '$GEO_TOWN_ID = ?', whereArgs: [geoTownId], orderBy: "$GEO_WARD_NAME ASC");
    List<Map<String, dynamic>> geoWards = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        geoWards.add(maps[i] as Map<String, dynamic>);
      }
    }
    return geoWards;
  }

  //
  // GEO VILLAGE Functions //
  //
  Future<List<GeoVillage>> syncGeoVillage(List<GeoVillage> geoVillageList) async {
    var dbClient = await db;
    dbClient.delete(GEO_VILLAGE_TABLE);
    var batch = dbClient.batch();
    geoVillageList.forEach((element) async {
      batch.insert(GEO_VILLAGE_TABLE, element.toMap());
      // element.geoVillageId = await dbClient.insert(GEO_VILLAGE_TABLE, element.toMap());
    });
    await batch.commit();
    return geoVillageList;
  }

  Future<List<Map<String, dynamic>>> getVillages(int? geoTownId) async {
    var dbClient = await db;
    List<Map> maps = await dbClient.query(GEO_VILLAGE_TABLE, columns: [GEO_VILLAGE_ID, GEO_VILLAGE_NAME], where: '$GEO_TOWN_ID = ?', whereArgs: [geoTownId], orderBy: "$GEO_VILLAGE_NAME ASC");
    List<Map<String, dynamic>> geoVillages = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        geoVillages.add(maps[i] as Map<String, dynamic>);
      }
    }
    return geoVillages;
  }

  //
  // POS Functions //
  //
  Future<List<OriginationPOS>> syncPOS(List<OriginationPOS> posList) async {
    var dbClient = await db;
    dbClient.delete(POS_TABLE);
    try {
      posList.forEach((element) async {
        element.posId = await dbClient.insert(POS_TABLE, element.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
      });
    } catch (Exception) {}

    return posList;
  }

  Future<List<Map<String, dynamic>>> getAllPOS() async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $POS_TABLE.*, $MERCHANT_TABLE.$MERCHANT_NAME" + " FROM $POS_TABLE " + " LEFT JOIN $MERCHANT_TABLE ON $POS_TABLE.$MERCHANT_ID = $MERCHANT_TABLE.$MERCHANT_ID" + " ORDER BY $MERCHANT_TABLE.$MERCHANT_NAME ASC, $POS_TABLE.$POS_NAME ASC");
    List<Map<String, dynamic>> allPOS = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        allPOS.add({
          'posId': maps[i]['posId'],
          'posCode': maps[i]['posCode'],
          'posName': maps[i]['posName'],
          'posAddress': maps[i]['posAddress'],
          'merchantId': maps[i]['merchantId'],
          'merchantName': maps[i]['merchantName'],
        });
      }
    }
    return allPOS;
  }

  //
  // Merchant Functions //
  //
  Future<List<Merchant>> syncMerchant(List<Merchant> merchantList) async {
    var dbClient = await db;
    dbClient.delete(MERCHANT_TABLE);
    merchantList.forEach((element) async {
      element.merchantId = await dbClient.insert(MERCHANT_TABLE, element.toMap());
    });
    return merchantList;
  }

  Future<Map<String, dynamic>?> getMerchant(int? merchantId) async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $MERCHANT_TABLE.*" + " FROM $MERCHANT_TABLE" + " WHERE $MERCHANT_TABLE.merchantId = $merchantId");
    Map<String, dynamic>? merchant;
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        merchant = maps[0] as Map<String, dynamic>?;
      }
    }
    print('merchant: $merchant');
    return merchant;
  }

  // Future<List<Merchant>> getAllMerchant() async {
  //   var dbClient = await db;
  //   List<Map> maps = await dbClient.rawQuery("SELECT $POS_TABLE.*, $MERCHANT_TABLE.$MERCHANT_NAME" + " FROM $POS_TABLE " + " LEFT JOIN $MERCHANT_TABLE ON $POS_TABLE.$MERCHANT_ID = $MERCHANT_TABLE.$MERCHANT_ID" + " ORDER BY $MERCHANT_TABLE.$MERCHANT_NAME ASC, $POS_TABLE.$POS_NAME ASC");
  //   List<Merchant> allMerchant = [];
  //   if (maps.length > 0) {
  //     for (int i = 0; i < maps.length; i++) {
  //       allMerchant.add(Merchant.fromMap(maps[i]));
  //     }
  //   }
  //   return allMerchant;
  // }

  //
  // BRAND Functions //
  //
  Future<List<Brand>> syncBrand(List<Brand> brandList) async {
    var dbClient = await db;
    dbClient.delete(BRAND_TABLE);
    var batch = dbClient.batch();
    brandList.forEach((element) async {
      batch.insert(BRAND_TABLE, element.toMap());
    });
    await batch.commit();
    return brandList;
  }

  Future<List<Map<String, dynamic>>> getBrands(int? posId, int? isZeroCost) async {
    var dbClient = await db;
    List<Map> maps = await dbClient.query(BRAND_TABLE, columns: [BRAND_ID, BRAND_CODE, BRAND_NAME, BRAND_CATEGORY, BRAND_IS_ZERO_COST], where: '$POS_ID = ? AND $BRAND_IS_ZERO_COST = ?', whereArgs: [posId, isZeroCost], orderBy: "$BRAND_NAME ASC");
    List<Map<String, dynamic>> brands = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        brands.add(maps[i] as Map<String, dynamic>);
      }
    }
    return brands;
  }

  //
  // PRODUCT Functions //
  //
  Future<List<Product>> syncProduct(List<Product> productList) async {
    var dbClient = await db;
    dbClient.delete(PRODUCT_TABLE);
    dbClient.delete(FIN_SCHEME_PRODUCT_TABLE);

    var batch = dbClient.batch();
    productList.forEach((element) async {
      batch.insert(PRODUCT_TABLE, element.toMap());
    });
    await batch.commit();
    return productList;
  }

  Future<List<Map<String, dynamic>>> getProducts(int? posId, int? brandId, int? isZeroCost) async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $PRODUCT_TABLE.* FROM $PRODUCT_TABLE WHERE $PRODUCT_TABLE.$POS_ID = $posId AND $PRODUCT_TABLE.$BRAND_ID = $brandId and $PRODUCT_IS_ZERO_COST = $isZeroCost ORDER BY $PRODUCT_TABLE.$PRODUCT_NAME ASC");
    List<Map<String, dynamic>> products = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        products.add(maps[i] as Map<String, dynamic>);
      }
    }
    return products;
  }

  //
  // SECONDARY PRODUCT Functions //
  //
  Future<List<SecondaryProduct>> syncSecondaryProduct(List<SecondaryProduct> secProductList) async {
    var dbClient = await db;
    dbClient.delete(SECONDARY_PRODUCT_TABLE);
    secProductList.forEach((element) async {
      element.secProductId = await dbClient.insert(SECONDARY_PRODUCT_TABLE, element.toMap());
    });
    return secProductList;
  }

  Future<List<Map<String, dynamic>>> getSecondaryProducts() async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $SECONDARY_PRODUCT_TABLE.* FROM $SECONDARY_PRODUCT_TABLE ORDER BY $SECONDARY_PRODUCT_TABLE.secProductName ASC");
    List<Map<String, dynamic>> secondaryProducts = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        secondaryProducts.add(maps[i] as Map<String, dynamic>);
      }
    }
    return secondaryProducts;
  }

  //
  // SUPPLIER BANK ACCOUNT Functions //
  //
  Future<List<SupplierBankAccount>> syncSupplierBankAccount(List<SupplierBankAccount> supplierBankAccountList) async {
    var dbClient = await db;
    dbClient.delete(SUPPLIER_BANK_ACCOUNT_TABLE);
    supplierBankAccountList.forEach((element) async {
      element.bankAccountId = await dbClient.insert(SUPPLIER_BANK_ACCOUNT_TABLE, element.toMap());
    });
    return supplierBankAccountList;
  }

  Future<List<Map<String, dynamic>>> getSupplierBankAccounts() async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $SUPPLIER_BANK_ACCOUNT_TABLE.* FROM $SUPPLIER_BANK_ACCOUNT_TABLE ORDER BY $SUPPLIER_BANK_ACCOUNT_TABLE.supplierName ASC");
    List<Map<String, dynamic>> supplierBankAccounts = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        supplierBankAccounts.add(maps[i] as Map<String, dynamic>);
      }
    }
    return supplierBankAccounts;
  }

  //
  // FIN SCHEME DET Functions //
  //
  Future<List<FinSchemeProductDetail>> syncFinSchemeDetail(List<FinSchemeProductDetail> finSchemeDetList) async {
    var dbClient = await db;

    var batch = dbClient.batch();
    finSchemeDetList.forEach((element) async {
      batch.insert(FIN_SCHEME_PRODUCT_TABLE, element.toMap());
    });
    await batch.commit();
    return finSchemeDetList;
  }

  Future<List<Map<String, dynamic>>> getFinSchemeDetails(int? finSchemeId, int? productId) async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $FIN_SCHEME_PRODUCT_TABLE.* FROM $FIN_SCHEME_PRODUCT_TABLE WHERE $FIN_SCHEME_PRODUCT_TABLE.financialSchemeId = $finSchemeId AND $FIN_SCHEME_PRODUCT_TABLE.productId = $productId");
    // List<Map> maps = await dbClient.query(INS_SCHEME_DET_TABLE, columns: [INS_SCHEME_DET_ID, PRODUCT_ID, INS_SCHEME_ID, INS_FIXED_COST, INS_VARIABLE_COST, INS_VARIABLE_COST_APPLIED, INS_VARIABLE_CUSTOM_VALUE_APPLIED, INS_SCHEME_DET_TABLE], where: '$PRODUCT_ID = ?', whereArgs: [productId]);
    List<Map<String, dynamic>> finSchemes = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        finSchemes.add(maps[i] as Map<String, dynamic>);
      }
    }
    return finSchemes;
  }

  //
  // INS SCHEME DET Functions //
  //
  Future<List<InsSchemeProductDetail>> syncInsSchemeDetail(List<InsSchemeProductDetail> insSchemeDetList) async {
    var dbClient = await db;

    var batch = dbClient.batch();
    insSchemeDetList.forEach((element) async {
      batch.insert(INS_SCHEME_PRODUCT_TABLE, element.toMap());
    });
    await batch.commit();
    return insSchemeDetList;
  }

  Future<List<Map<String, dynamic>>> getInsSchemeDetails(int? productId) async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $INS_SCHEME_PRODUCT_TABLE.* FROM $INS_SCHEME_PRODUCT_TABLE WHERE $INS_SCHEME_PRODUCT_TABLE.productId = $productId");
    // List<Map> maps = await dbClient.query(INS_SCHEME_DET_TABLE, columns: [INS_SCHEME_DET_ID, PRODUCT_ID, INS_SCHEME_ID, INS_FIXED_COST, INS_VARIABLE_COST, INS_VARIABLE_COST_APPLIED, INS_VARIABLE_CUSTOM_VALUE_APPLIED, INS_SCHEME_DET_TABLE], where: '$PRODUCT_ID = ?', whereArgs: [productId]);
    List<Map<String, dynamic>> insSchemes = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        insSchemes.add(maps[i] as Map<String, dynamic>);
      }
    }
    return insSchemes;
  }

  //
  // NRC1 Functions //
  //
  Future<List<Nrc1>> syncNrc1(List<Nrc1> nrc1List) async {
    var dbClient = await db;
    dbClient.delete(NRC1_TABLE);
    nrc1List.forEach((element) async {
      element.nrc1Id = await dbClient.insert(NRC1_TABLE, element.toMap());
    });
    return nrc1List;
  }

  Future<List<Map<String, dynamic>>> getNrc1s() async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $NRC1_TABLE.* FROM $NRC1_TABLE ORDER BY $NRC1_TABLE.$NRC1_NAME ASC");
    List<Map<String, dynamic>> nrc1s = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        nrc1s.add(maps[i] as Map<String, dynamic>);
      }
    }
    return nrc1s;
  }

  //
  // NRC2 Functions //
  //
  Future<List<Nrc2>> syncNrc2(List<Nrc2> nrc2List) async {
    var dbClient = await db;
    dbClient.delete(NRC2_TABLE);
    nrc2List.forEach((element) async {
      element.nrc2Id = await dbClient.insert(NRC2_TABLE, element.toMap());
    });
    return nrc2List;
  }

  Future<List<Map<String, dynamic>>> getNrc2s(int? nrc1Id) async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $NRC2_TABLE.* FROM $NRC2_TABLE WHERE $NRC2_TABLE.$NRC1_ID = $nrc1Id ORDER BY $NRC2_TABLE.$NRC2_NAME ASC");
    List<Map<String, dynamic>> nrc2s = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        nrc2s.add(maps[i] as Map<String, dynamic>);
      }
    }
    return nrc2s;
  }

  //
  // PRODUCT CATEGORY Functions //
  //
  Future<List<ProductCategory>> syncProductCategory(List<ProductCategory> prodCatList) async {
    var dbClient = await db;
    dbClient.delete(PRODUCT_CATEGORY_TABLE);
    prodCatList.forEach((element) async {
      element.productCategoryId = await dbClient.insert(PRODUCT_CATEGORY_TABLE, element.toMap());
    });
    return prodCatList;
  }

  Future<List<ProductCategory>> getProductCategories() async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $PRODUCT_CATEGORY_TABLE.* FROM $PRODUCT_CATEGORY_TABLE ORDER BY $PRODUCT_CATEGORY_TABLE.productCategoryName ASC");
    List<ProductCategory> prodCatList = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        prodCatList.add(ProductCategory.fromMap(maps[i] as Map<String, dynamic>));
      }
    }
    return prodCatList;
  }

  //
  // USER Functions //
  //
  Future<List<User>> syncUser(List<User> userList) async {
    var dbClient = await db;
    dbClient.delete(USER_TABLE);
    userList.forEach((element) async {
      element.userId = await dbClient.insert(USER_TABLE, element.toMap());
    });
    return userList;
  }

  //
  // APP DOC TYPE Functions //
  //
  Future<List<AppDocType>> syncAppDocType(List<AppDocType> appDocTypeList) async {
    var dbClient = await db;
    dbClient.delete(APP_DOC_TYPE_TABLE);
    appDocTypeList.forEach((element) async {
      element.docTypeId = await dbClient.insert(APP_DOC_TYPE_TABLE, element.toMap());
    });
    return appDocTypeList;
  }

  Future<List<AppDocType>> getAppDocTypes() async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $APP_DOC_TYPE_TABLE.* FROM $APP_DOC_TYPE_TABLE ORDER BY $APP_DOC_TYPE_TABLE.docTypeName ASC");
    List<AppDocType> appDocTypeList = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        appDocTypeList.add(AppDocType.fromMap(maps[i] as Map<String, dynamic>));
      }
    }
    return appDocTypeList;
  }

  //
  // APP DOCUMENT Functions //
  //
  Future<List<AppDocument>> syncAppDocument(List<AppDocument> appDocumentList) async {
    var dbClient = await db;
    dbClient.delete(APP_DOCUMENT_TABLE);
    appDocumentList.forEach((element) async {
      element.docTypeId = await dbClient.insert(APP_DOCUMENT_TABLE, element.toMap());
    });
    return appDocumentList;
  }

  Future<List<Map<String, dynamic>>> getAppDocuments(String? docProductType, int? applicationId) async {
    var dbClient = await db;
    String strCond = docProductType == 'car' ? "= 'car'" : "is NULL";
    List<Map> maps = await dbClient.rawQuery("SELECT $APP_DOCUMENT_TABLE.*, $APP_DOC_TYPE_TABLE.docTypeName" +
        " FROM $APP_DOCUMENT_TABLE" +
        " LEFT JOIN $APP_DOC_TYPE_TABLE ON $APP_DOCUMENT_TABLE.docTypeId = $APP_DOC_TYPE_TABLE.docTypeId" +
        " WHERE $APP_DOCUMENT_TABLE.docProductType $strCond AND $APP_DOCUMENT_TABLE.documentId NOT IN (SELECT $APP_DOC_DETAIL_TABLE.documentId FROM $APP_DOC_DETAIL_TABLE WHERE $APP_DOC_DETAIL_TABLE.applicationId = $applicationId)" +
        " ORDER BY $APP_DOCUMENT_TABLE.docProductType ASC, $APP_DOCUMENT_TABLE.documentCode ASC, $APP_DOCUMENT_TABLE.documentName ASC");
    List<Map<String, dynamic>> appDocTypeList = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        appDocTypeList.add(maps[i] as Map<String, dynamic>);
      }
    }

    List<Map> docTypes = await dbClient.rawQuery("SELECT $APP_DOC_TYPE_TABLE.* from $APP_DOC_TYPE_TABLE");
    print('docTypes Sources: $docTypes');
    return appDocTypeList;
  }

  Future<List<Map<String, dynamic>>> getAllAppDocuments(String? docProductType) async {
    var dbClient = await db;
    String strCond = docProductType == 'car' ? "= 'car'" : "is NULL";
    List<Map> maps = await dbClient.rawQuery("SELECT $APP_DOCUMENT_TABLE.*, $APP_DOC_TYPE_TABLE.docTypeName" + " FROM $APP_DOCUMENT_TABLE" + " LEFT JOIN $APP_DOC_TYPE_TABLE ON $APP_DOCUMENT_TABLE.docTypeId = $APP_DOC_TYPE_TABLE.docTypeId" + " WHERE $APP_DOCUMENT_TABLE.docProductType $strCond" + " ORDER BY $APP_DOCUMENT_TABLE.docProductType ASC, $APP_DOCUMENT_TABLE.documentCode ASC, $APP_DOCUMENT_TABLE.documentName ASC");
    List<Map<String, dynamic>> appDocTypeList = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        appDocTypeList.add(maps[i] as Map<String, dynamic>);
      }
    }

    List<Map> docTypes = await dbClient.rawQuery("SELECT $APP_DOC_TYPE_TABLE.* from $APP_DOC_TYPE_TABLE");
    print('docTypes Sources: $docTypes');
    return appDocTypeList;
  }

  //
  // PROSPECT Functions //
  //
  Future<Prospect> createProspect(Prospect prospect) async {
    var dbClient = await db;
    prospect.prospectId = await dbClient.insert(PROSPECT_TABLE, prospect.toMap());
    return prospect;
  }

  Future<List<Map<String, dynamic>>> getProspects() async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $PROSPECT_TABLE.* FROM $PROSPECT_TABLE ORDER BY prospectId DESC");
    List<Map<String, dynamic>> prospects = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        prospects.add(maps[i] as Map<String, dynamic>);
      }
    }
    return prospects;
  }

  Future<Map<String, dynamic>?> getProspect(int? prospectId) async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $PROSPECT_TABLE.*, $PRODUCT_PACKAGE_TABLE.productId," +
        " $PRODUCT_PACKAGE_TABLE.packageId, $PRODUCT_CATEGORY_TABLE.productCategoryName, $BRAND_TABLE.brandName," +
        " $PRODUCT_TABLE.modelName, $PRODUCT_TABLE.productCode, $PRODUCT_TABLE.productName," +
        " $PRODUCT_PACKAGE_TABLE.isBundle," +
        " $PRODUCT_PACKAGE_TABLE.primaryUnitPrice, $PRODUCT_PACKAGE_TABLE.quantity," +
        " $PRODUCT_PACKAGE_TABLE.primaryTotalPrice, $PRODUCT_PACKAGE_TABLE.packageTotalPrice," +
        " $SIMULATION_TABLE.simulationId, $SIMULATION_TABLE.paymentAtEnd, $SIMULATION_TABLE.totalPrice," +
        " $SIMULATION_TABLE.depositAmount, $SIMULATION_TABLE.depositPercentage," +
        " $SIMULATION_TABLE.earlyPrepaymentAmount, $SIMULATION_TABLE.earlyPrepaymentPercentage," +
        " $SIMULATION_TABLE.amountFinanced, $SIMULATION_TABLE.effectiveAmountFinanced," +
        " $SIMULATION_TABLE.interestRate, $SIMULATION_TABLE.pmtPeriodicity, $SIMULATION_TABLE.duration," +
        " $SIMULATION_TABLE.maintenanceCovered, $SIMULATION_TABLE.insuranceCovered, $SIMULATION_TABLE.adminFee," +
        " $SIMULATION_TABLE.actualFirstPayment," +
        " $SIMULATION_TABLE.amountFinancedAdminFeeAddUp," +
        " $SIMULATION_TABLE.zeroCostTotalInsCost, $SIMULATION_TABLE.zeroCostTotalMaintCost," +
        " $SIMULATION_TABLE.isZeroCost, $SIMULATION_TABLE.followingPayment," +
        " $SIMULATION_TABLE.zeroCostPmtTimes, $SIMULATION_TABLE.zeroCostMonthlyPaymentAmount," +
        " $SIMULATION_TABLE.zeroCostTotalInsCost, $SIMULATION_TABLE.zeroCostTotalMaintCost," +
        " $APPLICATION_TABLE.applicationId, $USER_TABLE.userFullName AS personDesignatedTo, " +
        " $CUSTOMER_TABLE.*, " +
        " $MARITAL_STATUS_TABLE.maritalStatusName, $GEO_REGION_TABLE.geoRegionName, $GEO_DISTRICT_TABLE.geoDistrictName," +
        " $GEO_TOWN_SHIP_TABLE.geoTownShipName, $GEO_TOWN_TABLE.geoTownName, $GEO_WARD_TABLE.geoWardName, " +
        " $GEO_VILLAGE_TABLE.geoVillageName" +
        " FROM $PROSPECT_TABLE" +
        " LEFT JOIN $PRODUCT_PACKAGE_TABLE ON $PRODUCT_PACKAGE_TABLE.prospectId = $PROSPECT_TABLE.prospectId" +
        " LEFT JOIN $PRODUCT_TABLE ON $PRODUCT_PACKAGE_TABLE.productId = $PRODUCT_TABLE.productId" +
        " LEFT JOIN $PRODUCT_CATEGORY_TABLE ON $PRODUCT_TABLE.productCategoryId = $PRODUCT_CATEGORY_TABLE.productCategoryId" +
        " LEFT JOIN $BRAND_TABLE ON $PRODUCT_TABLE.brandId = $BRAND_TABLE.brandId" +
        " LEFT JOIN $SIMULATION_TABLE ON $PRODUCT_PACKAGE_TABLE.prospectId = $SIMULATION_TABLE.prospectId" +
        " LEFT JOIN $APPLICATION_TABLE ON $PROSPECT_TABLE.prospectId = $APPLICATION_TABLE.prospectId" +
        " LEFT JOIN $USER_TABLE ON $APPLICATION_TABLE.personDesignatedTo = $USER_TABLE.userId" +
        " LEFT JOIN $CUSTOMER_TABLE ON $PROSPECT_TABLE.createdCustId = $CUSTOMER_TABLE.customerId" +
        " LEFT JOIN $MARITAL_STATUS_TABLE ON $CUSTOMER_TABLE.maritalStatusId = $MARITAL_STATUS_TABLE.maritalStatusId" +
        " LEFT JOIN $GEO_VILLAGE_TABLE ON $CUSTOMER_TABLE.geoVillageId = $GEO_VILLAGE_TABLE.geoVillageId " +
        " LEFT JOIN $GEO_WARD_TABLE ON $CUSTOMER_TABLE.geoWardId = $GEO_WARD_TABLE.geoWardId" +
        " LEFT JOIN $GEO_TOWN_TABLE ON $CUSTOMER_TABLE.geoTownId = $GEO_TOWN_TABLE.geoTownId" +
        " LEFT JOIN $GEO_TOWN_SHIP_TABLE ON $CUSTOMER_TABLE.geoTownShipId = $GEO_TOWN_SHIP_TABLE.geoTownShipId" +
        " LEFT JOIN $GEO_DISTRICT_TABLE ON $GEO_TOWN_SHIP_TABLE.geoDistrictId = $GEO_DISTRICT_TABLE.geoDistrictId" +
        " LEFT JOIN $GEO_REGION_TABLE ON $GEO_DISTRICT_TABLE.geoRegionId = $GEO_REGION_TABLE.geoRegionId" +
        " WHERE $PROSPECT_TABLE.$PROSPECT_ID = $prospectId" +
        " ORDER BY $PROSPECT_TABLE.prospectId DESC");
    Map<String, dynamic>? prospect;
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        prospect = maps[0] as Map<String, dynamic>?;
      }
    }
    print('prospect: $prospect');

    List<Map> icomeSources = await dbClient.rawQuery("SELECT $CUSTOMER_INCOME_SOURCE_TABLE.* from $CUSTOMER_INCOME_SOURCE_TABLE");
    print('Income Sources: $icomeSources');
    return prospect;
  }

  Future<Map<String, dynamic>?> editProspect(int? prospectId) async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $PROSPECT_TABLE.* FROM $PROSPECT_TABLE WHERE $PROSPECT_TABLE.prospectId = $prospectId");
    Map<String, dynamic>? prospect;
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        prospect = maps[0] as Map<String, dynamic>?;
      }
    }
    print('prospect: $prospect');
    return prospect;
  }

  Future<int> deleteProspect(int id) async {
    var dbClient = await db;
    return await dbClient.delete(PROSPECT_TABLE, where: '$PROSPECT_ID = ?', whereArgs: [id]);
  }

  Future<int> updateProspect(Prospect item) async {
    var dbClient = await db;
    return await dbClient.update(PROSPECT_TABLE, item.toMap(), where: '$PROSPECT_ID = ?', whereArgs: [item.prospectId]);
  }

  Future<List<Map<String, dynamic>>> getAllProspects() async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $PROSPECT_TABLE.* FROM $PROSPECT_TABLE");
    List<Map<String, dynamic>> prospects = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        prospects.add(maps[i] as Map<String, dynamic>);
      }
    }
    return prospects;
  }

  Future<int> deleteAllProspects() async {
    var dbClient = await db;
    return await dbClient.delete(PROSPECT_TABLE);
  }

  // PRODUCT PACKAGE //
  Future<ProductPackage> createProductPackage(ProductPackage package) async {
    var dbClient = await db;
    await dbClient.delete(PRODUCT_PACKAGE_TABLE, where: 'prospectId = ?', whereArgs: [package.prospectId]);
    await dbClient.delete(ATTACHED_PRODUCT_TABLE, where: 'packageId = ?', whereArgs: [package.packageId]);
    package.packageId = await dbClient.insert(PRODUCT_PACKAGE_TABLE, package.toMap());
    return package;
  }

  Future<Map<String, dynamic>?> getProductPackage(int? packageId) async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $PRODUCT_PACKAGE_TABLE.*, $PRODUCT_TABLE.productName" + " FROM $PRODUCT_PACKAGE_TABLE" + " LEFT JOIN $PRODUCT_TABLE ON $PRODUCT_PACKAGE_TABLE.productId = $PRODUCT_TABLE.productId" + " WHERE $PRODUCT_PACKAGE_TABLE.packageId = $packageId");
    Map<String, dynamic>? package;
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        package = maps[0] as Map<String, dynamic>?;
      }
    }
    print('package: $package');
    return package;
  }

  Future<List<Map<String, dynamic>>> getProductPackages() async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT * FROM $PRODUCT_PACKAGE_TABLE");
    List<Map<String, dynamic>> packages = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        packages.add(maps[i] as Map<String, dynamic>);
      }
    }
    print('packages: $packages');
    return packages;
  }

  Future<int> deleteAllProductPackages() async {
    var dbClient = await db;
    return await dbClient.delete(PRODUCT_PACKAGE_TABLE);
  }

  // SIMULATION //
  Future<Simulation> createSimulation(Simulation simulation, int? prospectId, int? packageId) async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $SIMULATION_TABLE.* FROM $SIMULATION_TABLE WHERE $SIMULATION_TABLE.packageId = $packageId AND $SIMULATION_TABLE.prospectId = $prospectId");
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        await dbClient.delete(SIMULATION_TABLE, where: 'simulationId = ?', whereArgs: [maps[i]['simulationId']]);
        await dbClient.delete(PAYMENT_SCHEDULE_TABLE, where: 'simulationId = ?', whereArgs: [maps[i]['simulationId']]);
      }
    }

    simulation.simulationId = await dbClient.insert(SIMULATION_TABLE, simulation.toMap());
    return simulation;
  }

  Future<List<Map<String, dynamic>>> getSimulations() async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $SIMULATION_TABLE.* FROM $SIMULATION_TABLE");
    List<Map<String, dynamic>> simulations = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        simulations.add(maps[i] as Map<String, dynamic>);
      }
    }
    return simulations;
  }

  Future<int> deleteAllSimulations() async {
    var dbClient = await db;
    return await dbClient.delete(SIMULATION_TABLE);
  }

  // PAYMENT SCHEDULE //
  Future<PaymentSchedule> createPaymentSchedule(PaymentSchedule paymentSchedule, int? simulationId) async {
    var dbClient = await db;
    paymentSchedule.paymentId = await dbClient.insert(PAYMENT_SCHEDULE_TABLE, paymentSchedule.toMap());
    return paymentSchedule;
  }

  Future<List<Map<String, dynamic>>> getPaymentSchedules() async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $PAYMENT_SCHEDULE_TABLE.* FROM $PAYMENT_SCHEDULE_TABLE");
    List<Map<String, dynamic>> payments = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        payments.add(maps[i] as Map<String, dynamic>);
      }
    }
    return payments;
  }

  Future<int> deleteAllPaymentSchedules() async {
    var dbClient = await db;
    return await dbClient.delete(PAYMENT_SCHEDULE_TABLE);
  }

  // APPLICATION //
  Future<Application> createApplication(Application application, int? prospectId, int? simulationId) async {
    var dbClient = await db;
    await dbClient.delete(APPLICATION_TABLE, where: 'prospectId = ?', whereArgs: [prospectId]);
    application.applicationId = await dbClient.insert(APPLICATION_TABLE, application.toMap());
    // update appId for Prospect & Simulation table //
    await dbClient.rawUpdate("UPDATE $SIMULATION_TABLE SET applicationId=${application.applicationId} WHERE simulationId = $simulationId");
    return application;
  }

  Future<List<Map<String, dynamic>>> getApplications() async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $APPLICATION_TABLE.* FROM $APPLICATION_TABLE");
    List<Map<String, dynamic>> applications = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        applications.add(maps[i] as Map<String, dynamic>);
      }
    }
    return applications;
  }

  Future<int> deleteAllApplications() async {
    var dbClient = await db;
    return await dbClient.delete(APPLICATION_TABLE);
  }

  // CUSTOMER //
  Future<Customer> createCustomer(Customer customer, int? prospectId, int? applicationId) async {
    var dbClient = await db;
    customer.customerId = await dbClient.insert(CUSTOMER_TABLE, customer.toMap());
    await dbClient.rawUpdate("UPDATE $PROSPECT_TABLE SET createdCustId=${customer.customerId} WHERE prospectId = $prospectId");
    await dbClient.rawUpdate("UPDATE $APPLICATION_TABLE SET customerId=${customer.customerId} WHERE applicationId = $applicationId");
    return customer;
  }

  Future<Map<String, dynamic>?> getCustomer(int? customerId) async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT " +
        " $CUSTOMER_TABLE.*, $EDUCATION_TABLE.educationName, $MARITAL_STATUS_TABLE.maritalStatusName," +
        " $NRC1_TABLE.nrc1Id, $NRC1_TABLE.nrc1Name, $NRC2_TABLE.nrc2Name," +
        " SPOUSE_NRC1.nrc1Id spouseNrc1Id, SPOUSE_NRC1.nrc1Name spouseNrc1Name, SPOUSE_NRC2.nrc2Name spouseNrc2Name," +
        " $GEO_VILLAGE_TABLE.geoVillageName, $GEO_WARD_TABLE.geoWardName," +
        " $GEO_TOWN_TABLE.geoTownName, $GEO_TOWN_SHIP_TABLE.geoTownShipName," +
        " $GEO_DISTRICT_TABLE.geoDistrictId, $GEO_DISTRICT_TABLE.geoDistrictName," +
        " $GEO_REGION_TABLE.geoRegionId, $GEO_REGION_TABLE.geoRegionName" +
        " FROM $CUSTOMER_TABLE" +
        " LEFT JOIN $EDUCATION_TABLE ON $CUSTOMER_TABLE.educationId = $EDUCATION_TABLE.educationId" +
        " LEFT JOIN $MARITAL_STATUS_TABLE ON $CUSTOMER_TABLE.maritalStatusId = $MARITAL_STATUS_TABLE.maritalStatusId" +
        " LEFT JOIN $NRC2_TABLE ON $CUSTOMER_TABLE.nrc2Id = $NRC2_TABLE.nrc2Id" +
        " LEFT JOIN $NRC1_TABLE ON $NRC2_TABLE.nrc1Id = $NRC1_TABLE.nrc1Id" +
        " LEFT JOIN $NRC2_TABLE AS SPOUSE_NRC2 ON $CUSTOMER_TABLE.spouseNrc2Id = SPOUSE_NRC2.nrc2Id" +
        " LEFT JOIN $NRC1_TABLE AS SPOUSE_NRC1 ON SPOUSE_NRC2.nrc1Id = SPOUSE_NRC1.nrc1Id" +
        " LEFT JOIN $GEO_VILLAGE_TABLE ON $CUSTOMER_TABLE.geoVillageId = $GEO_VILLAGE_TABLE.geoVillageId" +
        " LEFT JOIN $GEO_WARD_TABLE ON $CUSTOMER_TABLE.geoWardId = $GEO_WARD_TABLE.geoWardId" +
        " LEFT JOIN $GEO_TOWN_TABLE ON $CUSTOMER_TABLE.geoTownId = $GEO_TOWN_TABLE.geoTownId" +
        " LEFT JOIN $GEO_TOWN_SHIP_TABLE ON $CUSTOMER_TABLE.geoTownShipId = $GEO_TOWN_SHIP_TABLE.geoTownShipId" +
        " LEFT JOIN $GEO_DISTRICT_TABLE ON $GEO_TOWN_SHIP_TABLE.geoDistrictId = $GEO_DISTRICT_TABLE.geoDistrictId" +
        " LEFT JOIN $GEO_REGION_TABLE ON $GEO_DISTRICT_TABLE.geoRegionId = $GEO_REGION_TABLE.geoRegionId" +
        " WHERE $CUSTOMER_TABLE.customerId = $customerId");
    Map<String, dynamic>? customer;
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        customer = maps[0] as Map<String, dynamic>?;
      }
    }
    print('customer: $customer');
    return customer;
  }

  Future<int> updateCustomer(Map<String, dynamic> item, int? customerId) async {
    var dbClient = await db;
    return await dbClient.update(CUSTOMER_TABLE, item, where: 'customerId = ?', whereArgs: [customerId]);
  }

  Future<List<Map<String, dynamic>>> getCustomers() async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $CUSTOMER_TABLE.* FROM $CUSTOMER_TABLE");
    List<Map<String, dynamic>> customers = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        customers.add(maps[i] as Map<String, dynamic>);
      }
    }
    return customers;
  }

  Future<int> deleteAllCustomers() async {
    var dbClient = await db;
    return await dbClient.delete(CUSTOMER_TABLE);
  }

  // CUSTOMER INCOME SOURCE //
  Future<CustomerIncomeSource> createCustomerIncomeSource(CustomerIncomeSource custIncomeSource, int? customerId) async {
    var dbClient = await db;
    custIncomeSource.incomeSourceId = await dbClient.insert(CUSTOMER_INCOME_SOURCE_TABLE, custIncomeSource.toMap());
    return custIncomeSource;
  }

  Future<int> updateCustomerIncomeSource(Map<String, dynamic> item, int? incomeSourceId) async {
    var dbClient = await db;
    return await dbClient.update(CUSTOMER_INCOME_SOURCE_TABLE, item, where: 'incomeSourceId = ?', whereArgs: [incomeSourceId]);
  }

  Future<int> deleteCustomerIncomeSource(int incomeSourceId) async {
    var dbClient = await db;
    return await dbClient.delete(CUSTOMER_INCOME_SOURCE_TABLE, where: 'incomeSourceId = ?', whereArgs: [incomeSourceId]);
  }

  Future<Map<String, dynamic>?> getCustomerIncomeSource(int? incomeCustomerId) async {
    var dbClient = await db;
    List<Map> maps = await dbClient
        .rawQuery("SELECT $CUSTOMER_INCOME_SOURCE_TABLE.*, $BUSINESS_TYPE_TABLE.businessTypeName, $JOB_CATEGORY_TABLE.jobCategoryName" + " FROM $CUSTOMER_INCOME_SOURCE_TABLE" + " LEFT JOIN $BUSINESS_TYPE_TABLE ON $CUSTOMER_INCOME_SOURCE_TABLE.businessTypeId = $BUSINESS_TYPE_TABLE.businessTypeId" + " LEFT JOIN $JOB_CATEGORY_TABLE ON $CUSTOMER_INCOME_SOURCE_TABLE.jobCategoryId = $JOB_CATEGORY_TABLE.jobCategoryId" + " WHERE $CUSTOMER_INCOME_SOURCE_TABLE.incomeSourceId = $incomeCustomerId");
    Map<String, dynamic>? incomeSource;
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        incomeSource = maps[0] as Map<String, dynamic>?;
      }
    }
    print('incomeSource: $incomeSource');
    return incomeSource;
  }

  Future<List<Map<String, dynamic>>> getCustomerIncomeSources(int? customerId) async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $CUSTOMER_INCOME_SOURCE_TABLE.*, $BUSINESS_TYPE_TABLE.businessTypeName, $JOB_CATEGORY_TABLE.jobCategoryName" +
        " FROM $CUSTOMER_INCOME_SOURCE_TABLE" +
        " LEFT JOIN $BUSINESS_TYPE_TABLE ON $CUSTOMER_INCOME_SOURCE_TABLE.businessTypeId = $BUSINESS_TYPE_TABLE.businessTypeId" +
        " LEFT JOIN $JOB_CATEGORY_TABLE ON $CUSTOMER_INCOME_SOURCE_TABLE.jobCategoryId = $JOB_CATEGORY_TABLE.jobCategoryId" +
        " WHERE $CUSTOMER_INCOME_SOURCE_TABLE.customerId = $customerId" +
        " ORDER BY $CUSTOMER_INCOME_SOURCE_TABLE.incomeSourceId DESC");
    List<Map<String, dynamic>> incomeSources = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        incomeSources.add(maps[i] as Map<String, dynamic>);
      }
    }
    return incomeSources;
  }

  Future<List<Map<String, dynamic>>> getAllCustomerIncomeSources() async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $CUSTOMER_INCOME_SOURCE_TABLE.* FROM $CUSTOMER_INCOME_SOURCE_TABLE");
    List<Map<String, dynamic>> incomeSources = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        incomeSources.add(maps[i] as Map<String, dynamic>);
      }
    }
    return incomeSources;
  }

  Future<int> deleteAllCustomerIncomeSources() async {
    var dbClient = await db;
    return await dbClient.delete(CUSTOMER_INCOME_SOURCE_TABLE);
  }

  // CUSTOMER HOUSEHOLD //
  Future<CustomerHouseHold> createHousehold(CustomerHouseHold household, int? customerId) async {
    var dbClient = await db;
    household.householdId = await dbClient.insert(CUSTOMER_HOUSEHOLD_TABLE, household.toMap());
    return household;
  }

  Future<int> updateHousehold(Map<String, dynamic> item, int? householdId) async {
    var dbClient = await db;
    return await dbClient.update(CUSTOMER_HOUSEHOLD_TABLE, item, where: 'householdId = ?', whereArgs: [householdId]);
  }

  Future<int> deleteHousehold(int householdId) async {
    var dbClient = await db;
    return await dbClient.delete(CUSTOMER_HOUSEHOLD_TABLE, where: 'householdId = ?', whereArgs: [householdId]);
  }

  Future<Map<String, dynamic>?> getHousehold(int? householdId) async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $CUSTOMER_HOUSEHOLD_TABLE.*, $NRC2_TABLE.nrc1Id, $NRC2_TABLE.nrc2Name" +
        " FROM $CUSTOMER_HOUSEHOLD_TABLE" +
        " LEFT JOIN $NRC2_TABLE ON $CUSTOMER_HOUSEHOLD_TABLE.nrc2Id = $NRC2_TABLE.nrc2Id"
            " WHERE $CUSTOMER_HOUSEHOLD_TABLE.householdId = $householdId");
    Map<String, dynamic>? household;
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        household = maps[0] as Map<String, dynamic>?;
      }
    }
    print('household: $household');
    return household;
  }

  Future<List<Map<String, dynamic>>> getHouseholds(int? customerId) async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $CUSTOMER_HOUSEHOLD_TABLE.*, $NRC2_TABLE.nrc1Id, $NRC2_TABLE.nrc2Name" + " FROM $CUSTOMER_HOUSEHOLD_TABLE" + " LEFT JOIN $NRC2_TABLE ON $CUSTOMER_HOUSEHOLD_TABLE.nrc2Id = $NRC2_TABLE.nrc2Id" + " WHERE $CUSTOMER_HOUSEHOLD_TABLE.customerId = $customerId" + " ORDER BY $CUSTOMER_HOUSEHOLD_TABLE.householdId DESC");
    List<Map<String, dynamic>> households = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        households.add(maps[i] as Map<String, dynamic>);
      }
    }
    return households;
  }

  Future<List<Map<String, dynamic>>> getAllCustomerHouseholds() async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $CUSTOMER_HOUSEHOLD_TABLE.* FROM $CUSTOMER_HOUSEHOLD_TABLE");
    List<Map<String, dynamic>> households = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        households.add(maps[i] as Map<String, dynamic>);
      }
    }
    return households;
  }

  Future<int> deleteAllCustomerHouseholds() async {
    var dbClient = await db;
    return await dbClient.delete(CUSTOMER_HOUSEHOLD_TABLE);
  }

  // CUSTOMER CONTACT DETAIL //
  Future<CustomerContactDetail> createCustomerContactDetail(CustomerContactDetail customerContactDetail, int? customerId) async {
    var dbClient = await db;
    customerContactDetail.contactDetId = await dbClient.insert(CUSTOMER_CONTACT_DETAIL_TABLE, customerContactDetail.toMap());
    return customerContactDetail;
  }

  Future<int> updateCustomerContactDetail(Map<String, dynamic> item, int? contactDetId) async {
    var dbClient = await db;
    return await dbClient.update(CUSTOMER_CONTACT_DETAIL_TABLE, item, where: 'contactDetId = ?', whereArgs: [contactDetId]);
  }

  Future<int> deleteCustomerContactDetail(int contactDetId) async {
    var dbClient = await db;
    return await dbClient.delete(CUSTOMER_CONTACT_DETAIL_TABLE, where: 'contactDetId = ?', whereArgs: [contactDetId]);
  }

  Future<Map<String, dynamic>?> getCustomerContactDetail(int? contactDetId) async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT " +
        " $CUSTOMER_CONTACT_DETAIL_TABLE.*, $NRC2_TABLE.nrc1Id," +
        " $BUSINESS_TYPE_TABLE.businessTypeName, $JOB_CATEGORY_TABLE.jobCategoryName" +
        " FROM $CUSTOMER_CONTACT_DETAIL_TABLE" +
        " LEFT JOIN $BUSINESS_TYPE_TABLE ON $CUSTOMER_CONTACT_DETAIL_TABLE.businessTypeId = $BUSINESS_TYPE_TABLE.businessTypeId" +
        " LEFT JOIN $JOB_CATEGORY_TABLE ON $CUSTOMER_CONTACT_DETAIL_TABLE.jobCategoryId = $JOB_CATEGORY_TABLE.jobCategoryId" +
        " LEFT JOIN $NRC2_TABLE ON $CUSTOMER_CONTACT_DETAIL_TABLE.nrc2Id = $NRC2_TABLE.nrc2Id"
            " WHERE $CUSTOMER_CONTACT_DETAIL_TABLE.contactDetId = $contactDetId");
    Map<String, dynamic>? customerContact;
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        customerContact = maps[0] as Map<String, dynamic>?;
      }
    }
    print('customerContact: $customerContact');
    return customerContact;
  }

  Future<List<Map<String, dynamic>>> getCustomerContactDetails(int? customerId) async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT " +
        " $CUSTOMER_CONTACT_DETAIL_TABLE.*," +
        " $BUSINESS_TYPE_TABLE.businessTypeName, $JOB_CATEGORY_TABLE.jobCategoryName" +
        " FROM $CUSTOMER_CONTACT_DETAIL_TABLE" +
        " LEFT JOIN $BUSINESS_TYPE_TABLE ON $CUSTOMER_CONTACT_DETAIL_TABLE.businessTypeId = $BUSINESS_TYPE_TABLE.businessTypeId" +
        " LEFT JOIN $JOB_CATEGORY_TABLE ON $CUSTOMER_CONTACT_DETAIL_TABLE.jobCategoryId = $JOB_CATEGORY_TABLE.jobCategoryId" +
        " WHERE $CUSTOMER_CONTACT_DETAIL_TABLE.customerId = $customerId" +
        " ORDER BY $CUSTOMER_CONTACT_DETAIL_TABLE.contactDetId DESC");
    List<Map<String, dynamic>> customerContacts = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        customerContacts.add(maps[i] as Map<String, dynamic>);
      }
    }
    print('customerContacts: $customerContacts');
    return customerContacts;
  }

  Future<List<Map<String, dynamic>>> getAllCustomerContacts() async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $CUSTOMER_CONTACT_DETAIL_TABLE.* FROM $CUSTOMER_CONTACT_DETAIL_TABLE");
    List<Map<String, dynamic>> contacts = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        contacts.add(maps[i] as Map<String, dynamic>);
      }
    }
    return contacts;
  }

  Future<int> deleteAllCustomerContacts() async {
    var dbClient = await db;
    return await dbClient.delete(CUSTOMER_CONTACT_DETAIL_TABLE);
  }

  // APP DOC DETAIL Functions //
  Future<AppDocDetail> createAppDocDetail(AppDocDetail appDocDetail, int? applicationId) async {
    var dbClient = await db;
    appDocDetail.docDetId = await dbClient.insert(APP_DOC_DETAIL_TABLE, appDocDetail.toMap());
    return appDocDetail;
  }

  Future<int> updateAppDocDetail(Map<String, dynamic> item, int? docDetId) async {
    var dbClient = await db;
    return await dbClient.update(APP_DOC_DETAIL_TABLE, item, where: 'docDetId = ?', whereArgs: [docDetId]);
  }

  Future<int> deleteAppDocDetail(int docDetId) async {
    var dbClient = await db;
    return await dbClient.delete(APP_DOC_DETAIL_TABLE, where: 'docDetId = ?', whereArgs: [docDetId]);
  }

  Future<List<Map<String, dynamic>>> getAppDocDetails(int? applicationId) async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT " +
        " $APP_DOC_DETAIL_TABLE.*, $APP_DOCUMENT_TABLE.documentName, $APP_DOC_TYPE_TABLE.docTypeName" +
        " FROM $APP_DOC_DETAIL_TABLE" +
        " LEFT JOIN $APP_DOCUMENT_TABLE ON $APP_DOC_DETAIL_TABLE.documentId = $APP_DOCUMENT_TABLE.documentId" +
        " LEFT JOIN $APP_DOC_TYPE_TABLE ON $APP_DOCUMENT_TABLE.docTypeId = $APP_DOC_TYPE_TABLE.docTypeId" +
        " WHERE $APP_DOC_DETAIL_TABLE.applicationId = $applicationId" +
        " ORDER BY $APP_DOC_TYPE_TABLE.docTypeName ASC, $APP_DOCUMENT_TABLE.documentName ASC");
    List<Map<String, dynamic>> docDetails = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        docDetails.add(maps[i] as Map<String, dynamic>);
      }
    }
    return docDetails;
  }

  Future<Map<String, dynamic>?> getAppDocDetail(int? docDetId) async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery(
        "SELECT " + " $APP_DOC_DETAIL_TABLE.*, $APP_DOCUMENT_TABLE.documentName, $APP_DOC_TYPE_TABLE.docTypeName" + " FROM $APP_DOC_DETAIL_TABLE" + " LEFT JOIN $APP_DOCUMENT_TABLE ON $APP_DOC_DETAIL_TABLE.documentId = $APP_DOCUMENT_TABLE.documentId" + " LEFT JOIN $APP_DOC_TYPE_TABLE ON $APP_DOCUMENT_TABLE.docTypeId = $APP_DOC_TYPE_TABLE.docTypeId" + " WHERE $APP_DOC_DETAIL_TABLE.docDetId = $docDetId" + " ORDER BY $APP_DOC_TYPE_TABLE.docTypeName ASC, $APP_DOCUMENT_TABLE.documentName ASC");
    Map<String, dynamic>? docDetail;
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        docDetail = maps[0] as Map<String, dynamic>?;
      }
    }
    print('docDetail: $docDetail');
    return docDetail;
  }

  Future<List<Map<String, dynamic>>> getAllAppDocDetails() async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $APP_DOC_DETAIL_TABLE.* FROM $APP_DOC_DETAIL_TABLE");
    List<Map<String, dynamic>> contacts = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        contacts.add(maps[i] as Map<String, dynamic>);
      }
    }
    return contacts;
  }

  Future<int> deleteAllAppDocDetails() async {
    var dbClient = await db;
    return await dbClient.delete(APP_DOC_DETAIL_TABLE);
  }

  // APP UPLOAD Functions //
  Future<AppUpload> createAppUpload(AppUpload appDocUpload, int? applicationId) async {
    var dbClient = await db;
    appDocUpload.uploadId = await dbClient.insert(APP_UPLOAD_TABLE, appDocUpload.toMap());
    return appDocUpload;
  }

  Future<int> updateAppUpload(Map<String, dynamic> item, int? uploadId) async {
    var dbClient = await db;
    return await dbClient.update(APP_UPLOAD_TABLE, item, where: 'uploadId = ?', whereArgs: [uploadId]);
  }

  Future<int> deleteAppUpload(int uploadId) async {
    var dbClient = await db;
    return await dbClient.delete(APP_UPLOAD_TABLE, where: 'uploadId = ?', whereArgs: [uploadId]);
  }

  Future<List<Map<String, dynamic>>> getAppUploads(int? applicationId) async {
    var dbClient = await db;
    List<Map> maps = await dbClient
        .rawQuery("SELECT " + " $APP_UPLOAD_TABLE.*, $APP_DOCUMENT_TABLE.documentName, $APP_DOC_TYPE_TABLE.docTypeName" + " FROM $APP_UPLOAD_TABLE" + " LEFT JOIN $APP_DOCUMENT_TABLE ON $APP_UPLOAD_TABLE.documentId = $APP_DOCUMENT_TABLE.documentId" + " LEFT JOIN $APP_DOC_TYPE_TABLE ON $APP_DOCUMENT_TABLE.docTypeId = $APP_DOC_TYPE_TABLE.docTypeId" + " WHERE $APP_UPLOAD_TABLE.applicationId = $applicationId" + " ORDER BY $APP_DOC_TYPE_TABLE.docTypeName ASC, $APP_DOCUMENT_TABLE.documentName ASC");
    List<Map<String, dynamic>> docUploads = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        docUploads.add(maps[i] as Map<String, dynamic>);
      }
    }
    return docUploads;
  }

  Future<Map<String, dynamic>?> getAppUpload(int? uploadId) async {
    var dbClient = await db;
    List<Map> maps = await dbClient
        .rawQuery("SELECT " + " $APP_UPLOAD_TABLE.*, $APP_DOCUMENT_TABLE.documentName, $APP_DOC_TYPE_TABLE.docTypeName" + " FROM $APP_UPLOAD_TABLE" + " LEFT JOIN $APP_DOCUMENT_TABLE ON $APP_UPLOAD_TABLE.documentId = $APP_DOCUMENT_TABLE.documentId" + " LEFT JOIN $APP_DOC_TYPE_TABLE ON $APP_DOCUMENT_TABLE.docTypeId = $APP_DOC_TYPE_TABLE.docTypeId" + " WHERE $APP_UPLOAD_TABLE.uploadId = $uploadId" + " ORDER BY $APP_DOC_TYPE_TABLE.docTypeName ASC, $APP_DOCUMENT_TABLE.documentName ASC");
    Map<String, dynamic>? docDetail;
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        docDetail = maps[0] as Map<String, dynamic>?;
      }
    }
    print('docDetail: $docDetail');
    return docDetail;
  }

  Future<List<Map<String, dynamic>>> getAllAppUploads() async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $APP_UPLOAD_TABLE.* FROM $APP_UPLOAD_TABLE");
    List<Map<String, dynamic>> uploads = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        uploads.add(maps[i] as Map<String, dynamic>);
      }
    }
    print('uploads: $uploads');
    return uploads;
  }

  Future<int> deleteAllAppUploads() async {
    var dbClient = await db;
    return await dbClient.delete(APP_UPLOAD_TABLE);
  }

  // ATTACHED PRODUCT Functions //
  Future<AttachedProduct> createAttachProduct(AttachedProduct attachedProduct, int? packageId) async {
    var dbClient = await db;
    attachedProduct.attachedProductId = await dbClient.insert(ATTACHED_PRODUCT_TABLE, attachedProduct.toMap());
    return attachedProduct;
  }

  Future<int> deleteAttachedProduct(int attachedProductId) async {
    var dbClient = await db;
    return await dbClient.delete(ATTACHED_PRODUCT_TABLE, where: 'attachedProductId = ?', whereArgs: [attachedProductId]);
  }

  Future<List<Map<String, dynamic>>> getAttachedProducts(int? packageId) async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $ATTACHED_PRODUCT_TABLE.* FROM $ATTACHED_PRODUCT_TABLE WHERE $ATTACHED_PRODUCT_TABLE.packageId = $packageId" + " ORDER BY $ATTACHED_PRODUCT_TABLE.attachedProductId DESC");
    List<Map<String, dynamic>> attachedProducts = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        attachedProducts.add(maps[i] as Map<String, dynamic>);
      }
    }
    return attachedProducts;
  }

  Future<List<Map<String, dynamic>>> getAllAttachedProducts() async {
    var dbClient = await db;
    List<Map> maps = await dbClient.rawQuery("SELECT $ATTACHED_PRODUCT_TABLE.* FROM $ATTACHED_PRODUCT_TABLE ORDER BY $ATTACHED_PRODUCT_TABLE.attachedProductId ASC");
    List<Map<String, dynamic>> attachedProducts = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        attachedProducts.add(maps[i] as Map<String, dynamic>);
      }
    }
    return attachedProducts;
  }

  Future<int> deleteAllAttachedProducts() async {
    var dbClient = await db;
    return await dbClient.delete(ATTACHED_PRODUCT_TABLE);
  }

  // Future<List<Map<String, dynamic>>> getAttachedProducts(int prospectId) async {
  //   var dbClient = await db;
  //   List<Map> maps = await dbClient
  //       .rawQuery("SELECT " + " $ATTACHED_PRODUCT_TABLE.*, $APP_DOCUMENT_TABLE.documentName, $APP_DOC_TYPE_TABLE.docTypeName"
  //         + " FROM $ATTACHED_PRODUCT_TABLE"
  //         + " LEFT JOIN $APP_DOCUMENT_TABLE ON $APP_UPLOAD_TABLE.documentId = $APP_DOCUMENT_TABLE.documentId"
  //         + " LEFT JOIN $APP_DOC_TYPE_TABLE ON $APP_DOCUMENT_TABLE.docTypeId = $APP_DOC_TYPE_TABLE.docTypeId"
  //         + " WHERE $APP_UPLOAD_TABLE.applicationId = $applicationId"
  //         + " ORDER BY $APP_DOC_TYPE_TABLE.docTypeName ASC, $APP_DOCUMENT_TABLE.documentName ASC");
  //   List<Map<String, dynamic>> attachedProducts = [];
  //   if (maps.length > 0) {
  //     for (int i = 0; i < maps.length; i++) {
  //       attachedProducts.add(maps[i]);
  //     }
  //   }
  //   return attachedProducts;
  // }

  // CLOSE DB //

  Future close() async {
    var dbClient = await db;
    dbClient.close();
  }
}
