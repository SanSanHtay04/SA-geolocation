import 'package:path/path.dart';
import 'package:sales/data/local/tables/checkin_table.dart';
import 'package:sales/data/local/tables/pos_table.dart';
import 'package:sqflite/sqflite.dart';

final String _fileName = "sales.db";

class AppDatabase {
  AppDatabase._();

  static Database? _db = null;

  static Future<Database> get db async {
    if (_db == null) {
      _db = await _open();
    }
    return _db!;
  }

  static Future<String> getDbPath() async => join(
        await getDatabasesPath(),
        _fileName,
      );

  static Future<Database> _open() async {
    return await openDatabase(
      await getDbPath(),
      version: 1,
      onCreate: (Database db, int version) async {
        await Future.wait([
          db.execute(POSDao.createTable),
          db.execute(CheckinDao.createTable),
        ]);
      },
      onConfigure: (Database db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
    );
  }

  /**
   * Close db and return the path of db.
   */
  static Future<String> close() async {
    if (_db == null || !_db!.isOpen) return await getDbPath();
    await _db!.close();
    _db = null;
    return await getDbPath();
  }
}
