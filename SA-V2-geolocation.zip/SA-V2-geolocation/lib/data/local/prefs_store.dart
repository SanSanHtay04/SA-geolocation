import 'dart:convert';

import 'package:sales/data/remote/models/responses/auth/account_info_response.dart';
import 'package:shared_preferences/shared_preferences.dart';

const String _ACCOUNT_INFO_KEY = "account_info";
const String _LAST_POST_LIST_FETCH_KEY = "last_pos_list_fetch";
const String _SKIPPED_VERSION = "skipped_version";

class PrefsStore {
  late SharedPreferences _preferences;

  PrefsStore(SharedPreferences sharedPreferences) {
    _preferences = sharedPreferences;
  }

  setAccountInfo(AuthResponse authResponse) {
    _preferences.setString(_ACCOUNT_INFO_KEY, json.encode(authResponse));
  }

  AuthResponse? get accountInfo {
    var data = _preferences.getString(_ACCOUNT_INFO_KEY);
    if (data == null) {
      return null;
    }
    var map = json.decode(data);
    return map == null ? null : AuthResponse.fromJson(map);
  }

  String? get accessToken => accountInfo?.accessToken;

  Future<void> clearAccountInfo() => _preferences.remove(_ACCOUNT_INFO_KEY);

  DateTime? get lastPOSListFetch {
    final value = _preferences.getString(_LAST_POST_LIST_FETCH_KEY);
    if (value == null) return null;
    return DateTime.tryParse(value);
  }

  Future<void> setPOSListLastFetch(DateTime dateTime) {
    return _preferences.setString(
        _LAST_POST_LIST_FETCH_KEY, dateTime.toIso8601String());
  }

  String? get skippedVersion => _preferences.getString(_SKIPPED_VERSION);

  void setSkippedVersion(String currentVersion) {
    _preferences.setString(_SKIPPED_VERSION, currentVersion);
  }
}
