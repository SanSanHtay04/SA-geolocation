// ignore_for_file: invalid_annotation_target

import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sqflite/sqflite.dart';

import '../../../utils/logging.dart';
import 'pos_table.dart' as POSTable;

part 'checkin_table.freezed.dart';
part 'checkin_table.g.dart';

final String table = "checkin_history";
const String columnId = "id";
const String columnPOSId = "pos_id";
const String columnPOSName = "pos_name";
const String columnType = "type";
const String columnLatitude = "latitude";
const String columnLongitude = "longitude";
const String columnCreatedAt = "created_at";

@freezed
class CheckinCache with _$CheckinCache {
  CheckinCache._();

  factory CheckinCache({
    @JsonKey(name: columnId) @Default(0) int id,
    @JsonKey(name: columnPOSId) required int posId,
    @JsonKey(name: columnPOSName) @Default("") String posName,
    @JsonKey(name: columnLatitude) required double latitude,
    @JsonKey(name: columnLongitude) required double longitude,
    @JsonKey(name: columnType) required String type,
    @JsonKey(name: columnCreatedAt) required String createdAt,
  }) = _CheckinCache;

  factory CheckinCache.fromJson(Map<String, dynamic> json) =>
      _$CheckinCacheFromJson(json);
}

class CheckinDao {
  final Database db;

  const CheckinDao({required this.db});

  static String get createTable => '''
      CREATE TABLE $table(
        $columnId INTEGER PRIMARY KEY AUTOINCREMENT, 
        $columnPOSId INTEGER NOT NULL, 
        $columnType TEXT NOT NULL, 
        $columnLatitude DOUBLE NOT NULL, 
        $columnLongitude DOUBLE NOT NULL,  
        $columnCreatedAt TEXT NOT NULL,
        FOREIGN KEY ($columnPOSId) REFERENCES ${POSTable.table} (${POSTable.columnId}) ON DELETE CASCADE
        );
        ''';

  Future<void> insert(CheckinCache cache) async {
    await db.insert(
        table,
        cache.toJson()
          ..remove(columnId)
          ..remove(columnPOSName));
  }

  Future<int> deleteALl() async {

    final dd =  await db.rawDelete("DELETE  FROM $table");
    AppLogger.i('Checkin Table : ${dd}');

    return dd;
  }

  Future<List<CheckinCache>> selectAll() async {
    final maps = await db.rawQuery('''
    SELECT checkin.*, pos.${POSTable.columnName} $columnPOSName
    FROM $table checkin
    LEFT JOIN ${POSTable.table} pos
    ON checkin.$columnPOSId = pos.${POSTable.columnId}
    ORDER BY checkin.${columnCreatedAt} DESC
    LIMIT 4
    ''');
    return maps.map((e) => CheckinCache.fromJson(e)).toList();
  }
}
