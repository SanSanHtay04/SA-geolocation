import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sqflite/sqflite.dart';

import 'package:sales/data/remote/models/models.dart';
import 'package:sales/utils/utils.dart';

part 'pos_table.freezed.dart';

final String table = "pos";
final String columnId = "id";
final String columnName = "name";
final String columnAddress = "address";
final String columnLatitude = "latitude";
final String columnLongitude = "longitude";
final String columnPh1 = "ph1";
final String columnPh2 = "ph2";
final String columnPosProductType = "posProductType";
final String columnPosCategory = "posCategory";
final String columnSalesAreaId = "sales_area_id";
final String columnIsMerchant = "is_merchant";

@freezed
class POSCache with _$POSCache {
  POSCache._();

  factory POSCache({
    required int id,
    required String name,
    String? address,
    double? latitude,
    double? longitude,
    String? ph1,
    String? ph2,
    String? posProductType,
    String? posCategory,
    int? isMerchant,
    required int salesAreaId,
  }) = _POSCache;

  Map<String, Object?> toMap() {
    var map = <String, Object?>{
      columnId: id,
      columnAddress: address,
      columnName: name,
      columnLatitude: latitude,
      columnLongitude: longitude,
      columnPh1: ph1,
      columnPh2: ph2,
      columnPosProductType: posProductType,
      columnPosCategory: posCategory,
      columnIsMerchant: isMerchant,
      columnSalesAreaId: salesAreaId,
    };
    return map;
  }

  factory POSCache.fromMap(Map<String, Object?> map) {
    return POSCache(
      id: map[columnId] as int,
      salesAreaId: map[columnSalesAreaId] as int,
      name: map[columnName] as String,
      address: map[columnAddress] as String?,
      latitude: map[columnLatitude] as double?,
      longitude: map[columnLongitude] as double?,
      ph1: map[columnPh1] as String?,
      ph2: map[columnPh2] as String?,
      posProductType: map[columnPosProductType] as String?,
      isMerchant: map[columnIsMerchant]  as int?,
      posCategory: map[columnPosCategory] as String?,
    );
  }

  factory POSCache.fromResponse(POSResponse response) {
    return POSCache(
      id: response.posId,
      salesAreaId: response.salesAreaId,
      name: response.posName,
      address: response.posAddress,
      latitude: response.geoLatitude.parseDouble(),
      longitude: response.geoLongitude.parseDouble(),
      ph1: response.posFixedTelNo1,
      ph2: response.posFixedTelNo2,
      posProductType: response.posProductType,
      posCategory: response.posCategory,
      isMerchant: response.isMerchant,
    );
  }
}

class POSDao {
  final Database db;

  const POSDao({required this.db});

  static String get createTable => '''
      CREATE TABLE $table(
        $columnId INTEGER PRIMARY KEY, 
        $columnSalesAreaId INTEGER NOT NULL,
        $columnName TEXT NOT NULL, 
        $columnAddress Text, 
        $columnLatitude DOUBLE, 
        $columnLongitude DOUBLE, 
        $columnPh1 TEXT, 
        $columnPh2 TEXT,
        $columnPosProductType TEXT,
        $columnPosCategory TEXT,
        $columnIsMerchant INTEGER);
        ''';

  Future<void> insert(POSCache pos) async {
    await db.insert(table, pos.toMap());
  }

  Future<void> deleteALl() {
    return db.rawDelete("DELETE FROM $table");
  }

  Future<void> insertAll(List<POSCache> poses) async {
    await db.transaction((txn) async {
      poses.forEach((pos) {
        txn.insert(table, pos.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
      });
    });
  }

  Future<List<POSCache>> selectAll() async {
    final maps = await db.rawQuery("SELECT * FROM $table");
    return maps.map((e) => POSCache.fromMap(e)).toList();
  }
}
