class Merchant {
  int? merchantId;
  String? merchantName;
  String? merchantAddress;

  Merchant({this.merchantId, this.merchantName, this.merchantAddress});

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "merchantId": merchantId,
      "merchantName": merchantName,
      "merchantAddress": merchantAddress,
    };
    return map;
  }

  Merchant.fromMap(Map<String, dynamic> map) {
    merchantId = map["merchantId"];
    merchantName = map["merchantName"];
    merchantAddress = map["merchantAddress"];
  }
}
