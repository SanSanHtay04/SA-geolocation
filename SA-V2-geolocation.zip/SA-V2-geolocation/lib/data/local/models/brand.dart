class Brand {
  int? brandId;
  int? posId;
  String? brandCode;
  String? brandName;
  String? brandCategory;
  int? isZeroCost;

  Brand(
      {this.brandId,
      this.posId,
      this.brandCode,
      this.brandName,
      this.brandCategory,
      this.isZeroCost});

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "brandId": brandId,
      "posId": posId,
      "brandCode": brandCode,
      "brandName": brandName,
      "brandCategory": brandCategory,
      "isZeroCost": isZeroCost,
    };
    return map;
  }

  Brand.fromMap(Map<String, dynamic> map) {
    brandId = map["brandId"];
    posId = map["posId"];
    brandCode = map["brandCode"];
    brandName = map["brandName"];
    brandCategory = map["brandCategory"];
    isZeroCost = map["isZeroCost"];
  }
}
