class JobCategory {
  int? jobCategoryId;
  int? businessTypeId;
  String? jobCategoryName;
  int? jobCategoryActive;
  int? selfemployed;

  JobCategory(
      {this.jobCategoryId,
      this.businessTypeId,
      this.jobCategoryName,
      this.jobCategoryActive,
      this.selfemployed});

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "jobCategoryId": jobCategoryId,
      "businessTypeId": businessTypeId,
      "jobCategoryName": jobCategoryName,
      "jobCategoryActive": jobCategoryActive,
      "selfemployed": selfemployed,
    };
    return map;
  }

  JobCategory.fromMap(Map<String, dynamic> map) {
    jobCategoryId = map["jobCategoryId"];
    businessTypeId = map["businessTypeId"];
    jobCategoryName = map["jobCategoryName"];
    jobCategoryActive = map["jobCategoryActive"];
    selfemployed = map["selfemployed"];
  }
}
