class AttachedProduct {
  int? attachedProductId;
  int? packageId;
  int? assetId;
  int? contractId;
  int? secProductId;
  String? productName;
  String? productType;
  String? productTypeDetail;
  String? productRemark;
  int? quantity;
  int? productPrice;
  int? totalPrice;
  int? merchantDiscountRate;
  double? merchantDiscountAmount;
  double? merchantPaymentAmount;
  int? merchantId;
  int? bankAccountId;
  String? supplierName;
  String? bankName;
  String? beneficiary;
  String? accountNo;
  String? accountRemark;

  AttachedProduct({
    this.attachedProductId,
    this.packageId,
    this.assetId,
    this.contractId,
    this.secProductId,
    this.productName,
    this.productType,
    this.productTypeDetail,
    this.productRemark,
    this.quantity,
    this.productPrice,
    this.totalPrice,
    this.merchantDiscountRate,
    this.merchantDiscountAmount,
    this.merchantPaymentAmount,
    this.merchantId,
    this.bankAccountId,
    this.supplierName,
    this.bankName,
    this.beneficiary,
    this.accountNo,
    this.accountRemark,
  });

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "attachedProductId": attachedProductId,
      "packageId": packageId,
      "assetId": assetId,
      "contractId": contractId,
      "secProductId": secProductId,
      "productName": productName,
      "productType": productType,
      "productTypeDetail": productTypeDetail,
      "productRemark": productRemark,
      "quantity": quantity,
      "productPrice": productPrice,
      "totalPrice": totalPrice,
      "merchantDiscountRate": merchantDiscountRate,
      "merchantDiscountAmount": merchantDiscountAmount,
      "merchantPaymentAmount": merchantPaymentAmount,
      "merchantId": merchantId,
      "bankAccountId": bankAccountId,
      "supplierName": supplierName,
      "bankName": bankName,
      "beneficiary": beneficiary,
      "accountNo": accountNo,
      "accountRemark": accountRemark,
    };
    return map;
  }

  AttachedProduct.fromMap(Map<String, dynamic> map) {
    attachedProductId = map["attachedProductId"];
    packageId = map["packageId"];
    assetId = map["assetId"];
    contractId = map["contractId"];
    secProductId = map["secProductId"];
    productName = map["productName"];
    productType = map["productType"];
    productTypeDetail = map["productTypeDetail"];
    productRemark = map["productRemark"];
    quantity = map["quantity"];
    productPrice = map["productPrice"];
    totalPrice = map["totalPrice"];
    merchantDiscountRate = map["merchantDiscountRate"];
    merchantDiscountAmount =
        double.tryParse(map["merchantDiscountAmount"].toString());
    merchantPaymentAmount =
        double.tryParse(map["merchantPaymentAmount"].toString());
    merchantId = map["merchantId"];
    bankAccountId = map["bankAccountId"];
    supplierName = map["supplierName"];
    bankName = map["bankName"];
    beneficiary = map["beneficiary"];
    accountNo = map["accountNo"];
    accountRemark = map["accountRemark"];
  }
}
