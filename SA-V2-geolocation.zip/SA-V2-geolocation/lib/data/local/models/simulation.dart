class Simulation {
  int? simulationId;
  int? isZeroCost;
  int? zeroCostPmtTimes;
  int? zeroCostTotalInsCost;
  int? zeroCostTotalMaintCost;
  int? zeroCostMonthlyPaymentAmount;
  int? insuranceCovered;
  int? maintenanceCovered;
  int? applicationId;
  int? packageId;
  int? prospectId;
  int? posId;
  int? salesAreaId;
  String? simulationDate;
  double? adminFee;
  double? adminFeePercentage;
  int? assetPrice;
  int? totalPrice;
  int? merchantDiscountRate;
  double? merchantDiscountAmount;
  double? effectiveAssetPrice;
  double? effectiveAmountFinanced;
  double? effectiveInterestRate;
  double? depositAmount;
  int? depositPercentage;
  double? amountFinanced;
  int? duration;
  double? interestRate;
  int? amountFinancedAdminFeeAddUp;
  String? pmtPeriodicity;
  int? paymentAtEnd;
  int? minAmountFinanced;
  int? minInstallmentAmount;
  int? otpFeePercentage;
  int? earlyPrepaymentPercentage;
  int? earlyPrepaymentAmount;
  double? accPmtShare;
  double? accPmtMonthlyShare;
  int? firstPayment;
  int? actualFirstPayment;
  int? followingPayment;
  double? accMonthlyPaymentAmount;
  double? accMonthlyLastPaymentAmount;
  double? accPaymentAmount;
  double? accLastPaymentAmount;
  int? netRentalFee;
  double? rentalFeeInsCostAddUp;
  double? rentalFeeMaintCostAddUp;
  double? rentalFeeEnvCostAddUp;
  double? amountPayable;
  int? simDuration;

  Simulation({
    this.simulationId,
    this.isZeroCost,
    this.zeroCostPmtTimes,
    this.zeroCostTotalInsCost,
    this.zeroCostTotalMaintCost,
    this.zeroCostMonthlyPaymentAmount,
    this.insuranceCovered,
    this.maintenanceCovered,
    this.applicationId,
    this.packageId,
    this.prospectId,
    this.posId,
    this.salesAreaId,
    this.simulationDate,
    this.adminFee,
    this.adminFeePercentage,
    this.assetPrice,
    this.totalPrice,
    this.merchantDiscountRate,
    this.merchantDiscountAmount,
    this.effectiveAssetPrice,
    this.effectiveAmountFinanced,
    this.effectiveInterestRate,
    this.depositAmount,
    this.depositPercentage,
    this.amountFinanced,
    this.duration,
    this.interestRate,
    this.amountFinancedAdminFeeAddUp,
    this.pmtPeriodicity,
    this.paymentAtEnd,
    this.minAmountFinanced,
    this.minInstallmentAmount,
    this.otpFeePercentage,
    this.earlyPrepaymentPercentage,
    this.earlyPrepaymentAmount,
    this.accPmtShare,
    this.accPmtMonthlyShare,
    this.firstPayment,
    this.actualFirstPayment,
    this.followingPayment,
    this.accMonthlyPaymentAmount,
    this.accMonthlyLastPaymentAmount,
    this.accPaymentAmount,
    this.accLastPaymentAmount,
    this.netRentalFee,
    this.rentalFeeInsCostAddUp,
    this.rentalFeeMaintCostAddUp,
    this.rentalFeeEnvCostAddUp,
    this.amountPayable,
    this.simDuration,
  });

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "simulationId": simulationId,
      "isZeroCost": isZeroCost,
      "zeroCostPmtTimes": zeroCostPmtTimes,
      "zeroCostTotalInsCost": zeroCostTotalInsCost,
      "zeroCostTotalMaintCost": zeroCostTotalMaintCost,
      "zeroCostMonthlyPaymentAmount": zeroCostMonthlyPaymentAmount,
      "insuranceCovered": insuranceCovered,
      "maintenanceCovered": maintenanceCovered,
      "applicationId": applicationId,
      "packageId": packageId,
      "prospectId": prospectId,
      "posId": posId,
      "salesAreaId": salesAreaId,
      "simulationDate": simulationDate,
      "adminFee": adminFee,
      "adminFeePercentage": adminFeePercentage,
      "assetPrice": assetPrice,
      "totalPrice": totalPrice,
      "merchantDiscountRate": merchantDiscountRate,
      "merchantDiscountAmount": merchantDiscountAmount,
      "effectiveAssetPrice": effectiveAssetPrice,
      "effectiveAmountFinanced": effectiveAmountFinanced,
      "effectiveInterestRate": effectiveInterestRate,
      "depositAmount": depositAmount,
      "depositPercentage": depositPercentage,
      "amountFinanced": amountFinanced,
      "duration": duration,
      "interestRate": interestRate,
      "amountFinancedAdminFeeAddUp": amountFinancedAdminFeeAddUp,
      "pmtPeriodicity": pmtPeriodicity,
      "paymentAtEnd": paymentAtEnd,
      "minAmountFinanced": minAmountFinanced,
      "minInstallmentAmount": minInstallmentAmount,
      "otpFeePercentage": otpFeePercentage,
      "earlyPrepaymentPercentage": earlyPrepaymentPercentage,
      "earlyPrepaymentAmount": earlyPrepaymentAmount,
      "accPmtShare": accPmtShare,
      "accPmtMonthlyShare": accPmtMonthlyShare,
      "firstPayment": firstPayment,
      "actualFirstPayment": actualFirstPayment,
      "followingPayment": followingPayment,
      "accMonthlyPaymentAmount": accMonthlyPaymentAmount,
      "accMonthlyLastPaymentAmount": accMonthlyLastPaymentAmount,
      "accPaymentAmount": accPaymentAmount,
      "accLastPaymentAmount": accLastPaymentAmount,
      "netRentalFee ": netRentalFee,
      "rentalFeeInsCostAddUp": rentalFeeInsCostAddUp,
      "rentalFeeMaintCostAddUp": rentalFeeMaintCostAddUp,
      "rentalFeeEnvCostAddUp": rentalFeeEnvCostAddUp,
      "amountPayable": amountPayable,
      "simDuration": simDuration,
    };
    return map;
  }

  Simulation.fromMap(Map<String, dynamic> map) {
    simulationId = map["simulationId"];
    isZeroCost = map["isZeroCost"];
    zeroCostPmtTimes = map["zeroCostPmtTimes"];
    zeroCostTotalInsCost = map["zeroCostTotalInsCost"];
    zeroCostTotalMaintCost = map["zeroCostTotalMaintCost"];
    zeroCostMonthlyPaymentAmount = map["zeroCostMonthlyPaymentAmount"];
    insuranceCovered = map["insuranceCovered"];
    maintenanceCovered = map["maintenanceCovered"];
    packageId = map["packageId"];
    prospectId = map["prospectId"];
    applicationId = map["applicationId"];
    posId = map["posId"];
    salesAreaId = map["salesAreaId"];
    simulationDate = map["simulationDate"];
    adminFee = double.tryParse(map["adminFee"].toString());
    adminFeePercentage = double.tryParse(map["adminFeePercentage"].toString());
    assetPrice = map["assetPrice"];
    totalPrice = map["totalPrice"];
    merchantDiscountRate = map["merchantDiscountRate"];
    merchantDiscountAmount =
        double.tryParse(map["merchantDiscountAmount"].toString());
    effectiveAssetPrice =
        double.tryParse(map["effectiveAssetPrice"].toString());
    effectiveAmountFinanced =
        double.tryParse(map["effectiveAmountFinanced"].toString());
    effectiveInterestRate =
        double.tryParse(map["effectiveInterestRate"].toString());
    depositAmount = double.tryParse(map["depositAmount"].toString());
    depositPercentage = map["depositPercentage"];
    amountFinanced = double.tryParse(map["amountFinanced"].toString());
    duration = map["duration"];
    interestRate = double.tryParse(map["interestRate"].toString());
    amountFinancedAdminFeeAddUp = map["amountFinancedAdminFeeAddUp"];
    pmtPeriodicity = map["pmtPeriodicity"];
    paymentAtEnd = map["paymentAtEnd"];
    minAmountFinanced = map["minAmountFinanced"];
    minInstallmentAmount = map["minInstallmentAmount"];
    otpFeePercentage = map["otpFeePercentage"];
    earlyPrepaymentPercentage = map["earlyPrepaymentPercentage"];
    earlyPrepaymentAmount = map["earlyPrepaymentAmount"];
    accPmtShare = double.tryParse(map["accPmtShare"].toString());
    accPmtMonthlyShare = double.tryParse(map["accPmtMonthlyShare"].toString());
    firstPayment = map["firstPayment"];
    actualFirstPayment = map["actualFirstPayment"];
    followingPayment = map["followingPayment"];
    accMonthlyPaymentAmount =
        double.tryParse(map["accMonthlyPaymentAmount"].toString());
    accMonthlyLastPaymentAmount =
        double.tryParse(map["accMonthlyLastPaymentAmount"].toString());
    accPaymentAmount = double.tryParse(map["accPaymentAmount"].toString());
    accLastPaymentAmount =
        double.tryParse(map["accLastPaymentAmount"].toString());
    netRentalFee = map["netRentalFee "];
    rentalFeeInsCostAddUp =
        double.tryParse(map["rentalFeeInsCostAddUp"].toString());
    rentalFeeMaintCostAddUp =
        double.tryParse(map["rentalFeeMaintCostAddUp"].toString());
    rentalFeeEnvCostAddUp =
        double.tryParse(map["rentalFeeEnvCostAddUp"].toString());
    amountPayable = double.tryParse(map["amountPayable"].toString());
    simDuration = map["simDuration"];
  }
}
