class CustomerContactDetail {
  int? contactDetId;
  int? customerId;

  // IDENTITY //
  String? relationFullName;
  String? relationDetail;
  String? relationGender;
  String? contactValue;
  int? contactTypeId;
  String? otherContactValue;
  String? homeAddress;
  String? contactDetRemark;

  // NRC //
  int? nrc2Id;
  String? nrcType;
  String? nonNrcPrefix;
  String? nrcDetail;
  String? natRegCardNo;
  String? natRegCardIssDate;

  // INCOME //
  String? contactRole;
  int? selfemployed;
  int? businessTypeId;
  int? jobCategoryId;
  String? workplaceName;
  String? workplaceFixedTel;
  String? workplaceAddress;
  int? incomePeriodicity;
  int? incomeAmount;
  String? incomeSourceRemark;

  CustomerContactDetail({
    this.contactDetId,
    this.customerId,

    // IDENTITY //
    this.relationFullName,
    this.relationDetail,
    this.relationGender,
    this.contactValue,
    this.contactTypeId,
    this.otherContactValue,
    this.homeAddress,
    this.contactDetRemark,

    // NRC //
    this.nrc2Id,
    this.nrcType,
    this.nonNrcPrefix,
    this.nrcDetail,
    this.natRegCardNo,
    this.natRegCardIssDate,

    // INCOME //
    this.contactRole,
    this.selfemployed,
    this.businessTypeId,
    this.jobCategoryId,
    this.workplaceName,
    this.workplaceFixedTel,
    this.workplaceAddress,
    this.incomePeriodicity,
    this.incomeAmount,
    this.incomeSourceRemark,
  });

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "contactDetId": contactDetId,
      "customerId": customerId,

      // IDENTITY //
      "relationFullName": relationFullName,
      "relationDetail": relationDetail,
      "relationGender": relationGender,
      "contactValue": contactValue,
      "contactTypeId": contactTypeId,
      "otherContactValue": otherContactValue,
      "homeAddress": homeAddress,
      "contactDetRemark": contactDetRemark,

      // NRC //
      "nrc2Id": nrc2Id,
      "nrcType": nrcType,
      "nonNrcPrefix": nonNrcPrefix,
      "nrcDetail": nrcDetail,
      "natRegCardNo": natRegCardNo,
      "natRegCardIssDate": natRegCardIssDate,

      // INCOME //
      "contactRole": contactRole,
      "selfemployed": selfemployed,
      "businessTypeId": businessTypeId,
      "jobCategoryId": jobCategoryId,
      "workplaceName": workplaceName,
      "workplaceFixedTel": workplaceFixedTel,
      "workplaceAddress": workplaceAddress,
      "incomePeriodicity": incomePeriodicity,
      "incomeAmount": incomeAmount,
      "incomeSourceRemark": incomeSourceRemark,
    };
    return map;
  }

  CustomerContactDetail.fromMap(Map<String, dynamic> map) {
    contactDetId = map["contactDetId"];
    customerId = map["customerId"];

    // IDENTITY //
    relationFullName = map["relationFullName"];
    relationDetail = map["relationDetail"];
    relationGender = map["relationGender"];
    contactValue = map["contactValue"];
    contactTypeId = map["contactTypeId"];
    otherContactValue = map["otherContactValue"];
    homeAddress = map["homeAddress"];
    contactDetRemark = map["contactDetRemark"];

    // NRC //
    nrc2Id = map["nrc2Id"];
    nrcType = map["nrcType"];
    nonNrcPrefix = map["nonNrcPrefix"];
    nrcDetail = map["nrcDetail"];
    natRegCardNo = map["natRegCardNo"];
    natRegCardIssDate = map["natRegCardIssDate"];

    // INCOME //
    contactRole = map["contactRole"];
    selfemployed = map["selfemployed"];
    businessTypeId = map["businessTypeId"];
    jobCategoryId = map["jobCategoryId"];
    workplaceName = map["workplaceName"];
    workplaceFixedTel = map["workplaceFixedTel"];
    workplaceAddress = map["workplaceAddress"];
    incomePeriodicity = int.tryParse(map["incomePeriodicity"].toString());
    incomeAmount = int.tryParse(map["incomeAmount"].toString());
    incomeSourceRemark = map["incomeSourceRemark"];
  }
}
