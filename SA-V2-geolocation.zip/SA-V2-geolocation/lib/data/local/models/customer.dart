class Customer {
  int? customerId;

  // IDENTITY //
  String? firstName;
  String? middleName;
  String? lastName;
  String? customerFullName;
  String? birthDate;
  String? gender;
  String? homeStatus;
  String? drivingLicenseNo;
  String? fatherName;
  String? fatherBirthDate;
  int? educationId;

  // NRC //
  int? nrc2Id;
  String? nrcType;
  String? nonNrcPrefix;
  String? nrcDetail;
  String? natRegCardNo;
  String? natRegCardIssDate;

  // MARITAL STATUS //
  int? maritalStatusId;
  String? spouseName;
  String? spouseMobileNo;
  String? spouseMobileStatus;
  int? spouseNrc2Id;
  String? spouseNrcType;
  String? spouseNonNrcPrefix;
  String? spouseNrcDetail;
  String? spouseNatRegCardNo;

  // HOME ADDRESS //
  String? homeAddress;
  int? geoTownShipId;
  int? geoTownId;
  int? geoWardId;
  int? geoVillageId;

  // HOUSEHOLD //
  int? childrenHousehold;
  int? relativeHousehold;
  int? otherHousehold;
  int? totalHousehold;

  // CONTACT //
  String? phoneNo1;
  String? phoneStatus1;
  String? phoneType1;
  String? phoneRemark1;
  String? phoneNo2;
  String? phoneNo3;
  String? emailAddress;
  int? hasViberAccount;
  int? isViberAccountSameNo;
  String? viberAccountNo;

  // OTHER //
  String? internalFraudCode;
  int? ownedMotorcycle;
  int? takenHirePurchaseContract;
  int? takenMicroFinanceLoan;
  String? motoFinancingRemark;
  String? customerRemark;

  Customer({
    this.customerId,

    // IDENTITY //
    this.firstName,
    this.middleName,
    this.lastName,
    this.customerFullName,
    this.birthDate,
    this.gender,
    this.homeStatus,
    this.drivingLicenseNo,
    this.fatherName,
    this.fatherBirthDate,
    this.educationId,

    // NRC //
    this.nrc2Id,
    this.nrcType,
    this.nonNrcPrefix,
    this.nrcDetail,
    this.natRegCardNo,
    this.natRegCardIssDate,

    // MARITAL STATUS //
    this.maritalStatusId,
    this.spouseName,
    this.spouseMobileNo,
    this.spouseMobileStatus,
    this.spouseNrc2Id,
    this.spouseNrcType,
    this.spouseNonNrcPrefix,
    this.spouseNrcDetail,
    this.spouseNatRegCardNo,

    // HOME ADDRESS //
    this.homeAddress,
    this.geoTownShipId,
    this.geoTownId,
    this.geoWardId,
    this.geoVillageId,

    // HOUSEHOLD //
    this.childrenHousehold,
    this.relativeHousehold,
    this.otherHousehold,
    this.totalHousehold,

    // CONTACT //
    this.phoneNo1,
    this.phoneStatus1,
    this.phoneType1,
    this.phoneRemark1,
    this.phoneNo2,
    this.phoneNo3,
    this.emailAddress,
    this.hasViberAccount,
    this.isViberAccountSameNo,
    this.viberAccountNo,

    // OTHER //
    this.internalFraudCode,
    this.ownedMotorcycle,
    this.takenHirePurchaseContract,
    this.takenMicroFinanceLoan,
    this.motoFinancingRemark,
    this.customerRemark,
  });

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "customerId": customerId,

      // IDENTITY //
      "firstName": firstName,
      "middleName": middleName,
      "lastName": lastName,
      "customerFullName": customerFullName,
      "birthDate": birthDate,
      "gender": gender,
      "homeStatus": homeStatus,
      "drivingLicenseNo": drivingLicenseNo,
      "fatherName": fatherName,
      "fatherBirthDate": fatherBirthDate,
      "educationId": educationId,

      // NRC //
      "nrc2Id": nrc2Id,
      "nrcType": nrcType,
      "nonNrcPrefix": nonNrcPrefix,
      "nrcDetail": nrcDetail,
      "natRegCardNo": natRegCardNo,
      "natRegCardIssDate": natRegCardIssDate,

      // MARITAL STATUS //
      "maritalStatusId": maritalStatusId,
      "spouseName": spouseName,
      "spouseMobileNo": spouseMobileNo,
      "spouseMobileStatus": spouseMobileStatus,
      "spouseNrc2Id": spouseNrc2Id,
      "spouseNrcType": spouseNrcType,
      "spouseNonNrcPrefix": spouseNonNrcPrefix,
      "spouseNrcDetail": spouseNrcDetail,
      "spouseNatRegCardNo": spouseNatRegCardNo,

      // HOME ADDRESS //
      "homeAddress": homeAddress,
      "geoTownShipId": geoTownShipId,
      "geoTownId": geoTownId,
      "geoWardId": geoWardId,
      "geoVillageId": geoVillageId,

      // HOUSEHOLD //
      "childrenHousehold": childrenHousehold,
      "relativeHousehold": relativeHousehold,
      "otherHousehold": otherHousehold,
      "totalHousehold": totalHousehold,

      // CONTACT //
      "phoneNo1": phoneNo1,
      "phoneStatus1": phoneStatus1,
      "phoneType1": phoneType1,
      "phoneRemark1": phoneRemark1,
      "phoneNo2": phoneNo2,
      "phoneNo3": phoneNo3,
      "emailAddress": emailAddress,
      "hasViberAccount": hasViberAccount,
      "isViberAccountSameNo": isViberAccountSameNo,
      "viberAccountNo": viberAccountNo,

      // OTHER //
      "internalFraudCode": internalFraudCode,
      "ownedMotorcycle": ownedMotorcycle,
      "takenHirePurchaseContract": takenHirePurchaseContract,
      "takenMicroFinanceLoan": takenMicroFinanceLoan,
      "motoFinancingRemark": motoFinancingRemark,
      "customerRemark": customerRemark,
    };
    return map;
  }

  Customer.fromMap(Map<String, dynamic> map) {
    customerId = map["customerId"];

    // IDENTITY //
    firstName = map["firstName"];
    middleName = map["middleName"];
    lastName = map["lastName"];
    customerFullName = map["customerFullName"];
    birthDate = map["birthDate"];
    gender = map["gender"];
    homeStatus = map["homeStatus"];
    drivingLicenseNo = map["drivingLicenseNo"];
    fatherName = map["fatherName"];
    fatherBirthDate = map["fatherBirthDate"];
    educationId = map["educationId"];

    // NRC //
    nrc2Id = map["nrc2Id"];
    nrcType = map["nrcType"];
    nonNrcPrefix = map["nonNrcPrefix"];
    nrcDetail = map["nrcDetail"];
    natRegCardNo = map["natRegCardNo"];
    natRegCardIssDate = map["natRegCardIssDate"];

    // MARITAL STATUS //
    maritalStatusId = map["maritalStatusId"];
    spouseName = map["spouseName"];
    spouseMobileNo = map["spouseMobileNo"];
    spouseMobileStatus = map["spouseMobileStatus"];
    spouseNrc2Id = map["spouseNrc2Id"];
    spouseNrcType = map["spouseNrcType"];
    spouseNonNrcPrefix = map["spouseNonNrcPrefix"];
    spouseNrcDetail = map["spouseNrcDetail"];
    spouseNatRegCardNo = map["spouseNatRegCardNo"];

    // HOME ADDRESS //
    homeAddress = map["homeAddress"];
    geoTownShipId = map["geoTownShipId"];
    geoTownId = map["geoTownId"];
    geoWardId = map["geoWardId"];
    geoVillageId = map["geoVillageId"];

    // HOUSEHOLD //
    childrenHousehold = int.tryParse(map["childrenHousehold"].toString());
    relativeHousehold = int.tryParse(map["relativeHousehold"].toString());
    otherHousehold = int.tryParse(map["otherHousehold"].toString());
    totalHousehold = int.tryParse(map["totalHousehold"].toString());

    // CONTACT //
    phoneNo1 = map["phoneNo1"].toString();
    phoneStatus1 = map["phoneStatus1"];
    phoneType1 = map["phoneType1"];
    phoneRemark1 = map["phoneRemark1"];
    phoneNo2 = map["phoneNo2"].toString();
    phoneNo3 = map["phoneNo3"].toString();
    emailAddress = map["emailAddress"];
    hasViberAccount = map["hasViberAccount"];
    isViberAccountSameNo = map["isViberAccountSameNo"];
    viberAccountNo = map["viberAccountNo"].toString();

    // OTHER //
    internalFraudCode = map["internalFraudCode"];
    ownedMotorcycle = map["ownedMotorcycle"] == true ? 1 : 0;
    takenHirePurchaseContract =
        map["takenHirePurchaseContract"] == true ? 1 : 0;
    takenMicroFinanceLoan = map["takenMicroFinanceLoan"] == true ? 1 : 0;
    motoFinancingRemark = map["motoFinancingRemark"];
    customerRemark = map["customerRemark"];
  }
}
