class AppDataDetailSync {
  int? syncDetId;
  int? syncId;
  String? tableName;
  String? syncVersion;

  AppDataDetailSync(
      {this.syncDetId, this.syncId, this.tableName, this.syncVersion});

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "syncDetId": syncDetId,
      "syncId": syncId,
      "tableName": tableName,
      "syncVersion": syncVersion,
    };
    return map;
  }

  AppDataDetailSync.fromMap(Map<String, dynamic> map) {
    syncDetId = map["syncDetId"];
    syncId = map["syncId"];
    tableName = map["tableName"];
    syncVersion = map["syncVersion"];
  }
}
