class Application {
  int? applicationId;
  int? applicationPlaceId;
  int? prospectId;
  int? customerId;
  int? personDesignatedTo;

  Application(
      {this.applicationId,
      this.applicationPlaceId,
      this.prospectId,
      this.customerId,
      this.personDesignatedTo});

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "applicationId": applicationId,
      "applicationPlaceId": applicationPlaceId,
      "prospectId": prospectId,
      "customerId": customerId,
      "personDesignatedTo": personDesignatedTo,
    };
    return map;
  }

  Application.fromMap(Map<String, dynamic> map) {
    applicationId = map["applicationId"];
    applicationPlaceId = map["applicationPlaceId"];
    prospectId = map["prospectId"];
    customerId = map["customerId"];
    personDesignatedTo = map["personDesignatedTo"];
  }
}
