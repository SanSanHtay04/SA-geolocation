class Product {
  int? productId;
  int? brandId;
  String? productCode;
  String? productName;
  String? modelName;
  int? productPrice;
  int? productCategoryId;
  int? posId;
  int? merchantId;
  String? pmtType;
  int? interestRate;
  String? pmtPeriodicity;
  int? adminFeePercentage;
  int? endDurationMin;
  int? endDurationMax;
  int? endDurationInterval;
  int? endDepositPercentageMin;
  int? endDepositPercentageMax;
  int? endDepositPercentageInterval;
  int? durationMin;
  int? durationInterval;
  int? minAmountFinanced;
  int? minInstallmentAmount;
  int? otpFeePercentage;
  int? merchantDiscountRate;
  int? isPriceLocked;
  int? financialSchemeId;
  String? financialSchemeCode;
  String? financialSchemeName;
  int? isZeroCost;
  int? zeroCostPmtTimes;
  int? maintSchemeId;
  String? maintSchemeCode;
  String? maintSchemeName;
  int? costPerVisit;
  int? intervalOfVisit;
  int? insSchemeId;
  String? insSchemeCode;
  String? insSchemeName;
  int? insFixedCost;
  int? insVariableCost;
  String? insVariableCostApplied;
  int? insVariableCustomValueApplied;
  int? earlyPrepaymentPercentage;

  Product({
    this.productId,
    this.brandId,
    this.productCode,
    this.productName,
    this.modelName,
    this.productPrice,
    this.productCategoryId,
    this.posId,
    this.merchantId,
    this.pmtType,
    this.interestRate,
    this.pmtPeriodicity,
    this.adminFeePercentage,
    this.endDurationMin,
    this.endDurationMax,
    this.endDurationInterval,
    this.endDepositPercentageMin,
    this.endDepositPercentageMax,
    this.endDepositPercentageInterval,
    this.durationMin,
    this.durationInterval,
    this.minAmountFinanced,
    this.minInstallmentAmount,
    this.otpFeePercentage,
    this.merchantDiscountRate,
    this.isPriceLocked,
    this.financialSchemeId,
    this.financialSchemeCode,
    this.financialSchemeName,
    this.isZeroCost,
    this.zeroCostPmtTimes,
    this.maintSchemeId,
    this.maintSchemeCode,
    this.maintSchemeName,
    this.costPerVisit,
    this.intervalOfVisit,
    this.insSchemeId,
    this.insSchemeCode,
    this.insSchemeName,
    this.insFixedCost,
    this.insVariableCost,
    this.insVariableCostApplied,
    this.insVariableCustomValueApplied,
    this.earlyPrepaymentPercentage,
  });

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "productId": productId,
      "brandId": brandId,
      "productCode": productCode,
      "productName": productName,
      "modelName": modelName,
      "productPrice": productPrice,
      "productCategoryId": productCategoryId,
      "posId": posId,
      "merchantId": merchantId,
      "pmtType": pmtType,
      "interestRate": interestRate,
      "pmtPeriodicity": pmtPeriodicity,
      "adminFeePercentage": adminFeePercentage,
      "endDurationMin": endDurationMin,
      "endDurationMax": endDurationMax,
      "endDurationInterval": endDurationInterval,
      "endDepositPercentageMin": endDepositPercentageMin,
      "endDepositPercentageMax": endDepositPercentageMax,
      "endDepositPercentageInterval": endDepositPercentageInterval,
      "durationMin": durationMin,
      "durationInterval": durationInterval,
      "minAmountFinanced": minAmountFinanced,
      "minInstallmentAmount": minInstallmentAmount,
      "otpFeePercentage": otpFeePercentage,
      "merchantDiscountRate": merchantDiscountRate,
      "isPriceLocked": isPriceLocked,
      "financialSchemeId": financialSchemeId,
      "financialSchemeCode": financialSchemeCode,
      "financialSchemeName": financialSchemeName,
      "isZeroCost": isZeroCost,
      "zeroCostPmtTimes": zeroCostPmtTimes,
      "maintSchemeId": maintSchemeId,
      "maintSchemeCode": maintSchemeCode,
      "maintSchemeName": maintSchemeName,
      "costPerVisit": costPerVisit,
      "intervalOfVisit": intervalOfVisit,
      "insSchemeId": insSchemeId,
      "insSchemeCode": insSchemeCode,
      "insSchemeName": insSchemeName,
      "insFixedCost": insFixedCost,
      "insVariableCost": insVariableCost,
      "insVariableCostApplied": insVariableCostApplied,
      "insVariableCustomValueApplied": insVariableCustomValueApplied,
      "earlyPrepaymentPercentage": earlyPrepaymentPercentage,
    };
    return map;
  }

  Product.fromMap(Map<String, dynamic> map) {
    productId = map["productId"];
    brandId = map["brandId"];
    productCode = map["productCode"];
    productName = map["productName"];
    modelName = map["modelName"];
    productPrice = map["productPrice"];
    productCategoryId = map["productCategoryId"];
    posId = map["posId"];
    merchantId = map["merchantId"];
    pmtType = map["pmtType"];
    interestRate = map["interestRate"];
    pmtPeriodicity = map["pmtPeriodicity"];
    adminFeePercentage = map["adminFeePercentage"];
    endDurationMin = map["endDurationMin"];
    endDurationMax = map["endDurationMax"];
    endDurationInterval = map["endDurationInterval"];
    endDepositPercentageMin = map["endDepositPercentageMin"];
    endDepositPercentageMax = map["endDepositPercentageMax"];
    endDepositPercentageInterval = map["endDepositPercentageInterval"];
    durationMin = map["durationMin"];
    durationInterval = map["durationInterval"];
    minAmountFinanced = map["minAmountFinanced"];
    minInstallmentAmount = map["minInstallmentAmount"];
    otpFeePercentage = map["otpFeePercentage"];
    merchantDiscountRate = map["merchantDiscountRate"];
    isPriceLocked = map["isPriceLocked"];
    financialSchemeId = map["financialSchemeId"];
    financialSchemeCode = map["financialSchemeCode"];
    financialSchemeName = map["financialSchemeName"];
    isZeroCost = map["isZeroCost"];
    zeroCostPmtTimes = map["zeroCostPmtTimes"];
    maintSchemeId = map["maintSchemeId"];
    maintSchemeCode = map["maintSchemeCode"];
    maintSchemeName = map["maintSchemeName"];
    costPerVisit = map["costPerVisit"];
    intervalOfVisit = map["intervalOfVisit"];
    insSchemeId = map["insSchemeId"];
    insSchemeCode = map["insSchemeCode"];
    insSchemeName = map["insSchemeName"];
    insFixedCost = map["insFixedCost"];
    insVariableCost = map["insVariableCost"];
    insVariableCostApplied = map["insVariableCostApplied"];
    insVariableCustomValueApplied = map["insVariableCustomValueApplied"];
    earlyPrepaymentPercentage = map["earlyPrepaymentPercentage"];
  }
}
