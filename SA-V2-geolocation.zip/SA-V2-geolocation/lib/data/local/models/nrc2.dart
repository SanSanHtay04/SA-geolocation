class Nrc2 {
  int? nrc2Id;
  int? nrc1Id;
  String? nrc2Name;

  Nrc2({this.nrc2Id, this.nrc1Id, this.nrc2Name});

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "nrc2Id": nrc2Id,
      "nrc1Id": nrc1Id,
      "nrc2Name": nrc2Name,
    };
    return map;
  }

  Nrc2.fromMap(Map<String, dynamic> map) {
    nrc2Id = map["nrc2Id"];
    nrc1Id = map["nrc1Id"];
    nrc2Name = map["nrc2Name"];
  }
}
