class Education {
  int? educationId;
  int? educationOrder;
  String? educationName;

  Education({
    this.educationId,
    this.educationOrder,
    this.educationName,
  });

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "educationId": educationId,
      "educationOrder": educationOrder,
      "educationName": educationName,
    };
    return map;
  }

  Education.fromMap(Map<String, dynamic> map) {
    educationId = map["educationId"];
    educationOrder = map["educationOrder"];
    educationName = map["educationName"];
  }
}
