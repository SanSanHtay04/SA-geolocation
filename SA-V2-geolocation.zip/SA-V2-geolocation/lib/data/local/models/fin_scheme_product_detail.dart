class FinSchemeProductDetail {
  int? finSchemeProductDetId;
  int? financialSchemeId;
  int? productId;
  int? paymentAtEnd;
  int? depositPercentage;
  double? interestRate;
  String? tenureExclusion;
  double? adminFeePercentage;
  int? annualFixedEnvironmentalCost;
  double? loyaltyInterestRate;
  double? loyaltyAdminFeePercentage;

  FinSchemeProductDetail(
      {this.finSchemeProductDetId,
      this.financialSchemeId,
      this.productId,
      this.paymentAtEnd,
      this.depositPercentage,
      this.interestRate,
      this.tenureExclusion,
      this.adminFeePercentage,
      this.annualFixedEnvironmentalCost,
      this.loyaltyInterestRate,
      this.loyaltyAdminFeePercentage});

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "finSchemeProductDetId": finSchemeProductDetId,
      "financialSchemeId": financialSchemeId,
      "productId": productId,
      "paymentAtEnd": paymentAtEnd,
      "depositPercentage": depositPercentage,
      "interestRate": interestRate,
      "tenureExclusion": tenureExclusion,
      "adminFeePercentage": adminFeePercentage,
      "annualFixedEnvironmentalCost": annualFixedEnvironmentalCost,
      "loyaltyInterestRate": loyaltyInterestRate,
      "loyaltyAdminFeePercentage": loyaltyAdminFeePercentage,
    };
    return map;
  }

  FinSchemeProductDetail.fromMap(Map<String, dynamic> map) {
    finSchemeProductDetId = map["finSchemeProductDetId"];
    financialSchemeId = map["financialSchemeId"];
    productId = map["productId"];
    paymentAtEnd = map["paymentAtEnd"];
    depositPercentage = map["depositPercentage"];
    interestRate = double.tryParse(map["interestRate"].toString());
    tenureExclusion = map["tenureExclusion"];
    adminFeePercentage = double.tryParse(map["adminFeePercentage"].toString());
    annualFixedEnvironmentalCost = map["annualFixedEnvironmentalCost"];
    loyaltyInterestRate =
        double.tryParse(map["loyaltyInterestRate"].toString());
    loyaltyAdminFeePercentage =
        double.tryParse(map["loyaltyAdminFeePercentage"].toString());
  }
}
