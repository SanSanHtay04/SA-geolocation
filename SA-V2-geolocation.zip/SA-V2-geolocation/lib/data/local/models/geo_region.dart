class GeoRegion {
  int? geoRegionId;
  String? geoRegionName;

  GeoRegion({this.geoRegionId, this.geoRegionName});

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "geoRegionId": geoRegionId,
      "geoRegionName": geoRegionName,
    };
    return map;
  }

  GeoRegion.fromMap(Map<String, dynamic> map) {
    geoRegionId = map["geoRegionId"];
    geoRegionName = map["geoRegionName"];
  }
}
