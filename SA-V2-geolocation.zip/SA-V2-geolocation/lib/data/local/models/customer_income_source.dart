class CustomerIncomeSource {
  int? incomeSourceId;
  int? customerId;
  int? selfemployed;
  int? businessTypeId;
  int? jobCategoryId;
  String? workplaceName;
  String? workplaceFixedTel;
  String? workplaceAddress;
  int? incomePeriodicity;
  int? incomeAmount;
  String? incomeSourceRemark;
  int? exclusionList;
  String? exclusionListRemark;

  CustomerIncomeSource({
    this.incomeSourceId,
    this.customerId,
    this.selfemployed,
    this.businessTypeId,
    this.jobCategoryId,
    this.workplaceName,
    this.workplaceFixedTel,
    this.workplaceAddress,
    this.incomePeriodicity,
    this.incomeAmount,
    this.incomeSourceRemark,
    this.exclusionList,
    this.exclusionListRemark,
  });

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "incomeSourceId": incomeSourceId,
      "customerId": customerId,
      "selfemployed": selfemployed,
      "businessTypeId": businessTypeId,
      "jobCategoryId": jobCategoryId,
      "workplaceName": workplaceName,
      "workplaceFixedTel": workplaceFixedTel,
      "workplaceAddress": workplaceAddress,
      "incomePeriodicity": incomePeriodicity,
      "incomeAmount": incomeAmount,
      "incomeSourceRemark": incomeSourceRemark,
      "exclusionList": exclusionList,
      "exclusionListRemark": exclusionListRemark
    };
    return map;
  }

  CustomerIncomeSource.fromMap(Map<String, dynamic> map) {
    incomeSourceId = map["incomeSourceId"];
    customerId = map["customerId"];
    selfemployed = map["selfemployed"];
    businessTypeId = map["businessTypeId"];
    jobCategoryId = map["jobCategoryId"];
    workplaceName = map["workplaceName"];
    workplaceFixedTel = map["workplaceFixedTel"];
    workplaceAddress = map["workplaceAddress"];
    incomePeriodicity = map["incomePeriodicity"];
    incomeAmount = map["incomeAmount"];
    incomeSourceRemark = map["incomeSourceRemark"];
    exclusionList = map["exclusionList"];
    exclusionListRemark = map["exclusionListRemark"];
  }
}
