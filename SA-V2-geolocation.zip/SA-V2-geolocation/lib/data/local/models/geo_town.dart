class GeoTown {
  int? geoTownId;
  int? geoTownShipId;
  String? geoTownName;
  int? isVillage;

  GeoTown(
      {this.geoTownId, this.geoTownShipId, this.geoTownName, this.isVillage});

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "geoTownId": geoTownId,
      "geoTownShipId": geoTownShipId,
      "geoTownName": geoTownName,
      "isVillage": isVillage,
    };
    return map;
  }

  GeoTown.fromMap(Map<String, dynamic> map) {
    geoTownId = map["geoTownId"];
    geoTownShipId = map["geoTownShipId"];
    geoTownName = map["geoTownName"];
    isVillage = map["isVillage"];
  }
}
