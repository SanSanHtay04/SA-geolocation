class InsSchemeProductDetail {
  int? insSchemeProductDetId;
  int? insSchemeId;
  String? insSchemeName;
  int? productId;
  int? insFixedCost;
  double? insVariableCost;
  String? insVariableCostApplied;
  int? insVariableCustomValueApplied;
  int? isZeroCost;

  InsSchemeProductDetail(
      {this.insSchemeProductDetId,
      this.insSchemeId,
      this.insSchemeName,
      this.productId,
      this.insFixedCost,
      this.insVariableCost,
      this.insVariableCostApplied,
      this.insVariableCustomValueApplied,
      this.isZeroCost});

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "insSchemeProductDetId": insSchemeProductDetId,
      "insSchemeId": insSchemeId,
      "insSchemeName": insSchemeName,
      "productId": productId,
      "insFixedCost": insFixedCost,
      "insVariableCost": insVariableCost,
      "insVariableCostApplied": insVariableCostApplied,
      "insVariableCustomValueApplied": insVariableCustomValueApplied,
      "isZeroCost": isZeroCost,
    };
    return map;
  }

  InsSchemeProductDetail.fromMap(Map<String, dynamic> map) {
    insSchemeProductDetId = map["insSchemeProductDetId"];
    insSchemeId = map["insSchemeId"];
    insSchemeName = map["insSchemeName"];
    productId = map["productId"];
    insFixedCost = map["insFixedCost"];
    insVariableCost = double.tryParse(map["insVariableCost"].toString());
    insVariableCostApplied = map["insVariableCostApplied"];
    insVariableCustomValueApplied = map["insVariableCustomValueApplied"];
    isZeroCost = map["isZeroCost"];
  }
}
