class GeoTownShip {
  int? geoTownShipId;
  int? geoDistrictId;
  String? geoTownShipName;

  GeoTownShip({this.geoTownShipId, this.geoDistrictId, this.geoTownShipName});

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "geoTownShipId": geoTownShipId,
      "geoDistrictId": geoDistrictId,
      "geoTownShipName": geoTownShipName,
    };
    return map;
  }

  GeoTownShip.fromMap(Map<String, dynamic> map) {
    geoTownShipId = map["geoTownShipId"];
    geoDistrictId = map["geoDistrictId"];
    geoTownShipName = map["geoTownShipName"];
  }
}
