class ProductCategory {
  int? productCategoryId;
  String? productCategoryType;
  String? productCategoryCode;
  String? productCategoryName;

  ProductCategory(
      {this.productCategoryId,
      this.productCategoryType,
      this.productCategoryCode,
      this.productCategoryName});

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "productCategoryId": productCategoryId,
      "productCategoryType": productCategoryType,
      "productCategoryCode": productCategoryCode,
      "productCategoryName": productCategoryName,
    };
    return map;
  }

  ProductCategory.fromMap(Map<String, dynamic> map) {
    productCategoryId = map["productCategoryId"];
    productCategoryType = map["productCategoryType"];
    productCategoryCode = map["productCategoryCode"];
    productCategoryName = map["productCategoryName"];
  }
}
