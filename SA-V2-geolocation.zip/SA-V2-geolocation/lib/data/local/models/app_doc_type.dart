class AppDocType {
  int? docTypeId;
  String? docTypeName;

  AppDocType({this.docTypeId, this.docTypeName});

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "docTypeId": docTypeId,
      "docTypeName": docTypeName,
    };
    return map;
  }

  AppDocType.fromMap(Map<String, dynamic> map) {
    docTypeId = map["docTypeId"];
    docTypeName = map["docTypeName"];
  }
}
