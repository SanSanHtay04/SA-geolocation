class BusinessType {
  int? businessTypeId;
  String? businessTypeName;
  int? businessTypeActive;
  int? selfEmployedApplied;
  int? employedApplied;
  int? unemployedApplied;

  BusinessType(
      {this.businessTypeId,
      this.businessTypeName,
      this.businessTypeActive,
      this.selfEmployedApplied,
      this.employedApplied,
      this.unemployedApplied});

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "businessTypeId": businessTypeId,
      "businessTypeName": businessTypeName,
      "businessTypeActive": businessTypeActive,
      "selfEmployedApplied": selfEmployedApplied,
      "employedApplied": employedApplied,
      "unemployedApplied": unemployedApplied,
    };
    return map;
  }

  BusinessType.fromMap(Map<String, dynamic> map) {
    businessTypeId = map["businessTypeId"];
    businessTypeName = map["businessTypeName"];
    businessTypeActive = map["businessTypeActive"];
    selfEmployedApplied = map["selfEmployedApplied"];
    employedApplied = map["employedApplied"];
    unemployedApplied = map["unemployedApplied"];
  }
}
