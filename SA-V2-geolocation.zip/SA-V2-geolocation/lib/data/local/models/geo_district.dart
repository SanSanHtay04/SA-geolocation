class GeoDistrict {
  int? geoDistrictId;
  int? geoRegionId;
  String? geoDistrictName;

  GeoDistrict({this.geoDistrictId, this.geoRegionId, this.geoDistrictName});

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "geoDistrictId": geoDistrictId,
      "geoRegionId": geoRegionId,
      "geoDistrictName": geoDistrictName,
    };
    return map;
  }

  GeoDistrict.fromMap(Map<String, dynamic> map) {
    geoDistrictId = map["geoDistrictId"];
    geoRegionId = map["geoRegionId"];
    geoDistrictName = map["geoDistrictName"];
  }
}
