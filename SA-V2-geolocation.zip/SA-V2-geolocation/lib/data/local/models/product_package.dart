class ProductPackage {
  int? packageId;
  int? productId;
  int? isBundle;
  int? quantity;
  int? primaryUnitPrice;
  int? primaryTotalPrice;
  int? packageTotalPrice;
  int? financialSchemeId;
  String? financialSchemeName;
  int? insuranceCovered;
  int? maintenanceCovered;
  int? prospectId;
  int? lockedContractId;
  int? isMultiProduct;
  int? paymentAtEnd;
  int? minAmountFinanced;
  int? minInstallmentAmount;
  int? otpFeePercentage;
  int? earlyPrepaymentPercentage;
  int? merchantDiscountRate;
  int? isZeroCost;
  int? zeroCostPmtTimes;
  int? zeroCostTotalInsCost;
  int? zeroCostTotalMaintCost;
  int? isPriceLocked;
  double? allowedInterestRate;
  int? allowedDurationMin;
  int? allowedDurationMax;
  int? allowedDurationInterval;
  int? allowedDepositPercentageMin;
  int? allowedDepositPercentageMax;
  int? allowedDepositPercentageInterval;
  String? allowedPmtPeriodicity;
  double? allowedAdminFeePercentage;
  double? totalMonthlyMaintCostPerVisit;
  int? totalInsFixedCost;
  double? totalInsVariableCostCV;
  double? totalInsVariableCostEV;
  double? totalInsVariableCostAF;
  String? packageRemark;
  int? maintSchemeId;
  String? maintSchemeName;
  int? costPerVisit;
  int? intervalOfVisit;

  ProductPackage({
    this.packageId,
    this.productId,
    this.isBundle,
    this.quantity,
    this.primaryUnitPrice,
    this.primaryTotalPrice,
    this.packageTotalPrice,
    this.financialSchemeId,
    this.financialSchemeName,
    this.insuranceCovered,
    this.maintenanceCovered,
    this.prospectId,
    this.lockedContractId,
    this.isMultiProduct,
    this.paymentAtEnd,
    this.minAmountFinanced,
    this.minInstallmentAmount,
    this.otpFeePercentage,
    this.earlyPrepaymentPercentage,
    this.merchantDiscountRate,
    this.isZeroCost,
    this.zeroCostPmtTimes,
    this.zeroCostTotalInsCost,
    this.zeroCostTotalMaintCost,
    this.isPriceLocked,
    this.allowedInterestRate,
    this.allowedDurationMin,
    this.allowedDurationMax,
    this.allowedDurationInterval,
    this.allowedDepositPercentageMin,
    this.allowedDepositPercentageMax,
    this.allowedDepositPercentageInterval,
    this.allowedPmtPeriodicity,
    this.allowedAdminFeePercentage,
    this.totalMonthlyMaintCostPerVisit,
    this.totalInsFixedCost,
    this.totalInsVariableCostCV,
    this.totalInsVariableCostEV,
    this.totalInsVariableCostAF,
    this.packageRemark,
    this.maintSchemeId,
    this.maintSchemeName,
    this.costPerVisit,
    this.intervalOfVisit,
  });

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "packageId": packageId,
      "productId": productId,
      "isBundle": isBundle,
      "quantity": quantity,
      "primaryUnitPrice": primaryUnitPrice,
      "primaryTotalPrice": primaryTotalPrice,
      "packageTotalPrice": packageTotalPrice,
      "financialSchemeId": financialSchemeId,
      "financialSchemeName": financialSchemeName,
      "insuranceCovered": insuranceCovered,
      "maintenanceCovered": maintenanceCovered,
      "prospectId": prospectId,
      "lockedContractId": lockedContractId,
      "isMultiProduct": isMultiProduct,
      "paymentAtEnd": paymentAtEnd,
      "minAmountFinanced": minAmountFinanced,
      "minInstallmentAmount": minInstallmentAmount,
      "otpFeePercentage": otpFeePercentage,
      "earlyPrepaymentPercentage": earlyPrepaymentPercentage,
      "merchantDiscountRate": merchantDiscountRate,
      "isZeroCost": isZeroCost,
      "zeroCostPmtTimes": zeroCostPmtTimes,
      "zeroCostTotalInsCost": zeroCostTotalInsCost,
      "zeroCostTotalMaintCost": zeroCostTotalMaintCost,
      "isPriceLocked": isPriceLocked,
      "allowedInterestRate": allowedInterestRate,
      "allowedDurationMin": allowedDurationMin,
      "allowedDurationMax": allowedDurationMax,
      "allowedDurationInterval": allowedDurationInterval,
      "allowedDepositPercentageMin": allowedDepositPercentageMin,
      "allowedDepositPercentageMax": allowedDepositPercentageMax,
      "allowedDepositPercentageInterval": allowedDepositPercentageInterval,
      "allowedPmtPeriodicity": allowedPmtPeriodicity,
      "allowedAdminFeePercentage": allowedAdminFeePercentage,
      "totalMonthlyMaintCostPerVisit": totalMonthlyMaintCostPerVisit,
      "totalInsFixedCost": totalInsFixedCost,
      "totalInsVariableCostCV": totalInsVariableCostCV,
      "totalInsVariableCostEV": totalInsVariableCostEV,
      "totalInsVariableCostAF": totalInsVariableCostAF,
      "packageRemark": packageRemark,
      "maintSchemeId": maintSchemeId,
      "maintSchemeName": maintSchemeName,
      "costPerVisit": costPerVisit,
      "intervalOfVisit": intervalOfVisit,
    };
    return map;
  }

  ProductPackage.fromMap(Map<String, dynamic> map) {
    packageId = map["packageId"];
    productId = map["productId"];
    isBundle = map["isBundle"];
    quantity = int.tryParse(map["quantity"].toString());
    primaryUnitPrice = map["primaryUnitPrice"];
    primaryTotalPrice = map["primaryTotalPrice"];
    packageTotalPrice = map["packageTotalPrice"];
    financialSchemeId = map["financialSchemeId"];
    financialSchemeName = map["financialSchemeName"];
    insuranceCovered = map["insuranceCovered"] == true ? 1 : 0;
    maintenanceCovered = map["maintenanceCovered"] == true ? 1 : 0;
    prospectId = map["prospectId"];
    lockedContractId = map["lockedContractId"];
    paymentAtEnd = map["paymentAtEnd"];
    minAmountFinanced = map["minAmountFinanced"];
    minInstallmentAmount = map["minInstallmentAmount"];
    otpFeePercentage = map["otpFeePercentage"];
    earlyPrepaymentPercentage = map["earlyPrepaymentPercentage"];
    merchantDiscountRate = map["merchantDiscountRate"];
    isZeroCost = map["isZeroCost"];
    zeroCostPmtTimes = map["zeroCostPmtTimes"];
    zeroCostTotalInsCost = map["zeroCostTotalInsCost"];
    zeroCostTotalMaintCost = map["zeroCostTotalMaintCost"];
    isPriceLocked = map["isPriceLocked"];
    allowedInterestRate =
        double.tryParse(map["allowedInterestRate"].toString());
    allowedDurationMin = map["allowedDurationMin"];
    allowedDurationMax = map["allowedDurationMax"];
    allowedDurationInterval = map["allowedDurationInterval"];
    allowedDepositPercentageMin = map["allowedDepositPercentageMin"];
    allowedDepositPercentageMax = map["allowedDepositPercentageMax"];
    allowedDepositPercentageInterval = map["allowedDepositPercentageInterval"];
    allowedPmtPeriodicity = map["allowedPmtPeriodicity"];
    allowedAdminFeePercentage =
        double.tryParse(map["allowedAdminFeePercentage"].toString());
    totalMonthlyMaintCostPerVisit =
        double.tryParse(map["totalMonthlyMaintCostPerVisit"].toString());
    totalInsFixedCost = map["totalInsFixedCost"];
    totalInsVariableCostCV =
        double.tryParse(map["totalInsVariableCostCV"].toString());
    totalInsVariableCostEV =
        double.tryParse(map["totalInsVariableCostEV"].toString());
    totalInsVariableCostAF =
        double.tryParse(map["totalInsVariableCostAF"].toString());
    packageRemark = map["packageRemark"];
    maintSchemeId = map["maintSchemeId"];
    maintSchemeName = map["maintSchemeName"];
    costPerVisit = map["costPerVisit"];
    intervalOfVisit = map["intervalOfVisit"];
  }
}
