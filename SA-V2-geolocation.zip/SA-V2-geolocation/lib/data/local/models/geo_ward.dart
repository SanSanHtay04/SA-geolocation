class GeoWard {
  int? geoWardId;
  int? geoTownId;
  String? geoWardName;

  GeoWard({this.geoWardId, this.geoTownId, this.geoWardName});

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "geoWardId": geoWardId,
      "geoTownId": geoTownId,
      "geoWardName": geoWardName,
    };
    return map;
  }

  GeoWard.fromMap(Map<String, dynamic> map) {
    geoWardId = map["geoWardId"];
    geoTownId = map["geoTownId"];
    geoWardName = map["geoWardName"];
  }
}
