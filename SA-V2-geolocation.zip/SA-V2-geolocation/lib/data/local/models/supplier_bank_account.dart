class SupplierBankAccount {
  int? bankAccountId;
  String? supplierName;
  String? bankName;
  String? beneficiary;
  String? accountNo;
  String? accountRemark;

  SupplierBankAccount(
      {this.bankAccountId,
      this.supplierName,
      this.bankName,
      this.beneficiary,
      this.accountNo,
      this.accountRemark});

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "bankAccountId": bankAccountId,
      "supplierName": supplierName,
      "bankName": bankName,
      "beneficiary": beneficiary,
      "accountNo": accountNo,
      "accountRemark": accountRemark,
    };
    return map;
  }

  SupplierBankAccount.fromMap(Map<String, dynamic> map) {
    bankAccountId = map["bankAccountId"];
    supplierName = map["supplierName"];
    bankName = map["bankName"];
    beneficiary = map["beneficiary"];
    accountNo = map["accountNo"];
    accountRemark = map["accountRemark"];
  }
}
