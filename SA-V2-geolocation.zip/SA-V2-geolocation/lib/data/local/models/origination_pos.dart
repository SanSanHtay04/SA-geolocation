class OriginationPOS {
  int? posId;
  int? merchantId;
  String? posCategory;
  String? posProductType;
  String? posName;
  String? posAddress;

  OriginationPOS(
      {this.posId,
      this.merchantId,
      this.posCategory,
      this.posProductType,
      this.posName,
      this.posAddress});

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "posId": posId,
      "merchantId": merchantId,
      "posCategory": posCategory,
      "posProductType": posProductType,
      "posName": posName,
      "posAddress": posAddress,
    };
    return map;
  }

  OriginationPOS.fromMap(Map<String, dynamic> map) {
    posId = map["posId"];
    merchantId = map["merchantId"];
    posCategory = map["posCategory"];
    posProductType = map["posProductType"];
    posName = map["posName"];
    posAddress = map["posAddress"];
  }
}
