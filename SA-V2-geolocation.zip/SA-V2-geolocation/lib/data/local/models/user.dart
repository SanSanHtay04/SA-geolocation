class User {
  int? userId;
  String? userName;
  String? userFullName;
  String? noticeMobile;
  String? noticeMobile2;
  String? noticeEmail;
  String? noticeEmail2;

  User(
      {this.userId,
      this.userName,
      this.userFullName,
      this.noticeMobile,
      this.noticeMobile2,
      this.noticeEmail,
      this.noticeEmail2});

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "userId": userId,
      "userName": userName,
      "userFullName": userFullName,
      "noticeMobile": noticeMobile,
      "noticeMobile2": noticeMobile2,
      "noticeEmail": noticeEmail,
      "noticeEmail2": noticeEmail2,
    };
    return map;
  }

  User.fromMap(Map<String, dynamic> map) {
    userId = map["userId"];
    userName = map["userName"];
    userFullName = map["userFullName"];
    noticeMobile = map["noticeMobile"];
    noticeMobile2 = map["noticeMobile2"];
    noticeEmail = map["noticeEmail"];
    noticeEmail2 = map["noticeEmail2"];
  }
}
