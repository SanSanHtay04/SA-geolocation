class MaritalStatus {
  int? maritalStatusId;
  String? maritalStatusName;
  int? maritalStatusActive;

  MaritalStatus(
      this.maritalStatusId, this.maritalStatusName, this.maritalStatusActive);

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "maritalStatusId": maritalStatusId,
      "maritalStatusName": maritalStatusName,
      "maritalStatusActive": maritalStatusActive,
    };
    return map;
  }

  MaritalStatus.fromMap(Map<String, dynamic> map) {
    maritalStatusId = map["maritalStatusId"];
    maritalStatusName = map["maritalStatusName"];
    maritalStatusActive = map["maritalStatusActive"];
  }
}
