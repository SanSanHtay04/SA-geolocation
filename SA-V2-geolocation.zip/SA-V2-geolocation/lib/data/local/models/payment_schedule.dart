class PaymentSchedule {
  int? paymentId;
  int? simulationId;
  int? lockedContractId;
  int? paymentNo;
  int? pmtPeriodicity;
  int? paymentAtEnd;
  String? originalDueDate;
  String? dueDate;
  String? expiredDate;
  int? lockedPeriod;
  int? lastPayment;
  int? paymentAmount;
  double? accPaymentAmount;
  int? totalAmount;
  double? remainingPrincipal;
  double? remainingInterest;
  double? effectivePrincipalPayment;
  double? effectiveInterestPayment;
  double? addedCost;
  double? remainingProductValue;
  double? effectiveRemainingProductValue;
  double? otpFeeAmount;
  double? otpAmount;
  double? partialZeroCostOtpAmount;

  PaymentSchedule({
    this.paymentId,
    this.simulationId,
    this.lockedContractId,
    this.paymentNo,
    this.pmtPeriodicity,
    this.paymentAtEnd,
    this.originalDueDate,
    this.dueDate,
    this.expiredDate,
    this.lockedPeriod,
    this.lastPayment,
    this.paymentAmount,
    this.accPaymentAmount,
    this.totalAmount,
    this.remainingPrincipal,
    this.remainingInterest,
    this.effectivePrincipalPayment,
    this.effectiveInterestPayment,
    this.addedCost,
    this.remainingProductValue,
    this.effectiveRemainingProductValue,
    this.otpFeeAmount,
    this.otpAmount,
    this.partialZeroCostOtpAmount,
  });

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "paymentId": paymentId,
      "simulationId": simulationId,
      "lockedContractId": lockedContractId,
      "paymentNo": paymentNo,
      "pmtPeriodicity": pmtPeriodicity,
      "paymentAtEnd": paymentAtEnd,
      "originalDueDate": originalDueDate,
      "dueDate": dueDate,
      "expiredDate": expiredDate,
      "lockedPeriod": lockedPeriod,
      "lastPayment": lastPayment,
      "paymentAmount": paymentAmount,
      "accPaymentAmount": accPaymentAmount,
      "totalAmount": totalAmount,
      "remainingPrincipal": remainingPrincipal,
      "remainingInterest": remainingInterest,
      "effectivePrincipalPayment": effectivePrincipalPayment,
      "effectiveInterestPayment": effectiveInterestPayment,
      "addedCost": addedCost,
      "remainingProductValue": remainingProductValue,
      "effectiveRemainingProductValue": effectiveRemainingProductValue,
      "otpFeeAmount": otpFeeAmount,
      "otpAmount": otpAmount,
      "partialZeroCostOtpAmount": partialZeroCostOtpAmount,
    };
    return map;
  }

  PaymentSchedule.fromMap(Map<String, dynamic> map) {
    paymentId = map["paymentId"];
    simulationId = map["simulationId"];
    lockedContractId = map["lockedContractId"];
    paymentNo = map["paymentNo"];
    pmtPeriodicity = map["pmtPeriodicity"];
    paymentAtEnd = map["paymentAtEnd"];
    originalDueDate = map["originalDueDate"];
    dueDate = map["dueDate"];
    expiredDate = map["expiredDate"];
    lockedPeriod = map["lockedPeriod"];
    lastPayment = map["lastPayment"];
    paymentAmount = map["paymentAmount"];
    accPaymentAmount = double.tryParse(map["accPaymentAmount"].toString());
    totalAmount = map["totalAmount"];
    remainingPrincipal = double.tryParse(map["remainingPrincipal"].toString());
    remainingInterest = double.tryParse(map["remainingInterest"].toString());
    effectivePrincipalPayment =
        double.tryParse(map["effectivePrincipalPayment"].toString());
    effectiveInterestPayment =
        double.tryParse(map["effectiveInterestPayment"].toString());
    addedCost = double.tryParse(map["addedCost"].toString());
    remainingProductValue =
        double.tryParse(map["remainingProductValue"].toString());
    effectiveRemainingProductValue =
        double.tryParse(map["effectiveRemainingProductValue"].toString());
    otpFeeAmount = double.tryParse(map["otpFeeAmount"].toString());
    otpAmount = double.tryParse(map["otpAmount"].toString());
    partialZeroCostOtpAmount =
        double.tryParse(map["partialZeroCostOtpAmount"].toString());
  }
}
