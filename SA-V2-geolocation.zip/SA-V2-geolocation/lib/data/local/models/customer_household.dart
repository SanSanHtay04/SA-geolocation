class CustomerHouseHold {
  int? householdId;
  int? customerId;
  String? householdName;
  String? householdMobileNo;
  String? otherMobileNo;
  int? incomeEarner;
  String? incomePeriodicity;
  int? incomeAmount;
  int? nrc2Id;
  String? nrcType;
  String? nonNrcPrefix;
  String? nrcDetail;
  String? natRegCardNo;
  String? natRegCardIssDate;
  String? householdRemark;

  CustomerHouseHold({
    this.householdId,
    this.customerId,
    this.householdName,
    this.householdMobileNo,
    this.otherMobileNo,
    this.incomeEarner,
    this.incomePeriodicity,
    this.incomeAmount,
    this.nrc2Id,
    this.nrcType,
    this.nonNrcPrefix,
    this.nrcDetail,
    this.natRegCardNo,
    this.natRegCardIssDate,
    this.householdRemark,
  });

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "householdId": householdId,
      "customerId": customerId,
      "householdName": householdName,
      "householdMobileNo": householdMobileNo,
      "otherMobileNo": otherMobileNo,
      "incomeEarner": incomeEarner,
      "incomePeriodicity": incomePeriodicity,
      "incomeAmount": incomeAmount,
      "nrc2Id": nrc2Id,
      "nrcType": nrcType,
      "nonNrcPrefix": nonNrcPrefix,
      "nrcDetail": nrcDetail,
      "natRegCardNo": natRegCardNo,
      "natRegCardIssDate": natRegCardIssDate,
      "householdRemark": householdRemark,
    };
    return map;
  }

  CustomerHouseHold.fromMap(Map<String, dynamic> map) {
    householdId = map["householdId"];
    customerId = map["customerId"];
    householdName = map["householdName"];
    householdMobileNo = map["householdMobileNo"];
    otherMobileNo = map["otherMobileNo"];
    incomeEarner = map["incomeEarner"];
    incomePeriodicity = map["incomePeriodicity"];
    incomeAmount = map["incomeAmount"];
    nrc2Id = map["nrc2Id"];
    nrcType = map["nrcType"];
    nonNrcPrefix = map["nonNrcPrefix"];
    nrcDetail = map["nrcDetail"];
    natRegCardNo = map["natRegCardNo"];
    natRegCardIssDate = map["natRegCardIssDate"];
    householdRemark = map["householdRemark"];
  }
}
