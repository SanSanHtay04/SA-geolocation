class SecondaryProduct {
  int? secProductId;
  String? secProductName;
  String? secProductType;
  int? secProductRetalPrice;
  int? secProductMerchantDiscountRate;
  String? secProductRemark;
  int? bankAccountId;

  SecondaryProduct(
      {this.secProductId,
      this.secProductName,
      this.secProductType,
      this.secProductRetalPrice,
      this.secProductMerchantDiscountRate,
      this.secProductRemark,
      this.bankAccountId});

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "secProductId": secProductId,
      "secProductName": secProductName,
      "secProductType": secProductType,
      "secProductRetalPrice": secProductRetalPrice,
      "secProductMerchantDiscountRate": secProductMerchantDiscountRate,
      "secProductRemark": secProductRemark,
      "bankAccountId": bankAccountId,
    };
    return map;
  }

  SecondaryProduct.fromMap(Map<String, dynamic> map) {
    secProductId = map["secProductId"];
    secProductName = map["secProductName"];
    secProductType = map["secProductType"];
    secProductRetalPrice = map["secProductRetalPrice"];
    secProductMerchantDiscountRate = map["secProductMerchantDiscountRate"];
    secProductRemark = map["secProductRemark"];
    bankAccountId = map["bankAccountId"];
  }
}
