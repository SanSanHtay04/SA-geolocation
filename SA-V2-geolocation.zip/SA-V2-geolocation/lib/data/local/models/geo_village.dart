class GeoVillage {
  int? geoVillageId;
  int? geoTownId;
  String? geoVillageName;

  GeoVillage({this.geoVillageId, this.geoTownId, this.geoVillageName});

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "geoVillageId": geoVillageId,
      "geoTownId": geoTownId,
      "geoVillageName": geoVillageName,
    };
    return map;
  }

  GeoVillage.fromMap(Map<String, dynamic> map) {
    geoVillageId = map["geoVillageId"];
    geoTownId = map["geoTownId"];
    geoVillageName = map["geoVillageName"];
  }
}
