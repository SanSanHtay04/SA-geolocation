class AppUpload {
  int? uploadId;
  int? applicationId;
  int? documentId;
  String? uploadName;
  String? uploadDesc;
  String? fileData;

  AppUpload({
    this.uploadId,
    this.applicationId,
    this.documentId,
    this.uploadName,
    this.uploadDesc,
    this.fileData,
  });

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "uploadId": uploadId,
      "applicationId": applicationId,
      "documentId": documentId,
      "uploadName": uploadName,
      "uploadDesc": uploadDesc,
      "fileData": fileData,
    };
    return map;
  }

  AppUpload.fromMap(Map<String, dynamic> map) {
    uploadId = map["uploadId"];
    applicationId = map["applicationId"];
    documentId = map["documentId"];
    uploadName = map["uploadName"];
    uploadDesc = map["uploadDesc"];
    fileData = map["fileData"];
  }
}
