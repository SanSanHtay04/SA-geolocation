class AppDocument {
  int? documentId;
  int? docTypeId;
  String? docProductType;
  String? documentCode;
  String? documentName;
  String? documentRemark;

  AppDocument({
    this.documentId,
    this.docTypeId,
    this.docProductType,
    this.documentCode,
    this.documentName,
    this.documentRemark,
  });

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "documentId": documentId,
      "docTypeId": docTypeId,
      "docProductType": docProductType,
      "documentCode": documentCode,
      "documentName": documentName,
      "documentRemark": documentRemark,
    };
    return map;
  }

  AppDocument.fromMap(Map<String, dynamic> map) {
    documentId = map["documentId"];
    docTypeId = map["docTypeId"];
    docProductType = map["docProductType"];
    documentCode = map["documentCode"];
    documentName = map["documentName"];
    documentRemark = map["documentRemark"];
  }
}
