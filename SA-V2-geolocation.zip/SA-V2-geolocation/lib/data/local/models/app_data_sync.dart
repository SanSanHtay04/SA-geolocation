class AppDataSync {
  int? syncId;
  String? frequency;
  String? syncName;
  String? syncVersion;
  String? onlineSyncVersion;
  String? syncRemark;

  AppDataSync(
      {this.syncId,
      this.frequency,
      this.syncName,
      this.syncVersion,
      this.onlineSyncVersion,
      this.syncRemark});

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "syncId": syncId,
      "frequency": frequency,
      "syncName": syncName,
      "syncVersion": syncVersion,
      "onlineSyncVersion": onlineSyncVersion,
      "syncRemark": syncRemark,
    };
    return map;
  }

  AppDataSync.fromMap(Map<String, dynamic> map) {
    syncId = map["syncId"];
    frequency = map["frequency"];
    syncName = map["syncName"];
    syncVersion = map["syncVersion"];
    onlineSyncVersion = map['onlineSyncVersion'];
    syncRemark = map["syncRemark"];
  }
}
