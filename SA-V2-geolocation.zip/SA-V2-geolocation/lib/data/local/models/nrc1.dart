class Nrc1 {
  int? nrc1Id;
  String? nrc1Name;

  Nrc1({this.nrc1Id, this.nrc1Name});

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "nrc1Id": nrc1Id,
      "nrc1Name": nrc1Name,
    };
    return map;
  }

  Nrc1.fromMap(Map<String, dynamic> map) {
    nrc1Id = map["nrc1Id"];
    nrc1Name = map["nrc1Name"];
  }
}
