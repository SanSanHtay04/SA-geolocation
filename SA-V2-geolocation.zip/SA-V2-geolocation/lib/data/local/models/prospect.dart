class Prospect {
  int? prospectId;
  int? posId;
  String? prospectName;
  String? prospectGender;
  String? prospectMobile;
  String? prospectOtherMobile;
  String? prospectRemark;
  int? createdCustId;
  int? submittedAppId;
  String? awarenessCode;
  int? directSales;

  Prospect({
    this.prospectId,
    this.posId,
    this.prospectName,
    this.prospectGender,
    this.prospectMobile,
    this.prospectOtherMobile,
    this.prospectRemark,
    this.createdCustId,
    this.submittedAppId,
    this.awarenessCode,
    this.directSales,
  });

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "prospectId": prospectId,
      "posId": posId,
      "prospectName": prospectName,
      "prospectGender": prospectGender,
      "prospectMobile": prospectMobile,
      "prospectOtherMobile": prospectOtherMobile,
      "prospectRemark": prospectRemark,
      "createdCustId": createdCustId,
      "submittedAppId": submittedAppId,
      "awarenessCode": awarenessCode,
      "directSales": directSales,
    };
    return map;
  }

  Prospect.fromMap(Map<String, dynamic> map) {
    prospectId = map["prospectId"];
    posId = map["posId"];
    prospectName = map["prospectName"];
    prospectGender = map["prospectGender"];
    prospectMobile = map["prospectMobile"];
    prospectOtherMobile = map["prospectOtherMobile"];
    prospectRemark = map["prospectRemark"];
    createdCustId = map["createdCustId"];
    submittedAppId = map["submittedAppId"];
    awarenessCode = map["awarenessCode"];
    directSales = map["directSales"];
  }
}
