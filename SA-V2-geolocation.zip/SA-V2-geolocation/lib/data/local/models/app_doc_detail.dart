class AppDocDetail {
  int? docDetId;
  int? applicationId;
  int? documentId;
  String? docDetRemark;

  AppDocDetail({
    this.docDetId,
    this.applicationId,
    this.documentId,
    this.docDetRemark,
  });

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      "docDetId": docDetId,
      "applicationId": applicationId,
      "documentId": documentId,
      "docDetRemark": docDetRemark,
    };
    return map;
  }

  AppDocDetail.fromMap(Map<String, dynamic> map) {
    docDetId = map["docDetId"];
    applicationId = map["applicationId"];
    documentId = map["documentId"];
    docDetRemark = map["docDetRemark"];
  }
}
