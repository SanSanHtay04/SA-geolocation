import 'package:sales/base/base_repository.dart';
import 'package:sales/base/data_response.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/data/remote/services/common_service.dart';

class MaritalStatusRepo with BaseRepository {
  final CommonService _api;
  MaritalStatusRepo(this._api);

  Future<DataResponse<List<MaritalStatus>>> getStatuses() {
    return getData(
      handleDataRequest: () => _api.getMaritalStatuses(),
      handleDataResponse: (ApiResponse<List<MaritalStatus>> res) => res.data,
    );
  }
}
