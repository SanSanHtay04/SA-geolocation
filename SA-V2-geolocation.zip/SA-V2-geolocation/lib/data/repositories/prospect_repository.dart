import 'package:sales/base/base_repository.dart';
import 'package:sales/base/data_response.dart';

import 'package:sales/data/remote/models/models.dart';
import 'package:sales/data/remote/models/requests/edit_prospect_request.dart';
import 'package:sales/data/remote/services/services.dart';
import 'package:sales/models/models.dart';

import '../../screens/origination/prospects/create_prospect/presentation/notifiers/form/prospect_form_state.dart';

class ProspectRepository with BaseRepository {
  final CommonService _api;
  ProspectRepository(this._api);

  Future<DataResponse<Prospect>> getProspect(int id) async {
    return getData(
      handleDataRequest: () => _api.getProspect(id),
      handleDataResponse: (res) => res.data.toDomainModel(),
    );
  }

  Future<DataResponse<String>> createProspect(
    ProspectFormState data, {
    int? customerId,
    int? applicationId,
    int? contractId,
  }) async {
    return getData(
      handleDataRequest: () {
        final request = ProspectRequest(
          posId: data.posId,
          prospectName: data.name ?? '',
          prospectGender: data.gender?.value ?? GenderType.male.value,
          prospectMobile: data.mobile ?? '',
          prospectOtherMobile: data.otherMobile,
          prospectRemark: data.remark,
          dupCustomerId: customerId,
          dupApplicationId: applicationId,
          dupContractId: contractId,
        );
        return _api.createProspect(request);
      },
      handleDataResponse: (res) => res.messages ?? '',
    );
  }

  Future<DataResponse<String>> editProspect(
    int prospectId,
    ProspectFormState data,
  ) async {
    return getData(
      handleDataRequest: () {
        final request = EditProspectRequest(
          prospectName: data.name ?? '',
          prospectGender: data.gender?.value ?? GenderType.male.value,
          prospectMobile: data.mobile ?? '',
          prospectOtherMobile: data.otherMobile,
          prospectRemark: data.remark,
        );
        return _api.editProspect(prospectId, request);
      },
      handleDataResponse: (res) => res.messages ?? '',
    );
  }
}
