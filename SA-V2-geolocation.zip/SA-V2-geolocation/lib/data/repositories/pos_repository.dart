import 'package:flutter/foundation.dart';
import 'package:sales/base/data_response.dart';
import 'package:sales/data/local/prefs_store.dart';
import 'package:sales/data/local/tables/checkin_table.dart';
import 'package:sales/data/local/tables/pos_table.dart';
import 'package:sales/data/remote/services/services.dart';
import 'package:sales/base/base_repository.dart';

import 'package:sales/utils/utils.dart';
import 'package:sales/models/models.dart';

class POSRepository with BaseRepository {
  final CommonService api;
  final POSDao posDao;
  final CheckinDao checkinDao;
  final PrefsStore prefsStore;

  POSRepository(this.api, {required this.posDao, required this.checkinDao, required this.prefsStore});

  Future<DataResponse<List<POS>>> getPOSList() async {
    List<POSCache> caches = [];

    if (shouldFetch) {
      await getData(
        handleDataRequest: () => api.getPOSList(),
        handleDataResponse: (res) async {
          caches = res.data.map((e) => POSCache.fromResponse(e)).toList();
          if (!kIsWeb) {
            await posDao.deleteALl();
            await posDao.insertAll(caches);
            await checkinDao.deleteALl();
            await prefsStore.setPOSListLastFetch(DateTime.now());
          }
        },
      );
    } else if (caches.isEmpty && !kIsWeb) {
      caches = await posDao.selectAll();
    }
    AppLogger.i('POS Cache size : ${caches.length}');
    if (caches.isEmpty)
      return DataResponse.failed("Empty POS!");
    else{
      return DataResponse.success(caches.map((e) => POS.fromCache(e)).toList());

    }
  }

  bool get shouldFetch {
    final lastFetch = prefsStore.lastPOSListFetch;

    return lastFetch == null ||
        lastFetch.add(Duration(minutes: 30)).isBefore(DateTime.now()) ||
        kIsWeb;
  }
}
