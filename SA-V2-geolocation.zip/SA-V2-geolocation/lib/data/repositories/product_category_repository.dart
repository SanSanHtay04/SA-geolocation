import 'package:sales/base/data_response.dart';
import 'package:sales/data/remote/services/services.dart';
import 'package:sales/base/base_repository.dart';
import 'package:sales/models/models.dart';

class ProductCategoryRepository with BaseRepository {
  final CommonService _api;

  ProductCategoryRepository(this._api);

  Future<DataResponse<List<ProductCategory>>> getCategoriesForAcquisition() {
    return getData(
      handleDataRequest: () => _api.getProductCategories(1),
      handleDataResponse: (res) => res.data
          .map((category) => ProductCategory(
                name: category.productCategoryName,
                id: category.productCategoryId,
              ))
          .toList(),
    );
  }

  Future<DataResponse<List<ProductCategory>>> getCategoriesForAll() {
    return getData(
      handleDataRequest: () => _api.getProductCategories(0),
      handleDataResponse: (res) => res.data
          .map((category) => ProductCategory(
                name: category.productCategoryName,
                id: category.productCategoryId,
              ))
          .toList(),
    );
  }
}
