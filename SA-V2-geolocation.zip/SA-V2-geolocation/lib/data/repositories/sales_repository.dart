import 'package:sales/base/base_repository.dart';
import 'package:sales/base/data_response.dart';
import 'package:sales/data/remote/services/services.dart';
import 'package:sales/models/models.dart';

class SalesRepository with BaseRepository {
  final CommonService api;

  SalesRepository(this.api);

  Future<DataResponse<List<SalesArea>>> getSalesArea() async {
    return getData(
      handleDataRequest: () => api.getSalesAreas(),
      handleDataResponse: (res) => res.data
          .where((area) => area.salesAreaActive == 1)
          .map((area) => SalesArea(
                name: area.salesAreaName ?? "",
                id: area.salesAreaId,
                regionId: area.workPlaceId,
              ))
          .toList(),
    );
  }

  Future<DataResponse<List<SalesChannel>>> getSalesChannel() async {
    return getData(
      handleDataRequest: () => api.getSalesChannels(),
      handleDataResponse: (res) => res.salesChannels
          .map((channel) => SalesChannel(
                name: channel.salesChannelName,
                id: channel.salesChannelId,
              ))
          .toList(),
    );
  }

  Future<DataResponse<List<SalesRegion>>> getSalesRegion() async {
    return getData(
      handleDataRequest: () => api.getSalesRegions(),
      handleDataResponse: (res) => res.data
          .map((region) => SalesRegion(
                name: region.workPlaceFullName,
                id: region.workPlaceId,
              ))
          .toList(growable: false),
    );
  }
}
