import 'package:sales/base/base_repository.dart';
import 'package:sales/base/data_response.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/data/remote/services/common_service.dart';

class NrcRepo with BaseRepository {
  final CommonService _service;

  NrcRepo(this._service);

  Future<DataResponse<List<NrcRegion>>> getNrcRegions() {
    return getData(
      handleDataRequest: () => _service.getNrcRegions(),
      handleDataResponse: (ApiResponse<List<NrcRegion>> res) => res.data
    );
  }

  Future<DataResponse<List<NrcPrefix>>> getNrcPrefixes(int regionId) {
    return getData(
      handleDataRequest: () => _service.getNrcPrefixes(regionId),
      handleDataResponse: (ApiResponse<List<NrcPrefix>> res) => res.data,
    );
  }
}
