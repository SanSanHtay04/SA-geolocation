import 'package:sales/base/data_response.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/models/models.dart';
import 'package:sales/data/remote/services/services.dart';
import 'package:sales/base/base_repository.dart';

class SimulationRepository with BaseRepository {
  final CommonService _api;

  SimulationRepository(this._api);

  // TODO: Remove this method to related repository
  Future<DataResponse<Map<String, dynamic>>> getProductPackage(
    int prospectId,
    int productPackageId,
  ) {
    return getData(
      handleDataRequest: () => _api.getProdPackage(
        prospectId,
        productPackageId,
      ),
      handleDataResponse: (res) => res.data,
    );
  }

  Future<DataResponse<Map<TenureType, List<DownPayment>>>> calcSimulation(
    int packageId,
  ) {
    return getData(
      handleDataRequest: () => _api.calcSimulation(packageId),
      handleDataResponse: (res) {
        final data = res.data.simulation;

        if (data.monthly.isEmpty && data.quarterly.isEmpty) {
          throw 'Down Payments & Tenures is empty!\nPlease re-check selected product and options.';
        }

        final monthly = _parseDownPayments(data.monthly);
        final quarterly = _parseDownPayments(data.quarterly);
        return {TenureType.monthly: monthly, TenureType.quarterly: quarterly};
      },
    );
  }

  List<DownPayment> _parseDownPayments(List<List<SimulationModel>> data) {
    return data.fold<List<DownPayment>>(
      <DownPayment>[],
      (list, element) => list..add(_parseDownPayment(element)),
    );
  }

  DownPayment _parseDownPayment(List<SimulationModel> data) {
    final firstSimulation = data.first;
    return DownPayment(
      depositPercentage: firstSimulation.depositPercentage,
      depositAmount: firstSimulation.depositAmount,
      zeroCost: ZeroCostData(
        zeroCostPmtTimes: firstSimulation.zeroCostPmtTimes,
        zeroCostMonthlyPaymentAmount: firstSimulation.zeroCostMonthlyPaymentAmount,
        zeroCostTotalInsCost: firstSimulation.zeroCostTotalInsCost,
        zeroCostTotalMaintCost: firstSimulation.zeroCostTotalMaintCost,
      ),
      tenures: data,
      adminFee: firstSimulation.adminFee,
    );
  }

  Future<DataResponse<String>> createSimulation({
    required int packageId,
    required int prospectId,
    required SimulationModel data,
  }) {
    return getData(
      handleDataRequest: () {
        final request = data.toRequestModel(
          packageId: packageId,
          prospectId: prospectId,
        );
        return _api.createSimulation(prospectId, request);
      },
      handleDataResponse: (res) => res.messages ?? '',
    );
  }
}
