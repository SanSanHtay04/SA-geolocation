import 'package:sales/base/data_response.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/data/remote/services/services.dart';
import 'package:sales/base/base_repository.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/models/models.dart';

class LocationTrackingRepository with BaseRepository {
  CommonService _api;

  LocationTrackingRepository(this._api);

  Future<DataResponse<WorkingTimeResponse>> getWorkingTime() {
    return getData(
      handleDataRequest: () => _api.getWorkingTime(),
      handleDataResponse: (ApiResponse<WorkingTimeResponse> res) => res.data,
    );
  }

  Future<void> sendLocation(double latitude, double longitude, POS? pos) async {
    await getData(
      handleDataRequest: () {
        final request = SendLocationRequest(
          geoLocation: [
            SendLocationRequestData(
              latitude: latitude,
              longitude: longitude,
              posId: pos?.id,
              datetime: DateTime.now().format(formatPattern: DATETIME_FORMAT),
            )
          ],
        );
        return _api.sendLocation(request);
      },
      handleDataResponse: (res) {},
    );
  }
}
