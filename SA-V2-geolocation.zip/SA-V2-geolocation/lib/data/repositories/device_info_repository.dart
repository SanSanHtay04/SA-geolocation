import 'package:sales/base/base_repository.dart';
import 'package:sales/base/data_response.dart';
import 'package:sales/configs.dart';
import 'package:sales/data/remote/models/models.dart';

import '../remote/services/services.dart';

class DeviceInfoRepository with BaseRepository {
  final DeviceInfoService _api;

  DeviceInfoRepository(this._api);

  Future<DataResponse<void>> submitCallLogs({
    String? ime,
    required List<DeviceCallLog> data,
  }) {
    return getData(
      handleDataRequest: () {
        final request = DeviceInfoCallLogRequest(
          data: data,
        );
        return _api.uploadCallLogs(request);
      },
      handleDataResponse: (res) {},
    );
  }

  Future<DataResponse<void>> submitSmsLogs({
    String? ime,
    required List<DeviceSmsLog> data,
  }) {
    return getData(
      handleDataRequest: () {
        final request = DeviceInfoSmsLogRequest(
          logs: data,
        );
        return _api.uploadSmsLogs(request);
      },
      handleDataResponse: (res) {},
    );
  }

  Future<DataResponse<void>> submitContacts({
    String? ime,
    required List<DeviceContactInfo> data,
  }) {
    return getData(
      handleDataRequest: () {
        final request = DeviceInfoContactRequest(
          data: data,
        );
        return _api.uploadContacts(request);
      },
      handleDataResponse: (res) {},
    );
  }

  Future<DataResponse<void>> submitDeviceDetailInfo({
    String? imeiNo,
    String? deviceModel,
    String? deviceBrand,
    String? deviceName,
    String? softwareId,
    String? operationSystemVersion,
  }) {
    return getData(
      handleDataRequest: () {
        final request = DeviceInfoDetailRequest(
          imeiNo: imeiNo,
          deviceModel: deviceModel,
          deviceBrand: deviceBrand,
          deviceName: deviceName,
          softwareId: softwareId,
          operationSystemVersion: operationSystemVersion,
        );
        return _api.uploadDevice(request);
      },
      handleDataResponse: (res) {},
    );
  }

  Future<DataResponse<void>> submitLocation({
    String? ime,
    String? latitude,
    String? longitude,
  }) {
    return getData(
      handleDataRequest: () {
        final request = DeviceInfoLiveLocationRequest(
          latitude: latitude,
          longitude: longitude,
        );
        return _api.uploadLocation(request);
      },
      handleDataResponse: (res) {},
    );
  }

  Future<DataResponse<void>> submitSimCard({
    String? ime,
    String? sim1,
    String? sim2,
  }) {
    return getData(
      handleDataRequest: () {
        final request = DeviceInfoSimCardRequest(
          simCardNo1: sim1,
          simCardNo2: sim2,
        );
        return _api.uploadSimCard(request);
      },
      handleDataResponse: (res) {},
    );
  }
}
