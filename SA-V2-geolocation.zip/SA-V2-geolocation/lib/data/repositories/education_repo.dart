import 'package:sales/base/base_repository.dart';
import 'package:sales/base/data_response.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/data/remote/services/common_service.dart';

class EducationRepo with BaseRepository {
  final CommonService _service;
  EducationRepo(this._service);

  Future<DataResponse<List<EducationLevel>>> getEducations() {
    return getData(handleDataRequest: () => _service.getEducations(), handleDataResponse: (ApiResponse<List<EducationLevel>> res) => res.data);
  }
}
