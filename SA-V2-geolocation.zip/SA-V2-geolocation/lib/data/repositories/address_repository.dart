import 'package:sales/base/base_repository.dart';
import 'package:sales/base/data_response.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/data/remote/services/services.dart';

class AddressRepository with BaseRepository {
  final AddressService _api;

  AddressRepository(this._api);

  Future<DataResponse<List<Region>>> getRegions() {
    return getData(
      handleDataRequest: () => _api.getRegions(),
      handleDataResponse: (ApiResponse<List<Region>> res) => res.data,
    );
  }

  Future<DataResponse<List<District>>> getDistricts(Region region) {
    return getData(
      handleDataRequest: () => _api.getDistricts(region.geoRegionId),
      handleDataResponse: (ApiResponse<List<District>> res) => res.data,
    );
  }

  Future<DataResponse<List<Township>>> getTownships(District district) {
    return getData(
      handleDataRequest: () => _api.getTownships(district.geoDistrictId),
      handleDataResponse: (ApiResponse<List<Township>> res) => res.data,
    );
  }

  Future<DataResponse<List<Town>>> getTowns(Township township) {
    return getData(
      handleDataRequest: () => _api.getTowns(township.geoTownShipId),
      handleDataResponse: (ApiResponse<List<Town>> res) => res.data,
    );
  }

  Future<DataResponse<List<Ward>>> getWards(Town town) {
    return getData(
      handleDataRequest: () => _api.getWards(town.geoTownId),
      handleDataResponse: (ApiResponse<List<Ward>> res) => res.data,
    );
  }

  Future<DataResponse<List<Town>>> getVillageTracts(Township township) {
    return getData(
      handleDataRequest: () => _api.getVillageTracts(township.geoTownShipId),
      handleDataResponse: (ApiResponse<List<Town>> res) => res.data,
    );
  }

  Future<DataResponse<List<Village>>> getVillages(Town town) {
    return getData(
      handleDataRequest: () => _api.getVillages(town.geoTownId),
      handleDataResponse: (ApiResponse<List<Village>> res) => res.data,
    );
  }
}
