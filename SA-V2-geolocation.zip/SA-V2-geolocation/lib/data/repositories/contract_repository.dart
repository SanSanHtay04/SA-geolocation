import 'package:sales/base/data_response.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/data/remote/services/services.dart';
import 'package:sales/base/base_repository.dart';
import 'package:sales/models/replicated_contract.dart';

class ContractRepository with BaseRepository {
  final CommonService _api;

  ContractRepository(this._api);

  Future<DataResponse<List<ContractDocumentResponse>>> getContracts(
    String query,
    int contractNoOrNRC,
  ) async {
    return getData(
      handleDataRequest: () => _api.getContractDocs(query, contractNoOrNRC),
      handleDataResponse: (res) => res.data,
    );
  }

  Future<DataResponse<ReplicatedContract>> getContract(String sequnece) async {
    return getData(
      handleDataRequest: () => _api.getContract(sequnece),
      handleDataResponse: (res) => res.data.toDomainData(),
    );
  }
}
