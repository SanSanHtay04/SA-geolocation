import 'package:sales/base/base_repository.dart';
import 'package:sales/base/data_response.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/data/remote/services/services.dart';
import 'package:sales/screens/origination/prospects/customer/notifiers/form/customer_form_state.dart';

class CustomerRepository with BaseRepository {
  final CommonService _api;
  CustomerRepository(this._api);

  Future<DataResponse<Customer>> getCustomerInfo(int id) {
    return getData(
      handleDataRequest: () => _api.getCustomerInfo(id),
      handleDataResponse: (res) => res.data,
    );
  }

  Future<DataResponse<String>> updateCustomer(CustomerFormState data) {
    return getData(
      handleDataRequest: () => _api.editCustomer(
        data.customerId!,
        data.toEditRequest(),
      ),
      handleDataResponse: (res) => res.messages ?? res.message ?? '',
    );
  }

  Future<DataResponse<String>> createCustomer(CustomerFormState data) {
    return getData(
      handleDataRequest: () {
        final request = data.toRequest();
        return _api.createCustomer(request);
      },
      handleDataResponse: (res) => res.messages ?? res.message ?? '',
    );
  }
}
