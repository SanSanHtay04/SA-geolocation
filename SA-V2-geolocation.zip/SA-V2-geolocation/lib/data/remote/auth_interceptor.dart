import 'dart:io';

import 'package:dio/dio.dart';
import 'package:sales/data/local/prefs_store.dart';
import 'package:sales/providers/local_auth_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AuthInterceptor extends Interceptor {
  final LocalAuthProvider _authProvider;

  AuthInterceptor(this._authProvider);

  @override
  void onRequest(
    RequestOptions options,
    RequestInterceptorHandler handler,
  ) async {
    final prefs = PrefsStore(await SharedPreferences.getInstance());
    final token = prefs.accessToken ?? '';
    if (token.isNotEmpty) {
      options.headers[HttpHeaders.authorizationHeader] = 'Bearer $token';
    }
    return super.onRequest(options, handler);
  }

  @override
  void onError(DioException exception, ErrorInterceptorHandler handler) {
    if (exception.response != null && exception.response?.statusCode == 401) {
      _authProvider.logout();
    }
    super.onError(exception, handler);
  }
}
