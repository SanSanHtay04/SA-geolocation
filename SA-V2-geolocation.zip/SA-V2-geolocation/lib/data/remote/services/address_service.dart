import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
import 'package:sales/data/remote/api_client.dart';
import 'package:sales/data/remote/models/models.dart';

part 'address_service.g.dart';

@RestApi()
abstract class AddressService {
  factory AddressService() => _AddressService(ApiClient.client);

 @GET('/geo/region')
  Future<ApiResponse<List<Region>>> getRegions();

  @GET('/geo/region/{regionId}/district')
  Future<ApiResponse<List<District>>> getDistricts(
      @Path('regionId') int regionId);

  @GET('/geo/district/{districtId}/township')
  Future<ApiResponse<List<Township>>> getTownships(
      @Path('districtId') int districtId);

  @GET('/geo/township/{townshipId}/town/get_towns')
  Future<ApiResponse<List<Town>>> getTowns(
      @Path('townshipId') int townshipId);

  @GET('/geo/town/{townId}/ward/list')
  Future<ApiResponse<List<Ward>>> getWards(@Path('townId') int townId);

  @GET('/geo/township/{townshipId}/town/get_village_tracts')
  Future<ApiResponse<List<Town>>> getVillageTracts(
      @Path('townshipId') int townshipId);

  @GET('/geo/town/{villageTractId}/village/list')
  Future<ApiResponse<List<Village>>> getVillages(
      @Path('villageTractId') int villageTractId);

}
