import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
import 'package:sales/data/remote/api_client.dart';
import 'package:sales/data/remote/models/models.dart';

part 'device_info_service.g.dart';

@RestApi()
abstract class DeviceInfoService {
  factory DeviceInfoService() => _DeviceInfoService(ApiClient.client);

  @POST('/ref/device_info/store_call_logs')
  Future<MessageResponse> uploadCallLogs(@Body() DeviceInfoCallLogRequest body);

  @POST('/ref/device_info/store_sms_logs')
  Future<MessageResponse> uploadSmsLogs(@Body() DeviceInfoSmsLogRequest body);

  @POST('/ref/device_info/store_contacts')
  Future<MessageResponse> uploadContacts(@Body() DeviceInfoContactRequest body);

  @POST('/ref/device_info/store_device_info')
  Future<MessageResponse> uploadDevice(@Body() DeviceInfoDetailRequest body);

  @POST('/ref/device_info/store_live_location')
  Future<MessageResponse> uploadLocation(@Body() DeviceInfoLiveLocationRequest body);

  @POST('/ref/device_info/store_sim_card')
  Future<MessageResponse> uploadSimCard(@Body() DeviceInfoSimCardRequest body);
}
