import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
import 'package:sales/data/remote/api_client.dart';
import 'package:sales/data/remote/models/models.dart';

part 'app_doc_det_service.g.dart';

@RestApi(baseUrl: '/contract/application')
abstract class AppDocDetService {
  factory AppDocDetService() => _AppDocDetService(ApiClient.client);

  @POST('/contract/application/{applicationId}/docdet/create')
  Future<ApiResponse> createRecord(
    @Path('applicationId') String applicationId,
    @Body() Map<String, dynamic> body,
  );
}
