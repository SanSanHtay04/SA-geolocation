import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
import 'package:sales/data/remote/api_client.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/screens/change_password/data/change_password_request.dart';

part 'auth_service.g.dart';

@RestApi()
abstract class AuthService {
  factory AuthService() => _AuthService(ApiClient.client);

  @POST('/system/user/login/sa_app')
  Future<LoginAuthResponse> login(@Body() LoginRequest request);

  @GET('/otp/v2/issue')
  Future<ApiResponse<OtpResponseData>> otpLogin(
    @Query('userName') String username,
    @Query('sendMethod') String sendMethod,
  );

  @POST('/otp/verify/sa_app')
  Future<ApiResponse<AuthResponse>> verifyOTP(
    @Query('userName') String username,
    @Query('token') String code,
    @Query('androidId') String androidId,
  );

  @DELETE('/access_token')
  Future<void> logout();

  @POST('/system/user/change_password')
  Future<MessageResponse> changePassword(@Body() ChangePasswordRequest request);
}
