import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
import 'package:sales/data/remote/api_client.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/data/remote/models/requests/edit_prospect_request.dart';
import 'package:sales/data/remote/models/responses/replicated_contract_response.dart';

import 'package:sales/screens/others/checkup/data/checkup_request.dart';
import 'package:sales/screens/others/checkup/data/checkup_types_response.dart';
import 'package:sales/screens/others/checkup/data/upload_image_response.dart';
import 'package:sales/screens/others/competitor_report/data/competitor_report_request.dart';

part 'common_service.g.dart';

@RestApi()
abstract class CommonService {
  factory CommonService() => _CommonService(ApiClient.client);

  @GET('/system/user/pos_assignment')
  Future<ApiResponse<List<POSResponse>>> getPOSList();

  @POST('/ca_app/v2/tracking/savetracking')
  Future<void> sendLocation(@Body() SendLocationRequest request);

  @GET('/ca_app/product_category')
  Future<ApiResponse<List<ProductCategoriesResponse>>> getProductCategories(
    @Query('forContactAcquisition') int forAcquisition,
  );

  @POST('/ca_app/comp_journal')
  Future<MessageResponse> submitCompetitorReport(
    @Body() CompetitorReportRequest request,
  );

  @POST('/ca_app/merchandises')
  Future<MessageResponse> submitMerchandiseRequest(@Body() MerchandiseRequest request);

  @POST('/ca_app/tracking/check_pos')
  Future<MessageResponse> checkInOutPos(@Body() CheckPosRequest request);

  @GET('/contract/contract/get_printing_doc_by_contract_no/{query}/{contractNoOrNRC}')
  Future<ApiResponse<List<ContractDocumentResponse>>> getContractDocs(
    @Path('query') String query,
    @Path('contractNoOrNRC') int contractNoOrNRC,
  );

  /**
   * the response [WorkingHourResponse] status would be "on" or "off"
   */
  @POST('/ca_app/working_hour')
  Future<WorkingHourResponse> switchWorkHour(@Body() Map<String, dynamic> body);

  @GET('/ca_app/working_hour')
  Future<WorkingHourResponse> getWorkHourState();

  /**
   * the response [BreakTimeResponse] status would be "on" or "off"
   */
  @POST('/ca_app/break_time')
  Future<BreakTimeResponse> switchBreakTime(@Body() Map<String, dynamic> body);

  @GET('/ca_app/break_time')
  Future<BreakTimeResponse> getBreakTimeState();

  /**
   * Sales municipalities
   */

  @GET('/ref/salesarea')
  Future<ApiResponse<List<SalesAreasResponse>>> getSalesAreas();

  @GET('/ca_app/sales_channels')
  Future<SalesChannelsResponse> getSalesChannels();

  @GET('/shared/workplace')
  Future<ApiResponse<List<SalesRegionsResponse>>> getSalesRegions();

  /// END

  @POST('/ca_app/contact_acquisitions')
  Future<MessageResponse> submitAcquisition(
    @Body() AcquisitionRequest request,
  );

  @GET('/ca_app/check_up/type')
  Future<ApiResponse<List<CheckupTypesResponse>>> getCheckupTypes(
    @Query('for') String typeFor,
  );

  @GET('/ca_app/check_up/pos/{posId}/type')
  Future<ApiResponse<List<CheckupTypesResponse>>> getCheckupTypesByPos(
    @Query('for') String typeFor,
    @Path('posId') int posId,
  );

  @GET('/ca_app/tracking/working_time')
  Future<ApiResponse<WorkingTimeResponse>> getWorkingTime();

  @GET('/origination/simulation/package/{packageId}/calculate')
  Future<ApiResponse<CalcSimulationRes>> calcSimulation(
    @Path('packageId') int packageId,
  );

  /// PRODUCT PACKAGE API
  @GET('/origination/prospect/{prospectId}/prodpackage/{packageId}')
  Future<ApiResponse> getProdPackage(
    @Path('prospectId') int prospectId,
    @Path('packageId') int packageId,
  );

  @POST('/origination/prospect/{prospectId}/simulation')
  Future<MessageResponse> createSimulation(
    @Path('prospectId') int prospectId,
    @Body() SimulationRequest body,
  );

  @POST('/ca_app/check_up/upload_image')
  Future<ApiResponse<UploadImageResponse>> uploadImage(@Body() FormData data);

  @POST('/ca_app/check_up/create')
  Future<MessageResponse> createCheckUp(@Body() CheckupRequest body);

  /**
   *  Prospect Information
   */
  @POST('/contract/prospect/sa_mobileapp/create')
  Future<MessageResponse> createProspect(
    @Body() ProspectRequest body,
  );

  @POST('/contract/prospect/sa_mobileapp/{prospectId}/edit')
  Future<MessageResponse> editProspect(
    @Path('prospectId') int prospectId,
    @Body() EditProspectRequest body,
  );

  @GET('/contract/prospect/{prospectId}')
  Future<ApiResponse<ProspectResponse>> getProspect(
    @Path('prospectId') int prospectId,
  );

  /// END : Prospect

  @GET('/contract/prospect/sa_mobileapp/contract_sequence/{sequence}/search')
  Future<ApiResponse<ReplicatedContractResponse>> getContract(
    @Path('sequence') String contractSequence,
  );

  /**
   * Customer Information
   */

  @POST('/contract/customer')
  Future<MessageResponse> createCustomer(@Body() CustomerRequest body);

  @POST('/contract/customer/sa_mobileapp/{id}/edit')
  Future<MessageResponse> editCustomer(
    @Path('id') int customerId,
    @Body() CustomerEditRequest body,
  );

  @GET('/contract/customer/{id}')
  Future<ApiResponse<Customer>> getCustomerInfo(@Path('id') int customerId);

  @GET('/shared/nrc1')
  Future<ApiResponse<List<NrcRegion>>> getNrcRegions();

  @GET('/shared/nrc1/{regionId}/nrc2')
  Future<ApiResponse<List<NrcPrefix>>> getNrcPrefixes(
    @Path('regionId') int regionId,
  );

  @GET('/shared/maritalstatus')
  Future<ApiResponse<List<MaritalStatus>>> getMaritalStatuses();

  @GET('/shared/education')
  Future<ApiResponse<List<EducationLevel>>> getEducations();

  /// END : Customer Information
}
