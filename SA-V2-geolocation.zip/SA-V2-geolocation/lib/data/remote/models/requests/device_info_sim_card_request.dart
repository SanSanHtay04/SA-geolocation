import 'package:freezed_annotation/freezed_annotation.dart';

part 'device_info_sim_card_request.freezed.dart';
part 'device_info_sim_card_request.g.dart';

@freezed
class DeviceInfoSimCardRequest with _$DeviceInfoSimCardRequest {
  const DeviceInfoSimCardRequest._();

  const factory DeviceInfoSimCardRequest({
    String? simCardNo1,
    String? simCardNo2,
  }) = _DeviceInfoSimCardRequest;

  factory DeviceInfoSimCardRequest.fromJson(Map<String, dynamic> json) => _$DeviceInfoSimCardRequestFromJson(json);
}
/*
@freezed
class DeviceSimcardInfo with _$DeviceSimcardInfo {
  const DeviceSimcardInfo._();

  const factory DeviceSimcardInfo({
     String? simCardNo1,
    String? simCardNo2,
  }) = _DeviceSimcardInfo;

  factory DeviceSimcardInfo.fromJson(Map<String, dynamic> json) => _$DeviceSimcardInfoFromJson(json);
} */
