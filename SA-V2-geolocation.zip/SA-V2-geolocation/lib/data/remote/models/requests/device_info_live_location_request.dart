import 'package:freezed_annotation/freezed_annotation.dart';

part 'device_info_live_location_request.freezed.dart';
part 'device_info_live_location_request.g.dart';

@freezed
class DeviceInfoLiveLocationRequest with _$DeviceInfoLiveLocationRequest {
  const DeviceInfoLiveLocationRequest._();

  const factory DeviceInfoLiveLocationRequest({
    String? latitude,
    String? longitude,
  }) = _DeviceInfoLiveLocationRequest;

  factory DeviceInfoLiveLocationRequest.fromJson(Map<String, dynamic> json) => _$DeviceInfoLiveLocationRequestFromJson(json);
}

/*
@freezed
class DeviceLocationInfo with _$DeviceLocationInfo {
  const DeviceLocationInfo._();

  const factory DeviceLocationInfo({
    String? latitude,
    String? longitude,
  }) = _DeviceLocationInfo;

  factory DeviceLocationInfo.fromJson(Map<String, dynamic> json) => _$DeviceLocationInfoFromJson(json);
}
*/
