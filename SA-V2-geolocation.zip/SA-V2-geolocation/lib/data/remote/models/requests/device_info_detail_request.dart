import 'package:freezed_annotation/freezed_annotation.dart';

part 'device_info_detail_request.freezed.dart';
part 'device_info_detail_request.g.dart';

@freezed
class DeviceInfoDetailRequest with _$DeviceInfoDetailRequest {
  const DeviceInfoDetailRequest._();

  const factory DeviceInfoDetailRequest({
    String? imeiNo,
    String? deviceModel,
    String? deviceBrand,
    String? deviceName,
    String? softwareId,
    String? operationSystemVersion,
  }) = _DeviceInfoDetailRequest;

  factory DeviceInfoDetailRequest.fromJson(Map<String, dynamic> json) => _$DeviceInfoDetailRequestFromJson(json);
}
