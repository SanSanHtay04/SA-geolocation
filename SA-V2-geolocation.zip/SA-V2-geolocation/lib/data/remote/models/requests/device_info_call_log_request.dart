import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/utils/custom_date_time_converter.dart';

part 'device_info_call_log_request.freezed.dart';
part 'device_info_call_log_request.g.dart';

@freezed
class DeviceInfoCallLogRequest with _$DeviceInfoCallLogRequest {
  const DeviceInfoCallLogRequest._();

  const factory DeviceInfoCallLogRequest({
    String? imeiNo,
    @Default([]) List<DeviceCallLog> data,
  }) = _DeviceInfoCallLogRequest;

  factory DeviceInfoCallLogRequest.fromJson(Map<String, dynamic> json) => _$DeviceInfoCallLogRequestFromJson(json);
}

@freezed
class DeviceCallLog with _$DeviceCallLog {
  const DeviceCallLog._();

  const factory DeviceCallLog({
    @Default('') String callType,
    @Default('') String phoneNo,
    @Default('') String name,
    @Default('') String simDisplayName,
    @Default(0) int duration,
    @CustomDateTimeConverter() DateTime? calledAt,
  }) = _DeviceCallLog;

  factory DeviceCallLog.fromJson(Map<String, dynamic> json) => _$DeviceCallLogFromJson(json);
}
