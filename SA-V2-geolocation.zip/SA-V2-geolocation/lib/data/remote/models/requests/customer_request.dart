import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/models/address_type.dart';
import 'package:sales/models/gender_type.dart';
import 'package:sales/models/internal_fraud_code.dart';
import 'package:sales/models/phone_type.dart';
import 'package:sales/utils/utils.dart';

part 'customer_request.freezed.dart';
part 'customer_request.g.dart';

@freezed
class CustomerRequest with _$CustomerRequest {
  const CustomerRequest._();

  const factory CustomerRequest({
    required int prospectId,
    required int applicationId,
    required String customerFullName,
    @CustomDateTimeConverter() DateTime? birthDate,
    @Default(GenderType.male) GenderType gender,
    String? fatherName,
    int? educationId,
    @Default(HomeStatus.owned) HomeStatus homeStatus,
    String? homeAddress,
    int? geoWardId,
    int? geoVillageId,
    int? geoTownId,
    int? geoTownShipId,
    double? homeGeoLatitude,
    double? homeGeoLongitude,
    String? homeGeoAddress,
    String? natRegCardNo,
    int? nrc2Id,
    NRCType? nrcType,
    @JsonKey(name: 'nonNrcPrefix') String? frcPrefix,
    @JsonKey(name: 'nrcDetail') required String nrcNumber,
    @CustomDateTimeConverter() DateTime? natRegCardIssDate,
    int? maritalStatusId,
    String? spouseName,
    String? spouseMobileNo,
    PhoneStatus? spouseMobileStatus,
    int? spouseNrc2Id,
    @JsonKey(name: 'spouseNonNrcPrefix') String? spouseFrcPrefix,
    @JsonKey(name: 'spouseNrcDetail') String? spouseNrcNumber,
    @CustomDateTimeConverter() DateTime? spouseNatRegCardIssDate,
    String? spouseNatRegCardNo,
    NRCType? spouseNrcType,
    int? childrenHousehold,
    int? relativeHousehold,
    int? otherHousehold,
    int? totalHousehold,
    required String phoneNo1,
    PhoneStatus? phoneStatus1,
    PhoneType? phoneType1,
    String? phoneRemark1,
    String? phoneNo2,
    String? phoneNo3,
    String? emailAddress,
    @CustomBoolConverter() bool? hasViberAccount,
    @CustomBoolConverter() bool? isViberAccountSameNo,
    
    @JsonKey(name: 'viberAccountNo') String? viberPhoneNo,
    @JsonKey(name: 'viberAccountName') String? viberName,
    @JsonKey(name: 'internalFraudCode') InternalFraudCode? fraudCode,
    @JsonKey(name: 'ownedMotorcycle') @CustomBoolConverter() bool? isOwnedMoto,
    @JsonKey(name: 'takenHirePurchaseContract')
    @CustomBoolConverter()
        bool? isTakenContract,
    @JsonKey(name: 'takenMicroFinanceLoan')
    @CustomBoolConverter()
        bool? isTakenLoan,
    @JsonKey(name: 'motoFinancingRemark') String? motoRemark,
    String? customerRemark,
  }) = _CustomerRequest;

  factory CustomerRequest.fromJson(Map<String, dynamic> json) =>
      _$CustomerRequestFromJson(json);
}

@freezed
class CustomerEditRequest with _$CustomerEditRequest {
  const CustomerEditRequest._();

  const factory CustomerEditRequest({
    /// Identity
    required String customerFullName,
    @CustomDateTimeConverter() DateTime? birthDate,
    @Default(GenderType.male) GenderType gender,
    String? fatherName,
    int? educationId,

    /// Address
    @Default(HomeStatus.owned) HomeStatus homeStatus,
    String? homeAddress,
    int? geoWardId,
    int? geoVillageId,
    int? geoTownId,
    int? geoTownShipId,
    double? homeGeoLatitude,
    double? homeGeoLongitude,
    String? homeGeoAddress,

    /// NRC
    int? nrc2Id,
    NRCType? nrcType,
    @JsonKey(name: 'nonNrcPrefix') String? frcPrefix,
    @JsonKey(name: 'nrcDetail') required String nrcNumber,
    @CustomDateTimeConverter() DateTime? natRegCardIssDate,
    String? natRegCardNo,

    /// Marital Status
    int? maritalStatusId,
    String? spouseName,
    String? spouseMobileNo,
    PhoneStatus? spouseMobileStatus,
    int? spouseNrc2Id,
    NRCType? spouseNrcType,
    @JsonKey(name: 'spouseNonNrcPrefix') String? spouseFrcPrefix,
    @JsonKey(name: 'spouseNrcDetail') String? spouseNrcNumber,
    @CustomDateTimeConverter() DateTime? spouseNatRegCardIssDate,
    String? spouseNatRegCardNo,

    /// Household
    int? childrenHousehold,
    int? relativeHousehold,
    int? otherHousehold,
    int? totalHousehold,

    /// Contact
    required String phoneNo1,
    PhoneStatus? phoneStatus1,
    PhoneType? phoneType1,
    String? phoneRemark1,
    String? phoneNo2,
    String? phoneNo3,
    String? emailAddress,
    @CustomBoolConverter() bool? hasViberAccount,
    @CustomBoolConverter() bool? isViberAccountSameNo,
    @JsonKey(name: 'viberAccountNo') String? viberPhoneNo,
    @JsonKey(name: 'viberAccountName') String? viberName,

    /// Other
    @JsonKey(name: 'internalFraudCode') InternalFraudCode? fraudCode,
    @JsonKey(name: 'ownedMotorcycle') @CustomBoolConverter() bool? isOwnedMoto,
    @JsonKey(name: 'takenHirePurchaseContract')
    @CustomBoolConverter()
        bool? isTakenContract,
    @JsonKey(name: 'takenMicroFinanceLoan')
    @CustomBoolConverter()
        bool? isTakenLoan,
    @JsonKey(name: 'motoFinancingRemark') String? motoRemark,
    String? customerRemark,
  }) = _CustomerEditRequest;

  factory CustomerEditRequest.fromJson(Map<String, dynamic> json) =>
      _$CustomerEditRequestFromJson(json);
}
