import 'package:freezed_annotation/freezed_annotation.dart';

part 'edit_prospect_request.freezed.dart';
part 'edit_prospect_request.g.dart';

@freezed
class EditProspectRequest with _$EditProspectRequest {
  const EditProspectRequest._();

  const factory EditProspectRequest({
    required String prospectName,
    required String prospectGender,
    required String prospectMobile,
    @Default('') String? prospectOtherMobile,
    @Default('') String? prospectRemark,
  }) = _EditProspectRequest;

  factory EditProspectRequest.fromJson(Map<String, dynamic> json) => _$EditProspectRequestFromJson(json);
}


/*
  Map<String, dynamic> _recProspect = {
                'prospectName': _prospectNameController.text.trim().toUpperCase(),
                'prospectGender': _prospectGenderSelected,
                'prospectMobile': _prospectMobileController.text.trim(),
                'prospectOtherMobile': _prospectOtherMobileController.text.trim(),
                'prospectRemark': _prospectRemarkController.text.trim(),
                'awarenessCode': '',
                'directSales': 0,
              };
              */