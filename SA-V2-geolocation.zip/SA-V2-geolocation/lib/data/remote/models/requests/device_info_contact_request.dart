import 'package:freezed_annotation/freezed_annotation.dart';

part 'device_info_contact_request.freezed.dart';
part 'device_info_contact_request.g.dart';

@freezed
class DeviceInfoContactRequest with _$DeviceInfoContactRequest {
  const DeviceInfoContactRequest._();

  const factory DeviceInfoContactRequest({
    String? imeiNo,
    @Default([]) List<DeviceContactInfo> data,
  }) = _DeviceInfoContactRequest;

  factory DeviceInfoContactRequest.fromJson(Map<String, dynamic> json) => _$DeviceInfoContactRequestFromJson(json);
}

@freezed
class DeviceContactInfo with _$DeviceContactInfo {
  const DeviceContactInfo._();

  const factory DeviceContactInfo({
    @Default('') String identifier,
    String? displayName,
    String? firstName,
    String? middleName,
    String? lastName,
    String? phones,
    String? emails,
  }) = _DeviceContactInfo;

  factory DeviceContactInfo.fromJson(Map<String, dynamic> json) => _$DeviceContactInfoFromJson(json);
}
