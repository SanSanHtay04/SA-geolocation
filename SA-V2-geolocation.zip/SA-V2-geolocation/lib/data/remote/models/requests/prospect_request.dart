import 'package:freezed_annotation/freezed_annotation.dart';

part 'prospect_request.freezed.dart';
part 'prospect_request.g.dart';

@freezed
class ProspectRequest with _$ProspectRequest {
  const ProspectRequest._();

  const factory ProspectRequest({
    int? posId,
    required String prospectName,
    required String prospectGender,
    required String prospectMobile,
    @Default('') String? prospectOtherMobile,
    @Default('') String? prospectRemark,
    @Default('') String? awarenessCode,
    @Default(0) int? directSales,
    @Default('sa-mobileapp') String? prospectSource,
    int? dupCustomerId,
    int? dupApplicationId,
    int? dupContractId,
  }) = _ProspectRequest;

  factory ProspectRequest.fromJson(Map<String, dynamic> json) => _$ProspectRequestFromJson(json);
}


/*
  Map<String, dynamic> _recProspect = {
                'prospectName': _prospectNameController.text.trim().toUpperCase(),
                'prospectGender': _prospectGenderSelected,
                'prospectMobile': _prospectMobileController.text.trim(),
                'prospectOtherMobile': _prospectOtherMobileController.text.trim(),
                'prospectRemark': _prospectRemarkController.text.trim(),
                'awarenessCode': '',
                'directSales': 0,
              };
              */