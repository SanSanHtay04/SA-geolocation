import 'package:freezed_annotation/freezed_annotation.dart';

part 'simulation_request.freezed.dart';

part 'simulation_request.g.dart';

@freezed
class SimulationRequest with _$SimulationRequest {
  const factory SimulationRequest({
    @Default(0) num depositPercentage,
    @Default(0) num depositAmount,
    @Default(0) num duration,
    @Default(0) num simDuration, // e , duration
    @Default(0) num assetPrice,
    @Default(0) num totalPrice , // e ,assetPrice
    @Default(0) num adminFee,
    @Default(0) num followingPayment,
    @Default(0) num netRentalFee,
    @Default('') String pmtPeriodicity,
    @Default(0) int packageId,
    @Default(0) int prospectId,
    int? posId,
    int? salesAreaId,
    String? simulationDate,
    num? adminFeePercentage,
    num? minAmountFinanced,
    num? minInstallmentAmount,
    int? otpFeePercentage,
    num? merchantDiscountRate,
    num? merchantDiscountAmount,
    num? effectiveAssetPrice,
    num? amountFinanced, //new
    num? amountPayable, // e, amountFinanced
    num? effectiveAmountFinanced,
    num? interestRate,
    num? rentalFeeMaintCostAddUp,
    num? rentalFeeInsCostAddUp,
    num? rentalFeeEnvCostAddUp,
    num? paymentAtEnd,
    num? insuranceCovered,
    num? maintenanceCovered,
    num? insLifeCovered,//new
    num? insAssetCovered, // new
    num? isZeroCost,
    num? zeroCostTotalInsCost,
    num? zeroCostTotalMaintCost,
    double? effectiveInterestRate,
    num? firstPayment,
    num? actualFirstPayment,
    double? accPmtShare,
    double? accPmtMonthlyShare,
    double? accMonthlyPaymentAmount,
    double? accMonthlyLastPaymentAmount,
    double? accPaymentAmount,
    double? accLastPaymentAmount,
    num? zeroCostPmtTimes,
    num? zeroCostMonthlyPaymentAmount,
  }) = _SimulationRequest;

  factory SimulationRequest.fromJson(Map<String, dynamic> json) =>
      _$SimulationRequestFromJson(json);
}

