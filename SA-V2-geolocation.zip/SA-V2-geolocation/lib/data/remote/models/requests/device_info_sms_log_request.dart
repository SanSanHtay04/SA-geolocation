import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/utils/utils.dart';

part 'device_info_sms_log_request.freezed.dart';
part 'device_info_sms_log_request.g.dart';

@freezed
class DeviceInfoSmsLogRequest with _$DeviceInfoSmsLogRequest {
  const DeviceInfoSmsLogRequest._();

  const factory DeviceInfoSmsLogRequest({
    String? imeiNo,
    @Default([]) List<DeviceSmsLog> logs,
  }) = _DeviceInfoSmsLogRequest;

  factory DeviceInfoSmsLogRequest.fromJson(Map<String, dynamic> json) => _$DeviceInfoSmsLogRequestFromJson(json);
}

@freezed
class DeviceSmsLog with _$DeviceSmsLog {
  const DeviceSmsLog._();

  const factory DeviceSmsLog({
    String? name,
    @CustomDateTimeConverter() DateTime? dateTime,
    String? phoneNumber,
    @Default('') String content,
    @Default('') String type,
  }) = _DeviceSmsLog;

  factory DeviceSmsLog.fromJson(Map<String, dynamic> json) => _$DeviceSmsLogFromJson(json);
}
