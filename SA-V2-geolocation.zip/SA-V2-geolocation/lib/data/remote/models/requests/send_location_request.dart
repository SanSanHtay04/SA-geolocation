import 'package:freezed_annotation/freezed_annotation.dart';

part 'send_location_request.freezed.dart';
part 'send_location_request.g.dart';

@freezed
class SendLocationRequest with _$SendLocationRequest {
  const factory SendLocationRequest({
    @Default([]) List<SendLocationRequestData> geoLocation,
  }) = _SendLocationRequest;

  factory SendLocationRequest.fromJson(Map<String, dynamic> json) =>
      _$SendLocationRequestFromJson(json);
}

@freezed
class SendLocationRequestData with _$SendLocationRequestData {
  const factory SendLocationRequestData({
    required double latitude,
    required double longitude,
    required String datetime,
    int? posId,
    @Default('') String location,
  }) = _SendLocationRequestData;

  factory SendLocationRequestData.fromJson(Map<String, dynamic> json) =>
      _$SendLocationRequestDataFromJson(json);
}
