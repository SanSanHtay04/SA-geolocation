import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/configs.dart';

part 'login_request.freezed.dart';
part 'login_request.g.dart';

@freezed
class LoginRequest with _$LoginRequest {
  const LoginRequest._();

  const factory LoginRequest({
    required String username,
    required String password,
    required String androidId,
    @JsonKey(name: 'grant_type') @Default('password') String grantType,
    @JsonKey(name: 'client_id') @Default(2) num clientId,
    @JsonKey(name: 'client_secret')
    @Default(Configs.clientSecret)
        String clientSecret,
    @Default('') String scope,
  }) = _LoginRequest;

  factory LoginRequest.fromJson(Map<String, dynamic> json) =>
      _$LoginRequestFromJson(json);
}
