import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/utils/utils.dart';

part 'marital_status.freezed.dart';
part 'marital_status.g.dart';

@freezed
class MaritalStatusResponse with _$MaritalStatusResponse {
  const MaritalStatusResponse._();

  const factory MaritalStatusResponse({
    required List<MaritalStatus> maritalStatuses,
  }) = _MaritalStatusResponse;

  factory MaritalStatusResponse.fromJson(Map<String, dynamic> json) => _$MaritalStatusResponseFromJson(json);
}

@freezed
class MaritalStatus with _$MaritalStatus {
  const MaritalStatus._();

  const factory MaritalStatus({
    required int maritalStatusId,
    required String maritalStatusName,
    @Default('') String maritalStatusNameMyZawgyi,
    @Default('') String maritalStatusNameMyUnicode,
  }) = _MaritalStatus;

  factory MaritalStatus.fromJson(Map<String, dynamic> json) => _$MaritalStatusFromJson(json);

  bool get isMarried => maritalStatusName.deepContains('married');
  @override
  String toString() => '$maritalStatusName ($maritalStatusNameMyUnicode)';
}
