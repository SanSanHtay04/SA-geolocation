import 'package:flutter/material.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import 'nrc_prefix.dart';
import 'nrc_region.dart';

part 'nrc_number.freezed.dart';

enum NRCNumberType {
  noNrc,
  nrc,
  frc;
}

extension NRCNumberTypeX on NRCNumberType {
  String getName(BuildContext context) {
    switch (this) {
      case NRCNumberType.noNrc:
        return 'No NRC';
      case NRCNumberType.nrc:
        return 'NRC';
      case NRCNumberType.frc:
        return 'FRC/NVC';
    }
  }
}

enum NRCType {
  @JsonValue('N')
  n,
  @JsonValue('P')
  p
}

@freezed
class NRCNumber with _$NRCNumber {
  const NRCNumber._();

  const factory NRCNumber({
    @Default(NRCNumberType.nrc) NRCNumberType type,
    NrcRegion? region,
    NrcPrefix? nrcPrefix,
    NRCType? nrcType,
    String? frcPrefix,
    String? number,
    DateTime? issuanceDate,
  }) = _NRCNumber;

  String natRegCardNo() {
    switch (type) {
      case NRCNumberType.noNrc:
        return '';
      case NRCNumberType.nrc:
        return "${region?.nrc1Id}/${nrcPrefix?.nrc2Name}(${nrcType?.name.toUpperCase()})${number}";
      case NRCNumberType.frc:
        return "${frcPrefix}-${number}";
    }
  }
}
