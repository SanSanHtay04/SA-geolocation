import 'package:freezed_annotation/freezed_annotation.dart';

part 'nrc_prefix.freezed.dart';
part 'nrc_prefix.g.dart';

@freezed
class NrcPrefix with _$NrcPrefix {
  const NrcPrefix._();

  const factory NrcPrefix({
    required int nrc2Id,
    required String nrc2Name,
  }) = _NrcPrefix;

  factory NrcPrefix.fromJson(Map<String, dynamic> json) =>
      _$NrcPrefixFromJson(json);
}
