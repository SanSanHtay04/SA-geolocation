import 'package:freezed_annotation/freezed_annotation.dart';

part 'nrc_region.freezed.dart';
part 'nrc_region.g.dart';

@freezed
class NrcRegion with _$NrcRegion {
  const NrcRegion._();

  const factory NrcRegion({
    required int nrc1Id,
    required String nrc1Name,
  }) = _NrcRegion;

  factory NrcRegion.fromJson(Map<String, dynamic> json) =>
      _$NrcRegionFromJson(json);

  @override
  String toString() => '$nrc1Id ($nrc1Name)';
}
