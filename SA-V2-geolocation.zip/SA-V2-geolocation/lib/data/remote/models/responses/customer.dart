import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/models/models.dart';
import 'package:latlong2/latlong.dart';
import 'package:sales/utils/utils.dart';

import 'package:sales/screens/origination/prospects/customer/notifiers/form/customer_form_state.dart';

part 'customer.freezed.dart';
part 'customer.g.dart';

@freezed
class Customer with _$Customer {
  const Customer._();

  const factory Customer({
    int? customerId,
    @Default('') String customerFullName,
    @Default('') String customerImageDomain,
    @Default('') String customerImagePath,
    @Default('') String customerImageMime,
    DateTime? birthDate,
    @Default(GenderType.male) GenderType gender,
    @Default(HomeStatus.owned) HomeStatus homeStatus,
    @Default('') String homeAddress,
    int? geoWardId,
    int? geoVillageId,
    int? geoTownId,
    int? geoTownShipId,
    int? geoDistrictId,
    int? geoRegionId,
    @Default('') String geoWardName,
    @Default('') String geoWardNameBurmese,
    @Default('') String geoVillageName,
    @Default('') String geoVillageNameBurmese,
    @Default('') String geoTownName,
    @Default('') String geoTownNameBurmese,
    @Default('') String geoTownShipName,
    @Default('') String geoTownShipNameBurmese,
    @Default('') String geoDistrictName,
    @Default('') String geoDistrictNameBurmese,
    @Default('') String geoRegionName,
    @Default('') String geoRegionNameBurmese,
    @Default('') String fatherName,
    @Default('-') String natRegCardNo,
    @Default(0) int nrc1Id,
    @Default('') String nrc1Name,
    @Default(0) int nrc2Id,
    @Default('') String nrc2Name,
    @Default('') @JsonKey(name: 'nonNrcPrefix') String frcPrefix,
    @Default('') @JsonKey(name: 'nrcDetail') String nrcNumber,
    DateTime? natRegCardIssDate,
    NRCType? nrcType,
    @Default(0) int educationId,
    @Default('-') String educationName,
    @Default(0) int maritalStatusId,
    @Default('-') String maritalStatusName,
    @Default('') String spouseName,
    @Default('') String spouseMobileNo,
    PhoneStatus? spouseMobileStatus,
    @Default('') String spouseNatRegCardNo,
    @Default(0) int spouseNrc1Id,
    @Default('') String spouseNrc1Name,
    @Default(0) int spouseNrc2Id,
    @Default('') String spouseNrc2Name,
    @Default('') @JsonKey(name: 'spouseNonNrcPrefix') String spouseFrcPrefix,
    @Default('') @JsonKey(name: 'spouseNrcDetail') String spouseNrcNumber,
    DateTime? spouseNatRegCardIssDate,
    NRCType? spouseNrcType,
    @Default(0) int childrenHousehold,
    @Default(0) int relativeHousehold,
    @Default(0) int otherHousehold,
    @Default(0) int totalHousehold,
    @Default('') String phoneNo1,
    PhoneStatus? phoneStatus1,
    @Default(PhoneType.mobile) PhoneType phoneType1,
    @Default('') String phoneRemark1,
    @Default('') String phoneNo2,
    @Default('') String phoneNo3,
    @Default('') String emailAddress,
    @Default(false) @CustomBoolConverter() bool hasViberAccount,
    @Default(false) @CustomBoolConverter() bool isViberAccountSameNo, // same with phoneNo1
    @Default('') String viberAccountNo,
    @Default('') String viberAccountName,
    InternalFraudCode? internalFraudCode,
    @Default(false) @CustomBoolConverter() bool ownedMotorcycle,
    @Default(false) @CustomBoolConverter() bool takenHirePurchaseContract,
    @Default(false) @CustomBoolConverter() bool takenMicroFinanceLoan,
    @Default('') String motoFinancingRemark,
    @Default('') String customerRemark,
    String? homeGeoLatitude,
    String? homeGeoLongitude,
    String? homeGeoAddress,
  }) = _Customer;

  factory Customer.fromJson(Map<String, dynamic> json) => _$CustomerFromJson(json);

  CustomerFormState toDomain(int? prospectId, int? appId) => CustomerFormState(
        loaded: true,
        prospectId: prospectId,
        applicationId: appId,
        customerId: customerId,
        customerFullName: customerFullName,
        birthDate: birthDate,
        gender: gender,
        fatherName: fatherName,
        nrcDetail: NRCNumber(
          type: frcPrefix.isNotEmpty ? NRCNumberType.frc : NRCNumberType.nrc,
          region: nrc1Id == 0
              ? null
              : NrcRegion(
                  nrc1Id: nrc1Id,
                  nrc1Name: nrc1Name,
                ),
          nrcPrefix: frcPrefix.isNotEmpty
              ? null
              : NrcPrefix(
                  nrc2Id: nrc2Id,
                  nrc2Name: nrc2Name,
                ),
          frcPrefix: frcPrefix,
          nrcType: nrcType,
          number: nrcNumber,
          issuanceDate: natRegCardIssDate,
        ),
        maritalStatus: MaritalStatus(
          maritalStatusId: maritalStatusId,
          maritalStatusName: maritalStatusName,
        ),
        education: EducationLevel(
          educationId: educationId,
          educationName: educationName,
        ),
        address: Address(
          homeStatus: homeStatus,
          address: homeAddress,
          type: geoVillageId == null ? AddressType.urban : AddressType.rural,
          region: geoRegionId == null
              ? null
              : Region(
                  geoRegionId: geoRegionId!,
                  geoRegionName: geoRegionName,
                  geoRegionNameBurmese: geoRegionNameBurmese,
                ),
          district: geoDistrictId == null
              ? null
              : District(
                  geoDistrictId: geoDistrictId!,
                  geoDistrictName: geoDistrictName,
                  geoDistrictNameBurmese: geoDistrictNameBurmese,
                ),
          township: geoTownShipId == null
              ? null
              : Township(
                  geoTownShipId: geoTownShipId!,
                  geoTownShipName: geoTownShipName,
                  geoTownShipNameBurmese: geoTownShipNameBurmese,
                ),
          villageTract: geoVillageId == null
              ? null
              : Town(
                  geoTownId: geoTownId!,
                  geoTownName: geoTownName,
                  geoTownNameBurmese: geoTownNameBurmese,
                ),
          village: geoVillageId == null
              ? null
              : Village(
                  geoVillageId: geoVillageId!,
                  geoVillageName: geoVillageName,
                  geoVillageNameBurmese: geoVillageNameBurmese,
                ),
          town: geoWardId == null
              ? null
              : Town(
                  geoTownId: geoTownId!,
                  geoTownName: geoTownName,
                  geoTownNameBurmese: geoTownNameBurmese,
                ),
          ward: geoWardId == null
              ? null
              : Ward(
                  geoWardId: geoWardId!,
                  geoWardName: geoWardName,
                  geoWardNameBurmese: geoWardNameBurmese,
                ),
        ),
        spouseName: spouseName,
        spousePhone: spouseMobileNo,
        spouseNrcDetail: NRCNumber(
          type: spouseNrcNumber.isEmpty
              ? NRCNumberType.noNrc
              : spouseFrcPrefix.isNotEmpty
                  ? NRCNumberType.frc
                  : NRCNumberType.nrc,
          region: NrcRegion(
            nrc1Id: spouseNrc1Id,
            nrc1Name: spouseNrc1Name,
          ),
          nrcPrefix: spouseFrcPrefix.isNotEmpty
              ? null
              : NrcPrefix(
                  nrc2Id: spouseNrc2Id,
                  nrc2Name: spouseNrc2Name,
                ),
          frcPrefix: spouseFrcPrefix,
          nrcType: spouseNrcType,
          number: spouseNrcNumber,
          issuanceDate: spouseNatRegCardIssDate,
        ),
        householdNumber: HouseholdNumber(
          children: childrenHousehold,
          relative: relativeHousehold,
          other: otherHousehold,
        ),
        phoneNo1: phoneNo1,
        phoneNo2: phoneNo2,
        phoneNo3: phoneNo3,
        emailAddress: emailAddress,
        phoneStatus1: phoneStatus1,
        phoneType1: phoneType1,
        phoneRemark1: phoneRemark1,
        hasViberAccount: hasViberAccount,
        isViberAccountSameNo: isViberAccountSameNo,
        viberPhoneNo: viberAccountNo,
        viberAccountName: viberAccountName,
        fraudCode: internalFraudCode,
        isOwnedMoto: ownedMotorcycle,
        isTakenContract: takenHirePurchaseContract,
        isTakenLoan: takenMicroFinanceLoan,
        motoRemark: motoFinancingRemark,
        customerRemark: customerRemark,
        geoLocation: (homeGeoLatitude != null && homeGeoLongitude != null) ? LatLng(double.parse(homeGeoLatitude!), double.parse(homeGeoLongitude!)) : null,
        geoAddress: homeGeoAddress,
      );
}
