import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/models/replicated_contract.dart';

import 'package:sales/utils/utils.dart';

part 'replicated_contract_response.freezed.dart';
part 'replicated_contract_response.g.dart';

@freezed
class ReplicatedContractResponse with _$ReplicatedContractResponse {
  const ReplicatedContractResponse._();

  const factory ReplicatedContractResponse({
    required int prospectId,
    required int customerId,
    required int applicationId,
    required int contractId,
    required String contractNo,
    @CustomDateTimeConverter() DateTime? contractDate,
    @CustomDateTimeConverter() DateTime? contractExpiryDate,
    @CustomDateTimeConverter() DateTime? terminationDate,
    int? contractStatusId,
    String? contractStatusName,
    @Default('') String contractType,
    num? totalAmountPaid,
    num? maxDaysOverdueGross,
    @Default('') String customerFullName,
    num? unitPrice,
    String? productColor,
    String? chassisNo,
    String? engineNo,
    String? plateNo,
    int? productId,
    String? serialNo,
    String? imeiNo,
    String? deliveryDate,
    String? productName,
    String? brandName,
    String? ownerBookExpiryDate,
    num? followingPayment,
    int? productCategoryId,
    String? productCategoryName,
    String? assetProductName,
    int? duration,
    num? amountFinanced,
    @Default(DuplicateInfo()) DuplicateInfo duplicate,
  }) = _ReplicatedContractResponse;

  factory ReplicatedContractResponse.fromJson(Map<String, dynamic> json) => _$ReplicatedContractResponseFromJson(json);

  ReplicatedContract toDomainData() {
    return ReplicatedContract(
      prospectId: prospectId,
      contractId: contractId,
      customerId: customerId,
      applicationId: applicationId,
      customerFullName: customerFullName,
      contract: contractInfo,
      product: productInfo,
      canDuplicated: duplicate.canDuplicate,
      duplicatedReason: duplicate.reason,
    );
  }

  ContractInfo get contractInfo => ContractInfo(
        number: contractNo,
        type: contractType,
        statusId: contractStatusId,
        statusName: contractStatusName,
        contractDate: contractDate,
        expiryDate: contractExpiryDate,
        terminationDate: terminationDate,
      );

  ProductInfo get productInfo => ProductInfo(
        name: productName ?? '',
        categoryId: productCategoryId,
        categoryName: productCategoryName,
        unitPrice: unitPrice,
        amountFinanced: amountFinanced,
        followingPayment: followingPayment,
        duration: duration,
      );
}

@freezed
class DuplicateInfo with _$DuplicateInfo {
  const DuplicateInfo._();

  const factory DuplicateInfo({
    @Default(false) @CustomBoolConverter() bool canDuplicate,
    @Default('') String reason,
  }) = _DuplicateInfo;

  factory DuplicateInfo.fromJson(Map<String, dynamic> json) => _$DuplicateInfoFromJson(json);
}

/*
{
    "messages": "Contract with sequence '315658' found.",
    "data": {
        "prospectId": 1071254,
        "customerId": 445847,
        "applicationId": 452857,
        "contractId": 322535,
        "contractNo": "C-315658-2-11-2401",
        "contractDate": "2024-01-05",
        "contractExpiryDate": "2024-10-01",
        "terminationDate": null,
        "contractStatusId": 10,
        "contractStatusName": "Performing Contract",
        "contractType": "normal",
        "totalAmountPaid": 525000,
        "maxDaysOverdueGross": null,
        "customerFullName": "AYE MYAT MYAT MOE",
        "unitPrice": 1000000,
        "productColor": "GOLD",
        "chassisNo": null,
        "engineNo": null,
        "plateNo": null,
        "productId": 219840,
        "serialNo": "126469875568",
        "imeiNo": "78945632153355856",
        "deliveryDate": "2024-01-05",
        "productName": "APPLE IPHONE 12 PRO 128GB",
        "brandName": "APPLE (WG)",
        "ownerBookExpiryDate": null,
        "followingPayment": 74000,
        "productCategoryId": 18,
        "productCategoryName": "Phone",
        "assetProductName": null,
        "duration": 9,
        "amountFinanced": 500000
    }
}
*/
