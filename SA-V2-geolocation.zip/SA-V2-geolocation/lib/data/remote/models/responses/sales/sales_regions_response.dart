import 'package:freezed_annotation/freezed_annotation.dart';

part 'sales_regions_response.freezed.dart';
part 'sales_regions_response.g.dart';

@freezed
class SalesRegionsResponse with _$SalesRegionsResponse {
  factory SalesRegionsResponse({
    required int workPlaceId,
    String? workPlaceCode,
    String? workPlaceShortName,
    required String workPlaceFullName,
  }) = _SalesRegionsResponse;

  factory SalesRegionsResponse.fromJson(Map<String, dynamic> json) =>
      _$SalesRegionsResponseFromJson(json);
}
