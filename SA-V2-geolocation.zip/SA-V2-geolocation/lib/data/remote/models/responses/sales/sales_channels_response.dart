import 'package:freezed_annotation/freezed_annotation.dart';

part 'sales_channels_response.freezed.dart';
part 'sales_channels_response.g.dart';

@freezed
class SalesChannelsResponse with _$SalesChannelsResponse {
  factory SalesChannelsResponse(
    String message,
    List<SalesChannelsResponseData> salesChannels,
  ) = _SalesChannelsResponse;

  factory SalesChannelsResponse.fromJson(Map<String, dynamic> json) =>
      _$SalesChannelsResponseFromJson(json);
}

@freezed
class SalesChannelsResponseData with _$SalesChannelsResponseData {
  factory SalesChannelsResponseData(
    int salesChannelId,
    String salesChannelName,
  ) = _SalesChannelsResponseData;

  factory SalesChannelsResponseData.fromJson(Map<String, dynamic> json) =>
      _$SalesChannelsResponseDataFromJson(json);
}
