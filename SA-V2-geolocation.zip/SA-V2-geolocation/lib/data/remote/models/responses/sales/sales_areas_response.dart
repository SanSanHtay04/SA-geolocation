import 'package:freezed_annotation/freezed_annotation.dart';

part 'sales_areas_response.freezed.dart';
part 'sales_areas_response.g.dart';

@freezed
class SalesAreasResponse with _$SalesAreasResponse {
  factory SalesAreasResponse(
    int salesAreaId,
    String? salesAreaCode,
    String? salesAreaName,
    String? salesAreaNameBurmese,
    int? salesAreaActive,
    int workPlaceId,
  ) = _SalesAreasResponse;

  factory SalesAreasResponse.fromJson(Map<String, dynamic> json) =>
      _$SalesAreasResponseFromJson(json);
}
