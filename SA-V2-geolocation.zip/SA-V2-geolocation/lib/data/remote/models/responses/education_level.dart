import 'package:freezed_annotation/freezed_annotation.dart';

part 'education_level.freezed.dart';
part 'education_level.g.dart';

@freezed
class EducationLevel with _$EducationLevel {
  const EducationLevel._();

  const factory EducationLevel({
    required int educationId,
    required String educationName,
  }) = _EducationLevel;

  factory EducationLevel.fromJson(Map<String, dynamic> json) => _$EducationLevelFromJson(json);

   @override
  String toString() => '$educationName';

}


/*
  value: item["educationId"],
            child: Text(item["educationName"]),
*/
