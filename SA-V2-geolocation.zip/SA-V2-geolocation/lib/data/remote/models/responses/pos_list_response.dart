import 'package:freezed_annotation/freezed_annotation.dart';

part 'pos_list_response.freezed.dart';
part 'pos_list_response.g.dart';

/// messages : "24 POS are successfully loaded."
/// data : [{"posId":57,"salesAreaId":12,"salesAreaName":"Pyay","posProductType":"2w","posName":"HONDA NCX(Aung Aung Lwin/Pyay)","posAddress":"No.249,Bogyoke Road,Pyay","posFixedTelNo1":"09783364225","posFixedTelNo2":null,"geoLatitude":"18.820932","geoLongitude":"95.237386"},{"posId":58,"salesAreaId":12,"salesAreaName":"Pyay","posProductType":"2w","posName":"Ye Lay & Brothers Motorcycle Trade(Ye Min Htun/Pyay)","posAddress":"Pyay-Aung lan Road, Pyay Thar Yar.","posFixedTelNo1":"095311162","posFixedTelNo2":null,"geoLatitude":"18.82093789","geoLongitude":"95.222223551"},{"posId":66,"salesAreaId":12,"salesAreaName":"Pyay","posProductType":"2w","posName":"Global Power Tricycle Trade( Si Thu Khant/Pyay)","posAddress":"Room(A8/A9), Agricultural Tike Tan, Pyay-Aung Lan Road, Pyay.","posFixedTelNo1":"09423658488/0931446055","posFixedTelNo2":"0943107380","geoLatitude":"18.822326","geoLongitude":"95.249840"},{"posId":87,"salesAreaId":12,"salesAreaName":"Pyay","posProductType":"2w","posName":"Ko Phoe Phyu + Ma Aye Lay (Phoe Phyu/Pyay)","posAddress":"Nawaday Lane, yawar bal ward, Pyay","posFixedTelNo1":"095312282/09452335292","posFixedTelNo2":"09250555870","geoLatitude":"18.8059188","geoLongitude":"95.2359659"},{"posId":257,"salesAreaId":12,"salesAreaName":"Pyay","posProductType":"2w","posName":"5 STAR ( Ko Hla Win/Pyay )","posAddress":"No(316), Merchant St, Kyaung Gyi Oho Tan Wd, Pyay.","posFixedTelNo1":"05326361","posFixedTelNo2":"09793526142","geoLatitude":"18.82160323","geoLongitude":"95.22646831"},{"posId":452,"salesAreaId":12,"salesAreaName":"Pyay","posProductType":"2w","posName":"A.T.T(KO WIN SOE+MA NWE NI/Pyay/Oakshitpin)","posAddress":"12/Ka,Lan Madaw St,Yadanarpone Wd,Oakshitpin.","posFixedTelNo1":"05342313","posFixedTelNo2":"09253190088","geoLatitude":"18.684966","geoLongitude":"95.010373"},{"posId":453,"salesAreaId":12,"salesAreaName":"Pyay","posProductType":"2w","posName":"L.T(Ko Lin Thaw+Ma Kae Kae/Pyay/Oakshitpin)","posAddress":"Corner of Lan Madaw St & Moe Kote Wee Pat Thanar Damma Yate Thar St,Oakshitpin.","posFixedTelNo1":"09250816706","posFixedTelNo2":"05342104","geoLatitude":"18.685067","geoLongitude":"95.012135"},{"posId":656,"salesAreaId":12,"salesAreaName":"Pyay","posProductType":"2w","posName":"AUNG JRC (KO NYI AUNG/Pyay)","posAddress":"Room (A 13/14),Nawaday Lane, Yawar bal ward, Pyay","posFixedTelNo1":"09777774448","posFixedTelNo2":"09788888466","geoLatitude":"18.821907","geoLongitude":"95.248959"},{"posId":686,"salesAreaId":12,"salesAreaName":"Pyay","posProductType":"consumer","posName":"PYAE PHYO AUNG ELECTRONIC (U KYAW SOE MOE/PYAY)","posAddress":"No (62), Lamadaw Street, Pyay.","posFixedTelNo1":null,"posFixedTelNo2":null,"geoLatitude":"18.824184","geoLongitude":"95.216722"},{"posId":904,"salesAreaId":12,"salesAreaName":"Pyay","posProductType":"consumer","posName":"SAMSUNG (M-9/PYAY)","posAddress":"No.(145), Bo Gyoke Road, Ywar Bel Ward, Pyay.","posFixedTelNo1":"09977895037","posFixedTelNo2":"09977895038","geoLatitude":null,"geoLongitude":null},{"posId":917,"salesAreaId":12,"salesAreaName":"Pyay","posProductType":"consumer","posName":"HUAWEI (PYAY)","posAddress":"No.10/114, Nawin Kwat Thit 10th Street, Pyay City.","posFixedTelNo1":"09967411766","posFixedTelNo2":"09973060888","geoLatitude":"18.814855","geoLongitude":"95.253661"},{"posId":1027,"salesAreaId":12,"salesAreaName":"Pyay","posProductType":"2w","posName":"GOOD BROTHERS (U KYAW WIN/PYAY)","posAddress":"No (333), Bogyoke Rd, Ywar Bel Qt, Pyay.","posFixedTelNo1":"0941010339","posFixedTelNo2":null,"geoLatitude":null,"geoLongitude":null},{"posId":1353,"salesAreaId":12,"salesAreaName":"Pyay","posProductType":"2w","posName":"CROCODILE (KO NAY LIN OO/PYAY)","posAddress":"No (145), Bo Gyoke Road, Ywarbe Ward, Pyay","posFixedTelNo1":"09 5190 380","posFixedTelNo2":"09 402 607020","geoLatitude":null,"geoLongitude":null},{"posId":1384,"salesAreaId":12,"salesAreaName":"Pyay","posProductType":"2w","posName":"BAJAJ (PRECISION AUTO/PYAY)","posAddress":"No (145), Bo Gyoke Road, Ywarbe Ward, Pyay","posFixedTelNo1":"09977428016, 09402779219","posFixedTelNo2":null,"geoLatitude":null,"geoLongitude":null},{"posId":1464,"salesAreaId":12,"salesAreaName":"Pyay","posProductType":"consumer","posName":"Wai Yan-Lucky City","posAddress":"Bogyoke Rd, San Taw Qt, Pyay.","posFixedTelNo1":"05324034/05324040","posFixedTelNo2":"09450107005","geoLatitude":"18.82219","geoLongitude":"95.21604"},{"posId":1567,"salesAreaId":12,"salesAreaName":"Pyay","posProductType":"2w","posName":"TVS (MOON PRINCESS/PYAY)","posAddress":"No (145), Bo Gyoke Road, Ywarbe Ward Pyay","posFixedTelNo1":"09 259204288","posFixedTelNo2":null,"geoLatitude":null,"geoLongitude":null},{"posId":1748,"salesAreaId":12,"salesAreaName":"Pyay","posProductType":"consumer","posName":"SKYWORTH (U AUNG KYAW THU WIN/PYAY)","posAddress":"No (145), Bo Gyoke Road, Ywarbe Ward, Pyay.","posFixedTelNo1":"01373565","posFixedTelNo2":"09969920254","geoLatitude":null,"geoLongitude":null},{"posId":1790,"salesAreaId":12,"salesAreaName":"Pyay","posProductType":"consumer","posName":"HOME AID (DR AUNG KYAW THU WIN/PYAY)","posAddress":"No (145), Bo Gyoke Road, Ywarbe Ward, Pyay","posFixedTelNo1":"024068877","posFixedTelNo2":null,"geoLatitude":null,"geoLongitude":null},{"posId":1875,"salesAreaId":12,"salesAreaName":"Pyay","posProductType":"consumer","posName":"MIDEA SHOWROOM (VSK INTL CO,LTD/PYAY)","posAddress":"No(370) Lanmadaw Street , Lanmadaw Quarter , Pyay","posFixedTelNo1":"09457185885","posFixedTelNo2":null,"geoLatitude":null,"geoLongitude":null},{"posId":1944,"salesAreaId":12,"salesAreaName":"Pyay","posProductType":"2w","posName":"Aung Myint Mo","posAddress":"Room No (40), East High-way Compound, Bayin Naung Rd, Pyay.","posFixedTelNo1":"09666766769","posFixedTelNo2":null,"geoLatitude":"18.819155","geoLongitude":"95.250332"},{"posId":1945,"salesAreaId":12,"salesAreaName":"Pyay","posProductType":"2w","posName":"ADIXIN Showroom","posAddress":"No(24), Bogyoke Rd, Ywar Be Qt, Pyay.","posFixedTelNo1":"092673","posFixedTelNo2":null,"geoLatitude":"18.820512","geoLongitude":"95.244974"},{"posId":1998,"salesAreaId":12,"salesAreaName":"Pyay","posProductType":"2w","posName":"THARAPHU SOE MYINT (U SOE MYINT/PYAY)","posAddress":"No(77) (A/4),Nawaddy Junction,Sin SU Ward, Pyay","posFixedTelNo1":"09450043176","posFixedTelNo2":"09425754218","geoLatitude":"3248998","geoLongitude":"123456"},{"posId":2079,"salesAreaId":15,"salesAreaName":"Gyobingauk","posProductType":"consumer","posName":"U Soe Lin Oo","posAddress":"Ashae Lan Ma Taw Road ,Zay Cho Taung Ward, Gyobingauk","posFixedTelNo1":"09751006666","posFixedTelNo2":null,"geoLatitude":"18.230135","geoLongitude":"95.650549"},{"posId":2101,"salesAreaId":12,"salesAreaName":"Pyay","posProductType":"consumer","posName":"U Min Thu Aung","posAddress":"No(62),Lan Mataw Road, Pyay.","posFixedTelNo1":"095312623","posFixedTelNo2":null,"geoLatitude":"18.25468","geoLongitude":"96.125656"}]

@freezed
class PosListResponse with _$PosListResponse {
  factory PosListResponse({String? message, required List<POSResponse> data}) =
      _PosListResponse;

  factory PosListResponse.fromJson(Map<String, dynamic> json) =>
      _$PosListResponseFromJson(json);
}

/// posId : 57
/// salesAreaId : 12
/// salesAreaName : "Pyay"
/// posProductType : "2w"
/// posName : "HONDA NCX(Aung Aung Lwin/Pyay)"
/// posAddress : "No.249,Bogyoke Road,Pyay"
/// posFixedTelNo1 : "09783364225"
/// posFixedTelNo2 : null
/// geoLatitude : "18.820932"
/// geoLongitude : "95.237386"

@freezed
class POSResponse with _$POSResponse {
  factory POSResponse({
    required int posId,
    required int salesAreaId,
    String? salesAreaName,
    String? posProductType,
    String? posCategory,
    required String posName,
    String? posAddress,
    String? posFixedTelNo1,
    String? posFixedTelNo2,
    String? geoLatitude,
    String? geoLongitude,
    @Default(0) int  isMerchant, 
  }) = _POSResponse;

  factory POSResponse.fromJson(Map<String, dynamic> json) =>
      _$POSResponseFromJson(json);


}
