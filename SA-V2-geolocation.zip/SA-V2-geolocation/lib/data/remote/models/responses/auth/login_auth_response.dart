import 'package:freezed_annotation/freezed_annotation.dart';

import 'account_info_response.dart';

part 'login_auth_response.freezed.dart';
part 'login_auth_response.g.dart';

@freezed
class LoginAuthResponse with _$LoginAuthResponse {
  const LoginAuthResponse._();

  const factory LoginAuthResponse({
    required TokenResponse token,
    required UserResponse user,
  }) = _LoginAuthResponse;

  factory LoginAuthResponse.fromJson(Map<String, dynamic> json) =>
      _$LoginAuthResponseFromJson(json);

  AuthResponse toAuthResponse() {
    return AuthResponse(
      success: 1,
      accessToken: token.accessToken,
      saAccessToken: '',
      user: AuthResponseUser(
        userId: user.userId,
        userName: user.userName,
        userFullName: user.userFullName,
        pwd: user.pwd,
        posId: user.posId,
        workPlaceId: user.workPlaceId,
        checkDeviceImei: user.checkDeviceImei,
        androidId: user.androidId,
        userType: user.userType,
        phoneExtension: user.phoneExtension,
        userRemark: user.userRemark,
        noticeEmail: user.noticeEmail,
        noticeMobile: user.noticeMobile,
        userImagePath: user.userImagePath,
      ),
    );
  }
}

@freezed
class UserResponse with _$UserResponse {
  const factory UserResponse({
    required int userId,
    String? userName,
    String? userFullName,
    String? pwd,
    int? posId,
    int? workPlaceId,
    dynamic checkDeviceImei,
    dynamic androidId,
    String? userType,
    dynamic phoneExtension,
    dynamic userRemark,
    String? noticeEmail,
    String? noticeMobile,
    String? userImagePath,
  }) = _UserResponse;

  factory UserResponse.fromJson(Map<String, dynamic> json) =>
      _$UserResponseFromJson(json);
}

@freezed
class TokenResponse with _$TokenResponse {
  @JsonSerializable(fieldRename: FieldRename.snake)
  const factory TokenResponse({
    String? tokenType,
    required int expiresIn,
    required String accessToken,
    required String refreshToken,
  }) = _TokenResponse;

  factory TokenResponse.fromJson(Map<String, dynamic> json) =>
      _$TokenResponseFromJson(json);
}
