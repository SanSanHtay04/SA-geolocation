import 'package:freezed_annotation/freezed_annotation.dart';

part 'account_info_response.freezed.dart';
part 'account_info_response.g.dart';

@freezed
class AuthResponse with _$AuthResponse {
  factory AuthResponse({
    required int success,
    required AuthResponseUser user,
    required String accessToken,
    required String? saAccessToken,
  }) = _AuthResponse;

  factory AuthResponse.fromJson(Map<String, dynamic> json) =>
      _$AuthResponseFromJson(json);
}

@freezed
class AuthResponseUser with _$AuthResponseUser {
  factory AuthResponseUser({
    required int userId,
    dynamic employeeId,
    dynamic employeeCode,
    int? isCommercialAssistant,
    dynamic phoneAgentId,
    dynamic phoneExtension,
    int? isUserAccount,
    String? userType,
    String? userImagePath,
    String? userName,
    String? userFullName,
    String? pwd,
    dynamic userPosition,
    dynamic userRemark,
    int? officeStaff,
    int? workPlaceId,
    int? salesAreaId,
    dynamic managingSalesAreaIds,
    int? posLimited,
    int? loginActive,
    dynamic dtDeactivated,
    dynamic personDeactivated,
    int? posId,
    dynamic checkDeviceImei,
    dynamic androidId,
    String? noticeEmail,
    dynamic noticeEmail2,
    String? noticeMobile,
    dynamic noticeMobile2,
    int? changePassRequired,
    String? dtCreated,
    int? personCreated,
    String? dtUpdated,
    int? personUpdated,
    dynamic dtDeleted,
    dynamic personDeleted,
  }) = _AuthResponseUser;

  factory AuthResponseUser.fromJson(Map<String, dynamic> json) =>
      _$AuthResponseUserFromJson(json);
}
