import 'package:freezed_annotation/freezed_annotation.dart';

part 'otp_login_response.freezed.dart';
part 'otp_login_response.g.dart';

/// message : "OTP sent to user successfully"
/// data : {"otpToken":{"token":"8678","expiredAt":"2022-03-20 22:50:15"},"success":1}

@freezed
class OtpLoginResponse with _$OtpLoginResponse {
  const factory OtpLoginResponse(
      {String? message, required OtpResponseData data}) = _OtpLoginResponse;

  factory OtpLoginResponse.fromJson(Map<String, dynamic> json) =>
      _$OtpLoginResponseFromJson(json);
}

/// otpToken : {"token":"8678","expiredAt":"2022-03-20 22:50:15"}
/// success : 1

@freezed
class OtpResponseData with _$OtpResponseData {
  const factory OtpResponseData(
      {required OtpTokenResponse otpToken,
      required int success}) = _OtpResponseData;

  factory OtpResponseData.fromJson(Map<String, dynamic> json) =>
      _$OtpResponseDataFromJson(json);
}

/// token : "8678"
/// expiredAt : "2022-03-20 22:50:15"

@freezed
class OtpTokenResponse with _$OtpTokenResponse {
  const factory OtpTokenResponse(
      {required String token, required String expiredAt}) = _OtpTokenResponse;

  factory OtpTokenResponse.fromJson(Map<String, dynamic> json) =>
      _$OtpTokenResponseFromJson(json);
}
