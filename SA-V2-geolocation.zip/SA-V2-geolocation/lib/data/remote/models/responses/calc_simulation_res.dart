import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/data/remote/models/requests/simulation_request.dart';

part 'calc_simulation_res.freezed.dart';

part 'calc_simulation_res.g.dart';

@freezed
class CalcSimulationRes with _$CalcSimulationRes {
  const CalcSimulationRes._();

  const factory CalcSimulationRes({required SimulationData simulation}) =
      _CalcSimulationRes;

  factory CalcSimulationRes.fromJson(Map<String, dynamic> json) =>
      _$CalcSimulationResFromJson(json);
}

@freezed
class SimulationData with _$SimulationData {
  const SimulationData._();

  const factory SimulationData({
    @Default([]) @JsonKey(name: 'm') List<List<SimulationModel>> monthly,
    @Default([]) @JsonKey(name: 'q') List<List<SimulationModel>> quarterly,
  }) = _SimulationData;

  factory SimulationData.fromJson(Map<String, dynamic> json) =>
      _$SimulationDataFromJson(json);
}

@freezed
class SimulationModel with _$SimulationModel {
  const SimulationModel._();

  const factory SimulationModel({
    @Default(0) num depositPercentage,
    @Default(0) num depositAmount,
    @Default(0) num duration,
    @Default(0) num assetPrice,
    @Default(0) num adminFee,
    @Default(0) num followingPayment,
    @Default(0) num netRentalFee,
    @Default('') String pmtPeriodicity,
    int? productId,
    int? posId,
    int? salesAreaId,
    String? simulationDate,
    num? adminFeePercentage,
    num? minAmountFinanced,
    num? minInstallmentAmount,
    int? otpFeePercentage,
    num? merchantDiscountRate,
    num? merchantDiscountAmount,
    num? effectiveAssetPrice,
    num? amountFinanced,
    num? effectiveAmountFinanced,
    num? interestRate,
    num? rentalFeeMaintCostAddUp,
    num? rentalFeeInsCostAddUp,
    num? rentalFeeEnvCostAddUp,
    num? paymentAtEnd,
    num? insuranceCovered,
    num? maintenanceCovered,
    num? insLifeCovered,
    num? insAssetCovered,
    num? isSelfRegistered,
    num? isSecondHandProduct,
    num? maintSchemeId,
    String? maintSchemeName,
    num? costPerVisit,
    num? intervalOfVisit,
    num? financialSchemeId,
    String? financialSchemeName,
    num? durationMin,
    num? durationMax,
    num? durationInterval,
    double? totalMonthlyMaintCostPerVisit,
    num? totalInsFixedCost,
    num? totalInsVariableCostCV,
    num? totalInsVariableCostEV,
    num? totalInsVariableCostAF,
    num? isZeroCost,
    num? zeroCostTotalInsCost,
    num? zeroCostTotalMaintCost,
    double? effectiveInterestRate,
    num? firstPayment,
    num? actualFirstPayment,
    double? accPmtShare,
    double? accPmtMonthlyShare,
    double? accMonthlyPaymentAmount,
    double? accMonthlyLastPaymentAmount,
    double? accPaymentAmount,
    double? accLastPaymentAmount,
    num? zeroCostPmtTimes,
    num? zeroCostMonthlyPaymentAmount,
    @Default(0) num isBundle,
    int? primaryUnitPrice,
    int? primaryProductPrice,
    String? totalAttachedProductPrice,// TODO: data type of totalAttachedProductPrice must be  int?
  }) = _SimulationModel;

  factory SimulationModel.fromJson(Map<String, dynamic> json) =>
      _$SimulationModelFromJson(json);

  SimulationRequest toRequestModel(
      {required int packageId, required int prospectId}) {
    return SimulationRequest(
      depositPercentage: this.depositPercentage,
      depositAmount: this.depositAmount,
      duration: this.duration,
      simDuration: this.duration,
      assetPrice: this.assetPrice,
      totalPrice: this.assetPrice,
      adminFee: this.adminFee,
      followingPayment: this.followingPayment,
      netRentalFee: this.netRentalFee,
      pmtPeriodicity: this.pmtPeriodicity,
      packageId: packageId,
      prospectId: prospectId,
      posId: this.posId,
      salesAreaId: this.salesAreaId,
      simulationDate: this.simulationDate,
      adminFeePercentage: this.adminFeePercentage,
      minAmountFinanced: this.minAmountFinanced,
      minInstallmentAmount: this.minInstallmentAmount,
      otpFeePercentage: this.otpFeePercentage,
      merchantDiscountRate: this.merchantDiscountRate,
      merchantDiscountAmount: this.merchantDiscountAmount,
      effectiveAssetPrice: this.effectiveAssetPrice,
      amountFinanced: this.amountFinanced,
      amountPayable: this.amountFinanced,
      effectiveAmountFinanced: this.effectiveAmountFinanced,
      interestRate: this.interestRate,
      rentalFeeMaintCostAddUp: this.rentalFeeMaintCostAddUp,
      rentalFeeInsCostAddUp: this.rentalFeeInsCostAddUp,
      rentalFeeEnvCostAddUp: this.rentalFeeEnvCostAddUp,
      paymentAtEnd: this.paymentAtEnd,
      insuranceCovered: this.insuranceCovered,
      maintenanceCovered: this.maintenanceCovered,
      insLifeCovered: this.insLifeCovered,
      insAssetCovered: this.insAssetCovered,
      // isSelfRegistered: this.isSelfRegistered,
      // isSecondHandProduct: this.isSecondHandProduct,
      // maintSchemeId: this.maintSchemeId,
      // maintSchemeName: this.maintSchemeName,
      // costPerVisit: this.costPerVisit,
      // intervalOfVisit: this.intervalOfVisit,
      // financialSchemeId: this.financialSchemeId,
      // financialSchemeName: this.financialSchemeName,
      // durationMin: this.durationMin,
      // durationMax: this.durationMax,
      // durationInterval: this.durationInterval,
      // totalMonthlyMaintCostPerVisit: this.totalMonthlyMaintCostPerVisit,
      // totalInsFixedCost: this.totalInsFixedCost,
      // totalInsVariableCostCV: this.totalInsVariableCostCV,
      // totalInsVariableCostEV: this.totalInsVariableCostEV,
      // totalInsVariableCostAF: this.totalInsVariableCostAF,
      isZeroCost: this.isZeroCost,
      zeroCostTotalInsCost: this.zeroCostTotalInsCost,
      zeroCostTotalMaintCost: this.zeroCostTotalMaintCost,
      effectiveInterestRate: this.effectiveInterestRate,
      firstPayment: this.firstPayment,
      actualFirstPayment: this.actualFirstPayment,
      accPmtShare: this.accPmtShare,
      accPmtMonthlyShare: this.accPmtMonthlyShare,
      accMonthlyPaymentAmount: this.accMonthlyPaymentAmount,
      accMonthlyLastPaymentAmount: this.accMonthlyLastPaymentAmount,
      accPaymentAmount: this.accPaymentAmount,
      accLastPaymentAmount: this.accLastPaymentAmount,
      zeroCostPmtTimes: this.zeroCostPmtTimes,
      zeroCostMonthlyPaymentAmount: this.zeroCostMonthlyPaymentAmount,
      // isBundle: this.isBundle,
      // primaryUnitPrice: this.primaryUnitPrice,
      // primaryProductPrice: this.primaryProductPrice,
      // totalAttachedProductPrice: this.totalAttachedProductPrice,
    );
  }
}
