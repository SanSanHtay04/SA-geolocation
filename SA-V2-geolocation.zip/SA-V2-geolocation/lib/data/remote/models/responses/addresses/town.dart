import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:latlong2/latlong.dart';

part 'town.freezed.dart';
part 'town.g.dart';

@freezed
class TownResponse with _$TownResponse {
  const TownResponse._();

  const factory TownResponse({
    required List<Town> towns,
  }) = _TownResponse;

  factory TownResponse.fromJson(Map<String, dynamic> json) => _$TownResponseFromJson(json);
}

@freezed
class Town with _$Town {
  const Town._();

  const factory Town({
    required int geoTownId,
    required String geoTownName,
    String? geoTownNameBurmese,
    @JsonKey(name: 'newLatitude') String? latitude,
    @JsonKey(name: 'newLongitude') String? longitude,
  }) = _Town;

  factory Town.fromJson(Map<String, dynamic> json) => _$TownFromJson(json);

    @override
  String toString() => '$geoTownName (${geoTownNameBurmese ?? geoTownId})';

  
  bool get isValidLocation => !((latitude == null || latitude!.isEmpty) || (longitude == null || longitude!.isEmpty));
  
  LatLng? get latLng => (isValidLocation) ? LatLng(double.parse(latitude!), double.parse(longitude!)) : null;
}
