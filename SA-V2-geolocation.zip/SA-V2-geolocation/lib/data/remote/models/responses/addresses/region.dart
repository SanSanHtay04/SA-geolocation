import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:latlong2/latlong.dart';

part 'region.freezed.dart';
part 'region.g.dart';

@freezed
class RegionResponse with _$RegionResponse {
  const RegionResponse._();

  const factory RegionResponse({
    required List<Region> regions,
  }) = _RegionResponse;

  factory RegionResponse.fromJson(Map<String, dynamic> json) => _$RegionResponseFromJson(json);
}

@freezed
class Region with _$Region {
  const Region._();

  const factory Region({
    required int geoRegionId,
    required String geoRegionName,
    @Default('') String geoRegionNameBurmese,
    @JsonKey(name: 'newLatitude') String? latitude,
    @JsonKey(name: 'newLongitude') String? longitude,
  }) = _Region;

  factory Region.fromJson(Map<String, dynamic> json) => _$RegionFromJson(json);

  @override
  String toString() => '$geoRegionName ($geoRegionNameBurmese)';


  
  bool get isValidLocation => !((latitude == null || latitude!.isEmpty) || (longitude == null || longitude!.isEmpty));
  
  LatLng? get latLng => (isValidLocation) ? LatLng(double.parse(latitude!), double.parse(longitude!)) : null;
}
