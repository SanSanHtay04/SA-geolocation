import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:latlong2/latlong.dart';

part 'township.freezed.dart';
part 'township.g.dart';

@freezed
class TownshipResponse with _$TownshipResponse {
  const TownshipResponse._();

  const factory TownshipResponse({
    required List<Township> townShips,
  }) = _TownshipResponse;

  factory TownshipResponse.fromJson(Map<String, dynamic> json) => _$TownshipResponseFromJson(json);
}

@freezed
class Township with _$Township {
  const Township._();

  const factory Township({
    required int geoTownShipId,
    required String geoTownShipName,
    String? geoTownShipNameBurmese,
    @JsonKey(name: 'newLatitude') String? latitude,
    @JsonKey(name: 'newLongitude') String? longitude,
  }) = _Township;

  factory Township.fromJson(Map<String, dynamic> json) => _$TownshipFromJson(json);

  @override
  String toString() => '$geoTownShipName (${geoTownShipNameBurmese ?? geoTownShipId})';


  
  bool get isValidLocation => !((latitude == null || latitude!.isEmpty) || (longitude == null || longitude!.isEmpty));
  
  LatLng? get latLng => (isValidLocation) ? LatLng(double.parse(latitude!), double.parse(longitude!)) : null;
}
