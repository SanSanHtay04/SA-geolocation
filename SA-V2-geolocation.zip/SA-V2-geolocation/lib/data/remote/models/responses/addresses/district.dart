import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:latlong2/latlong.dart';

part 'district.freezed.dart';
part 'district.g.dart';

@freezed
class DistrictResponse with _$DistrictResponse {
  const DistrictResponse._();

  const factory DistrictResponse({
    required List<District> districts,
  }) = _DistrictResponse;

  factory DistrictResponse.fromJson(Map<String, dynamic> json) => _$DistrictResponseFromJson(json);
}

@freezed
class District with _$District {
  const District._();

  const factory District({
    required int geoDistrictId,
    required String geoDistrictName,
    String? geoDistrictNameBurmese,
    @JsonKey(name: 'newLatitude') String? latitude,
    @JsonKey(name: 'newLongitude') String? longitude,
  }) = _District;

  factory District.fromJson(Map<String, dynamic> json) => _$DistrictFromJson(json);

  @override
  String toString() => '$geoDistrictName ( ${geoDistrictNameBurmese ?? geoDistrictId})';

  bool get isValidLocation => !((latitude == null || latitude!.isEmpty) || (longitude == null || longitude!.isEmpty));
  
  LatLng? get latLng => (isValidLocation) ? LatLng(double.parse(latitude!), double.parse(longitude!)) : null;
}
