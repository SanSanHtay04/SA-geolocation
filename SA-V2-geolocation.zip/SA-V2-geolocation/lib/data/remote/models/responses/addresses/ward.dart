import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:latlong2/latlong.dart';

part 'ward.freezed.dart';
part 'ward.g.dart';

@freezed
class WardResponse with _$WardResponse {
  const WardResponse._();

  const factory WardResponse({
    required List<Ward> wards,
  }) = _WardResponse;

  factory WardResponse.fromJson(Map<String, dynamic> json) => _$WardResponseFromJson(json);
}

@freezed
class Ward with _$Ward {
  const Ward._();

  const factory Ward({
    required int geoWardId,
    required String geoWardName,
    String? geoWardNameBurmese,
    @JsonKey(name: 'newLatitude') String? latitude,
    @JsonKey(name: 'newLongitude') String? longitude,
  }) = _Ward;

  factory Ward.fromJson(Map<String, dynamic> json) => _$WardFromJson(json);

  @override
  String toString() => '$geoWardName (${geoWardNameBurmese ?? geoWardId})';

  bool get isValidLocation => !((latitude == null || latitude!.isEmpty) || (longitude == null || longitude!.isEmpty));

  LatLng? get latLng => (isValidLocation) ? LatLng(double.parse(latitude!), double.parse(longitude!)) : null;
}
