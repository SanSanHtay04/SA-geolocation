import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:latlong2/latlong.dart';

part 'village.freezed.dart';
part 'village.g.dart';

@freezed
class VillageResponse with _$VillageResponse {
  const VillageResponse._();

  const factory VillageResponse({
    required List<Village> geoVillages,
  }) = _VillageResponse;

  factory VillageResponse.fromJson(Map<String, dynamic> json) => _$VillageResponseFromJson(json);
}

@freezed
class Village with _$Village {
  const Village._();

  const factory Village({
    required int geoVillageId,
    required String geoVillageName,
    String? geoVillageNameBurmese,
    @JsonKey(name: 'newLatitude') String? latitude,
    @JsonKey(name: 'newLongitude') String? longitude,
  }) = _Village;

  factory Village.fromJson(Map<String, dynamic> json) => _$VillageFromJson(json);

  @override
  String toString() => '$geoVillageName (${geoVillageNameBurmese ?? geoVillageId})';

  bool get isValidLocation => !((latitude == null || latitude!.isEmpty) || (longitude == null || longitude!.isEmpty));

  LatLng? get latLng => (isValidLocation) ? LatLng(double.parse(latitude!), double.parse(longitude!)) : null;
}
