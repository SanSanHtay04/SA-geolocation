import 'package:freezed_annotation/freezed_annotation.dart';

part 'app_version_response.freezed.dart';
part 'app_version_response.g.dart';

@freezed
class AppVersionResponse with _$AppVersionResponse {
  const AppVersionResponse._();

  const factory AppVersionResponse({
    required String appVersion,
    @Default(0) int updateRequired,
    @Default('') String appDownloadLink,
  }) = _AppVersionResponse;

  // const factory AppVersionResponse({
  //   @JsonKey(name: 'version') required String versionCode,
  //   @JsonKey(name: 'short_version') required String versionName,
  //   @JsonKey(name: 'download_url') required String downloadUrl,
  // }) = _AppVersionResponse;

  factory AppVersionResponse.fromJson(Map<String, dynamic> json) =>
      _$AppVersionResponseFromJson(json);
}
