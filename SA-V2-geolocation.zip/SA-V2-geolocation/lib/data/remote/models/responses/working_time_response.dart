import 'package:freezed_annotation/freezed_annotation.dart';

part 'working_time_response.freezed.dart';
part 'working_time_response.g.dart';

@freezed
class WorkingTimeResponse with _$WorkingTimeResponse {
  const WorkingTimeResponse._();

  const factory WorkingTimeResponse({
    @JsonKey(name: 'working_time_start') required String start,
    @JsonKey(name: 'working_time_end') required String end,
  }) = _WorkingTimeResponse;

  factory WorkingTimeResponse.fromJson(Map<String, dynamic> json) =>
      _$WorkingTimeResponseFromJson(json);
}
