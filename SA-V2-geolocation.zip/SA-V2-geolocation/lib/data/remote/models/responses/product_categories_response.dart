import 'package:freezed_annotation/freezed_annotation.dart';

part 'product_categories_response.freezed.dart';
part 'product_categories_response.g.dart';

/// messages : "List of product category is successfully loaded."
/// data : [{"productCategoryId":14,"productCategoryName":"Aircon"},{"productCategoryId":15,"productCategoryName":"Audio"},{"productCategoryId":11,"productCategoryName":"Computer PC"},{"productCategoryId":16,"productCategoryName":"Dryer"},{"productCategoryId":17,"productCategoryName":"Electric Oven"},{"productCategoryId":13,"productCategoryName":"Electronic Accessory"},{"productCategoryId":18,"productCategoryName":"Freezer"},{"productCategoryId":19,"productCategoryName":"Fridge"},{"productCategoryId":20,"productCategoryName":"Grill Oven"},{"productCategoryId":12,"productCategoryName":"Laptop"},{"productCategoryId":21,"productCategoryName":"Microwave"},{"productCategoryId":6,"productCategoryName":"Motorcycle (S1)"},{"productCategoryId":7,"productCategoryName":"Motorcycle (S2)"},{"productCategoryId":8,"productCategoryName":"Motorcycle (S3)"},{"productCategoryId":9,"productCategoryName":"Phone"},{"productCategoryId":10,"productCategoryName":"Tablet"},{"productCategoryId":2,"productCategoryName":"Tricycle"}]

/// productCategoryId : 14
/// productCategoryName : "Aircon"

@freezed
class ProductCategoriesResponse with _$ProductCategoriesResponse {
  factory ProductCategoriesResponse({
    required int productCategoryId,
    required String productCategoryName,
  }) = _ProductCategoriesResponse;

  factory ProductCategoriesResponse.fromJson(Map<String, dynamic> json) =>
      _$ProductCategoriesResponseFromJson(json);
}
