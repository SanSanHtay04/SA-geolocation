import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/models/models.dart';

part 'prospect_response.freezed.dart';
part 'prospect_response.g.dart';

@freezed
class ProspectResponse with _$ProspectResponse {
  const ProspectResponse._();

  const factory ProspectResponse({
    required int prospectId,
    @Default('') String prospectName,
    @Default(GenderType.male) GenderType prospectGender,
    @Default('') String prospectMobile,
    String? prospectOtherMobile,
    String? prospectRemark,
    int? submittedAppId,
    int? personCreated,
    int? packageId,
    String? productCategoryName,
    String? brandName,
    String? modelName,
    String? productCode,
    String? productName,
    int? isBundle,
    num? primaryUnitPrice,
    int? quantity,
    num? primaryTotalPrice,
    num? packageTotalPrice,
    num? isSecondHandProduct,
    num? isSelfRegistered,
    num? simulationId,
    num? paymentAtEnd,
    num? totalPrice,
    num? depositAmount,
    num? depositPercentage,
    num? earlyPrepaymentAmount,
    num? earlyPrepaymentPercentage,
    num? amountFinanced,
    num? effectiveAmountFinanced,
    num? interestRate,
    String? pmtPeriodicity,
    num? duration,
    num? maintenanceCovered,
    num? insuranceCovered,
    num? insLifeCovered,
    num? insAssetCovered,
    num? adminFee,
    num? actualFirstPayment,
    num? amountFinancedAdminFeeAddUp,
    num? zeroCostTotalInsCost,
    num? zeroCostTotalMaintCost,
    num? isZeroCost,
    num? followingPayment,
    num? zeroCostPmtTimes,
    num? zeroCostMonthlyPaymentAmount,
    num? applicationId,
    num? personDesignatedTo,
    String? personDesignatedToFullName,
    num? createdCustId,
    num? customerId,
    String? customerFullName,
    String? birthDate,
    String? natRegCardNo,
    String? fatherName,
    String? maritalStatusName,
    String? homeStatus,
    String? homeAddress,
    num? hasViberAccount,
    num? isViberAccountSameNo,
    String? viberAccountNo,
    num? totalHousehold,
    String? phoneNo1,
    String? geoRegionName,
    String? geoDistrictName,
    String? geoTownShipName,
    String? geoTownName,
    String? geoWardName,
    String? geoVillageName,
    num? geoWardId,
    num? geoVillageId,
    num? contractId,
    String? ContractNo,
    String? followingPaymentDate,
    num? adjustmentDays,
    num? adjustmentDiscountOrFee,
    required int posId,
    String? posName,
    String? merchantName,
    String? defaultFollowingPaymentDate,
    String? firstName,
    String? middleName,
    String? lastName,
    UserInfo? person_created,
    UserInfo? person_updated,
    @Default([]) @JsonKey(name: 'prospect_incomes') List<ProspectIncome> incomes,
  }) = _ProspectResponse;

  factory ProspectResponse.fromJson(Map<String, dynamic> json) => _$ProspectResponseFromJson(json);

  Prospect toDomainModel() {
    return Prospect(
      prospectId: prospectId,
      posId: posId,
      name: prospectName,
      gender: prospectGender,
      mobile: prospectMobile,
      otherMobile: prospectOtherMobile,
      remark: prospectRemark,
    );
  }
}

@freezed
class UserInfo with _$UserInfo {
  const UserInfo._();

  const factory UserInfo({
    @Default(0) num userId,
    @Default('') String userName,
    @Default('') String userFullName,
  }) = _UserInfo;

  factory UserInfo.fromJson(Map<String, dynamic> json) => _$UserInfoFromJson(json);
}

@freezed
class ProspectIncome with _$ProspectIncome {
  const ProspectIncome._();

  const factory ProspectIncome({
    @Default(0) num incomeSourceId,
    @Default(0) num customerId,
    num? selfemployed,
    @Default(0) num businessTypeId,
    num? businessSubTypeId,
    @Default(0) num jobCategoryId,
    String? workplaceName,
    String? workplaceFixedTel,
    String? workplaceAddress,
    num? incomePeriodicity,
    num? incomeAmount,
    num? monthlyIncomeAmount,
    String? monthlyIncomeRange,
    String? incomeSourceRemark,
    dynamic exclusionList,
    String? exclusionListRemark,
    num? callAvailableDuringOfficeHour,
    String? callAvailableTime,
    String? dtCreated,
    num? personCreated,
    String? dtUpdated,
    num? personUpdated,
    String? dtDeleted,
    num? personDeleted,
    num? laravel_through_key,
  }) = _ProspectIncome;

  factory ProspectIncome.fromJson(Map<String, dynamic> json) => _$ProspectIncomeFromJson(json);
}
