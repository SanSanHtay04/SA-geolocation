import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:pretty_dio_logger/pretty_dio_logger.dart';
import 'package:sales/configs.dart';
import 'package:sales/data/remote/auth_interceptor.dart';
import 'package:sales/providers/local_auth_provider.dart';

const int _connectTimeout = 30 * 1000;
const int _sendTimeout = 90 * 1000;
const int _receiveTimeout = 90 * 1000;

_parseAndDecode(String response) {
  return jsonDecode(response);
}

parseJson(String text) {
  return compute(_parseAndDecode, text);
}

class ApiClient {
  ApiClient._();

  static late final LocalAuthProvider _localAuth;

  static initialize(LocalAuthProvider authProvider) {
    _localAuth = authProvider;
  }

  static Dio get client {
    final options = BaseOptions(
      baseUrl: Configs.baseUrl,
      // connectTimeout: _connectTimeout,
      // sendTimeout: _sendTimeout,
      // receiveTimeout: _receiveTimeout,
      headers: {
        HttpHeaders.contentTypeHeader: 'application/json; charset=UTF-8',
        HttpHeaders.acceptHeader: 'application/json',
      },
    );
    final dio = Dio(options);

    dio.interceptors.add(AuthInterceptor(_localAuth));
    if (kDebugMode) {
      dio.interceptors.add(PrettyDioLogger(requestBody: true));
    }

    // Isolate JSON decode
    (dio.transformer as DefaultTransformer).jsonDecodeCallback = parseJson;

    return dio;
  }
}
