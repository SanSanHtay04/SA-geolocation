import 'package:freezed_annotation/freezed_annotation.dart';

part 'api_response.g.dart';

@JsonSerializable(genericArgumentFactories: true, createToJson: false)
class ApiResponse<T> {
  final int? success;
  final T data;
  final String? message;

  ApiResponse({this.success, required this.data, this.message});

  factory ApiResponse.fromJson(
    Map<String, dynamic> json,
    T Function(Object? json) fromJsonT,
  ) =>
      _$ApiResponseFromJson(json, fromJsonT);

  bool get isSuccess => success == 1;
}


@JsonSerializable()
class MessageResponse {
  final String? messages;
  final String? message;

  MessageResponse(this.messages, this.message);

  factory MessageResponse.fromJson(Map<String, dynamic> json) =>
      _$MessageResponseFromJson(json);
}
