import 'package:flutter/material.dart';

const defaultErrorMessage = 'Oops! Something when wrong with server';

enum AppErrorType {
  emptyJobCategories,
  defaultServerError,
  serverError,
  defaultError,
  noConnection,
  connectTimeout,
  unauthorized,
  badRequest,
  forbidden,
  notFound,
  cannotUpdateType,
}

class AppError<T> {
  final AppErrorType errorType;
  final T? data;

  AppError(this.errorType, {this.data});

  factory AppError.defaultServerError() => AppError(AppErrorType.defaultServerError);

  factory AppError.defaultError() => AppError(AppErrorType.defaultError);
}

extension AppErrorX on AppError? {
  String errorMessage(BuildContext context, String message) {
    if (this == null) return message;
    switch (this!.errorType) {
      case AppErrorType.noConnection:
        return 'No Internet';
      case AppErrorType.connectTimeout:
        return 'Connect timeout';
      case AppErrorType.unauthorized:
        return 'Unauthorized';  
      default:
        return defaultErrorMessage;
    }
  }
}
