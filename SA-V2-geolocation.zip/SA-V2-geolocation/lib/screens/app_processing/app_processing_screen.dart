import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/providers/application_provider.dart';
import 'package:sales/screens/app_processing/app_processing_widget.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/copyright_notice.dart';
import 'package:sales/widgets/waiting_modal_bottom_widget.dart';

class AppProcessingScreen extends StatefulWidget {
  const AppProcessingScreen({super.key});

  @override
  State<AppProcessingScreen> createState() => _AppProcessingScreenState();
}

class _AppProcessingScreenState extends State<AppProcessingScreen> {
  bool _isLoading = false;
  List<Map<String, dynamic>> _applications = [];

  String? filter;
  TextEditingController searchController = new TextEditingController();

  Future<void> _getSubmittedApplications() async {
    showWaitingModal(
        context: context,
        message: "List of applications are loading...",
        onWaiting: () async {
          try {
            await Provider.of<ApplicationProvider>(context, listen: false).getSubmittedApplications().then((value) {
              print('approved applications length ${_applications.length}');
              setState(() {
                _applications = Provider.of<ApplicationProvider>(context, listen: false).items;
              });
            });
          } catch (error) {
            print(error.toString());
          }
        });
  }

  Future<void> _reloadData() async {
    await this._getSubmittedApplications();
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      _reloadData();
      searchController.addListener(() {
        setState(() {
          filter = searchController.text;
        });
      });
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'APP PROCESSING (${_applications.length})',
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh_rounded),
            onPressed: () async {
              await this._getSubmittedApplications();
            },
          )
        ],
      ),
      body: Padding(
        padding: EdgeInsets.fromLTRB(5, 10, 5, 5),
        child: Column(children: <Widget>[
          new Padding(
            padding: new EdgeInsets.fromLTRB(10, 0, 10, 5),
            child: new TextField(
              controller: searchController,
              decoration: InputDecoration(
                hintText: 'Search Application',
                prefixIcon: Icon(
                  Icons.search,
                ),
                contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 15.0, 20.0),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15.0),
                ),
                suffixIcon: IconButton(
                  icon: Icon(Icons.clear),
                  onPressed: () => searchController.clear(),
                ),
              ),
            ),
          ),
          Divider(),
          Expanded(
            child: Container(
              child: RefreshIndicator(
                onRefresh: () => _reloadData(),
                child: ListView.builder(
                    itemCount: _applications.length,
                    itemBuilder: (context, i) {
                      return filter == null || filter == "" ? AppProcessingWidget(application: _applications[i]) : ('${_applications[i]['customerFullName']}'.toLowerCase().contains(filter!.toLowerCase()) || '${_applications[i]['applicationId']}'.toLowerCase().contains(filter!.toLowerCase()) || '${_applications[i]['productName']}'.toLowerCase().contains(filter!.toLowerCase()) ? AppProcessingWidget(application: _applications[i]) : SizedBox());
                    }),
              ),
            ),
          ),
          kSpaceVertical8,
          CopyrightNotice(),
        ]),
      ),
    );
  }
}
