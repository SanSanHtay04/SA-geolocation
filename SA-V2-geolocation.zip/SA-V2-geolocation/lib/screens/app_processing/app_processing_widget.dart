import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:sales/themes/dimensions.dart';

class AppProcessingWidget extends StatefulWidget {
  final Map<String, dynamic> application;

  AppProcessingWidget({Key? key, required this.application});
  @override
  State<AppProcessingWidget> createState() => _AppProcessingWidgetState();
}

class _AppProcessingWidgetState extends State<AppProcessingWidget> {
  @override
  Widget build(BuildContext context) {
    return ListTile(
      isThreeLine: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            '${widget.application['customerFullName']}',
            style: TextStyle(
              color: Colors.blue.shade800,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            "APP ID: ${widget.application['applicationId']}",
            style: TextStyle(color: Colors.blue.shade800, fontWeight: FontWeight.bold, fontSize: 14),
          ),
        ],
      ),
      subtitle: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    "Applicant's Phone: ${widget.application['phoneNo1']}${widget.application['phoneNo2'] != null ? (" / " + widget.application['phoneNo2']) : ''}",
                    style: TextStyle(fontSize: 12),
                  ),
                  widget.application['videoCallSupported'] == 1
                      ? Text(
                          '[Video Call]',
                          style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold, fontSize: 12),
                        )
                      : SizedBox(),
                ],
              ),
              Text(
                'Product: ${widget.application['productName']}',
                style: TextStyle(fontSize: 12),
              ),
              Text(
                'POS: ${widget.application['posName']}',
                style: TextStyle(fontSize: 12),
              ),
              Text(
                'Submitted At: ${DateFormat('dd/MM/yyyy HH:mm').format(DateTime.parse(widget.application['dtSubmitted'].toString()))}',
                style: TextStyle(fontSize: 12),
              ),
              Text(
                'Designated To Person: ${widget.application['personDesignatedToName']}',
                style: TextStyle(fontSize: 12),
              ),
            ],
          ),
          kSpaceVertical10,
        
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Container(
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.horizontal(
                    right: Radius.circular(60),
                  ),
                  color: Colors.blue,
                ),
                height: 40,
                width: 65,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 2),
                child: Text(
                  "Submitted",
                  style: TextStyle(color: Colors.white, fontSize: 9.5, fontWeight: FontWeight.bold),
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.horizontal(
                    right: Radius.circular(60),
                  ),
                  color: widget.application['dtUWAssigned'] != null ? Colors.blue : Colors.grey,
                ),
                height: 40,
                width: 65,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 2),
                child: Text(
                  "Assigned",
                  style: TextStyle(color: Colors.white, fontSize: 9.5, fontWeight: FontWeight.bold),
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.horizontal(
                    right: Radius.circular(60),
                  ),
                  color: widget.application['dtUWStarted'] != null ? Colors.blue : Colors.grey,
                ),
                height: 40,
                width: 65,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 2),
                child: Text(
                  "Reviewing",
                  style: TextStyle(color: Colors.white, fontSize: 9.5, fontWeight: FontWeight.bold),
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.horizontal(
                    right: Radius.circular(60),
                  ),
                  color: widget.application['dtSubmitted'] == null && widget.application['dtSentBackOrigination'] != null ? Colors.blue : Colors.grey,
                ),
                height: 40,
                width: 65,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 2),
                child: Text(
                  "CP",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 9.5,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.horizontal(
                    right: Radius.circular(60),
                  ),
                  color: widget.application['dtUWEnded'] != null ? (widget.application['appAccepted'] == 1 ? Colors.green : Colors.red) : Colors.grey,
                ),
                height: 40,
                width: 65,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 2),
                child: Text(
                  widget.application['appAccepted'] == 1 ? "Approved" : (widget.application['appAccepted'] == 0 ? "Rejected" : "-/-"),
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 9.5,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          kSpaceVertical8,
          Divider(),
        ],
      ),
    );
  }
}
