import 'package:flutter/material.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/work_layout.dart';

import '../../../configs.dart';
import '../../../widgets/copyright_notice.dart';

class LoginScaffold<VM extends ChangeNotifier> extends StatelessWidget {
  const LoginScaffold({
    super.key,
    this.appbar,
    required this.isLoading,
    this.form,
  });

  final Widget? form;
  final bool isLoading;
  final Widget? appbar;

  @override
  Widget build(BuildContext context) {
    return WorkLayout(
        isBusy: isLoading,
        child: Column(
          children: [
            Expanded(
              child: Center(
                child: SingleChildScrollView(
                  padding: kPaddingHorizontal16,
                  child: Column(
                    children: [
                      _loginHeader(),
                      form!,
                    ],
                  ),
                ),
              ),
            ),
            // Divider(),
            CopyrightNotice(),
          ],
        ));
  }

  Widget _loginHeader() {
    return Column(
      children: [
        Padding(
          padding: EdgeInsets.fromLTRB(35, 20, 35, 20),
          child: Image(
            image: new AssetImage('assets/images/r2o_logo.png'),
            fit: BoxFit.fill,
          ),
        ),
        Text(
          'SA APP',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20,
            color: Color.fromRGBO(0, 100, 160, 1),
          ),
        ),
        Configs.loginWithCredential
            ? Text('(TEST VERSION)',
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                    color: Colors.red))
            : SizedBox(),
        SizedBox(
          height: 20,
        ),
      ],
    );
  }
}
