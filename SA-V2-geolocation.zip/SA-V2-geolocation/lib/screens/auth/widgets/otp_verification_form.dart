import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/text_input_form_field.dart';

import '../otp_verification/viewmodel/otp_verification_viewmodel.dart';

class OtpVerificationForm extends StatelessWidget {
  const OtpVerificationForm({super.key, required this.vm});

  final OTPVerificationViewModel vm;

  @override
  Widget build(BuildContext context) {
    return Form(
      autovalidateMode: AutovalidateMode.onUserInteraction,
      child: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(16),
            child: Align(
              alignment: Alignment.center,
              child: Text(
                "Enter the OTP sent to your ${vm.formState.otpMethod}.",
              ),
            ),
          ),
          TextInputFormField(
            textAlign: TextAlign.center,
            textInputAction: TextInputAction.done,
            keyboardType: TextInputType.number,
            inputFormatters: [
              FilteringTextInputFormatter.allow(RegExp(r"[0-9]")),
              LengthLimitingTextInputFormatter(4)
            ],
            style: TextStyle(letterSpacing: 4, fontSize: 20),
            onChanged: vm.updateOtpCode,
          ),
          kSpaceVertical20,
          Row(children: [
            Expanded(
                child: ElevatedButton(
              child: const Text('Verify'),
              onPressed: vm.enableButton ? vm.verifyOTP : null,
            )),
          ]),
        ],
      ),
    );
  }
}
