import 'package:flutter/material.dart';
import 'package:sales/models/models.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/selected_group/single_selected_group.dart';
import 'package:sales/widgets/text_form_field/clearable_text_form_field.dart';

import '../otp_login/viewmodel/otp_login_viewModel.dart';

class OtpLoginForm extends StatelessWidget {
  const OtpLoginForm({super.key, required this.vm});

  final OtpLoginViewModel vm;

  @override
  Widget build(BuildContext context) {
    return Form(
      autovalidateMode: AutovalidateMode.onUserInteraction,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SingleSelectedGroup<OtpMethod>(
            items: OtpMethod.values,
            labelParser: (item) => item.getName(),
            onSelectChanged: vm.selectOtpMethod,
            selectedItem: vm.formState.otpMethod,
          ),
          kSpaceVertical10,
          ClearableTextFormField(
            initialValue: vm.formState.userName,
            required: true,
            labelText: 'Username',
            prefixIcon: const Icon(Icons.account_box),
            textInputAction: TextInputAction.done,
            onChanged: vm.updateUserName,
          ),
          kSpaceVertical20,
          Row(children: [
            Expanded(
                child: ElevatedButton(
              child: const Text('Login'),
              onPressed: vm.enableButton ? () => vm.generateOtp() : null,
            )),
          ]),
        ],
      ),
    );
  }
}
