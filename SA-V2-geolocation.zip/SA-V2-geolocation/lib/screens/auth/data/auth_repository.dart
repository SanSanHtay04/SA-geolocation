import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:sales/base/data_response.dart';
import 'package:sales/base/error.dart';
import 'package:sales/configs.dart';
import 'package:sales/data/local/tables/pos_table.dart';
import 'package:sales/data/remote/models/models.dart';

import 'package:sales/data/remote/services/services.dart';
import 'package:sales/base/base_repository.dart';
import 'package:sales/models/models.dart';
import 'package:http/http.dart' as http;


import '../../../data/local/prefs_store.dart';
import 'package:sales/utils/utils.dart';

class AuthRepository with BaseRepository {
  late AuthService _api;
  late PrefsStore _prefsStore;
  late POSDao _posDao;

  AuthRepository({
    required AuthService api,
    required PrefsStore prefsStore,
    required POSDao posDao,
  }) {
    _api = api;
    _prefsStore = prefsStore;
    _posDao = posDao;
  }

  AccountInfo? get accountInfo {
    var response = _prefsStore.accountInfo;
    if (response == null) return null;
    return AccountInfo.fromResponse(response);
  }

  bool get isLoggedIn => !_prefsStore.accessToken.isNullOrEmpty;

  Future<DataResponse<AccountInfo>> login({
   required String name,
    required  String password,
    required  String androidId,
  }) {
    return getData(
      handleDataRequest: () => _api.login(LoginRequest(
          username: name, password: password, androidId: androidId)),
      handleDataResponse: (LoginAuthResponse res) {
        _prefsStore.setAccountInfo(res.toAuthResponse());
        return AccountInfo(
          userId: res.user.userId,
          accessToken: res.token.accessToken,
        );
      },
    );
  }

  Future<DataResponse<OtpData>> otpLogin(String username, OtpMethod method) {
    return getData(
      handleDataRequest: () => _api.otpLogin(username, method.name),
      handleDataResponse: (ApiResponse<OtpResponseData> res) {
        AppLogger.i(" message : ${res}");
        if (res.data.success == 1) {
          return OtpData(token: res.data.otpToken.token);
        }
        throw res.message ?? defaultErrorMessage;
      },
    );
  }

  Future<DataResponse<AccountInfo>> verifyOTP(
    String username,
    String code,
    String androidId,
  ) {
    return getData(
      handleDataRequest: () => _api.verifyOTP(username, code, androidId),
      handleDataResponse: (ApiResponse<AuthResponse> res) async {
        if (res.data.success == 1) {
          String _saAccessToken = "";
          await _getSAApiToken(res.data.user.userName!, res.data.user.pwd!)
              .then((value) => _saAccessToken = value);

          final _authRes = AuthResponse(
              success: 1,
              user: res.data.user,
              accessToken: res.data.accessToken,
              saAccessToken: _saAccessToken);

          _prefsStore.setAccountInfo(_authRes);
          return AccountInfo.fromResponse(_authRes);
        }
        throw res.message ?? defaultErrorMessage;
      },
    );
  }

  Future<void> clearUserInfo() => _prefsStore.clearAccountInfo();

  Future<void> logout() async {
    /// Clear local data first coz error could occur on api call!
    clearUserInfo();
    await _posDao.deleteALl();
    await _prefsStore.setPOSListLastFetch(DateTime.now().subtract(Duration(minutes: 30)));
    _api.logout();
  }

  // TODO: instead of declaration of http client, need to refactor later
  Future<String> _getSAApiToken(String username, String pwd) async {
    AppLogger.i("username : $username, password: $pwd");
    final _response = await http.post(
      Uri.parse("${Configs.saPassportUrl}/oauth/token"),
      body: json.encode({
        'grant_type': 'password',
        'client_id': Configs.saPassportClientId,
        'client_secret': Configs.saPassportClientSecret,
        'username': username,
        'password': pwd,
      }),
      headers: {
        HttpHeaders.contentTypeHeader: 'application/json',
        HttpHeaders.acceptHeader: 'application/json',
      },
    );
    final Map<String, dynamic> tokenData = json.decode(_response.body);
    if (tokenData.containsKey('data')) {
      final Map<String, dynamic> userData = tokenData['data'];
      if (userData.containsKey('access_token')) {
        return userData['access_token'];
      }
    }
    return "";
  }
}
