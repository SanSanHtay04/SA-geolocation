import 'package:android_id/android_id.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:sales/screens/auth/data/auth_repository.dart';
import 'package:sales/screens/auth/otp_verification/viewmodel/otp_verification_form_state.dart';
import 'package:sales/screens/auth/otp_verification/viewmodel/otp_verification_submit_state.dart';
import 'package:sales/screens/shared/app_device_info.dart';
import 'package:sales/utils/utils.dart';

class OTPVerificationViewModel extends ChangeNotifier {
  OTPVerificationViewModel(this.repo);

  AuthRepository repo;
  

  OtpVerificationFormState formState = const OtpVerificationFormState();
  OtpVerificationSubmitState submitState =
      const OtpVerificationSubmitState.idle();

  bool get isLoading => (submitState is OtpVerificationSubmitStateLoading);

  bool get enableButton =>
      (!formState.otpCode.isNullOrEmpty && formState.otpCode.length == 4);

  _setFormState(OtpVerificationFormState value) {
    formState = value;
    notifyListeners();
  }

  updateOtpCode(String code) {
    _setFormState(formState.copyWith(otpCode: code));
  }

  Future<String> getImeiNo() async {
    return await AppDeviceInfo().getImei();
  }
  
  loadData(String name,String otpMethod) async {
    String androidId;
    try {
      // androidId = await AndroidId().getId() ?? 'Unknown ID';
      androidId = await getImeiNo();
    } on PlatformException {
      androidId = 'Unknown ID';
    }
    _setFormState(formState.copyWith(userName: name, otpMethod: otpMethod, androidId: androidId));
  }

  _setSubmitState(OtpVerificationSubmitState value) {
    submitState = value;
    notifyListeners();
  }

  resetSubmitState() {
    _setSubmitState(const OtpVerificationSubmitStateIdle());
  }

  void verifyOTP() async {
    _setSubmitState(const OtpVerificationSubmitStateLoading());
    final res = await repo.verifyOTP(
      formState.userName,
      formState.otpCode,
      formState.androidId,
    );
    final newState = res.when(
      success: (data) => OtpVerificationSubmitStateSuccess(data),
      failed: (msg, err) => OtpVerificationSubmitStateFailed(msg, error: err),
    );
    _setSubmitState(newState);
  }

  
}
