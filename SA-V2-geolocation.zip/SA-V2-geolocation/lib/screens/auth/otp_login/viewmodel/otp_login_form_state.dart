import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/models/models.dart';


part 'otp_login_form_state.freezed.dart';

@freezed
class OtpLoginFormState with _$OtpLoginFormState {
  const OtpLoginFormState._();
  const factory OtpLoginFormState({
    @Default('') String userName,
    @Default(OtpMethod.email) OtpMethod otpMethod,
  }) = _OtpLoginFormState;
}
