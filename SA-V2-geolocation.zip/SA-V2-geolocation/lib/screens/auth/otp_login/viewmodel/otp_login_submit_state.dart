import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/base/error.dart';
import 'package:sales/models/otp_data.dart';

part 'otp_login_submit_state.freezed.dart';

@freezed
class OtpLoginSubmitState with _$OtpLoginSubmitState {
  const factory OtpLoginSubmitState.idle() = OtpLoginSubmitStateIdle;

  const factory OtpLoginSubmitState.loading() = OtpLoginSubmitStateLoading;

  const factory OtpLoginSubmitState.success(OtpData data) = OtpLoginSubmitStateSuccess;

  const factory OtpLoginSubmitState.failed(String message, {AppError? error}) = OtpLoginSubmitStateFailed;
}
