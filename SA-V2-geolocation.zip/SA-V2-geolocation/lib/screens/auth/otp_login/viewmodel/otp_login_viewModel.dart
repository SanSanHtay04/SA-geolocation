import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:sales/models/models.dart';
import 'package:sales/utils/utils.dart';
import '../../data/auth_repository.dart';

import 'otp_login_form_state.dart';
import 'otp_login_submit_state.dart';


class OtpLoginViewModel extends ChangeNotifier {
  AuthRepository repo;

  OtpLoginViewModel(this.repo);

  OtpLoginFormState formState = const OtpLoginFormState();
  OtpLoginSubmitState submitState = const OtpLoginSubmitStateIdle();

  bool get isLoading => (submitState is OtpLoginSubmitStateLoading);

  bool get enableButton => (!formState.userName.isNullOrEmpty);

  setFormState(OtpLoginFormState value) {
    formState = value;
    notifyListeners();
  }

  updateUserName(String name) {
    setFormState(formState.copyWith(userName: name));
  }

  selectOtpMethod(OtpMethod method) {
    setFormState(formState.copyWith(otpMethod: method));
  }

  setSubmitState(OtpLoginSubmitState value) {
    submitState = value;
    notifyListeners();
  }

  resetSubmitState (){
    setSubmitState(const OtpLoginSubmitStateIdle());
  }

  generateOtp() async {
    if (formState.userName.isNullOrEmpty) return;

    setSubmitState(const OtpLoginSubmitStateLoading());
    final res = await repo.otpLogin(formState.userName, formState.otpMethod);

    final newState = res.when(
        success: (data) => OtpLoginSubmitStateSuccess(data),
        failed: (msg, error) =>
            OtpLoginSubmitStateFailed(msg, error: error));
    setSubmitState(newState);
  }
}
