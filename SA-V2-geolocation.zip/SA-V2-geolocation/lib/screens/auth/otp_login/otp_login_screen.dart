import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:provider/provider.dart';
import 'package:sales/base/error.dart';
import 'package:sales/models/otp_data.dart';
import 'package:sales/screens/auth/widgets/login_scaffold.dart';
import 'package:sales/providers/providers.dart';
import 'package:sales/widgets/app_snack_bar.dart';
import '../../shared/shared_screen.dart';

import '../otp_verification/otp_verification_screen.dart';
import '../widgets/otp_login_form.dart';
import 'viewmodel/otp_login_viewModel.dart';

class OTPLoginScreen extends StatelessWidget {
  const OTPLoginScreen({Key? key}) : super(key: key);

  goToSharedScreenIfLoggedIn(BuildContext context) {
    SchedulerBinding.instance.addPostFrameCallback((timeStamp) {
      Navigator.pushNamedAndRemoveUntil(
          context, SharedScreen.routeName, (_) => false);
    });
  }

  goToOtpVerification(BuildContext context, OtpData data) {
    SchedulerBinding.instance.addPostFrameCallback((timeStamp) {
       final formState = context.read<OtpLoginViewModel>().formState;
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => OTPVerificationScreen(username: formState.userName,otpMethod: formState.otpMethod.name,)),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<OtpLoginViewModel>(
      create: (context) => OtpLoginViewModel(context.read()),
      child: Consumer<OtpLoginViewModel>(
        builder: (context, vm, unsubscribedChild) {
          /// Handle CallBack for LoginSubmit State
          Future.delayed(Duration.zero, () {
            WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
              // TODO: rather than checking the current user is already authenticated in UI, better to handle it before routing
              bool isLoggedIn = context.read<AuthProvider>().isAuthenticated;
              if (isLoggedIn) goToSharedScreenIfLoggedIn(context);
            });

            vm.submitState.maybeWhen(
              failed: (message, error) => context.showErrorDialog(
                error.errorMessage(context, message),
                onClosePressed: vm.resetSubmitState,
              ),
              success: (data) => goToOtpVerification(context, data),
              orElse: () {},
            );
          });

          return LoginScaffold(
            isLoading: vm.isLoading,
            form: OtpLoginForm(vm: vm),
          );
        },
      ),
    );
  }
}
