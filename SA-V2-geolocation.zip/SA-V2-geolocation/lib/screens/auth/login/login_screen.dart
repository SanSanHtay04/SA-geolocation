import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:provider/provider.dart';
import 'package:sales/base/error.dart';
import 'package:sales/models/models.dart';
import 'package:sales/screens/auth/widgets/login_scaffold.dart';
import 'package:sales/screens/shared/shared_screen.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/app_snack_bar.dart';
import 'package:sales/widgets/selected_group/single_selected_group.dart';
import 'package:sales/widgets/text_form_field/clearable_text_form_field.dart';
import 'package:sales/widgets/text_form_field/password_text_form_field.dart';
import '../../../providers/auth_provider.dart';
import '../../change_password/presentation/change_password_screen.dart';
import 'viewmodel/login_view_model.dart';


class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  static const routeName = '/login';

  void goToSharedScreenIfLoggedIn(BuildContext context) {
    SchedulerBinding.instance.addPostFrameCallback((_) {
      Navigator.pushNamedAndRemoveUntil(
          context, SharedScreen.routeName, (route) => false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<LoginViewModel>(
      create: (context) => LoginViewModel(context.read())..loadData(),
      child: Consumer<LoginViewModel>(
        builder: (context, vm, unsubscribedChild) {
          /// Handle CallBack for LoginSubmit State
          Future.delayed(Duration.zero, () {

              vm.submitState.maybeWhen(
              failed: (message, error) => context.showErrorDialog(
                error.errorMessage(context, message),
                onClosePressed: vm.resetSubmitState,
              ),
              success: (data) => goToSharedScreenIfLoggedIn(context),
              orElse: () {},
            );

            WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
              // TODO: rather than checking the current user is already authenticated in UI, better to handle it before routing
              bool isLoggedIn = context.read<AuthProvider>().isAuthenticated;
              if (isLoggedIn) goToSharedScreenIfLoggedIn(context);
            });

       
          });

          return LoginScaffold
          (isLoading: vm.isLoading,
           form: LoginForm(vm: vm),);
        },
      ),
    );
  }
}

class LoginForm extends StatefulWidget {
  const LoginForm({super.key, required this.vm});

  final LoginViewModel vm;

  @override
  State<LoginForm> createState() => _LoginFormState();
}

class _LoginFormState extends State<LoginForm> {
  final GlobalKey<FormState> _formKey = GlobalKey();
  AutovalidateMode _mode = AutovalidateMode.disabled;

  _loginOffline() {
    SchedulerBinding.instance.addPostFrameCallback((_) {
      Navigator.pushNamedAndRemoveUntil(
          context, SharedScreen.routeName, (route) => false);
    });
  }

  _onTapChangePassword() {
    SchedulerBinding.instance.addPostFrameCallback((_) {
      Navigator.pushNamed(context, ChangePasswordScreen.routeName);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      autovalidateMode: _mode,
      child: Column(
        children: [
          SingleSelectedGroup<LoginType>(
            items: LoginType.values,
            labelParser: (item) => item.name,
            selectedItem: widget.vm.formState.loginType,
            onSelectChanged: widget.vm.selectLoginType,
          ),
          kSpaceVertical10,
          ClearableTextFormField(
            initialValue: widget.vm.formState.userName,
            required: true,
            labelText: 'Username',
            prefixIcon: const Icon(Icons.account_box),
            onChanged: widget.vm.updateUserName,
          ),
          kSpaceVertical8,
          if (widget.vm.formState.loginType == LoginType.ONLINE) ...[
            PasswordTextFormField(
              initialValue: widget.vm.formState.password,
              required: true,
              labelText: 'Password',
              prefixIcon: const Icon(Icons.lock_outline),
              onChanged: widget.vm.updatePassword,
            ),
            kSpaceVertical20,
            Row(children: [
              Expanded(
                child: ElevatedButton(
                  child: const Text('LOGIN'),
                  onPressed: () {
                    FocusScope.of(context).unfocus();
                    if (_formKey.currentState?.validate() ?? false) {
                      widget.vm.login();
                    } else {
                      setState(() {
                        _mode = AutovalidateMode.onUserInteraction;
                      });
                    }
                  },
                ),
              ),
              IconButton(icon: Icon(Icons.fingerprint), onPressed: null),
            ]),
            kSpaceVertical2,
            Row(children: [
              Expanded(
                child: OutlinedButton(
                  child: Text('CHANGE PASSWORD'),
                  onPressed: _onTapChangePassword,
                ),
              ),
            ]),
          ],
          if (widget.vm.formState.loginType == LoginType.OFFLINE) ...[
            kSpaceVertical20,
            Row(children: [
              Expanded(
                child: ElevatedButton(
                  child: Text("LOGIN"),
                  onPressed: _loginOffline,
                ),
              ),
            ]),
            kSpaceVertical4,
            Text(
              '1. Before using OFFLINE mode, please go to the Data Categories section to sync all items if not yet.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12, color: Colors.red),
            ),
            kSpaceVertical4,
            Text(
              '2. Admin Units & NRCs section has huge data & it will be taken a long time to complete, please be patient on it.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12, color: Colors.red),
            ),
          ]
        ],
      ),
    );
  }
}
