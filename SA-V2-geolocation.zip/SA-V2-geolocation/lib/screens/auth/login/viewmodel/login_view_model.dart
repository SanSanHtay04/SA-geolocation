import 'package:android_id/android_id.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:sales/models/models.dart';
import '../../data/auth_repository.dart';

import 'login_form_state.dart';
import 'login_submit_state.dart';

class LoginViewModel extends ChangeNotifier {
  AuthRepository repo;

  LoginViewModel(this.repo) {
    if (kDebugMode) {
      setFormState(
          formState.copyWith(userName: 'myattheingi', password: 'welcome'));
    }
  }

  LoginFormState formState = const LoginFormState();
  LoginSubmitState submitState = const LoginSubmitStateIdle();

  bool get isLoading => (submitState is LoginSubmitStateLoading);

  //bool get enableButton => (!formState.userName.isNullOrEmpty);

  setFormState(LoginFormState value) {
    formState = value;
    notifyListeners();
  }

  updateUserName(String name) {
    setFormState(formState.copyWith(userName: name));
  }

  updatePassword(String pwd) {
    setFormState(formState.copyWith(password: pwd));
  }

  selectLoginType(LoginType type) {
    setFormState(formState.copyWith(loginType: type));
  }

  setSubmitState(LoginSubmitState value) {
    submitState = value;
    notifyListeners();
  }

  resetSubmitState() {
    setSubmitState(const LoginSubmitStateIdle());
  }

  loadData() async {
    String androidId;
    try {
      androidId = await AndroidId().getId() ?? 'Unknown ID';
    } on PlatformException {
      androidId = 'Unknown ID';
    }
    setFormState(formState.copyWith(androidId: androidId));
  }

  login() async {
    setSubmitState(const LoginSubmitStateLoading());
    final res = await repo.login(
      name: formState.userName,
      password: formState.password,
      androidId: formState.androidId,
    );

    final newState = res.when(
        success: (data) => LoginSubmitStateSuccess(data),
        failed: (msg, error) => LoginSubmitStateFailed(msg, error: error));
    setSubmitState(newState);
  }
}
