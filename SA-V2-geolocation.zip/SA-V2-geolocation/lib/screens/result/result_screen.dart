import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/providers/application_provider.dart';
import 'package:sales/providers/attached_product_provider.dart';
import 'package:sales/providers/payment_schedule_provider.dart';
import 'package:sales/screens/result/asset/edit_asset_screen.dart';
import 'package:sales/screens/result/attached_product_detail/attached_product_details_partial.dart';
import 'package:sales/screens/result/contract/edit_contract_screen.dart';
import 'package:sales/screens/result/document_upload/document_uploads_partial.dart';
import 'package:sales/screens/result/partial_partials/application_partial.dart';
import 'package:sales/screens/result/partial_partials/asset_partial.dart';
import 'package:sales/screens/result/partial_partials/contract_partial.dart';
import 'package:sales/screens/result/partial_partials/delivery_partial.dart';
import 'package:sales/screens/result/partial_partials/e_signature_partial.dart';
import 'package:sales/screens/result/partial_partials/initial_payment_partial.dart';
import 'package:sales/screens/result/partial_partials/other_partial.dart';
import 'package:sales/screens/result/partial_partials/payment_merchant_partial.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/confirmation_modal_bottom_widget.dart';
import 'package:sales/widgets/copyright_notice.dart';
import 'package:sales/widgets/deprecated/alert_modal_bottom_widget.dart';
import 'package:sales/widgets/waiting_modal_bottom_widget.dart';

import '../origination/presentation/partial_widgets/partial_widgets.dart';

class ResultScreen extends StatefulWidget {
  static const routeName = '/create_contract';
  final int? prospectId;
  final int? applicationId;
  final int? contractId;

  ResultScreen({
    Key? key,
    required this.prospectId,
    required this.applicationId,
    required this.contractId,
  });

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  Map<String, dynamic>? _application;
  List<Map<String, dynamic>> _attachedProducts = [];
  List<Map<String, dynamic>> _contractAttachedProducts = [];

  TabBar get _tabBar => TabBar(
        labelColor: Colors.teal,
        unselectedLabelColor: Colors.grey,
        tabs: [
          Tab(
            text: "APP",
          ),
          Tab(
            text: "CON",
          ),
          Tab(
            text: "PMT",
          ),
          Tab(
            text: "SIGN",
          ),
          Tab(
            text: "DOC",
          ),
          Tab(
            text: "ACT",
          ),
        ],
      );

  Future<void> _getApplication(int? prospectId, int? applicationId) async {
    showWaitingModal(
        context: context,
        message: "Application information is loading...",
        onWaiting: () async {
          try {
            await Provider.of<ApplicationProvider>(context, listen: false)
                .getApplication(prospectId, applicationId)
                .then((value) {
              _application =
                  Provider.of<ApplicationProvider>(context, listen: false).item;
            });
            if (_application != null) {
              await _getAttachedProducts(_application!['packageId']);
              if (_application!['contractId'] != null) {
                await _getAttachedProductsByContract();
              }
            }
          } catch (error) {
            print(error.toString());
          }
          ;
        });
  }

  Future<void> _getAttachedProducts(int? packageId) async {
    try {
      await Provider.of<AttachedProductProvider>(context, listen: false)
          .getRecords(packageId)
          .then((value) {
        setState(() {
          _attachedProducts =
              Provider.of<AttachedProductProvider>(context, listen: false)
                  .items;
        });
      });
    } catch (error) {
      print(error.toString());
    }
  }

  Future<void> _getAttachedProductsByContract() async {
    try {
      await Provider.of<AttachedProductProvider>(context, listen: false)
          .getAttachedProductsByContract(_application!['contractId'] ?? 0)
          .then((value) {
        setState(() {
          _contractAttachedProducts =
              Provider.of<AttachedProductProvider>(context, listen: false)
                  .items;
        });
      });
    } catch (error) {
      print(error.toString());
    }
  }

  void _editContract() {
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => EditContractScreen(
                customerId: _application?['customerId'],
                contractId: _application?['contractId'],
                application: _application,
              )),
    ).then((value) {
      _getApplication(widget.prospectId, widget.applicationId);
    });
  }

  void _editAsset() {
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => EditAssetScreen(
                contractId: widget.contractId,
                assetId: _application?['assetId'],
                application: _application,
              )),
    ).then((value) async {
      _getApplication(widget.prospectId, widget.applicationId);
    });
  }

  Map<String, dynamic>? _recordResult;

  void _confirmPaidInitialPayment() {
    String? _message = 'Something went wrong.';
    showConfirmation(
        context: context,
        message:
            "Are you sure you want to confirm paid initial payment of contract '${_application!['contractNo']}'?",
        onYes: () async {
          await showWaitingModal(
              context: context,
              message: "Initial Payment is confirming...",
              onWaiting: () async {
                try {
                  Map<String, dynamic> _firstPaidParams = {
                    'contractId': _application!['contractId'],
                    'simulationId': _application!['simulationId'],
                    'firstPayment': _application!['firstPayment'],
                    'actualFirstPayment': _application!['actualFirstPayment'],
                    'paymentAtEnd': _application!['paymentAtEnd'],
                    'depositAmount': _application!['depositAmount'],
                    'followingPayment': _application!['followingPayment'],
                    'adminFee': _application!['adminFee'],
                    'paymentNo': 1,
                    'earlyPrepaymentAmount':
                        _application!['earlyPrepaymentAmount'],
                    'zeroCostTotalInsCost':
                        _application!['zeroCostTotalInsCost'],
                    'zeroCostTotalMaintCost':
                        _application!['zeroCostTotalMaintCost']
                  };

                  await Provider.of<PaymentScheduleProvider>(context,
                          listen: false)
                      .confirmPaidInitialPayment(_application!['simulationId'],
                          _application!['contractId'], _firstPaidParams)
                      .then((value) {
                    setState(() {
                      _recordResult = Provider.of<PaymentScheduleProvider>(
                              context,
                              listen: false)
                          .item;
                      _message = Provider.of<PaymentScheduleProvider>(context,
                              listen: false)
                          .responseMessage;
                    });
                  });
                } catch (error) {
                  setState(() {
                    _message = error.toString();
                  });
                }
              });
          await showAlertModal(
              context: context,
              message: _message,
              onDismiss: () async {
                await _getApplication(widget.prospectId, widget.applicationId);
              });
        });
  }

  void _reloadApplication() {
    _getApplication(widget.prospectId, widget.applicationId);
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      _getApplication(widget.prospectId, widget.applicationId);
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 6,
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          title: Text(
            'RESULT',
            style: TextStyle(color: Colors.white),
          ),
          iconTheme: IconThemeData(color: Colors.white),
          bottom: PreferredSize(
            preferredSize: _tabBar.preferredSize,
            child: ColoredBox(
              color: Colors.white,
              child: _tabBar,
            ),
          ),
          actions: [
            IconButton(
              icon: Icon(
                Icons.refresh_rounded,
                color: Colors.white,
              ),
              onPressed: () {
                _getApplication(widget.prospectId, widget.applicationId);
              },
            )
          ],
        ),
        body: Padding(
          padding: EdgeInsets.all(8),
          child: Column(
            children: [
              Expanded(
                child: TabBarView(
                    physics: const NeverScrollableScrollPhysics(),
                    children: [
                      Container(
                        child: SingleChildScrollView(
                          child: Column(
                            children: [
                              _application == null
                                  ? SizedBox()
                                  : ApplicationPartial(
                                      application: _application!),
                              SizedBox(
                                height: 5,
                              ),
                              _application == null
                                  ? SizedBox()
                                  : SimProspectWidget(
                                      prospect: _application,
                                      editProspect: null,
                                      connectionType: "online",
                                    ),
                              SizedBox(
                                height: 5,
                              ),
                              _application == null
                                  ? SizedBox()
                                  : SimProductWidget(
                                      prospect: _application,
                                      attachedProducts: _attachedProducts,
                                      chooseProduct: null),
                              SizedBox(
                                height: 5,
                              ),
                              _application == null ||
                                      _application!['packageId'] == null ||
                                      _application!['packageId'] == ""
                                  ? SizedBox()
                                  : SimSimulationWidget(
                                      prospect: _application,
                                      chooseSimulation: null),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        child: SingleChildScrollView(
                          child: _application != null &&
                                  _application!['appAccepted'] == 0
                              ? Text(
                                  "This application was rejected! You are unable to proceed with contract creation.",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: Colors.red,
                                  ),
                                )
                              : Column(
                                  children: [
                                    _application == null
                                        ? SizedBox()
                                        : ContractPartial(
                                            application: _application,
                                            createContract: _editContract,
                                          ),
                                    SizedBox(
                                      height: 5,
                                    ),
                                    _application == null ||
                                            _application!['assetId'] == null
                                        ? SizedBox()
                                        : AssetPartial(
                                            application: _application,
                                            editAsset: _editAsset,
                                          ),
                                    SizedBox(
                                      height: 5,
                                    ),
                                    _application == null ||
                                            _application!['attachedProducts'] ==
                                                null ||
                                            _application!['attachedProducts'] ==
                                                []
                                        ? SizedBox()
                                        : AttachedProductDetailsPartial(
                                            getAttachedProductsByContract:
                                                _getAttachedProductsByContract,
                                            attachedProducts:
                                                _contractAttachedProducts,
                                          ),
                                    _application == null ||
                                            _application!['attachedProducts'] ==
                                                null ||
                                            _application!['attachedProducts'] ==
                                                []
                                        ? SizedBox()
                                        : SizedBox(
                                            height: 5,
                                          ),
                                  ],
                                ),
                        ),
                      ),
                      Container(
                        child: SingleChildScrollView(
                          child: Column(
                            children: [
                              _application == null ||
                                      _application!['contractId'] == null
                                  ? SizedBox()
                                  : InitialPaymentPartial(
                                      application: _application,
                                      confirmPaidInitialPayment:
                                          _confirmPaidInitialPayment,
                                    ),
                              SizedBox(
                                height: 5,
                              ),
                              _application != null &&
                                      _application!['contractId'] != null &&
                                      _application!['contractStatusId'] == 9
                                  ? PaymentMerchantPartial(
                                      application: _application,
                                      confirmPaidToMerchant: () {},
                                    )
                                  : SizedBox(),
                              SizedBox(
                                height: 5,
                              ),
                              _application == null ||
                                      _application!['contractId'] == null
                                  ? SizedBox()
                                  : DeliveryPartial(
                                      application: _application,
                                      reloadApplication: _reloadApplication,
                                    ),
                              SizedBox(
                                height: 5,
                              ),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        child: _application == null ||
                                _application!['contractId'] == null
                            ? SizedBox()
                            // : ESignatureWidget(application: _application, reloadApplication: _reloadApplication, setSignatureTypeSelected: _setSignatureTypeSelected, signatureTypeSelected: _signatureTypeSelected, setContactDetIdSelected: _setContactDetIdSelected, contactDetIdSelected: _contactDetIdSelected,),
                            : ESignaturePartial(
                                application: _application,
                                reloadApplication: _reloadApplication,
                              ),
                      ),
                      Container(
                        child: _application == null ||
                                _application!['contractId'] == null
                            ? SizedBox()
                            : DocumentUploadsParital(application: _application),
                        // : DocsPartial(application: _application)
                      ),
                      Container(
                        child: _application == null ||
                                _application!['contractId'] == null
                            ? SizedBox()
                            : OtherPartial(
                                application: _application,
                              ),
                      ),
                    ]),
              ),
              kSpaceVertical8,
              CopyrightNotice(),
            ],
          ),
        ),
      ),
    );
  }
}
