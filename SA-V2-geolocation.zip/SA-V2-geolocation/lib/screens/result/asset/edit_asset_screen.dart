import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:provider/provider.dart';
import 'package:sales/providers/asset_provider.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/widgets/confirmation_modal_bottom_widget.dart';
import 'package:sales/widgets/copyright_notice.dart';
import 'package:sales/widgets/deprecated/alert_modal_bottom_widget.dart';
import 'package:sales/widgets/deprecated/button_widget.dart';
import 'package:sales/widgets/deprecated/date_picker_widget.dart';
import 'package:sales/widgets/deprecated/text_form_input.dart';
import 'package:sales/widgets/item_info_widget.dart';
import 'package:sales/widgets/waiting_modal_bottom_widget.dart';

class EditAssetScreen extends StatefulWidget {
  static const routeName = '/edit-contract';
  final int? contractId;
  final int? assetId;
  final Map<String, dynamic>? application;

  EditAssetScreen({
    required this.contractId,
    required this.assetId,
    required this.application,
  });

  @override
  State<EditAssetScreen> createState() => _EditAssetScreenState();
}

class _EditAssetScreenState extends State<EditAssetScreen> {
  bool _isLoading = false;
  Map<String, dynamic>? _recordAsset;
  final GlobalKey<FormState> _formKey = GlobalKey();
  late Map<String, dynamic> _formData;
  Map<String, dynamic> _formDataDefault = {
    'followingPaymentDate': null,
    'adjustmentDays': '',
    'adjustmentDiscountOrFee': '',
    'contractRemark': '',
  };

  final List<Map<String, dynamic>> _productColors = [
    {'id': 'UNKNOWN', 'title': 'UNKNOWN'},
    {'id': 'BEIGE', 'title': 'BEIGE'},
    {'id': 'BLACK', 'title': 'BLACK'},
    {'id': 'BLUE', 'title': 'BLUE'},
    {'id': 'BROWN', 'title': 'BROWN'},
    {'id': 'GOLD', 'title': 'GOLD'},
    {'id': 'GREEN', 'title': 'GREEN'},
    {'id': 'GREY', 'title': 'GREY'},
    {'id': 'ORANGE', 'title': 'ORANGE'},
    {'id': 'PINK', 'title': 'PINK'},
    {'id': 'PURPLE', 'title': 'PURPLE'},
    {'id': 'RED', 'title': 'RED'},
    {'id': 'SILVER', 'title': 'SILVER'},
    {'id': 'WHITE', 'title': 'WHITE'},
    {'id': 'YELLOW', 'title': 'YELLOW'}
  ];

  final List<Map<String, dynamic>> _obStatuses = [
    {'id': 'pending', 'title': 'Merchant'},
    {'id': 'backoffice', 'title': 'R2O'},
    {'id': 'collection', 'title': 'Collection'},
    {'id': 'customer', 'title': 'Customer'},
    {'id': 'pos-close', 'title': 'POS Close'},
    {'id': 'archive', 'title': 'Archive'},
    {'id': 'archive-l', 'title': 'Archive L'},
    {'id': 'unavailable', 'title': 'Unvailable'},
  ];

  // productColor //
  String? _productColorIdSelected;
  void _setProductColor(String id, Map<String, dynamic> item) {
    setState(() {
      _productColorIdSelected = id;
      _formData['productColor'] = id;
    });
  }

  // productColorDetail //
  final _productColorDetailFocusNode = FocusNode();
  final _productColorDetailController = TextEditingController();
  void _setProductDetailColor(String? value) {
    setState(() {
      _formData['productColorDetail'] = value.toString().trim();
    });
  }

  // engineNo //
  final _engineNoFocusNode = FocusNode();
  final _engineNoController = TextEditingController();
  void _setEngineNo(String? value) {
    setState(() {
      _formData['engineNo'] = value.toString().trim();
    });
  }

  // chassisNo //
  final _chassisNoFocusNode = FocusNode();
  final _chassisNoController = TextEditingController();
  void _setChassisNo(String? value) {
    setState(() {
      _formData['chassisNo'] = value.toString().trim();
    });
  }

  // plateNo //
  final _plateNoFocusNode = FocusNode();
  final _plateNoController = TextEditingController();
  void _setPlateNo(String? value) {
    setState(() {
      _formData['plateNo'] = value.toString().trim();
    });
  }

  // gpsImeiNumber //
  final _gpsImeiNoFocusNode = FocusNode();
  final _gpsImeiNoController = TextEditingController();
  void _setGpsImeiNo(String? value) {
    setState(() {
      _formData['gpsImeiNo'] = value.toString().trim();
    });
  }

  // gpsPhoneNumber //
  final _gpsPhoneNoFocusNode = FocusNode();
  final _gpsPhoneNoController = TextEditingController();
  void _setGpsPhoneNo(String? value) {
    setState(() {
      _formData['gpsPhoneNo'] = value.toString().trim();
    });
  }

  // serialNo //
  final _serialNoFocusNode = FocusNode();
  final _serialNoController = TextEditingController();
  void _setSerialNo(String? value) {
    setState(() {
      _formData['serialNo'] = value.toString().trim();
    });
  }

  // imeiNo //
  final _imeiNoFocusNode = FocusNode();
  final _imeiNoController = TextEditingController();
  void _setImeiNo(String? value) {
    setState(() {
      _formData['imeiNo'] = value.toString().trim();
    });
  }

  // imeiNo2 //
  final _imeiNo2FocusNode = FocusNode();
  final _imeiNo2Controller = TextEditingController();
  void _setImeiNo2(String? value) {
    setState(() {
      _formData['imeiNo2'] = value.toString().trim();
    });
  }

  // assetStorageAddress //
  final _assetStorageAddressFocusNode = FocusNode();
  final _assetStorageAddressController = TextEditingController();
  void _setAssetStorageAddress(String? value) {
    setState(() {
      _formData['assetStorageAddress'] = value.toString().trim();
    });
  }

  // ownerBookStatus //
  String? _obStatusIdSelected;
  void _setObStatus(String id, Map<String, dynamic> item) {
    setState(() {
      _obStatusIdSelected = id;
      _formData['ownerBookStatus'] = id;
    });
  }

  // ownerBookExpiryDate //
  DateTime? _dtOwnerBookExpiryDateSelected;
  final _ownerBookExpiryDateFocusNode = FocusNode();
  final _ownerBookExpiryDateController = TextEditingController();
  void _setOwnerBookExpiryDate(String value) {
    setState(() {
      _formData['ownerBookExpiryDate'] = value;
      _dtOwnerBookExpiryDateSelected = DateFormat('yyyy-MM-dd').parse(value);
    });
  }

  _clearAllFields() {
    _initData();
  }

  _updateAsset() {
    if (!_formKey.currentState!.validate()) {
      // Invalid!
      return;
    }
    _formKey.currentState!.save();
    String? _message = 'Something went wrong.';
    String? _messageCode = 'SUCCESS';
    showConfirmation(
        context: context,
        message: "Are you sure you want to update asset info of contract '${widget.application!['contractNo']}'?",
        onYes: () async {
          await showWaitingModal(
              context: context,
              message: "Asset info is updating...",
              onWaiting: () async {
                try {
                  FocusScope.of(context).requestFocus(new FocusNode());

                  Map<String, dynamic> _recAsset = Map<String, dynamic>.from(_formData);
                  _recAsset['chassisNoDupLocked'] = 0;
                  _recAsset['engineNoDupLocked'] = 0;
                  if (widget.application!['productCategoryId'] == 1 || widget.application!['productCategoryId'] == 2 || widget.application!['productCategoryId'] == 17 || widget.application!['productCategoryId'] == 68) {
                    _recAsset['engineNo'] = _formData['engineNo'];
                    _recAsset['chassisNo'] = _formData['chassisNo'];
                    _recAsset['plateNo'] = _formData['plateNo'];
                    _recAsset['serialNo'] = null;
                    _recAsset['imeiNo'] = null;
                    _recAsset['imeiNo2'] = null;
                    _recAsset['ownerBookStatus'] = _formData['ownerBookStatus'];
                    if (_obStatusIdSelected == 'backoffice' || _obStatusIdSelected == 'collection' || _obStatusIdSelected == 'customer') {
                      _recAsset['ownerBookExpiryDate'] = _formData['ownerBookExpiryDate'];
                    } else {
                      _recAsset['ownerBookExpiryDate'] = null;
                    }
                  } else {
                    _recAsset['engineNo'] = null;
                    _recAsset['chassisNo'] = null;
                    _recAsset['plateNo'] = null;
                    _recAsset['serialNo'] = _formData['serialNo'];
                    _recAsset['imeiNo'] = _formData['imeiNo'];
                    _recAsset['imeiNo2'] = _formData['imeiNo2'];
                    _recAsset['ownerBookStatus'] = null;
                    _recAsset['ownerBookExpiryDate'] = null;
                  }
                  await Provider.of<AssetProvider>(context, listen: false).updateAsset(widget.contractId, widget.assetId, _recAsset).then((value) {
                    setState(() {
                      _messageCode = Provider.of<AssetProvider>(context, listen: false).responseCode;
                      _message = Provider.of<AssetProvider>(context, listen: false).responseMessage;
                    });
                  });
                } catch (error) {
                  setState(() {
                    _message = error.toString();
                  });
                }
              });
          await showAlertModal(
              context: context,
              message: _message,
              onDismiss: () {
                if (_messageCode == 'SUCCESS') {
                  Navigator.pop(context);
                }
              });
        });
  }

  void _initData() {
    setState(() {
      _productColorIdSelected = widget.application!['productColor'] ?? null;
      _productColorDetailController.text = widget.application!['productColorDetail'] ?? '';
      _engineNoController.text = widget.application!['engineNo'] ?? '';
      _chassisNoController.text = widget.application!['chassisNo'] ?? '';
      _plateNoController.text = widget.application!['plateNo'] ?? '';
      _serialNoController.text = widget.application!['serialNo'] ?? '';
      _imeiNoController.text = widget.application!['imeiNo'] ?? '';
      _imeiNo2Controller.text = widget.application!['imeiNo2'] ?? '';
      _gpsImeiNoController.text = widget.application!['gpsImeiNo'] ?? '';
      _gpsPhoneNoController.text = widget.application!['gpsPhoneNo'] ?? '';
      _obStatusIdSelected = widget.application!['ownerBookStatus'] ?? null;
      _assetStorageAddressController.text = widget.application!['assetStorageAddress'] ?? null;

      if (widget.application!['ownerBookExpiryDate'] != null) {
        _dtOwnerBookExpiryDateSelected = DateFormat('yyyy-MM-dd').parse(widget.application!['ownerBookExpiryDate']);
        _ownerBookExpiryDateController.text = DateFormat('dd/MM/yyyy').format(DateTime.parse(widget.application!['ownerBookExpiryDate']));
      } else {
        _dtOwnerBookExpiryDateSelected = DateTime.now();
        _ownerBookExpiryDateController.text = '';
      }

      _formDataDefault = Map<String, dynamic>.from({
        'productColor': widget.application!['productColor'],
        'productColorDetail': widget.application!['productColorDetail'],
        'engineNo': widget.application!['engineNo'],
        'chassisNo': widget.application!['chassisNo'],
        'plateNo': widget.application!['plateNo'],
        'serialNo': widget.application!['serialNo'],
        'imeiNo': widget.application!['imeiNo'],
        'imeiNo2': widget.application!['imeiNo2'],
        'gpsImeiNo': widget.application!['gpsImeiNo'],
        'gpsPhoneNo': widget.application!['gpsPhoneNo'],
        'ownerBookStatus': widget.application!['ownerBookStatus'],
        'ownerBookExpiryDate': widget.application!['ownerBookExpiryDate'],
        'assetStorageAddress': widget.application!['assetStorageAddress'],
      });
      _formData = Map<String, dynamic>.from(_formDataDefault);
    });
  }

  @override
  void initState() {
    _initData();
    super.initState();
  }

  @override
  void dispose() {
    _productColorDetailFocusNode.dispose();
    _engineNoFocusNode.dispose();
    _imeiNoFocusNode.dispose();
    _imeiNo2FocusNode.dispose();
    _chassisNoFocusNode.dispose();
    _plateNoFocusNode.dispose();
    _assetStorageAddressFocusNode.dispose();
    _ownerBookExpiryDateFocusNode.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Widget _buildProductColorDropdownButton() {
      return DropdownButtonFormField<dynamic>(
        dropdownColor: Colors.white,
        decoration: InputDecoration(
          contentPadding: EdgeInsets.fromLTRB(15, 13, 12, 13),
          labelText: "Product Color",
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
          ),
        ),
        items: _productColors.map((item) {
          return DropdownMenuItem<String>(
            value: item["id"],
            child: Text(item["title"]),
          );
        }).toList(),
        value: _productColorIdSelected ?? null,
        onChanged: (newValue) {
          setState(() {
            _productColorIdSelected = newValue;
            _productColors.forEach((item) {
              if (item["id"] == newValue) {
                _formData["productColor"] = item["id"];
              }
            });
          });
        },
        validator: (value) {
          if (_productColorIdSelected == null) {
            return "Product Color is required";
          }
          return null;
        },
      );
    }

    Widget _buildObStatusDropdownButton() {
      return DropdownButtonFormField<dynamic>(
        dropdownColor: Colors.white,
        decoration: InputDecoration(
          contentPadding: EdgeInsets.fromLTRB(15, 13, 12, 13),
          labelText: "Owner Book Status",
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
          ),
        ),
        items: _obStatuses.map((item) {
          return DropdownMenuItem<String>(
            value: item["id"],
            child: Text(item["title"]),
          );
        }).toList(),
        value: _obStatusIdSelected ?? null,
        onChanged: (newValue) {
          setState(() {
            _obStatusIdSelected = newValue;
            _obStatuses.forEach((item) {
              if (item["id"] == newValue) {
                _formData["ownerBookStatus"] = item["id"];
              }
            });
          });
        },
        validator: (value) {
          if (_obStatusIdSelected == null) {
            return "Owner Book Status is required";
          }
          return null;
        },
      );
    }

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(
          'UPDATE ASSET',
          style: TextStyle(color: Colors.white),
        ),
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: ModalProgressHUD(
        inAsyncCall: _isLoading,
        opacity: 0.5,
        progressIndicator: CircularProgressIndicator(
          valueColor: new AlwaysStoppedAnimation<Color>(
            context.getColorScheme().primary,
          ),
        ),
        child: Padding(
          padding: EdgeInsets.all(10),
          child: Column(children: [
            Expanded(
              child: Container(
                child: Column(
                  children: [
                    Expanded(
                      child: Form(
                        key: _formKey,
                        autovalidateMode: AutovalidateMode.always,
                        child: SingleChildScrollView(
                          child: Column(
                            children: [
                              SizedBox(
                                height: 5,
                              ),

                              // productName //
                              ItemInfoWidget(
                                title: 'Product Name',
                                value: widget.application!['productName'] ?? '-/-',
                              ),
                              Divider(),

                              SizedBox(
                                height: 5,
                              ),

                              // productColor //
                              _buildProductColorDropdownButton(),
                              SizedBox(
                                height: 10,
                              ),

                              // productColorDetail //
                              TextFormInput(
                                controller: _productColorDetailController,
                                focusNode: _productColorDetailFocusNode,
                                nextFocusNode: _engineNoFocusNode,
                                label: "Product Color Detail",
                                textInputAction: TextInputAction.next,
                                onSaved: _setProductDetailColor,
                                maxLines: 1,
                              ),
                              SizedBox(
                                height: 10,
                              ),

                              widget.application!['productCategoryId'] == 1 || widget.application!['productCategoryId'] == 2 || widget.application!['productCategoryId'] == 17 || widget.application!['productCategoryId'] == 68
                                  ? Column(
                                      children: [
                                        // engineNo //
                                        TextFormInput(
                                          controller: _engineNoController,
                                          focusNode: _engineNoFocusNode,
                                          nextFocusNode: _chassisNoFocusNode,
                                          label: "Engine Number (6 to 23 digits)",
                                          textInputAction: TextInputAction.next,
                                          isRequired: true,
                                          minimumLength: 6,
                                          maximumLength: 23,
                                          requiredMessage: "Engine Number is required.",
                                          minimumLengthMessage: "You have not met this field's minimum length.",
                                          maximumLengthMessage: "The maximum length is 23 characters.",
                                          onSaved: _setEngineNo,
                                          maxLines: 1,
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),

                                        // chassisNo //
                                        TextFormInput(
                                          controller: _chassisNoController,
                                          focusNode: _chassisNoFocusNode,
                                          label: "Chassis Number (6 to 23 digits)",
                                          textInputAction: TextInputAction.next,
                                          isRequired: true,
                                          minimumLength: 6,
                                          maximumLength: 23,
                                          requiredMessage: "Chassis Number is required.",
                                          minimumLengthMessage: "You have not met this field's minimum length.",
                                          maximumLengthMessage: "The maximum length is 23 characters.",
                                          onSaved: _setChassisNo,
                                          maxLines: 1,
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),

                                        // plateNo //
                                        TextFormInput(
                                          controller: _plateNoController,
                                          focusNode: _plateNoFocusNode,
                                          nextFocusNode: _assetStorageAddressFocusNode,
                                          label: "Plate Number",
                                          textInputAction: TextInputAction.next,
                                          onSaved: _setPlateNo,
                                          maxLines: 1,
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),

                                        widget.application!['productCategoryId'] == 2 || widget.application!['productCategoryId'] == 17 || widget.application!['productCategoryId'] == 68 || (widget.application!['productCategoryId'] == 1 && widget.application!['isGpsEquipped'] == 1)
                                            ? Column(
                                                children: [
                                                  // gpsImeiNo //
                                                  TextFormInput(
                                                    controller: _gpsImeiNoController,
                                                    focusNode: _gpsImeiNoFocusNode,
                                                    nextFocusNode: _gpsPhoneNoFocusNode,
                                                    label: "GPS Imei Number",
                                                    textInputAction: TextInputAction.next,
                                                    onSaved: _setGpsImeiNo,
                                                    maxLines: 1,
                                                  ),
                                                  SizedBox(
                                                    height: 10,
                                                  ),

                                                  // gpsPhoneNo //
                                                  TextFormInput(
                                                    controller: _gpsPhoneNoController,
                                                    focusNode: _gpsPhoneNoFocusNode,
                                                    label: "GPS Phone Number",
                                                    textInputAction: TextInputAction.next,
                                                    keyboardType: TextInputType.number,
                                                    onSaved: _setGpsPhoneNo,
                                                    maxLines: 1,
                                                  ),
                                                  SizedBox(
                                                    height: 10,
                                                  ),
                                                ],
                                              )
                                            : SizedBox(),

                                        // ownerBookStatus //
                                        _buildObStatusDropdownButton(),
                                        SizedBox(
                                          height: 10,
                                        ),

                                        // ownerBookExpiryDate //
                                        _obStatusIdSelected == 'backoffice' || _obStatusIdSelected == 'collection' || _obStatusIdSelected == 'customer'
                                            ? DatePickerWidget(
                                                controller: _ownerBookExpiryDateController,
                                                labelText: "OB Expiry Date",
                                                isRequired: true,
                                                requiredMessage: "OB Expiry Date is required.",
                                                initialDateTime: _dtOwnerBookExpiryDateSelected,
                                                setFormDataValue: _setOwnerBookExpiryDate,
                                              )
                                            : SizedBox(),
                                        SizedBox(
                                          height: 10,
                                        ),
                                      ],
                                    )
                                  : Column(
                                      children: [
                                        // serialNo //
                                        TextFormInput(
                                          controller: _serialNoController,
                                          focusNode: _serialNoFocusNode,
                                          nextFocusNode: _imeiNoFocusNode,
                                          label: "Serial Number",
                                          textInputAction: TextInputAction.next,
                                          isRequired: true,
                                          requiredMessage: "Serial Number is required.",
                                          onSaved: _setSerialNo,
                                          maxLines: 1,
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),

                                        // imeiNo //
                                        TextFormInput(
                                          controller: _imeiNoController,
                                          focusNode: _imeiNoFocusNode,
                                          nextFocusNode: _imeiNo2FocusNode,
                                          label: "IMEI Number",
                                          textInputAction: TextInputAction.next,
                                          keyboardType: TextInputType.number,
                                          isRequired: widget.application!['productCategoryId'] == 18 ? true : false,
                                          requiredMessage: "IMEI Number is required.",
                                          onSaved: _setImeiNo,
                                          maxLines: 1,
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),

                                        // imeiNo2 //
                                        TextFormInput(
                                          controller: _imeiNo2Controller,
                                          focusNode: _imeiNo2FocusNode,
                                          nextFocusNode: _assetStorageAddressFocusNode,
                                          label: "IMEI Number2",
                                          textInputAction: TextInputAction.next,
                                          keyboardType: TextInputType.number,
                                          isRequired: widget.application!['productCategoryId'] == 18 ? true : false,
                                          requiredMessage: "IMEI Number2 is required.",
                                          onSaved: _setImeiNo2,
                                          maxLines: 1,
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                      ],
                                    ),

                              // assetStorageAddress //
                              TextFormInput(
                                controller: _assetStorageAddressController,
                                focusNode: _assetStorageAddressFocusNode,
                                label: "Parking Address",
                                textInputAction: TextInputAction.done,
                                onSaved: _setAssetStorageAddress,
                                maxLines: 2,
                              ),
                              SizedBox(
                                height: 10,
                              ),

                              Row(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
                                ButtonWidget(
                                  text: "CLEAR ALL",
                                  isWhiteBackgroundColor: true,
                                  onPressed: _clearAllFields,
                                ),
                                SizedBox(
                                  width: 5,
                                ),
                                ButtonWidget(
                                  text: "SAVE CHANGES",
                                  isWhiteBackgroundColor: false,
                                  onPressed: !_isLoading ? _updateAsset : null,
                                ),
                              ]),
                              SizedBox(
                                height: 10,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            kSpaceVertical8,
            CopyrightNotice(),
          ]),
        ),
      ),
    );
  }
}
