import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:sales/providers/attached_product_detail_provider.dart';
import 'package:sales/widgets/confirmation_modal_bottom_widget.dart';
import 'package:sales/widgets/deprecated/alert_modal_bottom_widget.dart';
import 'package:sales/widgets/deprecated/button_widget.dart';
import 'package:sales/widgets/deprecated/text_form_input.dart';
import 'package:sales/widgets/item_info_widget.dart';
import 'package:sales/widgets/waiting_modal_bottom_widget.dart';

class EditAttachedProductDetailScreen extends StatefulWidget {
  static const routeName = '/edit-attached-product-detail';
  final int? attachedProductId;
  final int? attachedProductDetailId;

  EditAttachedProductDetailScreen({
    required this.attachedProductId,
    required this.attachedProductDetailId,
  });

  @override
  State<EditAttachedProductDetailScreen> createState() => _EditAttachedProductDetailScreenState();
}

class _EditAttachedProductDetailScreenState extends State<EditAttachedProductDetailScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey();
  Map<String, dynamic>? _attProductItem;
  late Map<String, dynamic> _formData;
  Map<String, dynamic> _formDataDefault = {
    'productColorDetail': '',
    'serialNo': '',
    'imeiNo': '',
    'imeiNo2': '',
  };

  // productColor //
  final _productColorFocusNode = FocusNode();
  final _productColorController = TextEditingController();
  void _setProductColor(String? value) {
    setState(() {
      _formData['productColor'] = value.toString().trim();
    });
  }

  // productColorDetail //
  final _productColorDetailFocusNode = FocusNode();
  final _productColorDetailController = TextEditingController();
  void _setProductColorDetail(String? value) {
    setState(() {
      _formData['productColorDetail'] = value.toString().trim();
    });
  }

  // serialNo //
  final _serialNoFocusNode = FocusNode();
  final _serialNoController = TextEditingController();
  void _setSerialNo(String? value) {
    setState(() {
      _formData['serialNo'] = value.toString().trim();
    });
  }

  // imeiNo //
  final _imeiNoFocusNode = FocusNode();
  final _imeiNoController = TextEditingController();
  void _setImeiNo(String? value) {
    setState(() {
      _formData['imeiNo'] = value.toString().trim();
    });
  }

  // imeiNo2 //
  final _imeiNo2FocusNode = FocusNode();
  final _imeiNo2Controller = TextEditingController();
  void _setImeiNo2(String? value) {
    setState(() {
      _formData['imeiNo2'] = value.toString().trim();
    });
  }

  Future<void> _getAttachedProductDetail() async {
    await showWaitingModal(
        context: context,
        message: "Attached Product Detail is loading...",
        onWaiting: () async {
          try {
            await Provider.of<AttachedProductDetailProvider>(context, listen: false).getRecord(widget.attachedProductId, widget.attachedProductDetailId).then((value) {
              setState(() {
                _attProductItem = Provider.of<AttachedProductDetailProvider>(context, listen: false).item;
                _formDataDefault = {
                  'productColor': _attProductItem!['productColor'],
                  'productColorDetail': _attProductItem!['productColorDetail'],
                  'serialNo': _attProductItem!['serialNo'],
                  'imeiNo': _attProductItem!['imeiNo'],
                  'imeiNo2': _attProductItem!['imeiNo2'],
                };
                _formData = Map<String, dynamic>.from(_formDataDefault);
                _productColorDetailController.text = _attProductItem!['productColorDetail'] ?? '';
                _serialNoController.text = _attProductItem!['serialNo'] ?? '';
                _imeiNoController.text = _attProductItem!['imeiNo'] ?? '';
                _imeiNo2Controller.text = _attProductItem!['imeiNo2'] ?? '';
              });
            });
          } catch (error) {
            print(error.toString());
          }
        });
  }

  void _updateAttachedProductDetail() async {
    if (!_formKey.currentState!.validate()) {
      // Invalid!
      return;
    }
    _formKey.currentState!.save();
    String? _message = 'Something went wrong.';
    String? _messageCode = '';
    showConfirmation(
        context: context,
        message: "Are you sure you want to update the selected attached product?",
        onYes: () async {
          await showWaitingModal(
              context: context,
              message: "Attached product is updating...",
              onWaiting: () async {
                try {
                  FocusScope.of(context).requestFocus(new FocusNode());

                  Map<String, dynamic> _recAttachedProduct = Map<String, dynamic>.from(_formData);
                  await Provider.of<AttachedProductDetailProvider>(context, listen: false).editRecord(widget.attachedProductId, widget.attachedProductDetailId, _recAttachedProduct).then((value) {
                    setState(() {
                      _message = Provider.of<AttachedProductDetailProvider>(context, listen: false).responseMessage;
                      _messageCode = Provider.of<AttachedProductDetailProvider>(context, listen: false).responseCode;
                    });
                  });
                } catch (error) {
                  setState(() {
                    _message = error.toString();
                  });
                }
              });
          await showAlertModal(
              context: context,
              message: _message,
              onDismiss: () {
                if (_messageCode == 'SUCCESS') {
                  Navigator.pop(context);
                }
              });
        });
  }

  void _initData() async {
    await this._getAttachedProductDetail();
  }

  _clearAllFields() {
    setState(() {
      _formData = Map<String, dynamic>.from(_formDataDefault);
      _productColorController.text = _attProductItem!['productColor'] ?? '';
      _productColorDetailController.text = _attProductItem!['productColorDetail'] ?? '';
      _serialNoController.text = _attProductItem!['serialNo'] ?? '';
      _imeiNoController.text = _attProductItem!['imeiNo'] ?? '';
      _imeiNo2Controller.text = _attProductItem!['imeiNo2'] ?? '';
    });
  }

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      _initData();
    });
    super.initState();
  }

  @override
  void dispose() {
    _productColorFocusNode.dispose();
    _productColorDetailFocusNode.dispose();
    _serialNoFocusNode.dispose();
    _imeiNoFocusNode.dispose();
    _imeiNo2FocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(
          'UPDATE ATTACHED PRODUCT',
          style: TextStyle(color: Colors.white),
        ),
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: Padding(
        padding: EdgeInsets.all(10),
        child: Column(children: [
          Expanded(
            child: _attProductItem == null
                ? Text(
                    "There is no data found....",
                    style: TextStyle(
                      color: Colors.grey,
                    ),
                    textAlign: TextAlign.center,
                  )
                : Container(
                    child: Column(
                      children: [
                        Expanded(
                          child: Form(
                            key: _formKey,
                            autovalidateMode: AutovalidateMode.always,
                            child: SingleChildScrollView(
                              child: Column(
                                children: [
                                  SizedBox(
                                    height: 5,
                                  ),

                                  // productType //
                                  ItemInfoWidget(
                                    title: 'Product Type',
                                    value: _attProductItem!['productType'] != null ? _attProductItem!['productType'].toString().toUpperCase() : '-/-',
                                  ),
                                  Divider(),

                                  // productName //
                                  ItemInfoWidget(
                                    title: 'Product Name',
                                    value: _attProductItem!['productName'] ?? '-/-',
                                  ),
                                  Divider(),

                                  // unitPrice //
                                  ItemInfoWidget(
                                    title: 'Product Price',
                                    value: _attProductItem!['productPrice'] != null ? '${NumberFormat("#,###").format(_attProductItem!['productPrice'])} MMK' : '-/-',
                                  ),
                                  Divider(),

                                  SizedBox(
                                    height: 5,
                                  ),

                                  // productColor //
                                  TextFormInput(
                                    controller: _productColorController,
                                    focusNode: _productColorFocusNode,
                                    nextFocusNode: _productColorDetailFocusNode,
                                    label: "Product Color",
                                    textInputAction: TextInputAction.next,
                                    isRequired: true,
                                    requiredMessage: "Product color is required.",
                                    onSaved: _setProductColor,
                                    maxLines: 1,
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),

                                  // productColorDetail //
                                  TextFormInput(
                                    controller: _productColorDetailController,
                                    focusNode: _productColorDetailFocusNode,
                                    nextFocusNode: _serialNoFocusNode,
                                    label: "Product Color Detail",
                                    textInputAction: TextInputAction.next,
                                    onSaved: _setProductColorDetail,
                                    maxLines: 1,
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),

                                  // serialNo //
                                  TextFormInput(
                                    controller: _serialNoController,
                                    focusNode: _serialNoFocusNode,
                                    nextFocusNode: _imeiNoFocusNode,
                                    label: "Serial Number",
                                    textInputAction: TextInputAction.next,
                                    isRequired: true,
                                    requiredMessage: "Serial Number is required.",
                                    onSaved: _setSerialNo,
                                    maxLines: 1,
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),

                                  // imeiNo //
                                  TextFormInput(
                                    controller: _imeiNoController,
                                    focusNode: _imeiNoFocusNode,
                                    label: "IMEI Number",
                                    textInputAction: TextInputAction.next,
                                    keyboardType: TextInputType.number,
                                    isRequired: _attProductItem!['productType'] == 'phone' ? true : false,
                                    requiredMessage: "IMEI Number is required.",
                                    onSaved: _setImeiNo,
                                    maxLines: 1,
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),

                                  // imeiNo2 //
                                  TextFormInput(
                                    controller: _imeiNo2Controller,
                                    focusNode: _imeiNo2FocusNode,
                                    label: "IMEI Number2",
                                    textInputAction: TextInputAction.next,
                                    keyboardType: TextInputType.number,
                                    isRequired: _attProductItem!['productType'] == 'phone' ? true : false,
                                    requiredMessage: "IMEI Number2 is required.",
                                    onSaved: _setImeiNo2,
                                    maxLines: 1,
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),

                                  Row(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
                                    ButtonWidget(
                                      text: "CLEAR ALL",
                                      isWhiteBackgroundColor: true,
                                      onPressed: _clearAllFields,
                                    ),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    ButtonWidget(text: "SAVE CHANGES", isWhiteBackgroundColor: false, onPressed: _updateAttachedProductDetail),
                                  ]),
                                  SizedBox(
                                    height: 10,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
          ),
          SizedBox(
            height: 5,
          ),
          Container(
            height: 20,
            child: Align(
              alignment: Alignment.center,
              child: Text("Copyright @ 2020 Rent 2 Own Myanmar", textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
            ),
          ),
        ]),
      ),
    );
  }
}
