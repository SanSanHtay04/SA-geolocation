import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:sales/screens/result/attached_product_detail/edit_attached_product_detail_screen.dart';
import 'package:sales/widgets/waiting_modal_bottom_widget.dart';

class AttachedProductDetailsPartial extends StatefulWidget {
  // final int contractId;
  final Function() getAttachedProductsByContract;
  final List<Map<String, dynamic>> attachedProducts;
  AttachedProductDetailsPartial({
    // required this.contractId,
    required this.getAttachedProductsByContract,
    required this.attachedProducts,
  });

  @override
  State<AttachedProductDetailsPartial> createState() => _AttachedProductDetailsPartialState();
}

class _AttachedProductDetailsPartialState extends State<AttachedProductDetailsPartial> {
  void _editAttachedProductDetail(int attachedProductId, int attachedProductDetailId) {
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => EditAttachedProductDetailScreen(
                attachedProductId: attachedProductId,
                attachedProductDetailId: attachedProductDetailId,
              )),
    ).then((value) async {
      showWaitingModal(context: context, message: "Attached product is loading...", onWaiting: widget.getAttachedProductsByContract);
    });
  }

  void _initData() async {
    await widget.getAttachedProductsByContract;
  }

  @override
  void initState() {
    _initData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(15, 10, 15, 0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(
              'ATTACHED PRODUCTS',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.teal[600]),
            ),
          ]),
          Divider(
            thickness: 1.5,
          ),
          widget.attachedProducts.length == 0
              ? Padding(
                  padding: const EdgeInsets.only(
                    bottom: 8.0,
                  ),
                  child: Text("There is no attached product found."),
                )
              : ListView.builder(
                  shrinkWrap: true,
                  itemCount: widget.attachedProducts.length,
                  itemBuilder: (context, i) {
                    Map<String, dynamic> _attachedProduct = widget.attachedProducts[i];
                    List<dynamic> _attachedProductDetails = widget.attachedProducts[i]['attached_product_details'];
                    return Column(mainAxisAlignment: MainAxisAlignment.start, crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "${i + 1}. ",
                            style: TextStyle(fontWeight: FontWeight.bold, color: Colors.blue.shade700),
                            textAlign: TextAlign.center,
                          ),
                          Text(
                            '[${_attachedProduct['productType'].toString().toUpperCase()}] ',
                            style: TextStyle(fontWeight: FontWeight.bold, color: Colors.blue.shade700),
                          ),
                          Flexible(
                            child: Text(
                              '${_attachedProduct['productName']} ',
                              style: TextStyle(fontWeight: FontWeight.bold, color: Colors.blue.shade700),
                            ),
                          ),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                          left: 12.0,
                          top: 3.0,
                          bottom: 2.0,
                        ),
                        child: Text(
                          '${NumberFormat('#,###').format(_attachedProduct['productPrice'])} x ${_attachedProduct['quantity'].toString()} = ${NumberFormat('#,###').format(_attachedProduct['productPrice'] * _attachedProduct['quantity'])} MMK',
                          style: TextStyle(color: Colors.blue.shade800),
                        ),
                      ),
                      SizedBox(
                        height: 3,
                      ),
                      ListView.builder(
                          shrinkWrap: true,
                          physics: ClampingScrollPhysics(),
                          itemCount: _attachedProductDetails.length,
                          itemBuilder: (BuildContext context, int j) {
                            final _item = _attachedProductDetails[j];
                            return Padding(
                              padding: const EdgeInsets.only(left: 12.0, bottom: 5.0),
                              child: Container(
                                padding: EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  border: Border.all(color: Colors.grey.shade400, style: BorderStyle.solid),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Column(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.only(bottom: 5.0),
                                          child: Row(
                                            children: [
                                              Text(
                                                "- Color: ",
                                                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                                              ),
                                              Text(
                                                '${_item['productColor'] ?? '-/-'}',
                                                style: TextStyle(fontSize: 12),
                                              )
                                            ],
                                          ),
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.only(bottom: 5.0),
                                          child: Row(
                                            children: [
                                              Text(
                                                "- Color Detail: ",
                                                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                                              ),
                                              Text(
                                                '${_item['productColorDetail'] ?? '-/-'}',
                                                style: TextStyle(fontSize: 12),
                                              )
                                            ],
                                          ),
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.only(bottom: 5.0),
                                          child: Row(
                                            children: [
                                              Text(
                                                "- Serial No: ",
                                                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                                              ),
                                              Text(
                                                '${_item['serialNo'] ?? '-/-'}',
                                                style: TextStyle(fontSize: 12),
                                              )
                                            ],
                                          ),
                                        ),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Text(
                                              "- Imei No: ",
                                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                                            ),
                                            Text(
                                              '${_item['imeiNo'] ?? '-/-'}',
                                              style: TextStyle(fontSize: 12),
                                            ),
                                            _item['imeiNoDupLocked'] == 1
                                                ? Padding(
                                                    padding: const EdgeInsets.only(left: 5),
                                                    child: Icon(
                                                      Icons.lock,
                                                      size: 11,
                                                      color: Colors.red,
                                                    ),
                                                  )
                                                : SizedBox(),
                                          ],
                                        ),
                                        // ImeiNo2 //
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Text(
                                              "- Imei No2: ",
                                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                                            ),
                                            Text(
                                              '${_item['imeiNo2'] ?? '-/-'}',
                                              style: TextStyle(fontSize: 12),
                                            ),
                                            _item['imeiNo2DupLocked'] == 1
                                                ? Padding(
                                                    padding: const EdgeInsets.only(left: 5),
                                                    child: Icon(
                                                      Icons.lock,
                                                      size: 11,
                                                      color: Colors.red,
                                                    ),
                                                  )
                                                : SizedBox(),
                                          ],
                                        ),
                                      ],
                                    ),
                                    InkWell(
                                      onTap: () {
                                        _editAttachedProductDetail(_item['attachedProductId'], _item['attachedProductDetailId']);
                                      },
                                      child: CircleAvatar(
                                        radius: 16,
                                        backgroundColor: Colors.blue.shade600,
                                        child: Column(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            Icon(
                                              Icons.edit,
                                              color: Colors.white,
                                              size: 14,
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          }),
                      Divider(
                        thickness: 0.5,
                      ),
                    ]);
                  }),
        ],
      ),
    );
  }
}
