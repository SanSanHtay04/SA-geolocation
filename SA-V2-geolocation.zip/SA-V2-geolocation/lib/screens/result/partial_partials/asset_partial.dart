import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:sales/widgets/deprecated/text_button_widget.dart';
import 'package:sales/widgets/item_info_widget.dart';

class AssetPartial extends StatefulWidget {
  final Map<String, dynamic>? application;
  final Function() editAsset;

  AssetPartial({required this.application, required this.editAsset});

  @override
  State<AssetPartial> createState() => _AssetPartialState();
}

class _AssetPartialState extends State<AssetPartial> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(children: [
        SizedBox(
          height: 5,
        ),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(
            'ASSET',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.teal[600]),
          ),
          widget.application == null
              ? SizedBox()
              : TextButtonWidget(
                  text: "UPDATE",
                  iconData: Icons.edit,
                  onTap: widget.editAsset,
                ),
        ]),
        widget.application!['assetId'] == null
            ? SizedBox()
            : Column(
                children: [
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  ItemInfoWidget(
                    title: 'Product Category',
                    value: widget.application!['productCategoryName'] ?? '-/-',
                  ),
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  ItemInfoWidget(
                    title: 'Product Brand',
                    value: widget.application!['brandName'] ?? '-/-',
                  ),
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  ItemInfoWidget(
                    title: 'Product Model',
                    value: widget.application!['modelName'] ?? '-/-',
                  ),
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  ItemInfoWidget(
                    title: 'Product Name',
                    value: widget.application!['productName'] ?? '-/-',
                  ),
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  ItemInfoWidget(
                    title: 'Product Color',
                    value: (widget.application!['productColor'] ?? '-/-') + " (" + (widget.application!['productColorDetail'] ?? '') + ")",
                  ),
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  widget.application!['productCategoryId'] == 1 || widget.application!['productCategoryId'] == 2 || widget.application!['productCategoryId'] == 17 || widget.application!['productCategoryId'] == 68
                      ? Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'Engine N\u1d52',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Row(
                                  children: [
                                    widget.application!['engineNoDupLocked'] == 1
                                        ? Padding(
                                            padding: const EdgeInsets.only(right: 5),
                                            child: Icon(
                                              Icons.lock,
                                              size: 12,
                                              color: Colors.red,
                                            ),
                                          )
                                        : SizedBox(),
                                    Text(
                                      widget.application!['engineNo'] ?? '-/-',
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            Divider(
                              height: 10,
                              thickness: 0.5,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'Chassis N\u1d52',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Row(
                                  children: [
                                    widget.application!['chassisNoDupLocked'] == 1
                                        ? Padding(
                                            padding: const EdgeInsets.only(right: 5),
                                            child: Icon(
                                              Icons.lock,
                                              size: 12,
                                              color: Colors.red,
                                            ),
                                          )
                                        : SizedBox(),
                                    Text(
                                      widget.application!['chassisNo'] ?? '-/-',
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            Divider(
                              height: 10,
                              thickness: 0.5,
                            ),
                            ItemInfoWidget(
                              title: 'Plate N\u1d52',
                              value: (widget.application!['plateNo'] ?? '-/-'),
                            ),
                            Divider(
                              height: 10,
                              thickness: 0.5,
                            ),
                            widget.application!['productCategoryId'] == 2 || widget.application!['productCategoryId'] == 17 || widget.application!['productCategoryId'] == 68 || (widget.application!['productCategoryId'] == 1 && widget.application!['isGpsEquipped'] == 1)
                                ? Column(
                                    children: [
                                      ItemInfoWidget(
                                        title: 'GPS Imei N\u1d52',
                                        value: (widget.application!['gpsImeiNo'] ?? '-/-'),
                                      ),
                                      Divider(
                                        height: 10,
                                        thickness: 0.5,
                                      ),
                                      ItemInfoWidget(
                                        title: 'GPS Phone N\u1d52',
                                        value: (widget.application!['gpsPhoneNo'] ?? '-/-'),
                                      ),
                                      Divider(
                                        height: 10,
                                        thickness: 0.5,
                                      ),
                                    ],
                                  )
                                : SizedBox(),
                          ],
                        )
                      : Column(
                          children: [
                            ItemInfoWidget(
                              title: 'Serial N\u1d52',
                              value: (widget.application!['serialNo'] ?? '-/-'),
                            ),
                            Divider(
                              height: 10,
                              thickness: 0.5,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'IMEI N\u1d52',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Row(
                                  children: [
                                    widget.application!['imeiNoDupLocked'] == 1
                                        ? Padding(
                                            padding: const EdgeInsets.only(right: 5),
                                            child: Icon(
                                              Icons.lock,
                                              size: 12,
                                              color: Colors.red,
                                            ),
                                          )
                                        : SizedBox(),
                                    Text(
                                      widget.application!['imeiNo'] ?? '-/-',
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            Divider(
                              height: 10,
                              thickness: 0.5,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'IMEI2 N\u1d52',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Row(
                                  children: [
                                    widget.application!['imeiNo2DupLocked'] == 1
                                        ? Padding(
                                            padding: const EdgeInsets.only(right: 5),
                                            child: Icon(
                                              Icons.lock,
                                              size: 12,
                                              color: Colors.red,
                                            ),
                                          )
                                        : SizedBox(),
                                    Text(
                                      widget.application!['imeiNo2'] ?? '-/-',
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            Divider(
                              height: 10,
                              thickness: 0.5,
                            ),
                          ],
                        ),
                  ItemInfoWidget(
                    title: 'Product Price',
                    value: widget.application!['primaryUnitPrice'] != null ? (NumberFormat("#,###").format(widget.application!['primaryUnitPrice']) + " MMK") : '-/-',
                  ),
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  ItemInfoWidget(
                    title: 'Parking Address',
                    value: widget.application!['assetStorageAddress'] ?? '-/-',
                  ),
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  ItemInfoWidget(
                    title: 'OB Status',
                    value: widget.application!['ownerBookStatus'] != null ? (widget.application!['ownerBookStatus'].toString().toUpperCase()) : '-/-',
                  ),
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  ItemInfoWidget(
                    title: 'OB Expiry Date',
                    value: widget.application!['ownerBookExpiryDate'] != null ? DateFormat('dd/MM/yyyy').format(DateTime.parse(widget.application!['ownerBookExpiryDate'])) : '-/-',
                  ),
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  ItemInfoWidget(
                    title: 'MAINTENANCE Covered',
                    value: widget.application!['maintenanceCovered'] == 1 ? 'YES' : 'NO',
                  ),
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  ItemInfoWidget(
                    title: 'LIFE INSURANCE Covered',
                    value: widget.application!['insLifeCovered'] == 1 ? 'YES' : 'NO',
                  ),
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  ItemInfoWidget(
                    title: 'ASSET INSURANCE Covered',
                    value: widget.application!['insAssetCovered'] == 1 ? 'YES' : 'NO',
                  ),
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  SizedBox(
                    height: 10,
                  ),
                ],
              ),
      ]),
    );
  }
}
