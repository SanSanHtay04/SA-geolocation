import 'package:flutter/material.dart';
import 'package:sales/widgets/item_info_widget.dart';

class ApplicationPartial extends StatefulWidget {
  final Map<String, dynamic> application;

  ApplicationPartial(
    { Key? key,
      required this.application,
    });

  @override
  State<ApplicationPartial> createState() => _ApplicationPartialState();
}

class _ApplicationPartialState extends State<ApplicationPartial> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        children: [
          SizedBox(
            height: 10,
          ),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(
              'APPLICATION',
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.teal[600]),
            ),
          ]),
          widget.application['applicationId'] != null ? Column(
            children: [
              Divider(
                height: 10,
                thickness: 0.5,
              ),
              ItemInfoWidget(
                title: 'APP ID',
                value: "${ widget.application['applicationId'] ?? '' }",
              ),
              Divider(
                height: 10,
                thickness: 0.5,
              ),
              ItemInfoWidget(
                title: 'Designated To Person',
                value: "${ widget.application['personDesignatedToName'] ?? '' }",
              )
            ],
          ) : SizedBox(),
          Divider(
            height: 10,
            thickness: 0.5,
          ),
        ],
      ),
    );
  }
}