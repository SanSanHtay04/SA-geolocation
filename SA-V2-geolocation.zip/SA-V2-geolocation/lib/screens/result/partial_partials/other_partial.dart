import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:sales/configs.dart';
import 'package:sales/providers/application_document_provider.dart';
import 'package:sales/providers/contract_provider.dart';
import 'package:sales/providers/document_type_provider.dart';
import 'package:sales/widgets/confirmation_modal_bottom_widget.dart';
import 'package:sales/widgets/deprecated/alert_modal_bottom_widget.dart';
import 'package:url_launcher/url_launcher.dart';

class OtherPartial extends StatefulWidget {
  final Map<String, dynamic>? application;

  OtherPartial({
    required this.application,
  });

  @override
  State<OtherPartial> createState() => _OtherPartialState();
}

class _OtherPartialState extends State<OtherPartial> {
  bool _isDocUploadCompleted = false;

  void _getClientDocs() async {
    final url = "${Configs.legacyUrl}/shareable-links?link=${Configs.legacyUrl}/contract/customer/${widget.application!['customerId']}/contract/${widget.application!['contractId']}/all_docs_needed_for_client/client/blankdate/0?isEmbedSignature=true&isDownload=true";
    final response = await http.get(Uri.parse(url));
    print('url: $url');
    if (response.statusCode == 200) {
      var jsonResponse = jsonDecode(response.body);
      var shareableLink = jsonResponse['shareableLink'];

      // copy link to clipboard //
      await Clipboard.setData(
        new ClipboardData(text: shareableLink),
      );

      showAlertModal(context: context, message: "The CLIENT'S DOCS link is copied.", onDismiss: () async {
        if (await canLaunch(url))
          await launch(shareableLink, forceSafariVC: false, forceWebView: false, );
        else {
          throw "Could not launch $url";
        }
      });
    } else {
      showAlertModal(context: context, message: "Request failed with status: ${response.statusCode}.", onDismiss: () async {});
    }
  }

  void _sendSMSDoc() async {
    showConfirmation(context: context, message: "Are you sure you want to send SMS Doc for contract '${widget.application!['contractNo']}'?", onYes: () async {
      String? _message = 'Something went wrong.';
      String? _code = '';
      try {
        final url = "${Configs.legacyUrl}/shareable-links?link=${Configs.legacyUrl}/contract/customer/${widget.application!['customerId']}/contract/${widget.application!['contractId']}/all_docs_needed_for_client/client/blankdate/0?isEmbedSignature=true&isDownload=true";
        final response = await http.get(Uri.parse(url));
        print('url: $url');
        if (response.statusCode == 200) {
          var jsonResponse = jsonDecode(response.body);
          var shareableLink = jsonResponse['shareableLink'];
          await Provider.of<ContractProvider>(context, listen: false)
            .sendSMSDoc(widget.application!['contractId'], {
              "contractLink": shareableLink
            })
            .then((value) {
              setState(() {
                _message = Provider.of<ContractProvider>(context, listen: false).responseMessage;
                _code = Provider.of<ContractProvider>(context, listen: false).responseCode;
              });
          });
        } else {
          showAlertModal(context: context, message: "Request failed with status: ${response.statusCode}.", onDismiss: () async {});
        }
      } catch (error) {
        setState(() {
          _message = error.toString();
        });
      }

      await showAlertModal(context: context, message: _message.toString(), onDismiss: () {});
    });
  }

  void _confirmPerforming() async {
    String? _message = 'Something went wrong.';
    String? _code = '';

    // Check Required Doc Uploads //
    List<Map<String, dynamic>> _documentTypes = [];
    List<Map<String, dynamic>> _documentUploads = [];

    await Provider.of<DocumentTypeProvider>(context, listen: false).getDocumentTypes().then((value) async {
      List<dynamic> _tempDocumentTypes = Provider.of<DocumentTypeProvider>(context, listen: false).items;
      final productCategorySubType1 = widget.application!['productCategorySubType1'];
      final productStatus = widget.application!['isSecondHandProduct'] == 0 ? 'new' : 'old';
      _tempDocumentTypes.forEach((docType) { 
        List<String> listAppliedProductCategories = docType['sa_app_applied_product_categories'].toString().split(",");
        List<String> listAppliedProductStatuses = docType['sa_app_applied_product_statuses'].toString().split(",");
        
        final productCategoryIndex = listAppliedProductCategories.indexWhere((element) => element == productCategorySubType1);
        final productStatusIndex = listAppliedProductStatuses.indexWhere((element) => element == productStatus);
        if (productCategoryIndex >= 0 && productStatusIndex >= 0) {
          _documentTypes.add(docType);
        }
      });
    });

    await Provider.of<ApplicationDocumentProvider>(context, listen: false)
      .getApplicationDocumentFiles(widget.application!['applicationId'])
      .then((value) {
      _documentUploads = Provider.of<ApplicationDocumentProvider>(context, listen: false).items;
    });

    for (var i=0; i<_documentTypes.length; i++) {
      List<Map<String, dynamic>> docTypes = [];
      _documentUploads.forEach((documentUpload) { 
        if (_documentTypes[i]['id'] == documentUpload['document_type_id']) {
          docTypes.add(documentUpload);
        }
      });
      _documentTypes[i]['documentUploads'] = docTypes;
    }


    _isDocUploadCompleted = false;
    int docRequiredCount = 0;
    int docUploadRequiredCount = 0;
    _documentTypes.forEach((docType) { 
      if (docType['sa_app_required'] == 1) {
        docRequiredCount += 1;
        if (docType['documentUploads'].length > 0) {
          docUploadRequiredCount += 1;
        }
      }
    });

    _isDocUploadCompleted = docRequiredCount == docUploadRequiredCount ? true : false;

    if (_isDocUploadCompleted) {
      showConfirmation(context: context, message: "Are you sure you want to confirm performing for contract '${widget.application!['contractNo']}'?", onYes: () async {
        try {
          await Provider.of<ContractProvider>(context, listen: false)
            .confirmPerforming(widget.application!['customerId'], widget.application!['contractId'])
            .then((value) {
              setState(() {
                _message =
                    Provider.of<ContractProvider>(context, listen: false)
                        .responseMessage;
                _code = Provider.of<ContractProvider>(context, listen: false)
                        .responseCode;
              });
          });
        } catch (error) {
          setState(() {
            _message = error.toString();
          });
        }

        showAlertModal(context: context, message: _message, onDismiss: () {
          if (_code == "SUCCESS") {
            Navigator.pop(context);
          }
        });
      });
    } else {
      showAlertModal(context: context, message: "You cannot confirm PERFORMING CONTRACT because the required documents are still missing!", onDismiss: (){});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(children: [
        SizedBox(height: 10,),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.teal.shade300,
            side: BorderSide(width: 1.0, color: Colors.teal.shade700),
            minimumSize: const Size.fromHeight(35), // NEW
          ),
          child: Text("GET CLIENT'S DOCS", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.white)),
          onPressed: _getClientDocs,
        ),

        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.teal.shade300,
            side: BorderSide(width: 1.0, color: Colors.teal.shade700),
            minimumSize: const Size.fromHeight(35), // NEW
          ),
          child: Text("SEND SMS DOC (${widget.application!["phoneNo1"]})", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.white)),
          onPressed: _sendSMSDoc,
        ),

        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blue.shade400,
            side: BorderSide(width: 1.0, color: Colors.blue.shade700),
            minimumSize: const Size.fromHeight(35), // NEW
          ),
          child: Text("CONFIRM PERFORMING", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.white)),
          onPressed: _confirmPerforming,
        ),
      ]),
    );
  }
}