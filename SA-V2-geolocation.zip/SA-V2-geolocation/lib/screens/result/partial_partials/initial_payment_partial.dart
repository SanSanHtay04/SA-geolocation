import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:sales/widgets/item_info_widget.dart';

class InitialPaymentPartial extends StatefulWidget {
  final Map<String, dynamic>? application;
  final Function() confirmPaidInitialPayment;

  InitialPaymentPartial({
    required this.application,
    required this.confirmPaidInitialPayment
  });
  
  @override
  State<InitialPaymentPartial> createState() => _InitialPaymentPartialState();
}

class _InitialPaymentPartialState extends State<InitialPaymentPartial> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(children: [
        SizedBox(
          height: 10,
        ),
        Text(
          'INITIAL PAYMENT',
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.teal[600]),
        ),
        widget.application!['contractId'] != null && widget.application!['contractStatusId'] == 8
          ? Column(
              children: [
                SizedBox(height: 10,),
                ItemInfoWidget(
                  title: 'Total Initial Payment',
                  value: widget.application!['firstPaymentNeedToConfirm'] != null ? '${NumberFormat("#,###").format(widget.application!['firstPaymentNeedToConfirm'])} MMK' : '-/-',
                  color: Colors.blue,
                ),
                  Divider(
                  height: 10,
                  thickness: 0.5,
                ),
                ItemInfoWidget(
                  title: '      - Admin Fee',
                  value: widget.application!['adminFee'] != null ? '${NumberFormat("#,###").format(widget.application!['adminFee'])} MMK' : '-/-',
                ),
                Divider(
                  height: 10,
                  thickness: 0.5,
                ),
                ItemInfoWidget(
                  title: '      - Down-payment',
                  value: widget.application!['adminFee'] != null ? '${NumberFormat("#,###").format(widget.application!['depositAmount'])} MMK' : '-/-',
                ),
                Divider(
                  height: 10,
                  thickness: 0.5,
                ),
                
                widget.application!['followingPayment'] == 0 
                ? Column(
                  children: [
                    ItemInfoWidget(
                      title: '         - First Installment',
                      value: widget.application!['followingPayment'] != null ? '${NumberFormat("#,###").format(widget.application!['followingPayment'])} MMK' : '-/-',
                    ),
                    Divider(
                      height: 10,
                      thickness: 0.5,
                    ),
                  ],
                )
                : SizedBox(),

                widget.application!['earlyPrepaymentAmount'] > 0 
                ? Column(
                  children: [
                    ItemInfoWidget(
                      title: '         - Early Pre-payment',
                      value: widget.application!['earlyPrepaymentAmount'] != null ? '${NumberFormat("#,###").format(widget.application!['earlyPrepaymentAmount'])} MMK' : '-/-',
                    ),
                    Divider(
                      height: 10,
                      thickness: 0.5,
                    ),
                  ],
                )
                : SizedBox(),

                widget.application!['zeroCostTotalInsCost'] > 0 
                ? Column(
                  children: [
                    ItemInfoWidget(
                      title: '         - Zero-Cost Upfront Insurance',
                      value: widget.application!['zeroCostTotalInsCost'] != null ? '${NumberFormat("#,###").format(widget.application!['zeroCostTotalInsCost'])} MMK' : '-/-',
                    ),
                    Divider(
                      height: 10,
                      thickness: 0.5,
                    ),
                  ],
                )
                : SizedBox(),

                widget.application!['zeroCostTotalMaintCost'] > 0 
                ? Column(
                  children: [
                    ItemInfoWidget(
                      title: '         - Zero-Cost Upfront Maintenance',
                      value: widget.application!['zeroCostTotalMaintCost'] != null ? '${NumberFormat("#,###").format(widget.application!['zeroCostTotalMaintCost'])} MMK' : '-/-',
                    ),
                    Divider(
                      height: 10,
                      thickness: 0.5,
                    ),
                  ],
                )
                : SizedBox(),
                
                SizedBox(
                  height: 10,
                ),

                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Theme.of(context).primaryColor,
                    minimumSize: const Size.fromHeight(36), // NEW
                  ),
                  child: Text("CONFIRM FIRST PAYMENT & PAID TO MERCHANT", style: TextStyle(fontSize: 13,)),
                  onPressed: widget.confirmPaidInitialPayment,
                ),

                SizedBox(
                  height: 10,
                ),
              ],
            )
          : SizedBox(),

        widget.application!['contractId'] != null && widget.application!['contractStatusId'] == 9
          ? Column(
              children: [
                SizedBox(
                  height: 5,
                ),
                Text("This contract was already paid first payment with total amount ${NumberFormat('#,###').format(widget.application!['actualFirstPayment'])} MMK", textAlign: TextAlign.center),
                SizedBox(
                  height: 10,
                ),
              ],
            )  
          : SizedBox()
      ]),
    );
  }
}