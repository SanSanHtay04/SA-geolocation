import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

import 'package:flutter/material.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:provider/provider.dart';
import 'package:sales/configs.dart';
import 'package:sales/providers/application_document_provider.dart';
import 'package:sales/providers/contract_provider.dart';
import 'package:sales/screens/result/partial_partials/docs_upload_partial.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/widgets/confirmation_modal_bottom_widget.dart';
import 'package:sales/widgets/deprecated/alert_modal_bottom_widget.dart';
import 'package:sales/widgets/deprecated/text_button_widget.dart';
import 'package:url_launcher/url_launcher.dart';

class DocsPartial extends StatefulWidget {
  final Map<String, dynamic>? application;

  DocsPartial({
    required this.application,
  });
  
  @override
  State<DocsPartial> createState() => _DocsPartialState();
}

class _DocsPartialState extends State<DocsPartial> {
  bool _isLoading = false;
  List<Map<String, dynamic>>? _appDocUploadsList = [];

  void _getClientDocs() async {
    final url = "${Configs.legacyUrl}/shareable-links?link=${Configs.legacyUrl}/contract/customer/${widget.application!['customerId']}/contract/${widget.application!['contractId']}/all_docs_needed_for_client/client/blankdate/0?isEmbedSignature=true&isDownload=true";
    final response = await http.get(Uri.parse(url));
    print('url: $url');
    if (response.statusCode == 200) {
    var jsonResponse = jsonDecode(response.body);
    var shareableLink = jsonResponse['shareableLink'];

    if (await canLaunch(url))
      await launch(shareableLink, forceSafariVC: false, forceWebView: false, );
    else {
      throw "Could not launch $url";
    }

    print('shareableLink: $shareableLink.');

    // copy link to clipboard //
    await Clipboard.setData(
      new ClipboardData(text: shareableLink),
    );

    return showDialog<void>(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            'ALERT',
            style: TextStyle(color: Colors.black),
          ),
          content: Text("The CLIENT'S DOCS link is copied."),
          actions: <Widget>[
            TextButton(
              child: Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      });
    } else {
      print('Request failed with status: ${response.statusCode}.');
    }
  }

  Future<void> _getDocUploads() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<ApplicationDocumentProvider>(context, listen: false)
          .getApplicationDocumentFiles(widget.application!['applicationId'])
          .then((value) {
        setState(() {
          _appDocUploadsList = Provider.of<ApplicationDocumentProvider>(context, listen: false).items;
          _isLoading = false;
        });
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  _deleteApplicationDocumentFile(int applicationId, int fileId) {
    String? _message = 'Something went wrong.';
    showConfirmation(context: context, message: "Are you sure you want to delete the selected item?", onYes: () async {
      try {
        setState(() {
          _isLoading = true;
        });
      
        await Provider.of<ApplicationDocumentProvider>(context, listen: false)
          .deleteApplicationDocumentFile(applicationId, fileId);
        _message = Provider.of<ApplicationDocumentProvider>(context, listen: false).responseMessage!;

        setState(() {
          _isLoading = false;
        });
      } catch (error) {
        _message = error.toString();
          _isLoading = false;
      }
      
      showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        builder: (context) {
          return AlertModalBottomWidget(_message, () async {
            await _getDocUploads();
            Navigator.pop(context);
          });
        }
      );
    });
  }

  Map<String, dynamic>? _recordResult;
  void _confirmPerforming() {
    String? _message = 'Something went wrong.';
    String? _code = '';
    showConfirmation(context: context, message: "Are you sure you want to confirm performing for contract '${widget.application!['contractNo']}'?", onYes: () async {
      try {
        setState(() {
          _isLoading = true;
        });

        await Provider.of<ContractProvider>(context, listen: false)
          .confirmPerforming(widget.application!['customerId'], widget.application!['contractId'])
          .then((value) {
            setState(() {
              _recordResult =
                  Provider.of<ContractProvider>(context, listen: false)
                      .item;
              _message =
                  Provider.of<ContractProvider>(context, listen: false)
                      .responseMessage;
              _code = Provider.of<ContractProvider>(context, listen: false)
                      .responseCode;
              print('_code: $_code');
              _isLoading = false;
            });
            print('_recordResult: $_recordResult');
        });
      } catch (error) {
        setState(() {
          _message = error.toString();
          _isLoading = false;
        });
      }

      showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        builder: (context) {
          return AlertModalBottomWidget(_message, () {
            Navigator.pop(context);
            if (_code == "SUCCESS") {
              Navigator.pop(context);
            }
          });
        });
    });
  }

  @override
  void initState() {
    super.initState();
    this._getDocUploads();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ModalProgressHUD(
      inAsyncCall: _isLoading,
      opacity: 0.5,
      progressIndicator: CircularProgressIndicator(
        valueColor: new AlwaysStoppedAnimation<Color>(
         context.getColorScheme().primary,
        ),
      ), 
      child: Column(
        children: [
          Expanded(
            child: Container(
              padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 5,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'DOCUMENT UPLOAD (${ _appDocUploadsList?.length })',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.teal[600]),
                      ),
                      TextButtonWidget(
                        text: "New",
                        iconData: Icons.add,
                        onTap: () async {
                          await showModalBottomSheet(
                            isScrollControlled: true,
                            context: context,
                            backgroundColor: Colors.transparent,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.vertical(top: Radius.circular(25.0)),
                            ),
                            builder: (builder) {
                              return StatefulBuilder(builder: (BuildContext ctx, StateSetter setModalState /*You can rename this!*/) {
                                // return SizedBox();
                                return DocsUploadPartial(application: widget.application, reloadApplicationDocuments: this._getDocUploads);
                              });
                            }
                          );
                        },
                      )
                    ],
                  ),
                  
                  Expanded(
                    child: Container(
                      child: ListView.separated(
                        itemBuilder: (BuildContext ctx, index){
                          Uint8List? bytes;
                          if (_appDocUploadsList?[index]['preview'] != null && _appDocUploadsList![index]['preview'] != "") {
                            bytes = base64Decode(_appDocUploadsList![index]['preview'].toString().split(',').last);
                          }

                          return ListTile(
                            leading: bytes == null ? SizedBox(child: Text("No upload available", textAlign: TextAlign.center, style: TextStyle(color: Colors.grey,),), width: 70.0,) : Image.memory(bytes, 
                              fit: BoxFit.cover,
                              width: 70.0,
                            ),
                            title: Text(_appDocUploadsList![index]['document_type']['name'], style: TextStyle(color: Colors.teal[600], fontWeight: FontWeight.bold),),
                            subtitle: Text(_appDocUploadsList![index]['remark'] ?? ''),
                            trailing: IconButton(icon: Icon(Icons.delete, color: Colors.red), onPressed: () async {
                              _deleteApplicationDocumentFile(widget.application!['submittedAppId'], _appDocUploadsList![index]["id"]);
                            }),
                          );
                        },
                        separatorBuilder: (BuildContext, index) {
                          return Divider(height: 1);
                        }, 
                        shrinkWrap: true,
                        // padding: EdgeInsets.all(5),
                        scrollDirection: Axis.vertical,
                        itemCount: _appDocUploadsList!.length
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          SizedBox(
            height: 5,
          ),

          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Theme.of(context).primaryColor,
              minimumSize: const Size.fromHeight(35), // NEW
            ),
            child: Text("GET CLIENT'S DOCS", style: TextStyle(fontSize: 15,)),
            onPressed: _getClientDocs,
          ),

          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue[600],
              minimumSize: const Size.fromHeight(35), // NEW
            ),
            child: Text("CONFIRM PERFORMING", style: TextStyle(fontSize: 15,)),
            onPressed: _confirmPerforming,
          ),

          
        ],
      ),
    );
  }
}