import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/providers/asset_provider.dart';
import 'package:sales/widgets/confirmation_modal_bottom_widget.dart';
import 'package:sales/widgets/deprecated/alert_modal_bottom_widget.dart';
import 'package:sales/widgets/waiting_modal_bottom_widget.dart';

class DeliveryPartial extends StatefulWidget {
  final Map<String, dynamic>? application;
  final Function()? reloadApplication;

  DeliveryPartial({
    required this.application,
    required this.reloadApplication,
  });
  
  @override
  State<DeliveryPartial> createState() => _DeliveryPartialState();
}

class _DeliveryPartialState extends State<DeliveryPartial> {
  Map<String, dynamic>? _recordResult;

  _confirmDelivery() {
    String? _message = 'Something went wrong.';
    showConfirmation(context: context, message: "Are you sure you want to confirm delivery for contract '${widget.application!['contractNo']}'?", onYes: () async {
      await showWaitingModal(context: context, message: "Equipment delivery note is creating...", onWaiting: () async {
        try {
          await Provider.of<AssetProvider>(context, listen: false)
            .confirmDelivery(widget.application!['contractId'], widget.application!['assetId'])
            .then((value) {
              setState(() {
                _recordResult = Provider.of<AssetProvider>(context, listen: false).item;
                _message = Provider.of<AssetProvider>(context, listen: false).responseMessage;
              });
          });
        } catch (error) {
          setState(() {
            _message = error.toString();
          });
        }
      });

      await showAlertModal(context: context, message: _message, onDismiss: () async {
        await widget.reloadApplication!();
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(children: [
        SizedBox(
          height: 10,
        ),
        Text(
          'EQUIPMENT DELIVERY NOTE',
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.teal[600]),
        ),

        widget.application!['contractId'] != null && widget.application!['deliveryDate'] == null
          ? Column(
              children: [
                SizedBox(
                  height: 5,
                ),

                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Theme.of(context).primaryColor,
                    minimumSize: const Size.fromHeight(36), // NEW
                  ),
                  child: Text("CONFIRM DELIVERY", style: TextStyle(fontSize: 15,)),
                  onPressed: _confirmDelivery,
                ),

                SizedBox(
                  height: 10,
                ),
              ],
            )
          : SizedBox(),

        widget.application!['contractId'] != null && widget.application!['deliveryDate'] != null
          ? Column(
              children: [
                SizedBox(
                  height: 5,
                ),
                Text("You have successfully confirmed delivery of the selected equipment.", textAlign: TextAlign.center),
                SizedBox(
                  height: 10,
                ),
              ],
            )  
          : SizedBox()
      ]),
    );
  }
}