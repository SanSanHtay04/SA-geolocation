import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/configs.dart';
import 'package:sales/providers/contract_provider.dart';
import 'package:sales/providers/customer_contact_detail_provider.dart';
import 'package:sales/widgets/confirmation_modal_bottom_widget.dart';
import 'package:sales/widgets/deprecated/alert_modal_bottom_widget.dart';
import 'package:sales/widgets/waiting_modal_bottom_widget.dart';
import 'package:signature/signature.dart';

class ESignaturePartial extends StatefulWidget {
  final Map<String, dynamic>? application;
  final Function()? reloadApplication;

  ESignaturePartial({
    required this.application,
    required this.reloadApplication,
  });
  
  @override
  State<ESignaturePartial> createState() => _ESignaturePartialState();
}

class _ESignaturePartialState extends State<ESignaturePartial> {
  bool _isLoading = false;
  SignatureController? _signatureController;
  int? _contactDetIdSelected;
  String? _signatureTypeSelected = 'customer';
  String? _signatureStatusSelected = 'sign';
  String? _customerSignaturePath;
  String? _merchantSignaturePath;
  String? _refereeSignaturePath;
  Map<String, dynamic>? _contract;
  List <Map<String, dynamic>> _referees = [];

  _onSignatureTypeSelection(String? item) {
    setState(() {
      _signatureTypeSelected = item;
      _contactDetIdSelected = null;
      _customerSignaturePath = item == 'customer' ? _contract!['customerSignaturePath'] : null;
      _merchantSignaturePath = item == 'merchant' ? _contract!['merchantSignaturePath'] : null;
      _signatureStatusSelected = _contract!['customerSignaturePath'] != null || _contract!['merchantSignaturePath'] != null ?  "signed" : "sign";
      if (_signatureTypeSelected == 'referee') {
        this._getReferees();
      }
    });
  }

  _onSignatureStatusSelection(String? item) {
    setState(() {
      _signatureStatusSelected = item;
    });
  }

  Future<void> _getContractSignature() async {
    imageCache.clear();

    showWaitingModal(context: context, message: "List of signatures are loading...", onWaiting: () async {
      await Provider.of<ContractProvider>(context, listen: false)
        .getContractSignature(widget.application!['customerId'], widget.application!['contractId'])
        .then((value) {
        setState(() {
          _contract = Provider.of<ContractProvider>(context, listen: false).item;
          _signatureStatusSelected = _contract!['customerSignaturePath'] != null || _contract!['merchantSignaturePath'] != null ?  "signed" : "sign";
          _customerSignaturePath = _signatureTypeSelected == 'customer' ? _contract!['customerSignaturePath'] : null;
          _merchantSignaturePath = _signatureTypeSelected == 'merchant' ? _contract!['merchantSignaturePath'] : null;
        });
      });
    });
  }

  Future<void> _getReferees() async {
    showWaitingModal(context: context, message: "List of Referees are loading...", onWaiting: () async {
      try {
        await Provider.of<CustomerContactDetailProvider>(context, listen: false)
            .getReferees(widget.application!['customerId'])
            .then((value) {
          setState(() {
            _referees = Provider.of<CustomerContactDetailProvider>(context, listen: false).items;
            _refereeSignaturePath = null;
            imageCache.clear();
            _referees.forEach((element) { 
              if (_contactDetIdSelected == element['contactDetId']) {
                _refereeSignaturePath = element['signaturePath'];
              }
            });
          });
        });
      } catch (error) {
        print(error.toString());
      }
    });
  }

  Future<void> _exportImage() async {
    if (_signatureController!.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          key: Key('snackbarPNG'),
          content: Text('No content'),
        ),
      );
      return;
    }
  
    if (_signatureController!.isEmpty) {
      return;
    }

    if (!mounted) return;

    String resultMessage = "Something went wrong.";
    showConfirmation(context: context, message: "Are you sure you want to upload this signature?", onYes: () async {
      await showWaitingModal(context: context, message: "The signature is uploading...", onWaiting: () async {
        final _signature = await _signatureController!.toPngBytes();
        final finalSignature = base64Encode(_signature!);

        String url = "${Configs.legacyUrl}/contracts/${widget.application!['contractId']}/signatures";
        Map<String, String> headers = {"Content-type": "application/json"};
        String jsonData = '{"signature": "$finalSignature", "type": "$_signatureTypeSelected"}';
        if (_signatureTypeSelected == 'referee') {
          url = "${Configs.legacyUrl}/contracts/${widget.application!['contractId']}/signatures";
          jsonData = '{"contactDetId": "$_contactDetIdSelected", "signature": "$finalSignature", "type": "$_signatureTypeSelected"}';
        } 
      
        final response = await http.post(Uri.parse(url), headers: headers, body: jsonData);
        if (response.statusCode == 200) {
          var jsonResponse = jsonDecode(response.body);
          resultMessage = jsonResponse['message'];
        } else {
          resultMessage = 'Request failed with status: ${response.statusCode}.';
          print('Request failed with status: ${response.statusCode}.');
        }
      });

      await showAlertModal(context: context, message: resultMessage, onDismiss: () async {
        if (_signatureTypeSelected == 'referee') {
          await this._getReferees();
        } else {
          await  this._getContractSignature();
        }
        _signatureController!.clear();
      });
    });
  }

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) { 
      _getContractSignature();
    });

    _signatureController = SignatureController(
      penStrokeWidth: 3,
      penColor: Colors.blue.shade900,
      exportBackgroundColor: Colors.transparent,
      exportPenColor: Colors.blue.shade900,
    )..addListener(() => print('Value changed'));
    super.initState();
  }

  @override
  void dispose() {
    _signatureController!.dispose();
    super.dispose(); 
  }

  @override
  Widget build(BuildContext context) {
    final deviceSize = MediaQuery.of(context).size;

    Widget _buildRefereeDropdownButton() {
      return DropdownButtonFormField<dynamic>(
        dropdownColor: Colors.white,
        decoration: InputDecoration(
          contentPadding: EdgeInsets.fromLTRB(15, 13, 12, 13),
          labelText: "Referee",
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
          ),
        ),
        items: _referees.map((item) {
          return DropdownMenuItem<int>(
            value: item["contactDetId"],
            child: Text(item["relationFullName"]),
          );
        }).toList(),
        value: _contactDetIdSelected ?? null,
        onChanged: (newValue) {
          setState(() {
            _contactDetIdSelected = newValue;
            _refereeSignaturePath = null;
            imageCache.clear();
            _referees.forEach((element) { 
              if (_contactDetIdSelected == element['contactDetId']) {
                _refereeSignaturePath = element['signaturePath'];
              }
            });
          });
        },
        validator: (value) {
          if (_signatureTypeSelected == 'referee' && _contactDetIdSelected == null) {
            return "Referee is required";
          }
          return null;
        },
        onSaved: (value) {
          print('onSaved $_contactDetIdSelected');
        },
      );
    }
    
    return Container(
      padding: EdgeInsets.zero,
      decoration: BoxDecoration(
        // border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        children: [
          Container(
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    // Customer //
                    new Radio(
                      value: 'customer',
                      groupValue: _signatureTypeSelected,
                      onChanged: _onSignatureTypeSelection,
                    ),
                    new InkWell(
                      child: Text('Customer',),
                      onTap: () {
                        _onSignatureTypeSelection('customer');
                      },
                    ),

                    // Referee //
                    new Radio(
                      value: 'referee',
                      groupValue: _signatureTypeSelected,
                      onChanged: _onSignatureTypeSelection,
                    ),
                    new InkWell(
                      child: Text('Referee',),
                      onTap: () {
                        _onSignatureTypeSelection('referee');
                      },
                    ),

                    // Merchant //
                    new Radio(
                      value: 'merchant',
                      groupValue: _signatureTypeSelected,
                      onChanged: _onSignatureTypeSelection,
                    ),
                    new InkWell(
                      child: Text('Merchant',),
                      onTap: () {
                        _onSignatureTypeSelection('merchant');
                      },
                    ),
                  ],
                ),

              ],
            ),
          ),

          _signatureTypeSelected == 'referee' ? _buildRefereeDropdownButton() : SizedBox(),

          Divider(height: 0,),
          
          Container(
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    // Customer //
                    new Radio(
                      value: 'signed',
                      groupValue: _signatureStatusSelected,
                      onChanged: _onSignatureStatusSelection,
                    ),
                    new InkWell(
                      child: Text('Signed',),
                      onTap: () {
                        _onSignatureStatusSelection('signed');
                      },
                    ),

                    // Merchant //
                    new Radio(
                      value: 'sign',
                      groupValue: _signatureStatusSelected,
                      onChanged: _onSignatureStatusSelection,
                    ),
                    new InkWell(
                      child: Text('Sign',),
                      onTap: () {
                        _onSignatureStatusSelection('sign');
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),

          _signatureStatusSelected == 'signed' && (_signatureTypeSelected == 'customer' || _signatureTypeSelected == 'merchant')
          ? Container(
            alignment: Alignment.center,
            height: 260,
            width: double.infinity,
            decoration: BoxDecoration(
                border: Border.all(width: 1, color: Colors.grey),
              borderRadius: BorderRadius.circular(10),
            ),
            // child: Image(image: _networkImageSelected!, fit: BoxFit.fill,)
            child: _customerSignaturePath == null && _merchantSignaturePath == null ? Text("No signature found.", textAlign: TextAlign.center, style: TextStyle(color: Colors.grey),) : Image(
              width: deviceSize.width,
              height: deviceSize.height,
              image: NetworkImage(_signatureTypeSelected == 'merchant' ? _merchantSignaturePath! : _customerSignaturePath!),
            ),
            
          )
          : SizedBox(),

          _signatureStatusSelected == 'signed' && _signatureTypeSelected == 'referee'
          ? Container(
            alignment: Alignment.center,
            height: 260,
            width: double.infinity,
            decoration: BoxDecoration(
                border: Border.all(width: 1, color: Colors.grey),
              borderRadius: BorderRadius.circular(10),
            ),
            // child: Image(image: _networkImageSelected!, fit: BoxFit.fill,)
            child: _refereeSignaturePath == null || _refereeSignaturePath == null ?  Text("No signature found.", textAlign: TextAlign.center, style: TextStyle(color: Colors.grey),)  : Image(
              width: deviceSize.width,
              height: deviceSize.height,
              image: NetworkImage(_refereeSignaturePath!),
            ),
            
          )
          : SizedBox(),

          _signatureStatusSelected == 'signed' || (_signatureTypeSelected == 'referee' && _signatureStatusSelected == "sign" && _contactDetIdSelected == null) ? SizedBox() : Expanded(
            child: Signature(
              controller: _signatureController!
            ),
          ),
          _signatureStatusSelected == 'signed' || (_signatureTypeSelected == 'referee' && _signatureStatusSelected == "sign" && _contactDetIdSelected == null) ? SizedBox() : Container(
            decoration: const BoxDecoration(color: Color(0xFF607D8B)),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              mainAxisSize: MainAxisSize.max,
              children: <Widget>[
                IconButton(
                  icon: const Icon(Icons.undo),
                  color: Colors.white,
                  onPressed: () {
                    setState(() => _signatureController!.undo());
                  },
                  tooltip: 'Undo',
                ),
                IconButton(
                  icon: const Icon(Icons.redo),
                  color: Colors.white,
                  onPressed: () {
                    setState(() => _signatureController!.redo());
                  },
                  tooltip: 'Redo',
                ),
                
                //CLEAR CANVAS
                IconButton(
                  key: const Key('clear'),
                  icon: const Icon(Icons.clear),
                  color: Colors.white,
                  onPressed: () {
                    setState(() => _signatureController!.clear());
                  },
                  tooltip: 'Clear',
                ),

                //SHOW EXPORTED IMAGE IN NEW ROUTE //
                IconButton(
                  key: const Key('exportPNG'),
                  icon: const Icon(Icons.save_rounded),
                  color: Colors.white,
                  onPressed: () => _exportImage(),
                  tooltip: 'Save Changes',
                ),
              ] 
            ),
          ),
        ]
      ),
    );
  }
}