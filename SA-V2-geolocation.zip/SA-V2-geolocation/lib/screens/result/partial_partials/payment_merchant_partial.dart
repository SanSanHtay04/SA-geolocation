import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class PaymentMerchantPartial extends StatefulWidget {
  final Map<String, dynamic>? application;
  final Function() confirmPaidToMerchant;

  PaymentMerchantPartial({
    required this.application,
    required this.confirmPaidToMerchant
  });
  
  @override
  State<PaymentMerchantPartial> createState() => _PaymentMerchantPartialState();
}

class _PaymentMerchantPartialState extends State<PaymentMerchantPartial> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(children: [
        SizedBox(
          height: 10,
        ),
        Text(
          'PAYMENT MERCHANT',
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.teal[600]),
        ),

        widget.application != null && 
        widget.application!['contractStatusId'] > 8 && widget.application!['actualFirstPayment'] > 0 &&
        widget.application!['totalAmountPaid'] > 0 && widget.application!['totalPaidToMerchant'] <= 0 && 
          [0, 1, '0', '1'].indexOf(widget.application!['directSales']) >= 0 && ((widget.application!['cashBackAmount'] > 0 && widget.application!['cashBackDtConfirmedPaid'] != '') || !(widget.application!['cashBackAmount'] > 0))
          ? Column(
            children: [
              SizedBox(
                height: 5,
              ),
              Text('Do you want to use all cash received from customer (total amount of ${NumberFormat('#,###').format(widget.application!['actualFirstPayment'])} MMK) to pay dealer as partial payment of the equipment?', textAlign: TextAlign.center),
              SizedBox(
                height: 5,
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Theme.of(context).primaryColor,
                  minimumSize: const Size.fromHeight(35), // NEW
                ),
                child: Text("CONFIRM PAID TO MERCHANT", style: TextStyle(fontSize: 15,)),
                onPressed: widget.confirmPaidToMerchant,
              ),

              SizedBox(
                height: 10,
              ),
            ],
          )
          : SizedBox(),

        widget.application!['contractId'] != null && widget.application!['totalPaidToMerchant'] > 0
          ? Column(
              children: [
                SizedBox(
                  height: 5,
                ),
                Text("This contract was already paid to merchant with total amount ${NumberFormat('#,###').format(widget.application!['actualFirstPayment'])} MMK", textAlign: TextAlign.center),
                SizedBox(
                  height: 10,
                ),
              ],
            )  
          : SizedBox()
      ]),
    );
  }
}