import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:sales/widgets/deprecated/text_button_widget.dart';
import 'package:sales/widgets/item_info_widget.dart';

class ContractPartial extends StatefulWidget {
  final Map<String, dynamic>? application;
  final Function() createContract;

  ContractPartial(
      {required this.application, required this.createContract});

  @override
  State<ContractPartial> createState() => _ContractPartialState();
}

class _ContractPartialState extends State<ContractPartial> {

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(children: [
        SizedBox(
          height: 5,
        ),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(
            'CONTRACT',
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.teal[600]),
          ),
          widget.application == null
              ? SizedBox()
              : TextButtonWidget(
                text: widget.application!['contractId'] == null
                    ? "CREATE"
                    : "UPDATE",
                iconData: widget.application!['contractId'] == null
                    ? Icons.add
                    : Icons.edit,
                onTap: widget.createContract,
              ),
        ]),
        widget.application!['contractId'] == null
            ? SizedBox()
            : Column(
                children: [
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  ItemInfoWidget(
                    title: 'Contract N\u1d52',
                    value: widget.application!['contractNo'].toString(),
                  ),
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  ItemInfoWidget(
                    title: 'Contract Date',
                    value: DateFormat('dd/MM/yyyy').format(DateTime.parse(widget.application!['contractDate'])),
                  ),
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  ItemInfoWidget(
                    title: 'Default/System Following Pmt Date',
                    value: DateFormat('dd/MM/yyyy').format(DateTime.parse(widget.application!['defaultFollowingPaymentDate'] ?? '-/-')),
                  ),
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  ItemInfoWidget(
                    title: 'Adjusted Following Payment Date',
                    value: DateFormat('dd/MM/yyyy').format(DateTime.parse(widget.application!['followingPaymentDate'] ?? '-/-')),
                  ),
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  ItemInfoWidget(
                    title: 'Commission CA',
                    value: '${widget.application!['commissionBeneficiaryName'] ?? '-/-'}',
                  ),  
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  ItemInfoWidget(
                    title: 'Adjusted Days',
                    value: widget.application!['adjustmentDays'].toString(),
                  ),  
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                   ItemInfoWidget(
                    title: 'Remark',
                    value: widget.application!['contractRemark'] ?? '-/-',
                  ),  
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  SizedBox(
                    height: 10,
                  ),
                ],
              ),
      ]),
    );
  }
}