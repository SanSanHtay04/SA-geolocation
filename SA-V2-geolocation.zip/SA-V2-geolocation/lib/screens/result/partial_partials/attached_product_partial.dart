import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class AttachedProductPartial extends StatefulWidget {
  final Map<String, dynamic>? application;
  AttachedProductPartial({required this.application});

  @override
  State<AttachedProductPartial> createState() => _AttachedProductPartialState();
}

class _AttachedProductPartialState extends State<AttachedProductPartial> {
  

  @override
  Widget build(BuildContext context) {
    List<dynamic> attachedProducts = widget.application!['attachedProducts'];

    return Container(
      padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        children: [
          SizedBox(
            height: 5,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween, 
            children: [
              Text(
                'ATTACHED PRODUCTS',
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.teal[600]),
              ),
            ],
          ),
          widget.application!['assetId'] == null
            ? SizedBox()
            : Column(
                children: [
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),

                  attachedProducts.length > 0
                      ? Container(
                          child: ListView.separated(
                            shrinkWrap: true,
                            itemCount: attachedProducts.length,
                            separatorBuilder: (context, index) {
                              return Divider(height: 0,);
                            },
                            itemBuilder: (context, i) {
                              return ListTile(
                                dense: true,
                                // isThreeLine: true,
                                contentPadding: EdgeInsets.zero,
                                visualDensity: VisualDensity(
                                    horizontal: 0, vertical: -4),
                                title: Row(
                                  children: [
                                    Text("${i + 1}. "),
                                    Text(
                                      "[${attachedProducts[i]['productType'].toString().toUpperCase()}]",
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Text(
                                        " ${attachedProducts[i]['productName']}"),
                                  ],
                                ),
                                subtitle: Padding(
                                  padding: EdgeInsets.only(
                                      left: 15, top: 0, right: 0, bottom: 0),
                                  child: Column(
                                    mainAxisAlignment:
                                        MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      attachedProducts[i]
                                                  ['productTypeDetail'] !=
                                              null
                                          ? Text(attachedProducts[i]
                                                  ['productTypeDetail']
                                              .toString())
                                          : SizedBox(),
                                      Text(
                                          "${NumberFormat('#,###').format(attachedProducts[i]['productPrice'])} x ${attachedProducts[i]['quantity'].toString()} = ${NumberFormat('#,###').format(attachedProducts[i]['productPrice'] * attachedProducts[i]['quantity'])} MMK"),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                        )
                      : SizedBox(),
                ],
            ),
          
        ],
      ),
    ); 
  }
}