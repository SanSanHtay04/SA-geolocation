import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import 'package:sales/providers/application_document_provider.dart';
import 'package:sales/providers/document_type_provider.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/widgets/deprecated/alert_modal_bottom_widget.dart';
import 'package:sales/widgets/waiting_modal_bottom_widget.dart';

class DocsUploadPartial extends StatefulWidget {
  final Map<String, dynamic>? application;
  final Function? reloadApplicationDocuments;
  DocsUploadPartial({ @required this.application, @required this.reloadApplicationDocuments });

  @override
  _DocsUploadPartialState createState() => _DocsUploadPartialState();
}

class _DocsUploadPartialState extends State<DocsUploadPartial> {
  bool _isLoading = false;
  File? _fileSelected;
  String? _filePathSelected;

  final picker = ImagePicker();
  
  int? _documentTypeIdSelected;
  List<dynamic> _documentTypes = [];
  var _uploadDocumentRemarkController = TextEditingController();

  Future<void> _getDocumentTypes() async {
    showWaitingModal(context: context, message: "List of document types are loading...", onWaiting: () async {
      try {
        await Provider.of<DocumentTypeProvider>(context, listen: false).getDocumentTypes().then((value) {
          setState(() {
            List<dynamic> _tempDocumentTypes = Provider.of<DocumentTypeProvider>(context, listen: false).items;

            final productCategorySubType1 = widget.application!['productCategorySubType1'];
            final isSecondHandProduct = widget.application!['isSecondHandProduct'];
            _tempDocumentTypes.forEach((docType) { 
              List<String> listProductCategoryApplied = docType['sa_app_applied_product_categories'].toString().split(",");
              final index = listProductCategoryApplied.indexWhere((element) => element == productCategorySubType1);
              if (index >= 0) {
                if (isSecondHandProduct == 0 && (docType['sa_app_applied_product_statuses'] == 'new' || docType['sa_app_applied_product_statuses'] == 'new-old')) {
                  this._documentTypes.add(docType);
                }
                if (isSecondHandProduct == 1 && (docType['sa_app_applied_product_statuses'] == 'old' || docType['sa_app_applied_product_statuses'] == 'new-old')) {
                  this._documentTypes.add(docType);
                }
              }
            });
          });
        });
      } catch (error) {
        print(error.toString());
      }
    });
  }

  Future<bool> checkAndRequestCameraPermissions() async {
    var status = await Permission.camera.status;
    if (status != PermissionStatus.granted) {
        Map<Permission, PermissionStatus> statuses = await [
          Permission.camera
        ].request();
      return statuses[Permission.camera] == PermissionStatus.granted;
    } else {
      return true;
    }
  }

  Future<void> _openCamera() async {
    if (await checkAndRequestCameraPermissions()) {
      final ImagePicker _picker = ImagePicker();
      final imageFile = await _picker.pickImage(
        source: ImageSource.camera,
        // maxWidth: 600,
      );
      CroppedFile? croppedFile;

      if (imageFile != null) {
        croppedFile = await ImageCropper().cropImage(
          sourcePath: imageFile.path,
          aspectRatioPresets: [
            CropAspectRatioPreset.square,
            CropAspectRatioPreset.ratio3x2,
            CropAspectRatioPreset.original,
            CropAspectRatioPreset.ratio4x3,
            CropAspectRatioPreset.ratio16x9
          ],
          uiSettings: [
            AndroidUiSettings(
                toolbarTitle: 'Cropper',
                toolbarColor: Colors.lightBlue,
                toolbarWidgetColor: Colors.white,
                initAspectRatio: CropAspectRatioPreset.original,
                lockAspectRatio: false),
            IOSUiSettings(
              minimumAspectRatio: 1.0,
            )
          ]
        );
      }

      if (croppedFile == null) {
        return;
      }

      setState(() {
        _fileSelected = File(croppedFile!.path);
      });

      File savedImage = File(croppedFile.path);
      _filePathSelected = '${savedImage.path}';
    }
  }

  Future<void> _choosePictureFromGallery() async {
    if (await checkAndRequestCameraPermissions()) {
      final imageFile = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        // maxWidth: 600,
      );

      CroppedFile? croppedFile;
      if (imageFile != null) {
        croppedFile = await ImageCropper().cropImage(
          sourcePath: imageFile.path,
          compressQuality: 100,
          uiSettings: [
            AndroidUiSettings(
                toolbarTitle: 'Cropper',
                toolbarColor: Colors.lightBlue,
                toolbarWidgetColor: Colors.white,
                initAspectRatio: CropAspectRatioPreset.original,
                lockAspectRatio: false),
            IOSUiSettings(
              minimumAspectRatio: 1.0,
            )
          ]
        );
      }

      if (croppedFile == null) {
        return;
      }

      setState(() {
        _fileSelected = File(croppedFile!.path);
      });

      File savedImage = File(croppedFile.path);
      _filePathSelected = '${savedImage.path}';
    }
  }

  void _uploadDocument() async {
    setState(() {
      _isLoading = true;
    });

    Map<String, dynamic> returnedData;
    
    await Provider.of<ApplicationDocumentProvider>(context, listen: false)
      .createApplicationDocumentFile(widget.application!['applicationId'], {
        'document_type_id': _documentTypeIdSelected.toString(),
        'file': _filePathSelected,
        'remark': _uploadDocumentRemarkController.text.trim(),
      });

    final _message = Provider.of<ApplicationDocumentProvider>(context, listen: false).responseMessage;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) {
        return AlertModalBottomWidget(_message, () async {
          Navigator.of(context).pop();
          Navigator.of(context).pop();
          widget.reloadApplicationDocuments!();
        });
      }
    );

    setState(() {
      _isLoading = false;
    });
    

  }

  void _initData() async {
    await _getDocumentTypes();
  }

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) { 
      _initData();
    });
    
    super.initState();
  }

  @override
  void dispose() {
    _uploadDocumentRemarkController.dispose();
    super.dispose();
  }
  

  @override
  Widget build(BuildContext context) {
    var width = MediaQuery.of(context).size.width;

    // Document Type //
    Widget _buildDocumentTypeButton() {
      return DropdownButtonFormField<int>(
        decoration: InputDecoration(
          labelText: "Document Type",
          labelStyle: Theme.of(context).inputDecorationTheme.labelStyle,
          errorStyle: Theme.of(context).inputDecorationTheme.errorStyle,
        ), 
        items: _documentTypes.map((item) {
          return DropdownMenuItem<int>(
            value: item['id'],
            child: Text(item['name']),
          );
        }).toList(),
        value: _documentTypeIdSelected,
        onChanged: (int? id) {
          setState(() {
            _documentTypeIdSelected = id;
          });
        },
        validator: (value) {
          if (_documentTypeIdSelected == null) {
            return "Please choose document type";
          } 
          return null;
        },
        onSaved: (value) {},
      );
    }

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(
          'UPLOAD DOCUMENT',
          style: TextStyle(color: Colors.white),
        ),
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: ModalProgressHUD(
        inAsyncCall: _isLoading,
        opacity: 0.5,
        progressIndicator: CircularProgressIndicator(
          valueColor: new AlwaysStoppedAnimation<Color>(
            context.getColorScheme().primary,
          ),
        ),
        child: Container(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                Expanded(
                  child: Container(
                    child: SingleChildScrollView(
                      physics: AlwaysScrollableScrollPhysics(),
                      child: Column(
                        children: <Widget>[
                          _buildDocumentTypeButton(),
                          SizedBox(height: 5,),
                          TextFormField(
                            maxLines: 3,
                            decoration: InputDecoration(
                              labelText: "Remark",
                              suffixIcon: IconButton(
                                icon: Icon(Icons.clear), 
                                onPressed: () => _uploadDocumentRemarkController.clear(),
                              ),
                            ),
                            textInputAction: TextInputAction.done,
                            controller: _uploadDocumentRemarkController,
                            onSaved: (value) {
                            },
                          ),
                          SizedBox(height: 10,),
                          Container(
                            width: width,
                            height: 250,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.all(Radius.circular(10)), 
                              border: Border.all(color: Theme.of(context).primaryColor),
                            ),
                            margin: EdgeInsets.only(bottom: 5),
                            child: Container(
                              alignment: Alignment.center,
                              child: _fileSelected == null ? Text('There no image selected', style: TextStyle(color: Colors.grey,), textAlign: TextAlign.center,) : Image(
                                image: FileImage(_fileSelected!), fit: BoxFit.fitHeight,
                                loadingBuilder:(BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                                  if (loadingProgress == null) return child;
                                    return Center(
                                      child: CircularProgressIndicator(
                                      ),
                                    );
                                },
                              ),
                            ),
                          ),

                          SizedBox(
                            height: 10,
                          ),

                          _documentTypeIdSelected == null ? SizedBox() : Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            mainAxisSize: MainAxisSize.max,
                            children: <Widget>[
                              IconButton(
                                key: const Key('openGallery'),
                                icon: const Icon(Icons.image_rounded),
                                color: Colors.teal,
                                onPressed: _choosePictureFromGallery,
                                tooltip: 'Gallery',
                                iconSize: 45,
                              ),

                              IconButton(
                                key: const Key('openCamera'),
                                icon: const Icon(Icons.camera_alt_outlined),
                                color: Colors.teal,
                                onPressed: _openCamera,
                                tooltip: 'Camera',
                                iconSize: 45,
                              ),

                              IconButton(
                                key: const Key('clear'),
                                icon: const Icon(Icons.clear_rounded),
                                color: Colors.red,
                                onPressed: () {
                                  setState(() {
                                    _fileSelected = null;
                                    _filePathSelected = "";
                                  });
                                },
                                tooltip: 'Clear',
                                iconSize: 45,
                              ),
                            ] 
                          ),


                          SizedBox(
                            height: 10,
                          ),

                          SizedBox(height: 5,),

                          _filePathSelected == null || _filePathSelected == "" ? SizedBox() : ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Theme.of(context).primaryColor,
                              minimumSize: const Size.fromHeight(35), // NEW
                            ),
                            child: Text("UPLOAD", style: TextStyle(fontSize: 15,)),
                            onPressed: _uploadDocument,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            )
          ),
        ),
      ),
    );
  }
}