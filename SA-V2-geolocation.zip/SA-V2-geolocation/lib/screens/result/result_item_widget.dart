import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class ResultItemWidget extends StatefulWidget {
  final Map<String, dynamic> application;
  final Function onPressProspect;

  ResultItemWidget(
    { Key? key,
      required this.application,
      required this.onPressProspect,
    });

  @override
  State<ResultItemWidget> createState() => _ResultItemWidgetState();
}

class _ResultItemWidgetState extends State<ResultItemWidget> {
  @override
  Widget build(BuildContext context) {
    return ListTile(
      isThreeLine: true,
      title: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text('${widget.application['customerFullName']}', style: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold),),
              SizedBox(width: 5,),
              Text('(${widget.application['gender'] == 'f' ? 'Female' : 'Male'})', style: TextStyle(color: Colors.blue, fontSize: 12),),
            ],
          ),
          AutoSizeText('[${widget.application['applicationStatus']}]', style: TextStyle(fontSize: 12, color: widget.application['applicationStatus'] == 'Rejected' ? Colors.red : Colors.teal[400], fontWeight: FontWeight.bold),),
        ],
      ),
      subtitle: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '- Mob: ${widget.application['phoneNo1']} ${(widget.application['phoneNo2'] != null && widget.application['phoneNo2'] != "") ? ('- ' + widget.application['phoneNo2']) : ''}',
                style: TextStyle(fontSize: 12),
              ),
              Text(
                '- Product: ${widget.application['productName']}',
                style: TextStyle(fontSize: 12),
              ),
            ],
          ),
          
          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '- Submitted: ${ widget.application['dtSubmitted'] != null ? DateFormat('dd/MM/yyyy HH:mm').format(DateTime.parse(widget.application['dtSubmitted'].toString())) : '-/-'}',
                style: TextStyle(fontSize: 12),
              ),
              Text(
                '- Finalized: ${DateFormat('dd/MM/yyyy HH:mm').format(DateTime.parse(widget.application['dtUWEnded'].toString()))}',
                style: TextStyle(fontSize: 12),
              ),
              Text(
                '- APP ID: ${widget.application['applicationId'] ?? '-/-'}  -  Contract N\u1d52: ${widget.application['contractNo'] ?? '-/-'}',
                style: TextStyle(fontSize: 12),
              ),
              Text(
                '- Designated To Person: ${widget.application['personDesignatedToName'] ?? '-/-'}',
                style: TextStyle(fontSize: 12),
              ),
            ],
          ),
          
          Divider(color: Colors.blue, thickness: 0.75,),
        ],
      ),
      onTap:  () {
        widget.onPressProspect(widget.application['prospectId'], widget.application['applicationId'], widget.application['contractId']);
      },
    ); 
  }
}