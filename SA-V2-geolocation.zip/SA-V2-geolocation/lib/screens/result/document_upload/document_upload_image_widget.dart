import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/providers/application_document_provider.dart';
import 'package:sales/widgets/confirmation_modal_bottom_widget.dart';
import 'package:sales/widgets/deprecated/alert_modal_bottom_widget.dart';
import 'package:sales/widgets/waiting_modal_bottom_widget.dart';

class DocumentUploadImageWidget extends StatefulWidget {
  final Map<String, dynamic> documentUpload;
  final Function() getDocumentUploadList;

  DocumentUploadImageWidget({ Key? key,
    required this.documentUpload,
    required this.getDocumentUploadList
  });

  @override
  State<DocumentUploadImageWidget> createState() => _DocumentUploadImageWidgetState();
}

class _DocumentUploadImageWidgetState extends State<DocumentUploadImageWidget> {

  _deleteAppUpload() {
    String? resultMessage = 'Something went wrong.';
    showConfirmation(context: context, message: "Are you sure you want to delete the selected upload?", onYes: () async {
      await showWaitingModal(context: context, message: "The selected upload is deleting...", onWaiting: () async {
        try {
          await Provider.of<ApplicationDocumentProvider>(context, listen: false)
            .deleteApplicationDocumentFile(widget.documentUpload['application_id'], widget.documentUpload['id']);
          resultMessage = Provider.of<ApplicationDocumentProvider>(context, listen: false).responseMessage!;
        } catch (error) {
          resultMessage = error.toString();
        }   
      });
      await showAlertModal(context: context, message: resultMessage, onDismiss: () async {
        await widget.getDocumentUploadList();
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          padding: EdgeInsets.all(6),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.teal.shade300, style: BorderStyle.solid),
            borderRadius: BorderRadius.circular(10),
          ), 
          child: Stack(
            children: [
              Container(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: widget.documentUpload['preview'] != null && widget.documentUpload['preview'] != ""
                      ? SizedBox(width: 100, height: 100, child: Image.memory(base64Decode(widget.documentUpload['preview'].toString().split(',').last), fit: BoxFit.fill,),)
                      : Center(child: Text("No Image", textAlign: TextAlign.center, style: TextStyle(color: Colors.grey),),)
                ),
              ),
              Positioned(
                top: 6.0,
                right: 6.0,
                child: Align(
                  child: InkWell(
                    onTap: _deleteAppUpload,
                    child: CircleAvatar(
                      radius: 10,
                      backgroundColor: Colors.red,
                      child: Icon(Icons.close, color: Colors.white, size: 14,),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(width: 5,),
      ],
    );
  }
}