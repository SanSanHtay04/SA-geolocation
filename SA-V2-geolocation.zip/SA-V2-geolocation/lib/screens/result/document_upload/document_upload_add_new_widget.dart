import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:sales/providers/application_document_provider.dart';
import 'package:sales/utils/permission_helper.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/widgets/confirmation_modal_bottom_widget.dart';
import 'package:sales/widgets/deprecated/alert_modal_bottom_widget.dart';
import 'package:sales/widgets/permission_required_widget.dart';
import 'package:sales/widgets/waiting_modal_bottom_widget.dart';

class DocumentUploadAddNewWidget extends StatefulWidget {
  final int applicationId;
  final Map<String, dynamic> documentType;
  final Function() getDocumentUploadList;

  DocumentUploadAddNewWidget({
    Key? key,
    required this.applicationId,
    required this.documentType,
    required this.getDocumentUploadList,
  });

  @override
  State<DocumentUploadAddNewWidget> createState() => _DocumentUploadAddNewWidgetState();
}

class _DocumentUploadAddNewWidgetState extends State<DocumentUploadAddNewWidget> {
  final _aspectRatioPresets = [
    CropAspectRatioPreset.square,
    CropAspectRatioPreset.ratio3x2,
    CropAspectRatioPreset.original,
    CropAspectRatioPreset.ratio4x3,
    CropAspectRatioPreset.ratio16x9,
  ];

  List<PlatformUiSettings> get _cropUiSettings => [
        AndroidUiSettings(
          toolbarTitle: 'Cropper',
          toolbarColor: Theme.of(context).primaryColor,
          toolbarWidgetColor: Colors.white,
          initAspectRatio: CropAspectRatioPreset.original,
          lockAspectRatio: false,
        ),
        IOSUiSettings(
          minimumAspectRatio: 1.0,
        )
      ];

  Future<void> _choosePicture(ImageSource source) async {
    final _pickedImage = await ImagePicker().pickImage(
      source: source,
      imageQuality: 50,
    );

    if (_pickedImage != null) {
      AppLogger.i("PICKED IMAGE LENGTH : ${_pickedImage.length()}");

      CroppedFile? croppedFile = await ImageCropper().cropImage(
        sourcePath: _pickedImage.path,
        aspectRatioPresets: _aspectRatioPresets,
        uiSettings: _cropUiSettings,
      );

      if (croppedFile == null) {
        return;
      }
      await PermissionHelper().requestStoragePermission(
        onGranted: () async {
          File savedImage = File(croppedFile.path);
          String _filePathSelected = '${savedImage.path}';

          String? resultMessage = 'Something went wrong.';
          showConfirmation(
              context: context,
              message: "Are you sure you want to upload the selected image?",
              onYes: () async {
                await showWaitingModal(
                    context: context,
                    message: "New upload is creating...",
                    onWaiting: () async {
                      try {
                        Map<String, dynamic> recDocumentUpload = {
                          'document_type_id': widget.documentType['id'].toString(),
                          'file': _filePathSelected,
                          'remark': "",
                        };

                        print('recDocumentUpload: $recDocumentUpload');

                        await Provider.of<ApplicationDocumentProvider>(context, listen: false).createApplicationDocumentFile(widget.applicationId, recDocumentUpload);

                        setState(() {
                          resultMessage = Provider.of<ApplicationDocumentProvider>(context, listen: false).responseMessage;
                        });
                      } catch (error) {
                        resultMessage = error.toString();
                      }
                    });
                await showAlertModal(
                    context: context,
                    message: resultMessage,
                    onDismiss: () async {
                      await widget.getDocumentUploadList();
                    });
              });
        },
        onNotGranted: () async {
          await showStoragePermissionRequired(context);
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    List<String> listImageSourceApplied = widget.documentType['sa_app_applied_image_sources'].toString().split(",");

    final cameraIndex = listImageSourceApplied.indexWhere((element) => element == "camera");
    final galleryIndex = listImageSourceApplied.indexWhere((element) => element == "gallery");

    return Row(
      children: [
        Container(
          padding: EdgeInsets.all(6),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.teal.shade300, style: BorderStyle.solid),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Container(
            width: 100,
            height: 100,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                cameraIndex >= 0
                    ? IconButton(
                        onPressed: () async {
                          await _choosePicture(ImageSource.camera);
                        },
                        icon: Icon(
                          Icons.camera_alt_rounded,
                          color: Colors.blue,
                        ),
                      )
                    : SizedBox(),
                galleryIndex >= 0
                    ? IconButton(
                        onPressed: () async {
                          await _choosePicture(ImageSource.gallery);
                        },
                        icon: Icon(Icons.image_rounded, color: Colors.blue),
                      )
                    : SizedBox(),
              ],
            ),
          ),
        ),
        SizedBox(
          width: 5,
        ),
      ],
    );
  }
}
