
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/providers/application_document_provider.dart';
import 'package:sales/providers/document_type_provider.dart';
import 'package:sales/screens/result/document_upload/document_upload_add_new_widget.dart';
import 'package:sales/screens/result/document_upload/document_upload_image_widget.dart';
import 'package:sales/widgets/deprecated/text_button_widget.dart';
import 'package:sales/widgets/waiting_modal_bottom_widget.dart';

class DocumentUploadsParital extends StatefulWidget {
  final Map<String, dynamic>? application;

  DocumentUploadsParital({
    required this.application
  });

  @override
  State<DocumentUploadsParital> createState() => _DocumentUploadsParitalState();
}

class _DocumentUploadsParitalState extends State<DocumentUploadsParital> {
  bool _isDocUploadCompleted = false;
  List<Map<String, dynamic>> _documentTypes = [];
  List<Map<String, dynamic>> _documentUploads = [];

  Future<void> _getDocumentUploadList() async {
    _documentTypes = [];
    showWaitingModal(context: context, message: "List of document uploads are loading...", onWaiting: () async {
      try {
        await Provider.of<DocumentTypeProvider>(context, listen: false).getDocumentTypes().then((value) async {
          setState(() {
            List<dynamic> _tempDocumentTypes = Provider.of<DocumentTypeProvider>(context, listen: false).items;

            final productCategorySubType1 = widget.application!['productCategorySubType1'];
            final productStatus = widget.application!['isSecondHandProduct'] == 0 ? 'new' : 'old';
            _tempDocumentTypes.forEach((docType) { 
              List<String> listAppliedProductCategories = docType['sa_app_applied_product_categories'].toString().split(",");
              List<String> listAppliedProductStatuses = docType['sa_app_applied_product_statuses'].toString().split(",");
             
              final productCategoryIndex = listAppliedProductCategories.indexWhere((element) => element == productCategorySubType1);
              if (productCategoryIndex >= 0) {
                if (productCategorySubType1 == 'moto') {
                  final productStatusIndex = listAppliedProductStatuses.indexWhere((element) => element == productStatus);
                  if (productStatusIndex >= 0) {
                    this._documentTypes.add(docType);
                  }
                } else {
                  this._documentTypes.add(docType);
                }
              }
            });
          });

          await _getDocUploads();
          for (var i=0; i<this._documentTypes.length; i++) {
            List<Map<String, dynamic>> docTypes = [];
            this._documentUploads.forEach((documentUpload) { 
              if (_documentTypes[i]['id'] == documentUpload['document_type_id']) {
                docTypes.add(documentUpload);
              }
            });
            this._documentTypes[i]['documentUploads'] = docTypes;
          }
        });
      } catch (error) {
        print(error.toString());
      }
    });
  }

  Future<void> _getDocUploads() async {
    try {
      await Provider.of<ApplicationDocumentProvider>(context, listen: false)
          .getApplicationDocumentFiles(widget.application!['applicationId'])
          .then((value) {
        setState(() {
          _documentUploads = Provider.of<ApplicationDocumentProvider>(context, listen: false).items;
        });
      });
    } catch (error) {
      print(error.toString());
    }
  }

  void _initData() async {
    await _getDocumentUploadList();
  }
  
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) { 
      _initData();
    });
    
    super.initState();
  }
  
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(15, 10, 15, 0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(
            '9. UPLOAD FILES',
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.teal[600]),
          ),
          TextButtonWidget(
            text: "Reload",
            iconData: Icons.refresh_rounded,
            onTap: _getDocumentUploadList,
          )
        ]),
        Divider(
          thickness: 1.5,
        ),
        Expanded(
          child: Container(
            padding: EdgeInsets.fromLTRB(0, 5, 0, 0),
            child: ListView.builder(
              shrinkWrap: false,
              itemCount: _documentTypes.length,
              itemBuilder: (context, i) {
                final documentUploads = _documentTypes[i]['documentUploads'];
                final documentUploadLength = documentUploads != null ? documentUploads.length : 0;
                final documentUploadLimited = _documentTypes[i]['sa_app_upload_limited'] ?? 0;
                return Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        CircleAvatar(
                          child: Text("${i+1}", style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold,), textAlign: TextAlign.center,),
                          radius: 14,
                          backgroundColor: Colors.teal[500],
                          foregroundColor: Colors.white,
                        ),
                        SizedBox(width: 8,),
                        Text('${_documentTypes[i]['name']} ', style: TextStyle(fontWeight: FontWeight.bold),),
                        Text('${_documentTypes[i]['sa_app_required'] == 1 ? "*" : ""}', style: TextStyle(color: Colors.red),),
                      ],
                    ),
                    SizedBox(height: 3,),
                    Container(
                      padding: EdgeInsets.only(left: 20),
                      height: 110,
                      child: ListView.builder(
                        shrinkWrap: true,
                        scrollDirection: Axis.horizontal,
                        itemCount: documentUploadLength >= documentUploadLimited ? documentUploadLength : documentUploadLimited,
                        itemBuilder: (BuildContext context, int j) {
                          if (documentUploadLength >= documentUploadLimited) {
                            return DocumentUploadImageWidget(documentUpload: documentUploads[j], getDocumentUploadList: this._getDocumentUploadList,);
                          } else {
                            if (documentUploadLength > 0) {
                              if (j < documentUploadLength) {
                                return DocumentUploadImageWidget(documentUpload: documentUploads[j], getDocumentUploadList: this._getDocumentUploadList,);
                              } else {
                                return DocumentUploadAddNewWidget(applicationId: widget.application!['applicationId'], documentType: _documentTypes[i], getDocumentUploadList: this._getDocumentUploadList,);
                              }
                            } else {
                              return DocumentUploadAddNewWidget(applicationId: widget.application!['applicationId'], documentType: _documentTypes[i], getDocumentUploadList: this._getDocumentUploadList,);
                            }
                          }
                        }
                      ),
                    ),
                    // SizedBox(height: 10,),
                    Divider(),
                  ],
                );
              }
            ),
          ),
        ),
      ]),
    );
  }
}