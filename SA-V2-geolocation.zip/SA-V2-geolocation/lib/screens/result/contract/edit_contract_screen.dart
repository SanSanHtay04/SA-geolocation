import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:sales/providers/contract_provider.dart';
import 'package:sales/providers/user_provider.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/confirmation_modal_bottom_widget.dart';
import 'package:sales/widgets/copyright_notice.dart';
import 'package:sales/widgets/deprecated/alert_modal_bottom_widget.dart';
import 'package:sales/widgets/deprecated/button_widget.dart';
import 'package:sales/widgets/deprecated/date_picker_widget.dart';
import 'package:sales/widgets/deprecated/text_form_input.dart';
import 'package:sales/widgets/item_info_widget.dart';
import 'package:sales/widgets/selected_field/selected_field.dart';
import 'package:sales/widgets/waiting_modal_bottom_widget.dart';

class EditContractScreen extends StatefulWidget {
  static const routeName = '/edit-contract';
  final int? customerId;
  final int? contractId;
  final Map<String, dynamic>? application;

  EditContractScreen({
    required this.customerId,
    required this.contractId,
    required this.application,
  });

  @override
  State<EditContractScreen> createState() => _EditContractScreenState();
}

class _EditContractScreenState extends State<EditContractScreen> {
  int _daysDiff = 0;
  var _daysPostponed = 0;
  var _postponedAmount = 0;
  var _absDaysPostponed = 0;
  var _absPostponedAmount = 0;
  var _commissionBeneficiarySelected;
  List<Map<String, dynamic>> _cas = [];
  Map<String, dynamic>? _newContract;
  final GlobalKey<FormState> _formKey = GlobalKey();
  late Map<String, dynamic> _formData;
  Map<String, dynamic> _formDataDefault = {
    'followingPaymentDate': null,
    'adjustmentDays': '',
    'adjustmentDiscountOrFee': '',
    'contractRemark': '',
    'commissionBeneficiary': null,
  };

  // contractDate //
  DateTime _dtContractDateSelected = DateTime.now();

  // defaultFollowingDate //
  DateTime _dtDefaultFollowingPaymentDateSelected = DateTime.now();

  // followingPaymentDate //
  DateTime _dtFollowingPaymentDateSelected = DateTime.now();
  final _followingPaymentDateFocusNode = FocusNode();
  final _followingPaymentDateController = TextEditingController();

  void _setFollowingPaymentDate(String value) {
    setState(() {
      _formData['followingPaymentDate'] = value;
      _dtFollowingPaymentDateSelected = DateFormat('yyyy-MM-dd').parse(value);
      this._calculateDaysDifference();
    });
  }

  // contractRemark //
  final _contractRemarkController = TextEditingController();

  void _setContractRemark(String? value) {}

  _calculateDaysDifference() {
    _daysDiff = _dtFollowingPaymentDateSelected
        .difference(_dtContractDateSelected)
        .inDays;
    _daysPostponed = _dtFollowingPaymentDateSelected
        .difference(_dtDefaultFollowingPaymentDateSelected)
        .inDays;
    _postponedAmount = 0;
    if (_daysPostponed != 0) {
      var annualInterestRate = widget.application!['isZeroCost'] > 0
          ? 0.75
          : (widget.application!['interestRate'] / 100);
      var dailyNomInterestRate = annualInterestRate / 365;
      if (_daysPostponed > 0) {
        _postponedAmount = ((dailyNomInterestRate *
                        _daysPostponed *
                        widget.application!['amountFinanced']) /
                    1000)
                .ceil() *
            1000;
      } else {
        _postponedAmount = ((dailyNomInterestRate *
                        _daysPostponed *
                        widget.application!['amountFinanced']) /
                    1000)
                .floor() *
            1000;
      }
    }

    _absDaysPostponed = _daysPostponed.abs();
    _absPostponedAmount = _postponedAmount.abs();
  }

  _clearAllFields() {
    _initData();
  }

  Future<void> _getCAs(int? posId) async {
    await showWaitingModal(
        context: context,
        message: "Contract information is loading...",
        onWaiting: () async {
          try {
            await Provider.of<UserProvider>(context, listen: false)
                .getUserAssignedToPOS(posId!)
                .then((value) {
              setState(() {
                _cas = Provider.of<UserProvider>(context, listen: false).items;
              });
            });
          } catch (error) {
            print(error.toString());
          }
        });
  }

  _createContract() {
    if (!_formKey.currentState!.validate()) {
      // Invalid!
      return;
    }
    _formKey.currentState!.save();

    String? resultMessage = 'Something went wrong.';
    showConfirmation(
        context: context,
        message: "Are you sure you want to create new contract?",
        onYes: () async {
          await showWaitingModal(
              context: context,
              message: "New contract is creating...",
              onWaiting: () async {
                try {
                  Map<String, dynamic> _recContract = {
                    'prospectId': widget.application!['prospectId'],
                    'simulationId': widget.application!['simulationId'],
                    'packageId': widget.application!['packageId'],
                    'contractDate': DateFormat('yyyy-MM-dd')
                        .format(_dtContractDateSelected),
                    'defaultFollowingPaymentDate': DateFormat('yyyy-MM-dd')
                        .format(_dtDefaultFollowingPaymentDateSelected),
                    'followingPaymentDate': DateFormat('yyyy-MM-dd')
                        .format(_dtFollowingPaymentDateSelected),
                    'adjustmentDays': _daysPostponed,
                    'adjustmentDiscountOrFee': _postponedAmount,
                    'contractRemark': _contractRemarkController.text.trim(),
                    'commissionBeneficiary':
                        _commissionBeneficiarySelected['userId'],
                  };

                  await Provider.of<ContractProvider>(context, listen: false)
                      .createRecord(widget.customerId, _recContract)
                      .then((value) {
                    setState(() {
                      _newContract =
                          Provider.of<ContractProvider>(context, listen: false)
                              .item;
                      resultMessage =
                          Provider.of<ContractProvider>(context, listen: false)
                              .responseMessage;
                    });
                  });
                } catch (error) {
                  setState(() {
                    resultMessage = error.toString();
                  });
                }
              });
          await showAlertModal(
              context: context,
              message: resultMessage,
              onDismiss: () {
                Navigator.pop(context);
              });
        });
  }

  _editContract() {
    if (!_formKey.currentState!.validate()) {
      // Invalid!
      return;
    }
    _formKey.currentState!.save();
    String? _message = 'Something went wrong.';
    showConfirmation(
        context: context,
        message:
            "Are you sure you want to update contract '${widget.application!['contractNo']}'?",
        onYes: () async {
          await showWaitingModal(
              context: context,
              message: "The selected contract is updating...",
              onWaiting: () async {
                try {
                  FocusScope.of(context).requestFocus(new FocusNode());
                  Map<String, dynamic> _recContract = {
                    'contractId': widget.application!['contractId'],
                    'followingPaymentDate': DateFormat('yyyy-MM-dd')
                        .format(_dtFollowingPaymentDateSelected),
                    'adjustmentDays': _daysPostponed,
                    'adjustmentDiscountOrFee': _postponedAmount,
                    'contractRemark': _contractRemarkController.text.trim(),
                    'applicationId': widget.application!['applicationId'],
                    'commissionBeneficiary':
                        _commissionBeneficiarySelected['userId'],
                  };

                  await Provider.of<ContractProvider>(context, listen: false)
                      .editRecord(
                          widget.customerId, widget.contractId, _recContract)
                      .then((value) {
                    setState(() {
                      _newContract =
                          Provider.of<ContractProvider>(context, listen: false)
                              .item;
                      _message =
                          Provider.of<ContractProvider>(context, listen: false)
                              .responseMessage;
                    });
                  });
                } catch (error) {
                  setState(() {
                    _message = error.toString();
                  });
                }
              });
          await showAlertModal(
              context: context,
              message: _message,
              onDismiss: () {
                Navigator.pop(context);
              });
        });
  }

  void _initData() async {
    await _getCAs(widget.application!['posId']);
    if (widget.application!['contractId'] != null &&
        widget.application!['contractId'] != '') {
      setState(() {
        _contractRemarkController.text =
            widget.application!['contractRemark'] ?? '';
        if (widget.application!['contractDate'] != null) {
          _dtContractDateSelected = DateFormat('yyyy-MM-dd')
              .parse(widget.application!['contractDate']);
        }

        if (widget.application!['defaultFollowingPaymentDate'] != null) {
          _dtDefaultFollowingPaymentDateSelected = DateFormat('yyyy-MM-dd')
              .parse(widget.application!['defaultFollowingPaymentDate']);
        }

        if (widget.application!['followingPaymentDate'] != null) {
          _dtFollowingPaymentDateSelected = DateFormat('yyyy-MM-dd')
              .parse(widget.application!['followingPaymentDate']);
          _followingPaymentDateController.text = DateFormat('dd/MM/yyyy')
              .format(
                  DateTime.parse(widget.application!['followingPaymentDate']));
        }

        _formDataDefault = Map<String, dynamic>.from({
          'contractDate': widget.application!['contractDate'],
          'followingPaymentDate': widget.application!['followingPaymentDate'],
          'adjustmentDays': widget.application!['adjustmentDays'],
          'adjustmentDiscountOrFee':
              widget.application!['adjustmentDiscountOrFee'],
          'contractRemark': widget.application!['contractRemark'],
          'commissionBeneficiary': widget.application!['commissionBeneficiary'],
        });
        _formData = Map<String, dynamic>.from(_formDataDefault);
        this._calculateDaysDifference();
      });
    } else {
      _dtDefaultFollowingPaymentDateSelected = DateFormat('yyyy-MM-dd')
          .parse(widget.application!['initialDefaultFollowingPaymentDate']);
      _dtFollowingPaymentDateSelected = DateFormat('yyyy-MM-dd')
          .parse(widget.application!['defaultFollowingPaymentDate']);
      _followingPaymentDateController.text = DateFormat('dd/MM/yyyy').format(
          DateTime.parse(widget.application!['defaultFollowingPaymentDate']));
      _contractRemarkController.text = "";
      _formData = Map<String, dynamic>.from(_formDataDefault);
      this._calculateDaysDifference();
    }

    this._cas.forEach((item) {
      if (item['userId'] == widget.application!['commissionBeneficiary']) {
        setState(() {
          _commissionBeneficiarySelected = item;
        });
      }
    });
  }

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      _initData();
    });

    super.initState();
  }

  @override
  void dispose() {
    // followingPaymentDate //
    _followingPaymentDateFocusNode.dispose();
    _followingPaymentDateController.dispose();

    // contractRemark //
    _contractRemarkController.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(
          widget.contractId == null ? 'CREATE CONTRACT' : 'UPDATE CONTRACT',
          style: TextStyle(color: Colors.white),
        ),
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: Padding(
        padding: EdgeInsets.all(10),
        child: Column(children: [
          Expanded(
            child: Container(
              child: Column(
                children: [
                  Expanded(
                    child: Form(
                      key: _formKey,
                      autovalidateMode: AutovalidateMode.always,
                      child: SingleChildScrollView(
                        child: Column(
                          children: [
                            SizedBox(
                              height: 5,
                            ),

                            // contractWorkPlaceId //
                            ItemInfoWidget(
                              title: 'Branch',
                              value: (widget.application!['person_created']
                                          ['workPlaceShortName'] ??
                                      '') +
                                  " (" +
                                  (widget.application!['person_created']
                                          ['workPlaceCode'] ??
                                      '') +
                                  ")",
                            ),
                            Divider(),

                            // contractNo //
                            widget.application!['contractNo'] != ''
                                ? ItemInfoWidget(
                                    title: 'Contract N\u1d52',
                                    value: (widget.application!['contractNo'] ??
                                        ''),
                                  )
                                : SizedBox(),
                            widget.application!['contractNo'] != ''
                                ? Divider()
                                : SizedBox(),

                            // contractDate //
                            widget.application!['contractDate'] != ''
                                ? ItemInfoWidget(
                                    title: 'Contract Date',
                                    value: (widget
                                                .application!['contractDate'] !=
                                            null
                                        ? DateFormat('dd/MM/yyyy').format(
                                            DateTime.parse(widget
                                                .application!['contractDate']))
                                        : ''),
                                  )
                                : SizedBox(),
                            widget.application!['contractNo'] != ''
                                ? Divider()
                                : SizedBox(),

                            SelectedField<Map<String, dynamic>>(
                              title: 'Designate To Person',
                              labelParser: (item) => '${item["userFullName"]}',
                              required: true,
                              items: _cas,
                              selectedItem: _commissionBeneficiarySelected,
                              onSelected: (item) {
                                setState(() {
                                  _commissionBeneficiarySelected = item;
                                  _formData["commissionBeneficiary"] =
                                      item["userId"];
                                });
                              },
                            ),

                            SizedBox(
                              height: 20,
                            ),

                            // followingPaymentDate //
                            DatePickerWidget(
                              controller: _followingPaymentDateController,
                              focusNode: _followingPaymentDateFocusNode,
                              labelText: "Following Payment Date",
                              isRequired: true,
                              requiredMessage:
                                  "Following Payment Date is required.",
                              initialDateTime: _dtFollowingPaymentDateSelected,
                              setFormDataValue: _setFollowingPaymentDate,
                            ),
                            SizedBox(
                              height: 10,
                            ),

                            // contractRemark //
                            TextFormInput(
                              controller: _contractRemarkController,
                              label: "Remark",
                              textInputAction: TextInputAction.done,
                              isRequired: false,
                              onSaved: _setContractRemark,
                              maxLines: 3,
                            ),
                            SizedBox(
                              height: 10,
                            ),

                            Divider(),

                            // contractDate //
                            _daysDiff >= 10 && _daysDiff <= 50
                                ? ItemInfoWidget(
                                    title:
                                        '${_daysPostponed >= 0 ? 'Extra' : 'Less'} Days',
                                    value: '$_absDaysPostponed days',
                                  )
                                : Text(
                                    'Following Payment Date ($_daysDiff days from contract date) is below the MIN allowed number of 50 days.',
                                    style: TextStyle(
                                        color: Colors.red, fontSize: 13),
                                  ),
                            Divider(),
                            // contractDate //
                            _daysDiff >= 10 && _daysDiff <= 50
                                ? ItemInfoWidget(
                                    title:
                                        'Adjustment ${_daysPostponed >= 0 ? 'Fee' : 'Discount'} ',
                                    value:
                                        '${NumberFormat("#,###").format(_absPostponedAmount)} MMK',
                                  )
                                : Text(
                                    'Invalid Following Payment Date. Your adjusted date is $_absDaysPostponed days beyond the limit.',
                                    style: TextStyle(
                                        color: Colors.red, fontSize: 13),
                                  ),
                            Divider(),

                            Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  ButtonWidget(
                                    text: "CLEAR ALL",
                                    isWhiteBackgroundColor: true,
                                    onPressed: _clearAllFields,
                                  ),
                                  SizedBox(
                                    width: 5,
                                  ),
                                  ButtonWidget(
                                    text: "SAVE CHANGES",
                                    isWhiteBackgroundColor: false,
                                    onPressed:
                                        _daysDiff >= 10 && _daysDiff <= 50
                                            ? (widget.contractId == null
                                                ? _createContract
                                                : _editContract)
                                            : null,
                                  ),
                                ]),
                            SizedBox(
                              height: 10,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          kSpaceVertical8,
          CopyrightNotice(),
        ]),
      ),
    );
  }
}
