import 'package:flutter/cupertino.dart';
import 'package:sales/models/models.dart';

import 'acquisition_form_state.dart';

class AcquisitionFormNotifier extends ChangeNotifier {
  AcquisitionFormState state = const AcquisitionFormState();

  emit(AcquisitionFormState value) {
    state = value;
    notifyListeners();
  }

  resetFormState() => emit(const AcquisitionFormState());

  onClientNameUpdate(String name) {
    emit(state.copyWith(clientName: name));
  }

  onPhoneNumberUpdate(String number) {
    emit(state.copyWith(phoneNo: number));
  }

  onOtherPhoneNumberUpdate(String number) {
    emit(state.copyWith(otherPhoneNo: number));
  }

  onMerchantPosUpdate(POS? pos) {
    emit(state.copyWith(pos: pos));
  }

  onSalesChannelUpdate(SalesChannel channel) {
    emit(state.copyWith(salesChannel: channel));
  }

  onSalesAreaUpdate(SalesArea area) {
    emit(state.copyWith(salesArea: area));
  }

  onProductCategoryUpdate(ProductCategory category) {
    emit(state.copyWith(productCategory: category));
  }
}
