import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/models/models.dart';
import 'package:sales/utils/utils.dart';

part 'acquisition_form_state.freezed.dart';

@freezed
class AcquisitionFormState with _$AcquisitionFormState {
  const AcquisitionFormState._();

  const factory AcquisitionFormState({
    String? clientName,
    String? phoneNo,
    String? otherPhoneNo,
    POS? pos,
    SalesArea? salesArea,
    SalesChannel? salesChannel,
    ProductCategory? productCategory,
  }) = _AcquisitionFormState;

  AcquisitionRequest toRequestModel() => AcquisitionRequest(
        clientName: clientName,
        phoneNo: phoneNo,
        otherPhoneNo: otherPhoneNo,
        posId: pos?.id,
        productCategoryId: productCategory?.id,
        salesChannelId: salesChannel?.id,
        salesAreaId: salesArea?.id,
        dtCreated: DateTime.now().format(formatPattern: DATETIME_FORMAT),
      );
}
