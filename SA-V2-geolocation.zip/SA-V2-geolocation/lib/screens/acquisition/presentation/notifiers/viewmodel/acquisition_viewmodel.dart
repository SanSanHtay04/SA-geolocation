import 'package:flutter/cupertino.dart';
import 'package:sales/data/repositories/repositories.dart';
import 'package:sales/models/models.dart';
import 'package:sales/screens/acquisition/data/acquisition_repository.dart';
import 'package:sales/screens/acquisition/presentation/notifiers/form/acquisition_form_state.dart';

import 'acquisition_data_state.dart';
import 'acquisition_submit_state.dart';

/// Serves as Notifier for both DataState and SubmitState.
class AcquisitionViewModel extends ChangeNotifier {
  late AcquisitionRepository repo;

  AcquisitionViewModel({
    required this.repo,
    required POSRepository posRepo,
    required ProductCategoryRepository categoryRepo,
    required SalesRepository salesRepo,
  }) {
    _init(posRepo, categoryRepo, salesRepo);
  }

  AcquisitionDataState dataState = const AcquisitionDataState.idle();
  AcquisitionSubmitState submitState = const AcquisitionSubmitState.idle();

  bool get isLoading => (dataState is AcquisitionDataStateLoading) || (submitState is AcquisitionSubmitStateLoading);

  AcquisitionDataStateIdle? get data => dataState.mapOrNull(idle: (value) => value);

  List<POS> getPosList() => data?.posList ?? [];
  List<SalesChannel> getSalesChannel() => data?.saleChannels ?? [];
  List<ProductCategory> getCategories() => data?.categories ?? [];
  List<SalesArea> getSalesArea() => data?.salesArea ?? [];

  void _setDataState(value) {
    dataState = value;
    notifyListeners();
  }

  void _setSubmitState(value) {
    submitState = value;
    notifyListeners();
  }

  void resetSubmitState() => _setSubmitState(const AcquisitionSubmitState.idle());
  void resetDataState() => _setDataState(const AcquisitionDataState.idle());

  Future<void> _init(
    POSRepository posRepo,
    ProductCategoryRepository categoryRepo,
    SalesRepository salesRepo,
  ) async {
    _setDataState(const AcquisitionDataState.loading());

    final responses = await Future.wait([
      posRepo.getPOSList(),
      categoryRepo.getCategoriesForAcquisition(),
      salesRepo.getSalesArea(),
      salesRepo.getSalesChannel(),
    ]);
    final errors = responses.where((e) => e.hadFailed).map((e) => e.message);

    if (errors.isNotEmpty) {
      final failedState = AcquisitionDataState.failed(
        errors.join('\n'),
        error: null,
      );
      _setDataState(failedState);
    } else {
      final data = responses.map((e) => e.data);
      final successState = AcquisitionDataState.idle(
        posList: data.elementAt(0) as List<POS>,
        categories: data.elementAt(1) as List<ProductCategory>,
        salesArea: data.elementAt(2) as List<SalesArea>,
        saleChannels: data.elementAt(3) as List<SalesChannel>,
      );
      _setDataState(successState);
    }
  }

  Future<void> submit({required AcquisitionFormState data}) async {
    _setSubmitState(const AcquisitionSubmitState.loading());
    final res = await repo.submit(data);
    final newState = res.when(
      success: (message) => AcquisitionSubmitState.success(message),
      failed: (message, error) => AcquisitionSubmitState.failed(message, error: error),
    );
    _setSubmitState(newState);
  }
}
