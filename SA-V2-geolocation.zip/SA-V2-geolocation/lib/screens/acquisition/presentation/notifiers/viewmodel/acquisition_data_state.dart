import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/base/error.dart';
import 'package:sales/models/models.dart';

part 'acquisition_data_state.freezed.dart';

/// Pre-requied data to load before user interactions.
@freezed
class AcquisitionDataState with _$AcquisitionDataState {
  const factory AcquisitionDataState.idle({
    @Default([]) List<POS> posList,
    @Default([]) List<SalesChannel> saleChannels,
    @Default([]) List<ProductCategory> categories,
    @Default([]) List<SalesArea> salesArea,
  }) = AcquisitionDataStateIdle;

  const factory AcquisitionDataState.loading() = AcquisitionDataStateLoading;

  const factory AcquisitionDataState.failed(msg, {AppError? error}) = AcquisitionDataStateFailed;
}
