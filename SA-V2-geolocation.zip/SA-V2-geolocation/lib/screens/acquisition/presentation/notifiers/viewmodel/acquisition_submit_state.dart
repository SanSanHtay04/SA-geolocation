import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/base/error.dart';

part 'acquisition_submit_state.freezed.dart';

/// Serve as SharedFlow for Submitting accquisition form-data
@freezed
class AcquisitionSubmitState with _$AcquisitionSubmitState {
  const factory AcquisitionSubmitState.idle() = AcquisitionSubmitStateIdle;

  const factory AcquisitionSubmitState.loading() = AcquisitionSubmitStateLoading;

  const factory AcquisitionSubmitState.success(String message) = AcquisitionSubmitStateSuccess;

  const factory AcquisitionSubmitState.failed(message, {AppError? error}) = AcquisitionSubmitStateFailed;
}
