import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/base/error.dart';
import 'package:sales/data/repositories/repositories.dart';
import 'package:sales/screens/acquisition/presentation/notifiers/viewmodel/acquisition_viewmodel.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/app_snack_bar.dart';
import '../../../widgets/work_layout.dart';
import '../data/acquisition_repository.dart';
import 'acquisition_form.dart';
import 'notifiers/form/acquisition_form_notifier.dart';

class AcquisitionScreen extends StatelessWidget {
  const AcquisitionScreen({super.key});

  static Widget create() {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) => AcquisitionViewModel(
            repo: AcquisitionRepository(context.read()),
            categoryRepo: context.read(),
            posRepo: context.read(),
            salesRepo: SalesRepository(context.read()),
          ),
        ),
        ChangeNotifierProvider(create: (_) => AcquisitionFormNotifier()),
      ],
      child: AcquisitionScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AcquisitionViewModel>(builder: (_, vm, __) {
      /// To handle the callback from dataState.
      Future.delayed(Duration.zero, () {
        vm.dataState.maybeWhen(
          failed: (message, error) => context.showErrorDialog(
            error.errorMessage(context, message),
            onClosePressed: vm.resetDataState,
          ),
          orElse: () {},
        );
      });

      /// To handle the callback from submitState.
      Future.delayed(Duration.zero, () {
        vm.submitState.maybeWhen(
          failed: (message, error) => context.showErrorDialog(
            error.errorMessage(context, message),
            onClosePressed: vm.resetSubmitState,
          ),
          success: (message) => context.showMessageDialog(
            message: message,
            onClosePressed: () {
              context.read<AcquisitionFormNotifier>().resetFormState();
              vm.resetSubmitState();
            },
          ),
          orElse: () {},
        );
      });

      return WorkLayout(
        appBar: AppBar(title: Text('ACQUISITION FORM')),
        isBusy: vm.isLoading,
        child: SingleChildScrollView(
          child: Padding(
            padding: kPadding16,
            child: AcquisitionFrom(vm: vm),
          ),
        ),
      );
    });
  }
}
