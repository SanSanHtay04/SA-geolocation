import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/models/models.dart';
import 'package:sales/screens/acquisition/presentation/notifiers/viewmodel/acquisition_viewmodel.dart';

import 'package:sales/widgets/app_snack_bar.dart';
import 'package:sales/widgets/save_button.dart';
import 'package:sales/widgets/selected_field/selected_field.dart';
import 'package:sales/widgets/text_form_field/clearable_text_form_field.dart';
import 'package:sales/widgets/text_form_field/phone_text_form_field.dart';

import 'notifiers/form/acquisition_form_notifier.dart';

class AcquisitionFrom extends StatefulWidget {
  const AcquisitionFrom({super.key, required this.vm});

  final AcquisitionViewModel vm;

  @override
  State<AcquisitionFrom> createState() => _AcquisitionFromState();
}

class _AcquisitionFromState extends State<AcquisitionFrom> {
  final _formKey = GlobalKey<FormState>();
  AutovalidateMode _mode = AutovalidateMode.disabled;

  @override
  Widget build(BuildContext context) {
    return Consumer<AcquisitionFormNotifier>(builder: (_, form, __) {
      return Form(
        key: _formKey,
        autovalidateMode: _mode,
        child: Wrap(
          runSpacing: 16,
          runAlignment: WrapAlignment.start,
          children: [
            ClearableTextFormField(
              initialValue: form.state.clientName,
              required: true,
              labelText: 'Client name',
              onChanged: form.onClientNameUpdate,
            ),
            PhoneTextFormField(
              initialValue: form.state.phoneNo,
              labelText: 'Phone number',
              required: true,
              onChanged: form.onPhoneNumberUpdate,
            ),
            PhoneTextFormField(
              initialValue: form.state.otherPhoneNo,
              labelText: 'Additional phone number',
              onChanged: form.onOtherPhoneNumberUpdate,
            ),
            SelectedField<POS>(
              title: "Merchandise/POS",
              required: true,
              items: widget.vm.getPosList(),
              labelParser: (item) => item.name,
              selectedItem: form.state.pos,
              onSelected: form.onMerchantPosUpdate,
            ),
            SelectedField<SalesChannel>(
              title: "How did client buy?",
              required: true,
              items: widget.vm.getSalesChannel(),
              labelParser: (item) => item.name,
              selectedItem: form.state.salesChannel,
              onSelected: form.onSalesChannelUpdate,
            ),
            SelectedField<ProductCategory>(
              title: "Product category",
              required: true,
              items: widget.vm.getCategories(),
              labelParser: (item) => item.name,
              selectedItem: form.state.productCategory,
              onSelected: form.onProductCategoryUpdate,
            ),
            SelectedField<SalesArea>(
              title: "Sales area",
              required: true,
              items: widget.vm.getSalesArea(),
              labelParser: (item) => item.name,
              selectedItem: form.state.salesArea,
              onSelected: form.onSalesAreaUpdate,
            ),
            SaveButton(onPressed: () {
              FocusScope.of(context).unfocus();
              if (_formKey.currentState?.validate() ?? false) {
                final state = form.state;
                context.showConfirmDialog(
                  message: "Do you want to create acquisition?",
                  onConfirmPressed: () => widget.vm.submit(data: state),
                );
              } else {
                _mode = AutovalidateMode.onUserInteraction;
              }
            })
          ],
        ),
      );
    });
  }
}
