import 'package:sales/base/data_response.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/data/remote/services/common_service.dart';
import 'package:sales/base/base_repository.dart';
import 'package:sales/screens/acquisition/presentation/notifiers/form/acquisition_form_state.dart';

class AcquisitionRepository with BaseRepository {
  final CommonService _api;

  AcquisitionRepository(this._api);

  Future<DataResponse<String>> submit(AcquisitionFormState data) async {
    return getData(
      handleDataRequest: () => _api.submitAcquisition(data.toRequestModel()),
      handleDataResponse: (MessageResponse res) => res.messages ?? 'Successfully created acquisition.',
    );
  }
}
