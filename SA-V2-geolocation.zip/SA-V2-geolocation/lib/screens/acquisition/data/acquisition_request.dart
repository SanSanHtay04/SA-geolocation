import 'package:freezed_annotation/freezed_annotation.dart';

part 'acquisition_request.freezed.dart';
part 'acquisition_request.g.dart';

@freezed
class AcquisitionRequest with _$AcquisitionRequest {
  const AcquisitionRequest._();

  const factory AcquisitionRequest({
    int? posId,
    int? productCategoryId,
    int? salesChannelId,
    int? salesAreaId,
    String? clientName,
    @JsonKey(name: 'mobileNo1') String? phoneNo,
    @JsonKey(name: 'mobileNo2') String? otherPhoneNo,
    String? dtCreated,
  }) = _AcquisitionRequest;

  factory AcquisitionRequest.fromJson(Map<String, dynamic> json) => _$AcquisitionRequestFromJson(json);
}
