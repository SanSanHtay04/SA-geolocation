import 'dart:async';

import 'package:geolocator/geolocator.dart';
import 'package:intl/intl.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/data/repositories/repositories.dart';
import 'package:sales/models/models.dart';
import 'package:sales/utils/utils.dart';

class LocationTracker {
  final _settings = AndroidSettings(
    intervalDuration: Duration(minutes: 20),
    distanceFilter: 30,
    foregroundNotificationConfig: const ForegroundNotificationConfig(
      notificationText: "Your location is being tracked for finding nearby POS",
      notificationTitle: "Location",
    ),
  );
  StreamSubscription<Position>? _locationUpdates = null;
  StreamSubscription<bool>? _serviceStatusStreamSubscription = null;
  late LocationTrackingRepository _repo;
  List<POS> _posList = [];
  WorkingTimeResponse? _workingTime;

  LocationTracker({
    required LocationTrackingRepository repo,
    required POSRepository posRepo,
  }) {
    _repo = repo;
    posRepo.getPOSList().then((value) => _posList = value.data ?? []);
  }

  void start() async {
    final inWorkingTime = await isInWorkingTime();
    if (!inWorkingTime) return;

    if (_serviceStatusStreamSubscription == null) {
      _serviceStatusStreamSubscription = _isLocationServiceEnabled.listen(
        (enabled) async {
          if (enabled) {
            _requestLocationUpdates();
          } else {
            if (_locationUpdates != null && !_locationUpdates!.isPaused) {
              _locationUpdates!.pause();
            }
            await Geolocator.openLocationSettings();
          }
        },
      );
    }
  }

  Future<bool> isInWorkingTime() async {
    if (_workingTime == null) {
      await _repo.getWorkingTime().then((value) => _workingTime = value.data);
    }
    final df = DateFormat('HH:mm');
    final currentTime = DateTime.now();
    final startWorkingTime = df.parse(_workingTime!.start);
    final endWorkingTime = df.parse(_workingTime!.end);
    final startTime = DateTime(
      currentTime.year,
      currentTime.month,
      currentTime.day,
      startWorkingTime.hour,
      startWorkingTime.minute,
    );
    final endTime = DateTime(
      currentTime.year,
      currentTime.month,
      currentTime.day,
      endWorkingTime.hour,
      endWorkingTime.minute,
    );
    return currentTime.isAfter(startTime) && currentTime.isBefore(endTime);
  }

  Stream<bool> get _isLocationServiceEnabled async* {
    // Geolocator.getServiceStatusStream() fires only when the status is changed.
    // So we must request manually first.
    final locationServiceEnabled = await Geolocator.isLocationServiceEnabled();
    yield locationServiceEnabled;
    await for (ServiceStatus status in Geolocator.getServiceStatusStream()) {
      yield status == ServiceStatus.enabled;
    }
  }

  void _requestLocationUpdates() {
    if (_locationUpdates == null) {
      _locationUpdates = Geolocator.getPositionStream(
        locationSettings: _settings,
      ).handleError((e, stackTrace) => AppLogger.e("cannot get location", e, stackTrace)).listen((Position position) {
        AppLogger.i('new location ${position.latitude.toString()}, ${position.longitude.toString()}');
        _sendLocationToServer(position);
      });
    } else {
      if (_locationUpdates!.isPaused) {
        _locationUpdates!.resume();
      }
    }
  }

  Future<void> _sendLocationToServer(Position position) async {
    final nearPOS = filterPOS(position, _posList);
    final nearestPOS = nearPOS.isEmpty ? null : nearPOS.first;
    AppLogger.i("Nearby pos: $nearestPOS");
    await _repo.sendLocation(position.latitude, position.longitude, nearestPOS);
  }

  Future<void> stop() async {
    if (_locationUpdates != null) {
      await _locationUpdates!.cancel();
    }
    if (_serviceStatusStreamSubscription != null) {
      await _serviceStatusStreamSubscription!.cancel();
    }
  }
}
