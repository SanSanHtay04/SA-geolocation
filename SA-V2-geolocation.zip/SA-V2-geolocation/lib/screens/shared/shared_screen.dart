import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/data/repositories/location_tracking_repository.dart';
import 'package:sales/utils/location_helper.dart';
import 'package:sales/widgets/location_permission_required.dart';
import 'package:sales/widgets/permission_required_widget.dart';
import '../../widgets/lazy_indexed_stack.dart';
import '../acquisition/presentation/acquisition_screen.dart';
import '../checkin/presentation/checkin_screen.dart';
import '../origination/origination_screen.dart';
import '../others/others_screen.dart';
import 'location_tracker.dart';
import 'package:sales/utils/permission_helper.dart';

final _screens = [
  OriginationScreen(connectionType: "online"),
  CheckinScreen.create(),
  AcquisitionScreen.create(),
  OthersScreen(),
];

final _tabs = [
  BottomNavigationBarItem(
    label: "Origination",
    icon: Icon(Icons.post_add),
  ),
  BottomNavigationBarItem(
    label: "Check-in/out",
    icon: Icon(Icons.add_location_alt_outlined),
  ),
  BottomNavigationBarItem(
    label: "Acquisition",
    icon: Icon(Icons.contact_phone),
  ),
  BottomNavigationBarItem(
    label: "Other",
    icon: Icon(Icons.more_horiz),
  ),
];

class SharedScreen extends StatefulWidget {
  static const routeName = "/shared";

  const SharedScreen({super.key});

  @override
  State<StatefulWidget> createState() => _SharedScreenState();
}

class _SharedScreenState extends State<SharedScreen> {
  late LocationTracker _locationTracker;

  int _currentIndex = 0;

  void _onTabTap(int index) {
    setState(() => _currentIndex = index);
  }

  @override
  void initState() {
    _locationTracker = LocationTracker(
      repo: LocationTrackingRepository(context.read()),
      posRepo: context.read(),
    );
    LocationHelper.requestPermission(
      onGranted: () => _locationTracker.start(),
      onNotGranted: () => showLocationPermissionRequired(context),
    );
    requestPersmission();

    super.initState();
  }

  void requestPersmission() async {
    await PermissionHelper().requestStoragePermission(
      onGranted: () {},
      onNotGranted: () async {
        await showStoragePermissionRequired(context);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LazyIndexedStack(
        index: _currentIndex,
        children: _screens,
        doNotCache: [2],
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _currentIndex,
        onTap: _onTabTap,
        items: _tabs,
      ),
    );
  }

  @override
  void dispose() {
    _locationTracker.stop();
    super.dispose();
  }
}
