import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/base/error.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/app_snack_bar.dart';
import 'package:sales/widgets/copyright_notice.dart';
import 'package:sales/widgets/save_button.dart';
import 'package:sales/widgets/text_form_field/clearable_text_form_field.dart';
import 'package:sales/widgets/text_form_field/password_text_form_field.dart';
import 'package:sales/widgets/work_layout.dart';

import '../data/change_password_repo.dart';
import 'notifiers/form/change_password_form_notifier.dart';
import 'notifiers/submit/change_password_view_model.dart';

class ChangePasswordScreen extends StatelessWidget {
  static const routeName = "/change-password";

  static Widget create() {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) => ChangePasswordViewModel(
            repo: ChangePasswordRepo(context.read()),
          ),
        ),
        ChangeNotifierProvider(create: (_) => ChangePasswordFormNotifier()),
      ],
      child: ChangePasswordScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<ChangePasswordViewModel>(builder: (_, vm, __) {
      /// To handle the callback from submitState.
      Future.delayed(Duration.zero, () {
        vm.state.maybeWhen(
          failed: (message, error) => context.showErrorDialog(
            error.errorMessage(context, message),
            onClosePressed: () {},
          ),
          success: (message) => context.showMessageDialog(
            message: message,
            onClosePressed: () => Navigator.pop(context),
          ),
          orElse: () {},
        );
      });

      return WorkLayout(
        appBar: AppBar(title: Text('CHANGE PASSWORD')),
        isBusy: vm.isLoading,
        child: Padding(
          padding: kPaddingHorizontal16 + const EdgeInsets.only(top: 16),
          child: ChangePasswordFrom(vm: vm),
        ),
      );
    });
  }
}

class ChangePasswordFrom extends StatefulWidget {
  const ChangePasswordFrom({super.key, required this.vm});
  final ChangePasswordViewModel vm;

  @override
  State<ChangePasswordFrom> createState() => _ChangePasswordFromState();
}

class _ChangePasswordFromState extends State<ChangePasswordFrom> {
  final _formKey = GlobalKey<FormState>();
  AutovalidateMode _mode = AutovalidateMode.disabled;

  onButtonPressed() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_formKey.currentState?.validate() ?? false) {
        FocusScope.of(context).unfocus();
        final formState = context.read<ChangePasswordFormNotifier>().state;
        context.showConfirmDialog(
          message: "Do you want to change password?",
          onConfirmPressed: () => widget.vm.submit(formState),
        );
      } else {
        _mode = AutovalidateMode.onUserInteraction;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<ChangePasswordFormNotifier>().state;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Expanded(
          child: Form(
            key: _formKey,
            autovalidateMode: _mode,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  ClearableTextFormField(
                    initialValue: state.userName,
                    required: true,
                    labelText: 'User name',
                    onChanged: (value) {
                      context.read<ChangePasswordFormNotifier>().updateUserName(value);
                    },
                  ),
                  kSpaceVertical8,
                  PasswordTextFormField(
                    initialValue: state.oldPassword,
                    required: true,
                    labelText: 'Old password',
                    onChanged: (value) {
                      context.read<ChangePasswordFormNotifier>().updateOldPassword(value);
                    },
                  ),
                  kSpaceVertical8,
                  PasswordTextFormField(
                    initialValue: state.newPassword,
                    required: true,
                    labelText: 'New password',
                    validator: (value) {
                      if (value != null && value.length < 6) return 'New Password must be at least 6 character long.';
                      return null;
                    },
                    onChanged: (value) {
                      context.read<ChangePasswordFormNotifier>().updateNewPassword(value);
                    },
                  ),
                  kSpaceVertical8,
                  PasswordTextFormField(
                    initialValue: state.confirmPassword,
                    required: true,
                    labelText: 'Re-type password',
                    validator: ((value) {
                      if (value != null && value.length < 6) {
                        return 'New Password must be at least 6 character long.';
                      }

                      if (state.newPassword != state.confirmPassword) {
                        return 'Re-type Password do not match.';
                      }

                      return null;
                    }),
                    onChanged: (value) {
                      context.read<ChangePasswordFormNotifier>().updateConfirmPassword(value);
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
        SaveButton(onPressed: onButtonPressed),
        CopyrightNotice()
      ],
    );
  }
}
