import 'package:flutter/material.dart';
import 'package:sales/screens/change_password/data/change_password_repo.dart';
import '../form/change_password_form_state.dart';
import 'change_password_submit_state.dart';


class ChangePasswordViewModel extends ChangeNotifier {
  ChangePasswordRepo repo;

  ChangePasswordViewModel({required this.repo});

  ChangePasswordSubmitState state = const ChangePasswordSubmitState.idle();
  bool get isLoading => state is ChangePasswordSubmitStateLoading;

  emit(ChangePasswordSubmitState value) {
    state = value;
    notifyListeners();
  }

  submit(ChangePasswordFormState data) async {
    emit(const ChangePasswordSubmitState.loading());
    final res = await repo.changePassword(
      username: data.userName,
      newPassword: data.newPassword,
      oldPassword: data.oldPassword,
      confirmPassword: data.confirmPassword,
    );
    final newState = res.when(
      success: (data) => ChangePasswordSubmitState.success(data),
      failed: (message, error) => ChangePasswordSubmitStateFailed(message, error: error),
    );
    emit(newState);
  }
}
