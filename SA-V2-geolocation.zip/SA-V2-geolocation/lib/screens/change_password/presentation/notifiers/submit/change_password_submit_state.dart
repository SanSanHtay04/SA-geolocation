import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/base/error.dart';

part 'change_password_submit_state.freezed.dart';

@freezed
class ChangePasswordSubmitState with _$ChangePasswordSubmitState {
  const factory ChangePasswordSubmitState.idle() = ChangePasswordSubmitStateIdle;

  const factory ChangePasswordSubmitState.loading() = ChangePasswordSubmitStateLoading;

  const factory ChangePasswordSubmitState.success(String message) = ChangePasswordSubmitStateSuccess;

  const factory ChangePasswordSubmitState.failed(String message, {AppError? error}) = ChangePasswordSubmitStateFailed;
}
