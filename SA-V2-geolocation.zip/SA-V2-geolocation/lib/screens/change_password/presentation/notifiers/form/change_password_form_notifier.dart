import 'package:flutter/material.dart';

import 'change_password_form_state.dart';


class ChangePasswordFormNotifier extends ChangeNotifier {
  ChangePasswordFormState state = const ChangePasswordFormState();

  emit(ChangePasswordFormState value) {
    state = value;
    notifyListeners();
  }

  updateUserName(String name) {
    emit(state.copyWith(userName: name));
  }

  updateOldPassword(String password) {
    emit(state.copyWith(oldPassword: password));
  }

  updateNewPassword(String password) {
    emit(state.copyWith(newPassword: password));
  }

  updateConfirmPassword(String password) {
    emit(state.copyWith(confirmPassword: password));
  }

  submit() {}
}
