import 'package:freezed_annotation/freezed_annotation.dart';

part 'change_password_form_state.freezed.dart';

@freezed
class ChangePasswordFormState with _$ChangePasswordFormState {
  const ChangePasswordFormState._();

  const factory ChangePasswordFormState({
    @Default('') String userName,
    @Default('') oldPassword,
    @Default('') newPassword,
    @Default('') confirmPassword,
  }) = _ChangePasswordFormState;
}
