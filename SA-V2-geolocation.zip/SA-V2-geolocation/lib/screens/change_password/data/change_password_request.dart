import 'package:freezed_annotation/freezed_annotation.dart';
part 'change_password_request.freezed.dart';
part 'change_password_request.g.dart';

@freezed
class ChangePasswordRequest with _$ChangePasswordRequest {
  const ChangePasswordRequest._();

  const factory ChangePasswordRequest({
    required String username,
    required String oldPassword,
    required String newPassword,
    @Default('') String? confirmNewPassword,
  }) = _ChangePasswordRequest;

  factory ChangePasswordRequest.fromJson(Map<String, dynamic> json) => _$ChangePasswordRequestFromJson(json);
}
