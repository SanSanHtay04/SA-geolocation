import 'package:sales/base/base_repository.dart';
import 'package:sales/base/data_response.dart';
import 'package:sales/data/remote/services/services.dart';

import 'change_password_request.dart';

class ChangePasswordRepo with BaseRepository {
  late AuthService api;

  ChangePasswordRepo( this.api);

  Future<DataResponse<String>> changePassword({
    required String username,
    required String newPassword,
    required String oldPassword,
    required String confirmPassword,
  }) {
    return getData(
      handleDataRequest: () {
        final request = ChangePasswordRequest(
          username: username,
          oldPassword: oldPassword,
          newPassword: newPassword,
          confirmNewPassword: confirmPassword,
        );
        return api.changePassword(request);
      },
      handleDataResponse: (res) => res.messages ?? '',
    );
  }
}
