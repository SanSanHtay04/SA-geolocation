import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/base/error.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/app_snack_bar.dart';
import 'package:sales/widgets/simple_toolbar.dart';
import 'package:sales/widgets/work_layout.dart';

import 'notifiers/simulation_data_state.dart';
import 'notifiers/simulation_view_model.dart';
import 'widgets/choose_simulation_form.dart';

class ChooseSimulationScreen extends StatelessWidget {
  static const routeName = "/choose-simulation";

  ChooseSimulationScreen({
    super.key,
    required this.prospectId,
    required this.packageId,
  });

  final int? prospectId;
  final int? packageId;

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<NewSimulationViewModel>(
      create: (context) => NewSimulationViewModel(
        repo: context.read(),
        prospectId: prospectId,
        packageId: packageId,
      )
        ..loadSimulation()
        ..loadPackageInfo(),
      child: Consumer<NewSimulationViewModel>(
        builder: (context, vm, unsubscribedChild) {
          WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
            if (vm.state.status == SimulationStatus.failed) {
              context.showErrorDialog(
                vm.state.error.errorMessage(context, vm.state.message),
                onClosePressed: () => Navigator.pop(context),
              );
            }
          });

          Future.delayed(Duration.zero, (() {
            vm.submitState.maybeWhen(
              success: (msg) => context.showMessageDialog(
                message: msg,
                onClosePressed: () => Navigator.pop(context),
              ),
              failed: (message, error) => context.showErrorDialog(
                error.errorMessage(context, message),
                onClosePressed: () => vm.clearSubmitState(),
              ),
              orElse: () {},
            );
          }));

          return WorkLayout(
            appBar: SimpleToolbar(title: 'SIMULATION'),
            isBusy: vm.isLoading,
            child: SingleChildScrollView(
              child: Padding(
                padding: kPadding8,
                child: ChooseSimulationForm(vm: vm),
              ),
            ),
          );
        },
      ),
    );
  }
}
