import 'package:flutter/material.dart';

import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/app_snack_bar.dart';

import '../notifiers/simulation_view_model.dart';
import 'simulation_form_card.dart';
import 'simulation_preview_card.dart';

class ChooseSimulationForm extends StatefulWidget {
  ChooseSimulationForm({super.key, required this.vm});
  final NewSimulationViewModel vm;

  @override
  _ChooseSimulationFormState createState() => _ChooseSimulationFormState();
}

class _ChooseSimulationFormState extends State<ChooseSimulationForm> {
  final _formKey = GlobalKey<FormState>();
  AutovalidateMode _mode = AutovalidateMode.disabled;

  @override
  Widget build(BuildContext context) {
    final simulationButton = Row(children: [
      Expanded(
          child: ElevatedButton(
        child: Text('SAVE SIMULATION'),
        onPressed: () {
          if (_formKey.currentState?.validate() ?? false) {
            final formErrors = <String>[];

            if (widget.vm.state.downPayment == null) {
              formErrors.add('Downpayment is required.');
            }

            if (widget.vm.state.tenure == null) {
              formErrors.add('Tenure is required.');
            }

            if (formErrors.isEmpty) {
              context.showConfirmDialog(
                message: 'Are you sure you want to create new simulation?',
                onConfirmPressed: () => widget.vm.createSimulation(),
              );
            } else {
              context.showErrorDialog('- ${formErrors.join('\n- ')}');
            }
          } else {
            _mode = AutovalidateMode.onUserInteraction;
          }
        },
      ))
    ]);

    return Container(
      child: Column(
        children: [
          Form(
            key: _formKey,
            autovalidateMode: _mode,
            child: const SimulationFormCard(),
          ),
          kSpaceVertical8,
          if (widget.vm.state.tenure != null) ...[
            const SimulationPreviewCard(),
            kSpaceVertical8,
          ],
          simulationButton,
        ],
      ),
    );
  }
}
