import 'package:flutter/widgets.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/models/models.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/widgets/data_row.dart';
import 'package:sales/widgets/preview_card.dart';

import '../notifiers/simulation_data_state.dart';
import '../notifiers/simulation_view_model.dart';

class SimulationPreviewCard extends StatelessWidget {
  const SimulationPreviewCard({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<NewSimulationViewModel>().state;

    return PreviewCard(
      primaryLabel: 'SIMULATION PREVIEW',
      primaryContent: Text(state.pacakge['productName'] ?? ''),
      children: [
        DataRowWidget(
          label: 'Product Price',
          value: NumberFormat('#,###').format(state.pacakge["packageTotalPrice"]) + " MMK",
        ),
        kSpaceVertical8,

        DataRowWidget(
          label: 'Downpayment Rate',
          value: '${state.downPayment?.depositPercentage}%',
        ),
        kSpaceVertical8,
        DataRowWidget(
          label: 'Downpayment Amount',
          value: state.downPayment?.depositAmount.currencyFormat(),
        ),
        kSpaceVertical8,
        // // TOTAL BUNDLE //
        // _package["isBundle"]==false ? SizedBox() : Row(
        //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
        //   children: <Widget>[
        //     AutoSizeText(
        //       "Total Bundle Price:",
        //       style: Theme.of(context).textTheme.display3,
        //     ),
        //     Text(NumberFormat('#,###').format(_leadProspect.leadSimulation.assetPrice) + " MMK", style: TextStyle(fontSize: 16),),
        //   ],
        // ),
        _FinicialSchemeCard(data: state),
      ],
    );
  }
}

class _FinicialSchemeCard extends StatelessWidget {
  const _FinicialSchemeCard({required this.data});

  final SimulationDataState data;

  @override
  Widget build(BuildContext context) {
    return PreviewCard(
      isViewCard: false,
      primaryContent: Text(data.tenure?.financialSchemeName ?? ''),
      children: [
        if (data.tenure?.isZeroCost == 1) ...[
          DataRowWidget(
            label: '0-Cost Installments',
            value: '${data.tenure?.zeroCostPmtTimes} months',
          ),
          kSpaceVertical8,
          DataRowWidget(
            label: '0-Cost Monthly Payment',
            value: data.tenure?.zeroCostMonthlyPaymentAmount.currencyFormat(),
          ),
          kSpaceVertical8,
        ],
        DataRowWidget(
          label: 'Periodicity',
          value: data.tenureType.getName(context),
        ),
        kSpaceVertical8,
        DataRowWidget(
          label: 'Tenure',
          value: '${data.tenure?.duration} months',
        ),
        kSpaceVertical8,
        DataRowWidget(
          label: 'First Payment',
          value: data.firstPaymentText,
        ),
        kSpaceVertical8,
        _AdminFeeDepositeCard(data: data.tenure),
        kSpaceVertical8,
        DataRowWidget(
          label: 'Following Payment',
          value: data.followingPaymentText,
        ),
      ],
    );
  }
}

class _AdminFeeDepositeCard extends StatelessWidget {
  const _AdminFeeDepositeCard({this.data});

  final SimulationModel? data;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(20, 0, 0, 0),
      child: Column(
        children: [
          DataRowWidget(
            label: 'Admin Fee (included) ${data?.adminFeePercentage}%',
            value: data?.adminFee.currencyFormat(),
          ),
          kSpaceVertical4,
          DataRowWidget(
            label: 'Downpayment (included) ${data?.depositPercentage}%',
            value: data?.depositAmount.currencyFormat(),
          ),
          kSpaceVertical4,
          if (data?.isZeroCost == 1) ...[
            DataRowWidget(
              label: 'Upfront Insurance (included)',
              value: data?.zeroCostTotalInsCost.currencyFormat(),
            ),
            kSpaceVertical4,
            DataRowWidget(
              label: 'Upfront Maintenance (included)',
              value: data?.zeroCostTotalMaintCost.currencyFormat(),
            ),
          ],
        ],
      ),
    );
  }
}
