import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/models/models.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/widgets/form_card.dart';
import 'package:sales/widgets/selected_field/selected_field.dart';
import 'package:sales/widgets/selected_group/single_selected_group.dart';

import '../notifiers/simulation_view_model.dart';

class SimulationFormCard extends StatefulWidget {
  const SimulationFormCard({super.key});

  @override
  State<SimulationFormCard> createState() => _SimulationFormCardState();
}

class _SimulationFormCardState extends State<SimulationFormCard> {
  bool isShownTenureTableView = false;

  void _setVisibleTenureTableView() {
    setState(() {
      isShownTenureTableView = !isShownTenureTableView;
    });
  }

  @override
  Widget build(BuildContext context) {
    return FormCard(
      title: 'Select DownPayment & Tenure',
      content: isShownTenureTableView ? _SelectTenureTableView() : _SelectTenureForm(),
      submitButton: Row(children: [
        Expanded(
          child: OutlinedButton(
            onPressed: _setVisibleTenureTableView,
            child: Text(isShownTenureTableView ? 'Close' : 'Open Simulation Table View'),
          ),
        )
      ]),
    );
  }
}

class _SelectTenureForm extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final state = context.watch<NewSimulationViewModel>().state;

    return Container(
      child: Column(
        children: [
          SingleSelectedGroup<TenureType>(
            items: TenureType.values,
            label: 'Periodicity',
            labelParser: (item) => item.getName(context).capitalize(),
            selectedItem: state.tenureType,
            onSelectChanged: state.downPayments.isEmpty
                ? null
                : (type) {
                    context.read<NewSimulationViewModel>().selectTenureType(type);
                  },
          ),
          kSpaceVertical8,
          SelectedField<DownPayment>.simple(
            title: 'Down Payment',
            required: true,
            selectedItem: state.downPayment,
            items: state.getDownPayments(),
            onSelected: (value) {
              context.read<NewSimulationViewModel>().selectDownPayment(value);
            },
          ),
          kSpaceVertical8,
          SelectedField<SimulationModel>(
            title: 'Tenure',
            required: true,
            items: state.downPayment?.tenures ?? [],
            selectedItem: state.tenure,
            labelParser: (item) => '${item.duration} month',
            onSelected: (value) {
              context.read<NewSimulationViewModel>().selectTenure(value);
            },
          ),
        ],
      ),
    );
  }
}

class _SelectTenureTableView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final double itemWidth = context.getScreenSize().width / 2;

    final state = context.watch<NewSimulationViewModel>().state;
    final donwPayments = state.getDownPayments();

    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SingleSelectedGroup<TenureType>(
            items: TenureType.values,
            label: 'Periodicity',
            labelParser: (item) => item.getName(context).capitalize(),
            selectedItem: state.tenureType,
            onSelectChanged: state.downPayments.isEmpty
                ? null
                : (type) {
                    context.read<NewSimulationViewModel>().selectTenureType(type);
                  },
          ),
          kSpaceVertical8,
          Text.rich(
            TextSpan(text: 'Down Payment', children: const [
              TextSpan(
                style: TextStyle(color: Colors.red),
                text: ' *\n (First payment includes Deposite, Admin Fee)',
              ),
            ]),
            textAlign: TextAlign.start,
          ),
          kSpaceVertical8,
          GridView.builder(
              shrinkWrap: true,
              physics: const ScrollPhysics(),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                childAspectRatio: (itemWidth / 150),
              ),
              itemCount: donwPayments.length,
              itemBuilder: (context, index) {
                var currentDownPayment = donwPayments[index];
                return InkWell(
                  child: Card(
                      color: state.downPayment != currentDownPayment ? Colors.teal[600] : Colors.teal[300],
                      child: Padding(
                        padding: kPadding12,
                        child: GridTile(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                softWrap: false,
                                style: const TextStyle(
                                  color: Colors.yellow,
                                ),
                                '${currentDownPayment.depositPercentage}%',
                              ),
                              kSpaceVertical10,
                              Text(
                                softWrap: false,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                                currentDownPayment.depositeAmountText,
                              ),
                            ],
                          ),
                        ),
                      )),
                  onTap: () {
                    context.read<NewSimulationViewModel>().selectDownPayment(currentDownPayment);
                  },
                );
              }),
          kSpaceVertical8,
          state.downPayment == null
              ? Text('There is no Down Payment selected!')
              : Text.rich(
                  TextSpan(text: 'Tenures of down payment ', children: const [
                    TextSpan(
                      style: TextStyle(color: Colors.red),
                      text: ' *',
                    ),
                  ]),
                ),
          kSpaceVertical8,
          if (state.downPayment != null) ...[
            GridView.builder(
                shrinkWrap: true,
                physics: const ScrollPhysics(),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  childAspectRatio: (itemWidth / 160),
                ),
                itemCount: state.downPayment?.tenures.length ?? 0,
                itemBuilder: (context, tenureIndex) {
                  var currentTenure = state.downPayment!.tenures[tenureIndex];
                  return InkWell(
                    child: Card(
                        color: state.tenure == currentTenure ? Colors.teal[100] : Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: kBorderRadius4,
                          side: BorderSide(color: Colors.teal.shade600),
                        ),
                        child: Container(
                          padding: kPadding2,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                softWrap: false,
                                style: TextStyle(
                                  color: Colors.yellow.shade900,
                                ),
                                '${currentTenure.duration.toString()}m',
                              ),
                              kSpaceVertical8,
                              Text(
                                softWrap: false,
                                style: TextStyle(
                                  color: Colors.teal.shade600,
                                  fontWeight: FontWeight.bold,
                                ),
                                '${currentTenure.followingPayment.simpleCurrencyFormat()}',
                              ),
                            ],
                          ),
                        )),
                    onTap: () {
                      context.read<NewSimulationViewModel>().selectTenure(currentTenure);
                    },
                  );
                }),
          ],
        ],
      ),
    );
  }
}
