import 'package:flutter/widgets.dart';
import 'package:sales/data/repositories/simulation_repository.dart';
import 'package:sales/models/models.dart';
import '../../../../../data/remote/models/responses/calc_simulation_res.dart';
import 'simulation_data_state.dart';
import 'simulation_submit_state.dart';

class NewSimulationViewModel extends ChangeNotifier {
  final SimulationRepository repo;

  NewSimulationViewModel({required this.repo, this.packageId, this.prospectId});
  final int? packageId;
  final int? prospectId;

  SimulationDataState state = const SimulationDataState();
  SimulationSubmitState submitState = const SimulationSubmitState.idle();

  bool get isLoading => (state.status == SimulationStatus.loading) || (submitState is SimulationSubmitStateLoading);

  setSubmitState(SimulationSubmitState value) {
    submitState = value;
    notifyListeners();
  }

  setDataState(SimulationDataState value) {
    state = value;
    notifyListeners();
  }

  Future<void> loadSimulation() async {
    if (packageId == null) return;
    setDataState(state.copyWith(status: SimulationStatus.loading));

    final res = await repo.calcSimulation(packageId!);
    final newState = res.when(
      success: (data) => state.copyWith(
        status: SimulationStatus.loaded,
        downPayments: data,
      ),
      failed: (message, error) => state.copyWith(
        status: SimulationStatus.failed,
        message: message,
        error: error,
      ),
    );

    setDataState(newState);
  }

  Future<void> loadPackageInfo() async {
    if (prospectId == null || packageId == null) return;
    setDataState(state.copyWith(status: SimulationStatus.loading));

    final res = await repo.getProductPackage(prospectId!, packageId!);
    final newState = res.when(
      success: (data) => state.copyWith(
        status: SimulationStatus.loaded,
        pacakge: data,
      ),
      failed: (message, error) => state.copyWith(
        status: SimulationStatus.failed,
        message: message,
        error: error,
      ),
    );
    setDataState(newState);
  }

  selectTenureType(TenureType type) {
    setDataState(state.copyWith(
      tenureType: type,
      downPayment: null,
      tenure: null,
    ));
  }

  selectDownPayment(DownPayment downPayment) {
    setDataState(state.copyWith(
      downPayment: downPayment,
      tenure: null,
    ));
  }

  selectTenure(SimulationModel tenure) {
    setDataState(state.copyWith(tenure: tenure));
  }

  clearSubmitState() => setSubmitState(const SimulationSubmitState.idle());

  createSimulation() async {
    if (packageId == null || prospectId == null) return;

    setSubmitState(SimulationSubmitState.loading());
    final res = await repo.createSimulation(
      packageId: packageId!,
      prospectId: prospectId!,
      data: state.tenure!,
    );
    final newState = res.when(
      success: (data) => SimulationSubmitState.success(data),
      failed: (message, error) => SimulationSubmitState.failed(
        message,
        error: error,
      ),
    );
    setSubmitState(newState);
  }
}
