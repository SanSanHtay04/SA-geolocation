import "package:freezed_annotation/freezed_annotation.dart";
import 'package:sales/base/error.dart';

part 'simulation_submit_state.freezed.dart';

@freezed
class SimulationSubmitState with _$SimulationSubmitState {
  const factory SimulationSubmitState.idle() = SimulationSubmitStateIdle;

  const factory SimulationSubmitState.loading() = SimulationSubmitStateLoading;

  const factory SimulationSubmitState.failed(String message, {AppError? error}) = SimulationSubmitStateFailed;

  const factory SimulationSubmitState.success(String message) = SimulationSubmitStateSuccess;
}
