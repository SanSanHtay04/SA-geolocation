import "package:freezed_annotation/freezed_annotation.dart";

import 'package:sales/base/error.dart';
import 'package:sales/data/remote/models/responses/responses.dart';
import 'package:sales/models/models.dart';
import 'package:sales/utils/utils.dart';

part 'simulation_data_state.freezed.dart';

enum SimulationStatus { loading, loaded, failed }

@freezed
class SimulationDataState with _$SimulationDataState {
  const SimulationDataState._();

  const factory SimulationDataState({
    @Default({}) Map<String, dynamic> pacakge,
    @Default({}) Map<TenureType, List<DownPayment>> downPayments,
    @Default(SimulationStatus.loaded) SimulationStatus status,
    @Default('') message,
    AppError? error,
    @Default(TenureType.monthly) TenureType tenureType,
    DownPayment? downPayment,
    SimulationModel? tenure,
  }) = _SimulationDataState;

  List<DownPayment> getDownPayments() => downPayments[tenureType] ?? [];

  List<SimulationModel> get tenures => downPayment?.tenures ?? [];

  String get firstPaymentText => " ${(tenure?.actualFirstPayment ?? 0 + (downPayment?.zeroCost?.zeroCostTotalInsCost ?? 0) + (downPayment?.zeroCost?.zeroCostTotalMaintCost ?? 0)).currencyFormat()} ";

  String get followingPaymentText => '${tenure?.followingPayment.currencyFormat()}';

// {NumberFormat('#,###').format(vm.tenure?.actualFirstPayment ?? 0 + (vm.downPayment?.zeroCost?.zeroCostTotalInsCost ?? 0) + (vm.downPayment?.zeroCost?.zeroCostTotalMaintCost ?? 0))}

}
