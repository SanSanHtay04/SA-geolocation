import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/models/models.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/form_card.dart';
import 'package:sales/widgets/selected_field/selected_field.dart';
import 'package:sales/widgets/text_form_field/text_area_field.dart';

import '../../notifiers/form/customer_form_notifier.dart';

class OtherInfoForm extends StatelessWidget {
  const OtherInfoForm({super.key});

  @override
  Widget build(BuildContext context) {
    final formState = context.watch<CustomerFormNotifier>().state;
    final now = DateTime.now();

    return FormCard(
      title: 'Other',
      content: Column(
        children: [
          SelectedField<InternalFraudCode>(
            title: 'Internal Fraud Code',
            required: true,
            items: InternalFraudCode.values,
            labelParser: (item) => item.name,
            selectedItem: formState.fraudCode,
            onSelected: (type) {
              context.read<CustomerFormNotifier>().updateInternalFraudCode(type);
            },
          ),
          kSpaceVertical8,
          SwitchListTile(
            value: formState.isOwnedMoto,
            title: Text('Already own motorcycle'),
            onChanged: (value) {
              context.read<CustomerFormNotifier>().toggleOwnedMotorcycle(value);
            },
          ),
          kSpaceVertical8,
          if (formState.isOwnedMoto) ...[
            SwitchListTile(
              value: formState.isTakenContract,
              title: Text('Hire-Purchase Contract'),
              onChanged: (value) {
                context.read<CustomerFormNotifier>().togglePurchaseContract(value);
              },
            ),
            kSpaceVertical8,
            SwitchListTile(
              value: formState.isTakenLoan,
              title: Text('Micro-Finance Loan'),
              onChanged: (value) {
                context.read<CustomerFormNotifier>().toggleFinanceLoan(value);
              },
            ),
            kSpaceVertical8,
          ],
          TextAreaField(
            initialValue: formState.motoRemark,
            labelText: 'Vehicle Financing Remark',
            onChanged: (remark) {
              context.read<CustomerFormNotifier>().updateFinanceRemark(remark);
            },
          ),
          kSpaceVertical8,
          TextAreaField(
            initialValue: formState.customerRemark,
            labelText: 'Customer Remark',
            onChanged: (remark) {
              context.read<CustomerFormNotifier>().updateCustomerRemark(remark);
            },
          ),
        ],
      ),
    );
  }
}
