import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/form_card.dart';
import 'package:sales/widgets/text_form_field/clearable_text_form_field.dart';

import '../../notifiers/form/customer_form_notifier.dart';

class HouseHoldInfoForm extends StatelessWidget {
  const HouseHoldInfoForm({super.key});

  @override
  Widget build(BuildContext context) {
    final formState = context.watch<CustomerFormNotifier>().state;

    return FormCard(
      title: 'Household',
      content: Column(
        children: [
          ClearableTextFormField(
            labelText: 'Children',
            required: true,
            keyboardType: TextInputType.number,
            initialValue: formState.householdNumber.childrenText,
            onChanged: (count) {
              context
                  .read<CustomerFormNotifier>()
                  .updateChildrenHousehold(count);
            },
          ),
          kSpaceVertical8,
          ClearableTextFormField(
            labelText: 'Relatives',
            required: true,
            keyboardType: TextInputType.number,
            initialValue: formState.householdNumber.relativeText,
            onChanged: (count) {
              context
                  .read<CustomerFormNotifier>()
                  .updateRelativeHousehold(count);
            },
          ),
          kSpaceVertical8,
          ClearableTextFormField(
            labelText: 'Others',
            required: true,
            keyboardType: TextInputType.number,
            initialValue: formState.householdNumber.otherText,
            onChanged: (count) {
              context.read<CustomerFormNotifier>().updateOtherHousehold(count);
            },
          ),
          kSpaceVertical8,
          Text(
            'Total HouseHold : ${formState.householdNumber.totalHouseholdText}',
            style: const TextStyle(
              fontSize: 12,
              color: Colors.red,
            ),
          ),
        ],
      ),
    );
  }
}
