
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:provider/provider.dart';
import 'package:sales/screens/origination/presentation/widgets/location_view/widgets/location_widget.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/utils/location_helper.dart';
import 'package:sales/utils/logging.dart';
import 'package:sales/widgets/preview_card.dart';
import 'package:latlong2/latlong.dart';

import '../../notifiers/form/customer_form_notifier.dart';
import '../map/customer_address_map_view.dart';

class LocationInfoForm extends StatefulWidget {
  const LocationInfoForm({super.key});

  @override
  State<LocationInfoForm> createState() => _LocationInfoFormState();
}

class _LocationInfoFormState extends State<LocationInfoForm> {
  LatLng? location;
  String? addressName;

  void onAddressConfirmed(LatLng? loc, String? name) {
    this.location = loc;
    this.addressName = name;
  }

  @override
  Widget build(BuildContext context) {
    final formState = context.watch<CustomerFormNotifier>().state;

    return PreviewCard(
      prefixIcon: Icon(Icons.location_on_outlined),
      onPrefixIconButtonTapped: () {
        Clipboard.setData(ClipboardData(text: formState.geoLocation.format())).then(
              (value) => Fluttertoast.showToast(msg: "Location copied"),
        );
      },
      buttonIcon: Icon(Icons.edit_outlined),
      onIconButtonTapped: () {
        Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => LocationWidget(
                geoLocation: formState.geoLocation,
                geoAddress: formState.geoAddress,
                onConfirmed: onAddressConfirmed,
              )),
        ).then((value) async {
          AppLogger.i("MaterialPageRoute : $location, $addressName");
          context.read<CustomerFormNotifier>().updateLocation(
            location,
            addressName,
          );
        });
      },
      primaryLabel: 'Location',
      children: [
        ConstrainedBox(
          constraints: BoxConstraints(minHeight: 150),
          child: CustomerAddressMapView(
            myLocation: formState.geoLocation,
            minHeight: 150,
            onMyLocationClick: () {
              context.read<CustomerFormNotifier>().getCurrentLocation();
            },
          ),
        ),
        kSpaceVertical4,
        (formState.geoLocation == null)
            ? Text(
          'There is no selected customer\'s current location',
          style: const TextStyle(fontSize: 12, color: Colors.red),
        )
            : Text.rich(
          TextSpan(text: formState.geoAddress, children: [

            TextSpan(
              text: formState.geoLocation.format(),
              style: TextStyle(color: Colors.red),
            )
          ]),
        ),
      ],
    );
  }
}
