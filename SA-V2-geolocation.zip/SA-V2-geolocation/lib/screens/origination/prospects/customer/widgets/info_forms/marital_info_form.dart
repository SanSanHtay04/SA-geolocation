import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

import 'package:sales/screens/origination/presentation/widgets/marital_status/widgets/marital_status_view.dart';
import 'package:sales/widgets/form_card.dart';
import 'package:sales/widgets/loading_view.dart';

import '../../notifiers/form/customer_form_notifier.dart';

class MaritalInfoForm extends StatelessWidget {
  const MaritalInfoForm({super.key});

  @override
  Widget build(BuildContext context) {
    final formState = context.watch<CustomerFormNotifier>().state;
    return FormCard(
      title: 'Marital Status',
      content: formState.maritalStatus == null
          ? const LoadingView()
          : MaritalStatusView(
              selectedValue: formState.maritalStatus,
              name: formState.spouseName,
              phone: formState.spousePhone,
              status: formState.spousePhoneStatus,
              nrcNumber: formState.spouseNrcDetail,
              onChanged: (status) {
                context.read<CustomerFormNotifier>().updateMaritalStatus(status);
              },
              onNameChanged: (name) {
                context.read<CustomerFormNotifier>().updateSpouseName(name);
              },
              onPhoneChanged: (phone) {
                context.read<CustomerFormNotifier>().updateSpousePhone(phone);
              },
              onStatusChanged: (status) {
                context.read<CustomerFormNotifier>().updateSpousePhoneStatus(status);
              },
              onNrcChanged: (nrc) {
                context.read<CustomerFormNotifier>().updateSpouseNrc(nrc);
              },
            ),
    );
  }
}
