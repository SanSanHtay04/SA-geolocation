import 'package:flutter/cupertino.dart';
import 'package:provider/provider.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/widgets/info_preview_card.dart';
import 'package:sales/widgets/item_info_widget.dart';

import '../../notifiers/form/customer_form_notifier.dart';

class OtherCard extends StatelessWidget {
  const OtherCard({super.key});

  @override
  Widget build(BuildContext context) {
    final data = context.watch<CustomerFormNotifier>().state;

    return InfoPreviewCard(
      isViewCard: false,
      primaryLabel: 'OTHER',
      children: [
        ItemInfoWidget(
          title: 'Internal Code',
          value: data.fraudCode?.name,
        ),
        ItemInfoWidget(
          title: 'Already own motorcycle(s)',
          value: data.isOwnedMoto.toYesNo(),
        ),
        if (data.isOwnedMoto) ...[
          ItemInfoWidget(
            title: 'Hire-Purchase Contract',
            value: data.isTakenContract.toYesNo(),
          ),
          ItemInfoWidget(
            title: 'Micro-Finance Loan',
            value: data.isTakenLoan.toYesNo(),
          )
        ],
        ItemInfoWidget(
          title: 'Vehicle Financing Remark',
          value: data.motoRemark,
        ),
        ItemInfoWidget(
          title: 'Customer Remark',
          value: data.customerRemark,
        ),
      ],
    );
  }
}
