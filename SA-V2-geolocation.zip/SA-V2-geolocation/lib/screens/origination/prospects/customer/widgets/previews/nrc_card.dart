import 'package:flutter/cupertino.dart';
import 'package:provider/provider.dart';
import 'package:sales/utils/datetime_x.dart';
import 'package:sales/widgets/info_preview_card.dart';
import 'package:sales/widgets/item_info_widget.dart';

import '../../notifiers/form/customer_form_notifier.dart';

class NrcCard extends StatelessWidget {
  const NrcCard({super.key});

  @override
  Widget build(BuildContext context) {
    final data = context.watch<CustomerFormNotifier>().state.nrcDetail;

    return InfoPreviewCard(
      isViewCard: false,
      primaryLabel: 'NRC',
      children: [
        ItemInfoWidget(
          title: 'NRC Number',
          value: data?.natRegCardNo(),
        ),
        ItemInfoWidget(
          title: 'Issuance Date',
          value: data?.issuanceDate?.format(),
        ),
      ],
    );
  }
}
