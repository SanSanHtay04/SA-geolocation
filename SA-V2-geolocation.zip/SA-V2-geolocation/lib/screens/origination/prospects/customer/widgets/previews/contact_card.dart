import 'package:flutter/cupertino.dart';
import 'package:provider/provider.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/widgets/info_preview_card.dart';
import 'package:sales/widgets/item_info_widget.dart';

import '../../notifiers/form/customer_form_notifier.dart';

class ContactCard extends StatelessWidget {
  const ContactCard({super.key});

  @override
  Widget build(BuildContext context) {
    final data = context.watch<CustomerFormNotifier>().state;

    return InfoPreviewCard(
      isViewCard: false,
      primaryLabel: 'CONTACT',
      children: [
        ItemInfoWidget(
          title: 'Phone No. 1',
          value: data.phoneNo1,
        ),
        ItemInfoWidget(
          title: 'Status / Type',
          value: "${data.phoneStatus1?.name} / ${data.phoneType1.name}",
        ),
        ItemInfoWidget(
          title: 'Remark',
          value: data.phoneRemark1,
        ),
        ItemInfoWidget(
          title: 'Phone No. 2',
          value: data.phoneNo2,
        ),
        ItemInfoWidget(
          title: 'Phone No. 3',
          value: data.phoneNo3,
        ),
        ItemInfoWidget(
          title: 'Email Address',
          value: data.emailAddress,
        ),
        ItemInfoWidget(
          title: 'Has VIBER Account',
          value: data.hasViberAccount.toYesNo(),
        ),
        if (data.hasViberAccount) ...[
          ItemInfoWidget(
            title: 'Same as Phone 1',
            value: data.isViberAccountSameNo.toYesNo(),
          ),
          if (!data.isViberAccountSameNo)
            ItemInfoWidget(
              title: 'Account No (if different)',
              value: data.viberPhoneNo,
            )
        ],
      ],
    );
  }
}
