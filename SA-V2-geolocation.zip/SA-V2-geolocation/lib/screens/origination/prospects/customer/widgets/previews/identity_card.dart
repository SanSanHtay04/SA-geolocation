import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/utils/datetime_x.dart';
import 'package:sales/widgets/info_preview_card.dart';
import 'package:sales/widgets/item_info_widget.dart';

import '../../notifiers/form/customer_form_notifier.dart';

class IdentityCard extends StatelessWidget {
  const IdentityCard({super.key});

  @override
  Widget build(BuildContext context) {
    final data = context.watch<CustomerFormNotifier>().state;

    return InfoPreviewCard(
      isViewCard: false,
      primaryLabel: 'IDENTITY',
      children: [
        ItemInfoWidget(
          title: 'Customer Name',
          value: data.customerFullName,
        ),
        ItemInfoWidget(
          title: 'Birth Date',
          value: data.birthDate?.format(),
        ),
        ItemInfoWidget(
          title: 'Gender',
          value: data.gender.name,
        ),
        ItemInfoWidget(
          title: "Father's Name",
          value: data.fatherName,
        ),
        ItemInfoWidget(
          title: "Education",
          value: data.education?.educationName,
        ),
      ],
    );
  }
}
/*
 // ItemInfoWidget(
                          //   title: 'Driving License',
                          //   value: _custIdentity!['drivingLicenseNo'] ??
                          //       '-/-',
                          // ),
                          // Divider(
                          //   height: 10,
                          //   thickness: 0.5,
                          // ),
                          // ItemInfoWidget(
                          //   title: "Father's Birth Date",
                          //   value: _custIdentity!['fatherBirthDate'] ==
                          //           null
                          //       ? '-/-'
                          //       : DateFormat('dd/MM/yyyy').format(
                          //           DateTime.parse(_custIdentity![
                          //               'fatherBirthDate'])),
                          // ),
                          // Divider(
                          //   height: 10,
                          //   thickness: 0.5,
                          // ),
 */
