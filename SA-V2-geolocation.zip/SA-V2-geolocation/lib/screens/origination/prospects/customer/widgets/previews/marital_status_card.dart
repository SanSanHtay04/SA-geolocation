import 'package:flutter/cupertino.dart';
import 'package:provider/provider.dart';
import 'package:sales/widgets/info_preview_card.dart';
import 'package:sales/widgets/item_info_widget.dart';

import '../../notifiers/form/customer_form_notifier.dart';

class MaritalStatusCard extends StatelessWidget {
  const MaritalStatusCard({super.key});

  @override
  Widget build(BuildContext context) {
    final data = context.watch<CustomerFormNotifier>().state;

    final isMarried = (data.maritalStatus != null &&
        data.maritalStatus?.maritalStatusId == 2);
    return InfoPreviewCard(
      isViewCard: false,
      primaryLabel: 'MARITAL STATUS',
      children: [
        ItemInfoWidget(
          title: 'Marital Status',
          value: data.maritalStatus?.maritalStatusName,
        ),
        if (isMarried) ...[
          ItemInfoWidget(
            title: 'Spouse Name',
            value: data.spouseName,
          ),
          ItemInfoWidget(
            title: 'Spouse Mobile',
            value: '${data.spousePhone} (${data.spousePhoneStatus?.name})',
          ),
          ItemInfoWidget(
            title: 'Spouse NRC Number',
            value: data.spouseNrcDetail?.natRegCardNo(),
          ),
        ],
      ],
    );
  }
}
