import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class CustomerAddressMapView extends StatefulWidget {
  final LatLng? myLocation;
  final GestureTapCallback onMyLocationClick;
  final double? minHeight;

  const CustomerAddressMapView({
    Key? key,
    required this.myLocation,
    required this.onMyLocationClick,
    required this.minHeight,
  }) : super(key: key);

  @override
  State<CustomerAddressMapView> createState() => _CustomerAddressMapViewState();
}

class _CustomerAddressMapViewState extends State<CustomerAddressMapView> {
  MapController _controller = MapController();

  @override
  Widget build(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      if (widget.myLocation != null) {
        _controller.move(widget.myLocation!, 17.0);
      }
    });
    return Column(
      children: [
        SizedBox(
          height: widget.minHeight ?? 150,
          child: FlutterMap(
            mapController: _controller,
            options: MapOptions(
              cameraConstraint: CameraConstraint.contain(
                bounds: LatLngBounds(
                  const LatLng(-90, -180),
                  const LatLng(90, 180),
                ),
              ),
            ),
            children: [
              TileLayer(
                urlTemplate: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                subdomains: ['a', 'b', 'c'],
              ),
              MarkerLayer(markers: [
                if (widget.myLocation != null) ...{
                  _userMarker(widget.myLocation!),
                },
              ])
            ],
            nonRotatedChildren: [
              _myLocationButton(widget.onMyLocationClick),
            ],
          ),
        ),
      ],
    );
  }

  Marker _userMarker(LatLng location) {
    return Marker(
      point: location,
      child:Icon(
        Icons.location_on,
        color: Theme.of(context).primaryColor,
      ),
    );
  }

  Widget _myLocationButton(VoidCallback onPress) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 16, horizontal: 4),
      child: Align(
        alignment: Alignment.bottomRight,
        child: ElevatedButton(
          child: Icon(
            Icons.my_location,
            color: Theme.of(context).primaryColor,
          ),
          onPressed: onPress,
          style: ElevatedButton.styleFrom(
            shape: CircleBorder(),
            backgroundColor: Colors.white,
          ),
        ),
      ),
    );
  }
}
