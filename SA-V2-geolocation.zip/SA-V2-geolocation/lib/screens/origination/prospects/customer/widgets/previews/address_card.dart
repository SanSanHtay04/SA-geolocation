
import 'package:flutter/cupertino.dart';
import 'package:provider/provider.dart';
import 'package:sales/utils/location_helper.dart';
import 'package:sales/widgets/info_preview_card.dart';
import 'package:sales/widgets/item_info_widget.dart';

import '../../notifiers/form/customer_form_notifier.dart';

class AddressCard extends StatelessWidget {
  const AddressCard({super.key});

  @override
  Widget build(BuildContext context) {
    final data = context.watch<CustomerFormNotifier>().state;

    return InfoPreviewCard(
      isViewCard: false,
      primaryLabel: 'ADDRESS',
      children: [
        ItemInfoWidget(
          title: 'Home Status',
          value: data.address?.homeStatus.name,
        ),
        ItemInfoWidget(
          title: 'Home Address',
          value: data.address?.address,
        ),
        ItemInfoWidget(
          title: 'Home Geolocation',
          value: data.geoLocation.format(),
        ),
        Text(
          data.address.toString(),
          textAlign: TextAlign.left,
        ),
      ],
    );
  }
}
