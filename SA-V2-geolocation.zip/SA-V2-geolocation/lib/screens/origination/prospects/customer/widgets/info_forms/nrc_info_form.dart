import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';
import 'package:sales/screens/origination/presentation/widgets/nrc_view/widgets/nrc_view.dart';
import 'package:sales/widgets/form_card.dart';
import 'package:sales/widgets/loading_view.dart';

import '../../notifiers/form/customer_form_notifier.dart';

class NRCInfoForm extends StatelessWidget {
  const NRCInfoForm({super.key});

  @override
  Widget build(BuildContext context) {
    final formState = context.watch<CustomerFormNotifier>().state;

    return FormCard(
      title: 'NRC',
      content: formState.nrcDetail == null //&& (formState.loaded)

          ? const LoadingView()
          : NrcView(
              initialValue: formState.nrcDetail,
              onNrcInfoChanged: (nrc) {
                context.read<CustomerFormNotifier>().updateNrc(nrc);
              },
            ),
    );
  }
}
