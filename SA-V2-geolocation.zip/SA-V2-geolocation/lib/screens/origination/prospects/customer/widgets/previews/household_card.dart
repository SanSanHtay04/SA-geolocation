import 'package:flutter/cupertino.dart';
import 'package:provider/provider.dart';
import 'package:sales/models/household_number.dart';
import 'package:sales/widgets/info_preview_card.dart';
import 'package:sales/widgets/item_info_widget.dart';

import '../../notifiers/form/customer_form_notifier.dart';

class HouseholdCard extends StatelessWidget {
  const HouseholdCard({super.key, this.data});

  final HouseholdNumber? data;

  @override
  Widget build(BuildContext context) {
    final data = context.watch<CustomerFormNotifier>().state.householdNumber;

    return InfoPreviewCard(
      isViewCard: false,
      primaryLabel: 'HOUSEHOLD',
      children: [
        ItemInfoWidget(
          title: 'Children',
          value: data.childrenText,
        ),
        ItemInfoWidget(
          title: 'Relatives',
          value: data.relativeText,
        ),
        ItemInfoWidget(
          title: 'Others',
          value: data.otherText,
        ),
        ItemInfoWidget(
          title: 'Total Household',
          value: data.totalHouseholdText,
        ),
      ],
    );
  }
}
