import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';
import 'package:sales/models/gender_type.dart';
import 'package:sales/screens/origination/presentation/widgets/education_view/widgets/education_status_view.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/form_card.dart';
import 'package:sales/widgets/selected_group/single_selected_group.dart';
import 'package:sales/widgets/text_form_field/clearable_text_form_field.dart';
import 'package:sales/widgets/text_form_field/date_picker_field.dart';

import '../../notifiers/form/customer_form_notifier.dart';

class IdentityInfoForm extends StatelessWidget {
  const IdentityInfoForm({super.key});

  @override
  Widget build(BuildContext context) {
    final formState = context.watch<CustomerFormNotifier>().state;
    final now = DateTime.now();

    return FormCard(
      title: 'Identity',
      content: Column(
        children: [
          ClearableTextFormField(
            labelText: 'Customer Name',
            required: true,
            textCapitalization: TextCapitalization.words,
            inputFormatters: [FilteringTextInputFormatter.allow(RegExp("[a-zA-Z ]"))],
            initialValue: formState.customerFullName,
            onChanged: (name) {
              context.read<CustomerFormNotifier>().updateCustomerName(name);
            },
          ),
          kSpaceVertical8,
          SingleSelectedGroup<GenderType>(
            label: 'Gender',
            required: true,
            items: GenderType.values,
            labelParser: (item) => item.getName(context),
            selectedItem: formState.gender,
            onSelectChanged: (item) {
              context.read<CustomerFormNotifier>().updateGender(item);
            },
          ),
          kSpaceVertical8,
          DatePickerField(
            required: true,
            labelText: 'Date of Birth',
            minTime: DateTime(now.year - 60, now.month, now.day),
            maxTime: DateTime(now.year - 18, now.month, now.day),
            onConfirm: (date) {
              context.read<CustomerFormNotifier>().updateDob(date);
            },
            selectedDateTime: formState.birthDate,
          ),
          kSpaceVertical8,
          ClearableTextFormField(
            labelText: 'Father Name',
            textCapitalization: TextCapitalization.words,
            inputFormatters: [FilteringTextInputFormatter.allow(RegExp("[a-zA-Z ]"))],
            required: true,
            initialValue: formState.fatherName,
            onChanged: (name) {
              context.read<CustomerFormNotifier>().updateFatherName(name);
            },
          ),
          kSpaceVertical8,
          EducationStatusView(
            selectedValue: formState.education,
            onChanged: (status) {
              context.read<CustomerFormNotifier>().updateEducation(status);
            },
          ),
          kSpaceVertical8,
        ],
      ),
    );
  }
}
