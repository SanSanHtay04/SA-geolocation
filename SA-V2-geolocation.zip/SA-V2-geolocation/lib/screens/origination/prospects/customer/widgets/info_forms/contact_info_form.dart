import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/models/phone_type.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/form_card.dart';
import 'package:sales/widgets/selected_field/selected_field.dart';
import 'package:sales/widgets/selected_group/single_selected_group.dart';
import 'package:sales/widgets/text_form_field/clearable_text_form_field.dart';
import 'package:sales/widgets/text_form_field/phone_text_form_field.dart';
import 'package:sales/widgets/text_form_field/text_area_field.dart';

import '../../notifiers/form/customer_form_notifier.dart';

class ContactInfoForm extends StatelessWidget {
  const ContactInfoForm({super.key});

  @override
  Widget build(BuildContext context) {
    final formState = context.watch<CustomerFormNotifier>().state;

    return FormCard(
      title: 'Contact',
      content: Column(
        children: [
          PhoneTextFormField(
            initialValue: formState.phoneNo1,
            labelText: 'Phone 1',
            required: true,
            onChanged: (number) {
              context.read<CustomerFormNotifier>().updatePhone1(number);
            },
          ),
          kSpaceVertical8,
          SelectedField<PhoneStatus>(
            title: 'Phone Status',
            required: true,
            items: PhoneStatus.values,
            labelParser: (item) => item.getName(context),
            selectedItem: formState.phoneStatus1,
            onSelected: (type) {
              context.read<CustomerFormNotifier>().updatePhoneStatus(type);
            },
          ),
          kSpaceVertical8,
          SingleSelectedGroup<PhoneType>(
            label: 'Phone Type',
            required: true,
            items: PhoneType.values,
            labelParser: (item) => item.getName(context),
            selectedItem: formState.phoneType1,
            onSelectChanged: (item) {
              context.read<CustomerFormNotifier>().updatePhoneType(item);
            },
          ),
          kSpaceVertical8,
          TextAreaField(
            initialValue: formState.phoneRemark1,
            labelText: 'Remark',
            onChanged: (remark) {
              context.read<CustomerFormNotifier>().updatePhoneRemark(remark);
            },
          ),
          kSpaceVertical8,
          PhoneTextFormField(
            initialValue: formState.phoneNo2,
            labelText: 'Phone 2',
            onChanged: (number) {
              context.read<CustomerFormNotifier>().updatePhone2(number);
            },
          ),
          kSpaceVertical8,
          PhoneTextFormField(
            initialValue: formState.phoneNo3,
            labelText: 'Phone 3',
            onChanged: (number) {
              context.read<CustomerFormNotifier>().updatePhone3(number);
            },
          ),
          kSpaceVertical8,
          ClearableTextFormField(
            labelText: 'Email Address',
            keyboardType: TextInputType.emailAddress,
            initialValue: formState.emailAddress,
            onChanged: (email) {
              context.read<CustomerFormNotifier>().updateEmailAddress(email);
            },
          ),
          kSpaceVertical8,
          SwitchListTile(
            value: formState.hasViberAccount,
            title: Text('Has VIBER Account'),
            onChanged: (value) {
              context.read<CustomerFormNotifier>().toggleHasViberAccount(value);
            },
          ),
          kSpaceVertical8,
          if (formState.hasViberAccount) ...[
            SwitchListTile(
              value: formState.isViberAccountSameNo,
              title: Text('Same as Phone1(${formState.phoneNo1})'),
              onChanged: (value) {
                context.read<CustomerFormNotifier>().toggleIsViberSameNo1(value);
              },
            ),
            kSpaceVertical8,
            ClearableTextFormField(
              labelText: 'Viber account name',
              required: true,
              initialValue: formState.viberAccountName,
              onChanged: (text) {
                context.read<CustomerFormNotifier>().updateViberAccountName(text);
              },
            ),
            kSpaceVertical8,
          ],
          if (!formState.isViberAccountSameNo && formState.hasViberAccount) ...[
            PhoneTextFormField(
              initialValue: formState.viberPhoneNo,
              labelText: 'Viber Phone Number',
              required: true,
              onChanged: (number) {
                context.read<CustomerFormNotifier>().updateViberAccountNo(number);
              },
            ),
          ]
        ],
      ),
    );
  }
}
