import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';
import 'package:sales/screens/origination/presentation/widgets/address_view/widgets/address_widget.dart';
import 'package:sales/widgets/loading_view.dart';

import '../../notifiers/form/customer_form_notifier.dart';

class AddressInfoForm extends StatelessWidget {
  const AddressInfoForm({super.key});

  @override
  Widget build(BuildContext context) {
    final formState = context.watch<CustomerFormNotifier>().state;
    return formState.address == null
        ? const LoadingView()
        : AddressWidget(
            address: formState.address,
            onAddressChanged: (address) {
              context.read<CustomerFormNotifier>().updateAddress(address);
            },
          );
  }
}
