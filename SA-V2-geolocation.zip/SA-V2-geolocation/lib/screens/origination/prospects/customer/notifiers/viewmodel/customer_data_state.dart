
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/base/error.dart';
import 'package:sales/data/remote/models/models.dart';
part 'customer_data_state.freezed.dart';

@freezed
class CustomerDataState with _$CustomerDataState {
  const factory CustomerDataState.initial({
    int? prospectId,
    int? applicationId,
    Customer? customer,
  }) = CustomerDataStateInitial;

  const factory CustomerDataState.loading() = CustomerDataStateLoading;

  const factory CustomerDataState.failed(String msg, {AppError? error}) =
  CustomerDataStateFailed;
}
