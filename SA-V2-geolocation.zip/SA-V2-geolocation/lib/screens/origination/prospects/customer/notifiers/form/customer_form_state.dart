import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/models/models.dart';
import 'package:latlong2/latlong.dart';

part 'customer_form_state.freezed.dart';

@freezed
class CustomerFormState with _$CustomerFormState {
  const CustomerFormState._();

  const factory CustomerFormState({
    @Default(false) bool loaded,
    int? customerId,
    int? prospectId,
    int? applicationId,
    @Default('') String customerFullName,
    DateTime? birthDate,
    @Default(GenderType.male) GenderType gender,
    @Default('') String fatherName,
    EducationLevel? education,
    NRCNumber? nrcDetail,
    MaritalStatus? maritalStatus,
    String? spouseName,
    String? spousePhone,
    PhoneStatus? spousePhoneStatus,
    NRCNumber? spouseNrcDetail,
    Address? address,
    LatLng? geoLocation,
    String? geoAddress,
    @Default(HouseholdNumber()) HouseholdNumber householdNumber,
    @Default('') String phoneNo1,
    PhoneStatus? phoneStatus1,
    @Default(PhoneType.mobile) PhoneType phoneType1,
    @Default('') String phoneRemark1,
    @Default('') String phoneNo2,
    @Default('') String phoneNo3,
    @Default('') String emailAddress,
    @Default(false) bool hasViberAccount,
    @Default(false) bool isViberAccountSameNo,
    @Default('') String viberAccountName,
    @Default('') String viberPhoneNo,
    InternalFraudCode? fraudCode,
    @Default(false) bool isOwnedMoto,
    @Default(false) bool isTakenContract,
    @Default(false) bool isTakenLoan,
    @Default('') String motoRemark,
    @Default('') String customerRemark,
  }) = _CustomerFormState;

  String get titleText => customerId == null ? 'Create Customer' : 'Edit Customer';

  String get descriptionText => customerId == null ? 'Are you sure you want to create new customer?' : 'Are you sure you want to edit customer information?';

  bool get isNewProspect => prospectId == null;

  CustomerRequest toRequest() => CustomerRequest(
    prospectId: prospectId!,
    applicationId: applicationId!,
    customerFullName: customerFullName,
    gender: gender,
    birthDate: birthDate,
    fatherName: fatherName,
    educationId: education?.educationId,
    nrc2Id: nrcDetail!.nrcPrefix?.nrc2Id,
    nrcType: nrcDetail!.nrcType,
    frcPrefix: nrcDetail!.type == NRCNumberType.frc ? nrcDetail!.frcPrefix : null,
    nrcNumber: nrcDetail!.number ?? '',
    natRegCardIssDate: nrcDetail!.issuanceDate,
    natRegCardNo: nrcDetail!.natRegCardNo(),
    maritalStatusId: maritalStatus?.maritalStatusId == 0 ? null : maritalStatus?.maritalStatusId,
    spouseName: spouseName,
    spouseMobileNo: spousePhone,
    spouseMobileStatus: spousePhoneStatus,
    spouseNrc2Id: spouseNrcDetail?.nrcPrefix?.nrc2Id,
    spouseNrcType: spouseNrcDetail?.nrcType,
    spouseFrcPrefix: spouseNrcDetail!.type == NRCNumberType.frc ? spouseNrcDetail!.frcPrefix : null,
    spouseNrcNumber: spouseNrcDetail?.number,
    spouseNatRegCardIssDate: spouseNrcDetail?.issuanceDate,
    spouseNatRegCardNo: spouseNrcDetail?.natRegCardNo(),
    homeAddress: address?.address,
    homeStatus: address?.homeStatus ?? HomeStatus.owned,
    geoTownShipId: address?.township?.geoTownShipId,
    geoTownId: address?.type == AddressType.urban
        ? address?.town?.geoTownId
        : address?.villageTract?.geoTownId,
    geoWardId: address?.ward?.geoWardId,
    geoVillageId: address?.village?.geoVillageId,
    homeGeoAddress: geoAddress,
    homeGeoLatitude:geoLocation == null ? null:
    double.parse((geoLocation!.latitude).toStringAsFixed(6)),
    homeGeoLongitude:geoLocation == null ? null:
    double.parse((geoLocation!.longitude).toStringAsFixed(6)),
    childrenHousehold: householdNumber.children,
    relativeHousehold: householdNumber.relative,
    otherHousehold: householdNumber.other,
    totalHousehold: householdNumber.totalHouseHold,
    phoneNo1: phoneNo1,
    phoneStatus1: phoneStatus1,
    phoneType1: phoneType1,
    phoneRemark1: phoneRemark1,
    phoneNo2: phoneNo2,
    phoneNo3: phoneNo3,
    emailAddress: emailAddress,
    hasViberAccount: hasViberAccount,
    isViberAccountSameNo: isViberAccountSameNo,
    viberPhoneNo: viberPhoneNo,
    viberName:  viberAccountName,
    fraudCode: fraudCode,
    isOwnedMoto: isOwnedMoto,
    isTakenContract: isTakenContract,
    isTakenLoan: isTakenLoan,
    motoRemark: motoRemark,
    customerRemark: customerRemark,
  );

  CustomerEditRequest toEditRequest() => CustomerEditRequest(
    customerFullName: customerFullName,
    gender: gender,
    birthDate: birthDate,
    fatherName: fatherName,
    educationId: education?.educationId,
    nrc2Id: nrcDetail!.nrcPrefix?.nrc2Id,
    nrcType: nrcDetail!.nrcType,
    frcPrefix: nrcDetail!.type == NRCNumberType.frc ? nrcDetail!.frcPrefix : null,
    nrcNumber: nrcDetail!.number ?? '',
    natRegCardIssDate: nrcDetail!.issuanceDate,
    natRegCardNo: nrcDetail!.natRegCardNo(),
    maritalStatusId: maritalStatus?.maritalStatusId == 0
        ? null
        : maritalStatus?.maritalStatusId,
    spouseName: spouseName,
    spouseMobileNo: spousePhone,
    spouseMobileStatus: spousePhoneStatus,
    spouseNrc2Id: spouseNrcDetail?.nrcPrefix?.nrc2Id,
    spouseNrcType: spouseNrcDetail?.nrcType,
    spouseFrcPrefix: spouseNrcDetail!.type == NRCNumberType.frc ? spouseNrcDetail!.frcPrefix : null,
    spouseNrcNumber: spouseNrcDetail?.number,
    spouseNatRegCardIssDate: spouseNrcDetail?.issuanceDate,
    spouseNatRegCardNo: spouseNrcDetail?.natRegCardNo(),
    homeAddress: address?.address,
    homeStatus: address?.homeStatus ?? HomeStatus.owned,
    geoTownShipId: address?.township?.geoTownShipId,
    geoTownId: address?.type == AddressType.urban
        ? address?.town?.geoTownId
        : address?.villageTract?.geoTownId,
    geoWardId: address?.ward?.geoWardId,
    geoVillageId: address?.village?.geoVillageId,
    homeGeoAddress: geoAddress,
    homeGeoLatitude: geoLocation == null ? null:
    double.parse((geoLocation!.latitude).toStringAsFixed(6)),
    homeGeoLongitude:geoLocation == null ? null:
    double.parse((geoLocation!.longitude).toStringAsFixed(6)),
    childrenHousehold: householdNumber.children,
    relativeHousehold: householdNumber.relative,
    otherHousehold: householdNumber.other,
    totalHousehold: householdNumber.totalHouseHold,
    phoneNo1: phoneNo1,
    phoneStatus1: phoneStatus1,
    phoneType1: phoneType1,
    phoneRemark1: phoneRemark1,
    phoneNo2: phoneNo2,
    phoneNo3: phoneNo3,
    emailAddress: emailAddress,
    hasViberAccount: hasViberAccount,
    isViberAccountSameNo: isViberAccountSameNo,
    viberPhoneNo: viberPhoneNo,
    viberName: viberAccountName,
    fraudCode: fraudCode,
    isOwnedMoto: isOwnedMoto,
    isTakenContract: isTakenContract,
    isTakenLoan: isTakenLoan,
    motoRemark: motoRemark,
    customerRemark: customerRemark,
  );
}