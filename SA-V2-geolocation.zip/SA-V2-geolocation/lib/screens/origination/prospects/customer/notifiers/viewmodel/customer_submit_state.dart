import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/base/error.dart';

part 'customer_submit_state.freezed.dart';

@freezed
class CustomerSubmitState with _$CustomerSubmitState {
  const factory CustomerSubmitState.initial() = CustomerSubmitStateInitial;

  const factory CustomerSubmitState.loading() = CustomerSubmitStateLoading;

  const factory CustomerSubmitState.failed(String message, {AppError? error}) = CustomerSubmitStateFailed;

  const factory CustomerSubmitState.success(String message) = CustomerSubmitStateSuccess;
}