
import 'package:flutter/foundation.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/models/models.dart';
import 'package:latlong2/latlong.dart';
import 'package:sales/utils/logging.dart';

import 'customer_form_state.dart';

class CustomerFormNotifier extends ChangeNotifier {
  CustomerFormNotifier();

  CustomerFormState state = const CustomerFormState();

  void emit(CustomerFormState data) {
    state = data;
    notifyListeners();
  }

  void resetData() {
    emit(const CustomerFormState());
  }

  Future<void> getCurrentLocation() async {
    final position = await Geolocator.getCurrentPosition();
    final addresses = await placemarkFromCoordinates(position.latitude, position.longitude);

    final address = addresses.first;
    emit(state.copyWith(
      geoLocation: LatLng(position.latitude, position.longitude),
      geoAddress: "${address.name}, ${address.street}, ${address.subAdministrativeArea}, ${address.administrativeArea}",
    ));
  }

  void updateLocation(LatLng? location, String? name) {
    if (location == null || name == null) return;
    emit(state.copyWith(geoLocation: location, geoAddress: name));
  }

  loadData(int? prospectId, int? appId, Customer? customer) {
    /// We need to add this line to make sure that prospect is loaded once
    if (customer == null || state.loaded) return;
    emit(customer.toDomain(prospectId, appId));
  }

  /** Update Identity  */
  updateCustomerName(String name) {
    emit(state.copyWith(customerFullName: name));
  }

  updateGender(GenderType gender) {
    emit(state.copyWith(gender: gender));
  }

  updateDob(DateTime? date) {
    emit(state.copyWith(birthDate: date));
  }

  updateFatherName(String name) {
    emit(state.copyWith(fatherName: name));
  }

  updateNrc(NRCNumber nrc) {
    emit(state.copyWith(nrcDetail: nrc));
  }

  updateEducation(EducationLevel level) {
    emit(state.copyWith(education: level));
  }

  /** Update Marital Status */
  updateMaritalStatus(MaritalStatus status) {
    emit(state.copyWith(maritalStatus: status));
  }

  updateSpouseName(String name) {
    emit(state.copyWith(spouseName: name));
  }

  updateSpousePhone(String phone) {
    emit(state.copyWith(spousePhone: phone));
  }

  updateSpousePhoneStatus(PhoneStatus value) {
    emit(state.copyWith(spousePhoneStatus: value));
  }

  updateSpouseNrc(NRCNumber nrc) {
    emit(state.copyWith(spouseNrcDetail: nrc));
  }

  updateAddress(Address address) {
    AppLogger.i("updateAddress: ${address} ${address.getLatlng()} : ${address.getAddressName()}");

    emit(state.copyWith(
      address: address,
      geoLocation: address.getLatlng(),
      geoAddress: address.getAddressName(),
    ));
  }

  /** Update CONTACT */
  updatePhone1(String phone) {
    emit(state.copyWith(phoneNo1: phone));
  }

  updatePhone2(String phone) {
    emit(state.copyWith(phoneNo2: phone));
  }

  updatePhoneStatus(PhoneStatus status) {
    emit(state.copyWith(phoneStatus1: status));
  }

  updatePhoneType(PhoneType type) {
    emit(state.copyWith(phoneType1: type));
  }

  updatePhoneRemark(String remark) {
    emit(state.copyWith(phoneRemark1: remark));
  }

  updatePhone3(String phone) {
    emit(state.copyWith(phoneNo3: phone));
  }

  updateEmailAddress(String email) {
    emit(state.copyWith(emailAddress: email));
  }

  updateViberAccountName(String viberName) {
    emit(state.copyWith(viberAccountName: viberName));
  }

  toggleHasViberAccount(bool hasAccount) {
    emit(state.copyWith(
      hasViberAccount: hasAccount,
      isViberAccountSameNo: false,
      viberAccountName: "",
      viberPhoneNo: "",
    ));
  }

  toggleIsViberSameNo1(bool isSame) {
    emit(state.copyWith(isViberAccountSameNo: isSame));
  }

  updateViberAccountNo(String account) {
    emit(state.copyWith(viberPhoneNo: account));
  }

  /** Update HouseHold */
  updateChildrenHousehold(String count) {
    updateHouseHoldNumber(children: count);
  }

  updateRelativeHousehold(String count) {
    updateHouseHoldNumber(relative: count);
  }

  updateOtherHousehold(String count) {
    updateHouseHoldNumber(other: count);
  }

  updateHouseHoldNumber({String? children, String? relative, String? other}) {
    final current = state.householdNumber;
    emit(state.copyWith(
      householdNumber: HouseholdNumber(
        children: children != null ? int.parse(children) : current.children,
        relative: relative != null ? int.parse(relative) : current.relative,
        other: other != null ? int.parse(other) : current.other,
      ),
    ));
  }

  /** Update Other */
  updateInternalFraudCode(InternalFraudCode fraudCode) {
    emit(state.copyWith(fraudCode: fraudCode));
  }

  toggleOwnedMotorcycle(bool isOwned) {
    emit(state.copyWith(isOwnedMoto: isOwned));
  }

  togglePurchaseContract(bool isTaken) {
    emit(state.copyWith(isTakenContract: isTaken));
  }

  toggleFinanceLoan(bool isTaken) {
    emit(state.copyWith(isTakenLoan: isTaken));
  }

  updateFinanceRemark(String remark) {
    emit(state.copyWith(motoRemark: remark));
  }

  updateCustomerRemark(String remark) {
    emit(state.copyWith(customerRemark: remark));
  }
}
