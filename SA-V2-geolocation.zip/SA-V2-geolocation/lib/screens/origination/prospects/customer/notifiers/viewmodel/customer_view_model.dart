
import 'package:flutter/widgets.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/data/repositories/repositories.dart';

import '../form/customer_form_state.dart';
import 'customer_data_state.dart';
import 'customer_submit_state.dart';

class CustomerViewModel extends ChangeNotifier {
  final CustomerRepository repo;

  CustomerViewModel(this.repo);

  CustomerDataState state = CustomerDataState.initial();
  CustomerSubmitState submitState = const CustomerSubmitState.initial();

  bool get isLoading => (state is CustomerDataStateLoading) || (submitState is CustomerSubmitStateLoading);

  CustomerDataStateInitial? get _data => (state is CustomerDataStateInitial) ? (state as CustomerDataStateInitial) : null;

  Customer? get customer => _data?.customer ?? null;

  setDataState(CustomerDataState data) {
    state = data;
    notifyListeners();
  }

  // TODO: Rather than accepting map, we need to figure out DataModel
  getCustomerInfo(Map<String, dynamic> prospect) async {
    final customerId = prospect['createdCustId'] ?? null;

    /// Check the customer is new creating
    if (customerId == null) {
      setDataState(CustomerDataState.initial(
        prospectId: prospect['prospectId'],
        applicationId: prospect['applicationId'],
        customer: Customer(
          customerFullName: prospect['prospectName'],
          phoneNo1: prospect['prospectMobile'],
        ),
      ));
      return;
    }

    /// the editing customer need to load previous customer's information
    setDataState(const CustomerDataState.loading());
    final res = await repo.getCustomerInfo(customerId);
    final newState = res.when(
      success: (data) => CustomerDataState.initial(
        prospectId: prospect['prospectId'],
        applicationId: prospect['applicationId'],
        customer: data,
      ),
      failed: (message, error) => CustomerDataState.failed(message, error: error),
    );
    setDataState(newState);
  }

  setSubmitState(CustomerSubmitState data) {
    submitState = data;
    notifyListeners();
  }

  resetSubmitState() => setSubmitState(const CustomerSubmitState.initial());

  save(CustomerFormState data) {
    (data.customerId == null) ? _create(data) : _edit(data);
  }

  _create(CustomerFormState data) async {
    setSubmitState(const CustomerSubmitState.loading());
    final res = await repo.createCustomer(data);
    final newState = res.when(
      success: (data) => CustomerSubmitState.success(data),
      failed: (message, error) => CustomerSubmitState.failed(message, error: error),
    );
    setSubmitState(newState);
  }

  _edit(CustomerFormState data) async {
    setSubmitState(const CustomerSubmitState.loading());
    final res = await repo.updateCustomer(data);
    final newState = res.when(
      success: (data) => CustomerSubmitState.success(data),
      failed: (message, error) => CustomerSubmitState.failed(message, error: error),
    );
    setSubmitState(newState);
  }
}
