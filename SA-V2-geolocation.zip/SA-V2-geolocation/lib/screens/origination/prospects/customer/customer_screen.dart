import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/base/error.dart';
import 'package:sales/data/repositories/repositories.dart';
import 'package:sales/screens/origination/prospects/customer/notifiers/viewmodel/customer_view_model.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/app_snack_bar.dart';
import 'package:sales/widgets/copyright_notice.dart';

import 'package:sales/widgets/work_layout.dart';

import 'customer_info_widget.dart';
import 'notifiers/form/customer_form_notifier.dart';
import 'widgets/previews/previews.dart';

class CustomerScreen extends StatefulWidget {
  CustomerScreen({super.key, required this.customerId});

  static const routeName = '/customer-info';

  final int? customerId;

  bool get isNewCustomer => this.customerId == null;

  /**
   *  We have Data, Form, Submit Notifiers
   *  DataNotifier is to get the pre-required information
   *  FormNotifier is to track the user-input form information
   *  SubmitNotifier is to submit the form information to repository
   */
  static Widget create({required Map<String, dynamic> prospect}) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) => CustomerViewModel(
            CustomerRepository(context.read()),
          )..getCustomerInfo(prospect),
        ),
        ChangeNotifierProvider(
          create: (context) => CustomerFormNotifier(),
        ),
      ],
      child: CustomerScreen(
        customerId: prospect['createdCustId'] ?? null,
      ),
    );
  }

  @override
  _CustomerScreenState createState() => _CustomerScreenState();
}

class _CustomerScreenState extends State<CustomerScreen> {
  bool isPreviewMode = false;

  @override
  Widget build(BuildContext context) {
    return Consumer<CustomerViewModel>(
      builder: (_, vm, __) {
        /// Handle the call back from SubmitState
        Future.delayed(Duration.zero, (() {
          vm.submitState.maybeWhen(
            success: (msg) => context.showMessageDialog(
                message: msg,
                onClosePressed: () {
                  vm.resetSubmitState();
                  Navigator.pop(context);
                }),
            failed: (message, error) => context.showErrorDialog(
              error.errorMessage(context, message),
              onClosePressed: () => vm.resetSubmitState(),
            ),
            orElse: () {},
          );
        }));

        Future.delayed(Duration.zero, (() {
          vm.state.maybeWhen(
            /// Initialize customer information to form.
            initial: (prospectId, appId, customer) {
              context
                  .read<CustomerFormNotifier>()
                  .loadData(prospectId, appId, customer);
            },
            failed: (message, error) => context.showErrorDialog(
              error.errorMessage(context, message),
              onClosePressed: () {
                Navigator.pop(context);
              },
            ),
            orElse: () {},
          );
        }));

        return WorkLayout(
          appBar: AppBar(
            title: Text(
                widget.isNewCustomer ? 'Create Customer' : 'Edit Customer'),
            actions: <Widget>[
              IconButton(
                icon: Icon(isPreviewMode ? Icons.edit : Icons.remove_red_eye),
                onPressed: () => setState(() => isPreviewMode = !isPreviewMode),
              ),
            ],
          ),
          isBusy: vm.isLoading,
          child: Padding(
            padding: kPadding8,
            child: isPreviewMode
                ? CustomerInfoPreviewWidget()
                : CustomerInfoWidget(
                    vm: vm,
                    isNewCustomer: widget.isNewCustomer,
                  ),
          ),
        );
      },
    );
  }
}

class CustomerInfoPreviewWidget extends StatelessWidget {
  const CustomerInfoPreviewWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          IdentityCard(),
          kSpaceVertical8,
          NrcCard(),
          kSpaceVertical8,
          MaritalStatusCard(),
          kSpaceVertical8,
          HouseholdCard(),
          kSpaceVertical8,
          AddressCard(),
          kSpaceVertical8,
          ContactCard(),
          kSpaceVertical8,
          OtherCard(),
          kSpaceVertical8,
          CopyrightNotice(),
        ],
      ),
    );
  }
}
