import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/screens/origination/presentation/widgets/address_view/widgets/address_widget.dart';
import 'package:sales/screens/origination/presentation/widgets/marital_status/widgets/marital_status_view.dart';
import 'package:sales/screens/origination/presentation/widgets/nrc_view/widgets/nrc_info_card.dart';
import 'package:sales/screens/origination/prospects/customer/notifiers/viewmodel/customer_view_model.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/app_snack_bar.dart';
import 'package:sales/widgets/clear_save_button.dart';
import 'package:sales/widgets/copyright_notice.dart';
import 'package:sales/widgets/form_card.dart';
import 'notifiers/form/customer_form_notifier.dart';
import 'notifiers/form/customer_form_state.dart';
import 'widgets/info_forms/info_forms.dart';

class CustomerInfoWidget extends StatefulWidget {
  const CustomerInfoWidget({
    super.key,
    required this.vm,
    this.isNewCustomer = true,
  });

  final CustomerViewModel vm;

  final bool isNewCustomer;

  @override
  State<CustomerInfoWidget> createState() => _CustomerInfoWidgetState();
}

class _CustomerInfoWidgetState extends State<CustomerInfoWidget> {
  final _formKey = GlobalKey<FormState>();
  AutovalidateMode _mode = AutovalidateMode.disabled;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Expanded(
            child: widget.isNewCustomer
                ? NewCustomerFormWidget(
                    formKey: _formKey,
                    mode: _mode,
                  )
                : EditCustomerFormWidget(
                    formKey: _formKey,
                    mode: _mode,
                  )),
        kSpaceVertical8,
        ClearSaveButton(
          onButtonTapped: () {
            if (_formKey.currentState?.validate() ?? false) {
              final formState = context.read<CustomerFormNotifier>().state;
              /*
              if (formState.geoLocation == null) {
                showAlertModal(
                  context: context,
                  message: "Required to fill the customer geolocation.",
                  onDismiss: () {},
                );
              }
               */
              context.showConfirmDialog(
                message: formState.descriptionText,
                onConfirmPressed: () => widget.vm.save(formState),
              );
            } else {
              setState(() {
                _mode = AutovalidateMode.onUserInteraction;
              });
            }
          },
        ),
        CopyrightNotice()
      ],
    );
  }
}

class NewCustomerFormWidget extends StatelessWidget {
  const NewCustomerFormWidget({
    Key? key,
    required GlobalKey<FormState> formKey,
    required AutovalidateMode mode,
  })  : _formKey = formKey,
        _mode = mode,
        super(key: key);

  final GlobalKey<FormState> _formKey;
  final AutovalidateMode _mode;

  @override
  Widget build(BuildContext context) {
    final formState = context.watch<CustomerFormNotifier>().state;

    return SingleChildScrollView(
      child: Form(
        key: _formKey,
        autovalidateMode: _mode,
        child: Column(
          children: [
            const IdentityInfoForm(),
            kSpaceVertical8,
            NrcInfoCard(
              initialValue: formState.nrcDetail,
              onNrcInfoChanged: (info) {
                context.read<CustomerFormNotifier>().updateNrc(info);
              },
            ),
            kSpaceVertical8,
            MaritalStatusWidget(context, formState),
            kSpaceVertical8,
            AddressWidget(
              address: formState.address,
              onAddressChanged: (address) {
                context.read<CustomerFormNotifier>().updateAddress(address);
              },
            ),
            kSpaceVertical8,
            LocationInfoForm(),
            kSpaceVertical8,
            const HouseHoldInfoForm(),
            kSpaceVertical8,
            const ContactInfoForm(),
            kSpaceVertical8,
            const OtherInfoForm(),
          ],
        ),
      ),
    );
  }

  MaritalStatusWidget(BuildContext context, CustomerFormState formState) =>
      FormCard(
        title: 'Marital Status',
        content: MaritalStatusView(
          selectedValue: formState.maritalStatus,
          name: formState.spouseName,
          phone: formState.spousePhone,
          status: formState.spousePhoneStatus,
          nrcNumber: formState.spouseNrcDetail,
          onChanged: (status) {
            context.read<CustomerFormNotifier>().updateMaritalStatus(status);
          },
          onNameChanged: (name) {
            context.read<CustomerFormNotifier>().updateSpouseName(name);
          },
          onPhoneChanged: (phone) {
            context.read<CustomerFormNotifier>().updateSpousePhone(phone);
          },
          onStatusChanged: (status) {
            context
                .read<CustomerFormNotifier>()
                .updateSpousePhoneStatus(status);
          },
          onNrcChanged: (nrc) {
            context.read<CustomerFormNotifier>().updateSpouseNrc(nrc);
          },
        ),
      );
}

class EditCustomerFormWidget extends StatelessWidget {
  const EditCustomerFormWidget({
    Key? key,
    required GlobalKey<FormState> formKey,
    required AutovalidateMode mode,
  })  : _formKey = formKey,
        _mode = mode,
        super(key: key);

  final GlobalKey<FormState> _formKey;
  final AutovalidateMode _mode;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Form(
        key: _formKey,
        autovalidateMode: _mode,
        child: Column(
          children: [
            const IdentityInfoForm(),
            kSpaceVertical8,
            const NRCInfoForm(),
            kSpaceVertical8,
            const MaritalInfoForm(),
            kSpaceVertical8,
            const AddressInfoForm(),
            kSpaceVertical8,
            const LocationInfoForm(),
            kSpaceVertical8,
            const HouseHoldInfoForm(),
            kSpaceVertical8,
            const ContactInfoForm(),
            kSpaceVertical8,
            const OtherInfoForm(),
          ],
        ),
      ),
    );
  }
}
