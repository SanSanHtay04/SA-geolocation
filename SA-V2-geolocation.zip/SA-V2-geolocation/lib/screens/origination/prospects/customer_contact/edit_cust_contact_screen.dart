import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:provider/provider.dart';
import 'package:sales/data/local/db_sqlite_helper.dart';
import 'package:sales/data/local/models/models.dart';
import 'package:sales/providers/providers.dart';
import 'package:sales/utils/utils.dart';

import 'package:sales/widgets/waiting_modal_bottom_widget.dart';
import './partial_widgets/contact_identity_modal.dart';
import './partial_widgets/contact_income_modal.dart';
import './partial_widgets/contact_nrc_modal.dart';

import '../../../../widgets/deprecated/alert_modal_bottom_widget.dart';
import '../../../../widgets/deprecated/button_widget.dart';
import '../../../../widgets/deprecated/text_button_widget.dart';
import '../../../../widgets/item_info_widget.dart';

class EditCustContactScreen extends StatefulWidget {
  static const routeName = '/edit-cust-contact';

  final int? customerId;
  final int? contactDetId;
  final int? userId;
  final String? connectionType;

  EditCustContactScreen({Key? key, required this.customerId, required this.contactDetId, required this.userId, required this.connectionType}) : super(key: key);

  @override
  _EditCustContactScreenState createState() => _EditCustContactScreenState();
}

class _EditCustContactScreenState extends State<EditCustContactScreen> {
  bool _isLoading = false;
  String _message = "";
  Map<String, dynamic>? _contact;
  Map<String, dynamic> _contactIdentity = {};
  Map<String, dynamic> _contactNrc = {};
  Map<String, dynamic> _contactIncome = {};

  void _setContactIdentity(Map<String, dynamic> item) {
    setState(() {
      _contactIdentity = Map.from(item);
    });
    print('_contactIdentity $_contactIdentity');
  }

  void _setContactNrc(Map<String, dynamic> item) {
    setState(() {
      _contactNrc = Map.from(item);
    });
    print('_contactNrc $_contactNrc');
  }

  void _setContactIncome(Map<String, dynamic> item) {
    setState(() {
      _contactIncome = Map.from(item);
    });
    print('_contactIncome $_contactIncome');
  }

  void _createContactIdentity() {
    showModalBottomSheet(
        isScrollControlled: true,
        context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (BuildContext context, StateSetter setModalState /*You can rename this!*/) {
            return ContactIdentityModal(
              customerId: widget.customerId,
              contactDetId: widget.contactDetId,
              userId: widget.userId,
              connectionType: widget.connectionType,
              initialContactIdentity: _contactIdentity,
              setContactIdentity: _setContactIdentity,
            );
          });
        }).then((value) async {
      if (widget.contactDetId != null) {
        await _getCustomerContact(widget.customerId, widget.contactDetId);
      }
    });
  }

  void _createContactNrc() {
    showModalBottomSheet(
        isScrollControlled: true,
        context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (BuildContext context, StateSetter setModalState /*You can rename this!*/) {
            return ContactNrcModal(
              customerId: widget.customerId,
              contactDetId: widget.contactDetId,
              userId: widget.userId,
              contactRole: _contactIdentity['contactRole'],
              connectionType: widget.connectionType,
              initialContactNrc: _contactNrc,
              setContactNrc: _setContactNrc,
            );
          });
        }).then((value) async {
      if (widget.contactDetId != null) {
        await _getCustomerContact(widget.customerId, widget.contactDetId);
        print('_contactNrc: ${_contactNrc}');
      }
    });
  }

  void _createContactIncome() {
    showModalBottomSheet(
        isScrollControlled: true,
        context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (BuildContext context, StateSetter setModalState /*You can rename this!*/) {
            return ContactIncomeModal(
              customerId: widget.customerId,
              contactDetId: widget.contactDetId,
              userId: widget.userId,
              connectionType: widget.connectionType,
              contactRole: _contactIdentity['contactRole'],
              initialContactIncome: _contactIncome,
              setContactIncome: _setContactIncome,
            );
          });
        }).then((value) async {
      if (widget.contactDetId != null) {
        await _getCustomerContact(widget.customerId, widget.contactDetId);
      }
    });
  }

  void _saveContact() {
    bool _canSaveContact = true;

    if (_contactIdentity.isEmpty) {
      _canSaveContact = false;
      setState(() {
        _message = "Please fill IDENTITY info before saving.";
      });
    } else {
      if (_contactIdentity['contactRole'] != 'broker') {
        if (_contactNrc.isEmpty) {
          _canSaveContact = false;
          setState(() {
            _message = "Please fill NRC info before saving.";
          });
        }
      }

      if (_contactIdentity['contactRole'] == 'guarantor') {
        if (_contactIncome.isEmpty) {
          _canSaveContact = false;
          setState(() {
            _message = "Please fill INCOME info before saving.";
          });
        }
      }
    }

    if (_canSaveContact) {
      showAlertModal(
          context: context,
          message: "Are you sure you want to create new contact?",
          onDismiss: () async {
            String? _message = 'Something went wrong.';
            await showWaitingModal(
                context: context,
                message: "New contact is creating...",
                onWaiting: () async {
                  try {
                    Map<String, dynamic> _data = {
                      'customerId': widget.customerId,

                      // IDENTITY //
                      'contactRole': _contactIdentity['contactRole'],
                      'relationFullName': _contactIdentity['relationFullName'],
                      'relationDetail': _contactIdentity['relationDetail'],
                      'relationGender': _contactIdentity['relationGender'],
                      'contactValue': _contactIdentity['contactValue'],
                      'contactTypeId': 1,
                      'otherContactValue': _contactIdentity['otherContactValue'],
                      'homeAddress': _contactIdentity['homeAddress'],
                      'contactDetRemark': _contactIdentity['contactDetRemark'],

                      // NRC //
                      'nrc2Id': _contactNrc['nrc2Id'],
                      'nrcType': _contactNrc['nrcType'],
                      'nonNrcPrefix': _contactNrc['nonNrcPrefix'],
                      'nrcDetail': _contactNrc['nrcDetail'],
                      'natRegCardNo': _contactNrc['natRegCardNo'],
                      'natRegCardIssDate': _contactNrc['natRegCardIssDate'] == null ? null : _contactNrc['natRegCardIssDate'],

                      // INCOME //
                      'selfemployed': _contactIdentity['contactRole'] == 'guarantor' ? _contactIncome['selfemployed'] : null,
                      'businessTypeId': _contactIdentity['contactRole'] == 'guarantor' ? _contactIncome['businessTypeId'] : null,
                      'jobCategoryId': _contactIdentity['contactRole'] == 'guarantor' ? _contactIncome['jobCategoryId'] : null,
                      'workplaceName': _contactIdentity['contactRole'] == 'guarantor' ? _contactIncome['workplaceName'] : null,
                      'workplaceFixedTel': _contactIdentity['contactRole'] == 'guarantor' ? _contactIncome['workplaceFixedTel'] : null,
                      'workplaceAddress': _contactIdentity['contactRole'] == 'guarantor' ? _contactIncome['workplaceAddress'] : null,
                      'incomePeriodicity': _contactIdentity['contactRole'] == 'guarantor' ? _contactIncome['incomePeriodicity'] : null,
                      'incomeAmount': _contactIdentity['contactRole'] == 'guarantor' ? _contactIncome['incomeAmount'] : null,
                      'incomeSourceRemark': _contactIdentity['contactRole'] == 'guarantor' ? _contactIncome['incomeSourceRemark'] : null,
                    };

                    if (widget.connectionType == 'online') {
                      await Provider.of<CustomerContactDetailProvider>(context, listen: false).createRecord(widget.customerId, _data).then((value) {
                        _message = Provider.of<CustomerContactDetailProvider>(context, listen: false).responseMessage;
                      });
                    } else {
                      Map<String, dynamic> offlineCustomerContactDetail = Map<String, dynamic>.from(_data);

                      _message = 'New customer contact detail is successfully created.';
                      await DBSqliteHelper().createCustomerContactDetail(CustomerContactDetail.fromMap(offlineCustomerContactDetail), widget.customerId);
                    }
                  } catch (error) {
                    _message = error.toString();
                  }
                });
            await showAlertModal(
                context: context,
                message: _message,
                onDismiss: () {
                  Navigator.pop(context);
                });
          });
    }
  }

  Future<void> _getCustomerContact(int? customerId, int? contactDetId) async {
    setState(() {
      _isLoading = true;
    });

    try {
      if (widget.connectionType == 'online') {
        await Provider.of<CustomerContactDetailProvider>(context, listen: false).getRecord(customerId, contactDetId).then((value) {
          setState(() {
            _contact = Provider.of<CustomerContactDetailProvider>(context, listen: false).item;
            print("_contact: $_contact");
            this.setContactData(_contact);
            _isLoading = false;
          });
        });
      } else {
        Map<String, dynamic>? offlineCustomerContact = await DBSqliteHelper().getCustomerContactDetail(contactDetId);
        setState(() {
          _contact = Map<String, dynamic>.from(offlineCustomerContact!);
          _isLoading = false;
        });
      }
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  void setContactData(Map<String, dynamic>? contact) {
    if (contact != null) {
      // IDENTITY //
      _contactIdentity = {
        'contactRole': contact['contactRole'],
        'relationFullName': contact['relationFullName'],
        'relationDetail': contact['relationDetail'],
        'relationGender': contact['relationGender'],
        'contactValue': contact['contactValue'],
        'otherContactValue': contact['otherContactValue'],
        'homeAddress': contact['homeAddress'],
        'contactDetRemark': contact['contactDetRemark'],
      };

      // NRC //
      _contactNrc = {
        'cardType': contact['nrc2Id'] != null ? 'nrc' : (contact['natRegCardNo'] != null ? 'nonNrc' : 'na'),
        'nrc1Id': contact['nrc1Id'],
        'nrc1Name': contact['nrc1Name'],
        'nrc2Id': contact['nrc2Id'],
        'nrc2Name': contact['nrc2Name'],
        'nrcType': contact['nrcType'],
        'nonNrcPrefix': contact['nonNrcPrefix'],
        'nrcDetail': contact['nrcDetail'],
        'natRegCardNo': contact['natRegCardNo'],
        'natRegCardIssDate': contact['natRegCardIssDate'],
      };

      // INCOME //
      _contactIncome = {
        'selfemployed': contact['selfemployed'],
        'businessTypeId': contact['businessTypeId'],
        'businessTypeName': contact['businessTypeName'],
        'jobCategoryId': contact['jobCategoryId'],
        'jobCategoryName': contact['jobCategoryName'],
        'workplaceName': contact['workplaceName'],
        'workplaceFixedTel': contact['workplaceFixedTel'],
        'workplaceAddress': contact['workplaceAddress'],
        'incomePeriodicity': contact['incomePeriodicity'],
        'incomePeriodicityTitle': contact['incomePeriodicityTitle'],
        'incomeAmount': contact['incomeAmount'],
        'incomeSourceRemark': contact['incomeSourceRemark'],
      };
    }
  }

  void _initData() async {
    await _getCustomerContact(widget.customerId, widget.contactDetId);
    if (_contact != null) {
      setState(() {
        setContactData(_contact);
      });
    }
  }

  @override
  void initState() {
    super.initState();
    if (widget.contactDetId != null) {
      _initData();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      // resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: Text(
          '${widget.contactDetId == null ? 'CREATE' : 'EDIT'} CONTACT',
          style: TextStyle(color: Colors.white),
        ),
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: ModalProgressHUD(
        inAsyncCall: _isLoading,
        opacity: 0.5,
        progressIndicator: CircularProgressIndicator(
          valueColor: new AlwaysStoppedAnimation<Color>(
            context.getColorScheme().primary,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      // IDENTITY //
                      Container(
                        padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(children: [
                          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                            Text(
                              'IDENTITY',
                              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: _contactIdentity.isEmpty ? Colors.grey : Colors.teal[600]),
                            ),
                            TextButtonWidget(
                              text: _contactIdentity.isEmpty ? "CREATE" : "EDIT",
                              iconData: _contactIdentity.isEmpty ? Icons.add : Icons.edit,
                              onTap: _createContactIdentity,
                            )
                          ]),
                          _contactIdentity.isEmpty
                              ? SizedBox()
                              : Column(children: [
                                  Divider(
                                    height: 10,
                                    thickness: 0.5,
                                  ),
                                  // Employment Status //
                                  ItemInfoWidget(
                                    title: 'Role',
                                    value: "${_contactIdentity['contactRole'].toString().toUpperCase()}",
                                  ),

                                  Divider(
                                    height: 10,
                                    thickness: 0.5,
                                  ),
                                  // Full Name //
                                  ItemInfoWidget(
                                    title: 'Full Name',
                                    value: "${_contactIdentity['relationFullName']}",
                                  ),
                                  Divider(
                                    height: 10,
                                    thickness: 0.5,
                                  ),

                                  // Contact Gender //
                                  ItemInfoWidget(
                                    title: 'Gender',
                                    value: "${_contactIdentity['relationGender'] == 'm' ? 'Male' : 'Female'}",
                                  ),
                                  Divider(
                                    height: 10,
                                    thickness: 0.5,
                                  ),

                                  // Relation Detail //
                                  ItemInfoWidget(
                                    title: 'Relation Detail',
                                    value: "${_contactIdentity['relationDetail'] ?? '-/-'}",
                                  ),
                                  Divider(
                                    height: 10,
                                    thickness: 0.5,
                                  ),

                                  // Mobile No //
                                  ItemInfoWidget(
                                    title: 'Mobile',
                                    value: "${_contactIdentity['contactValue'] ?? '-/-'}",
                                  ),
                                  Divider(
                                    height: 10,
                                    thickness: 0.5,
                                  ),

                                  // Other Mobile //
                                  ItemInfoWidget(
                                    title: 'Other Mobile',
                                    value: "${_contactIdentity['otherContactValue'] ?? '-/-'}",
                                  ),
                                  Divider(
                                    height: 10,
                                    thickness: 0.5,
                                  ),

                                  // Home Address //
                                  ItemInfoWidget(
                                    title: 'Home Address',
                                    value: "${_contactIdentity['homeAddress'] ?? '-/-'}",
                                  ),
                                  Divider(
                                    height: 10,
                                    thickness: 0.5,
                                  ),

                                  // Contact Remark //
                                  ItemInfoWidget(
                                    title: 'Contact Remark',
                                    value: "${_contactIdentity['contactDetRemark'] ?? '-/-'}",
                                  ),
                                  Divider(
                                    height: 10,
                                    thickness: 0.5,
                                  ),

                                  SizedBox(
                                    height: 10,
                                  ),
                                ]),
                        ]),
                      ),

                      SizedBox(
                        height: 5,
                      ),

                      // NRC //
                      _contactIdentity.isEmpty
                          ? SizedBox()
                          : Container(
                              padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
                              decoration: BoxDecoration(
                                border: Border.all(color: Colors.grey),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Column(children: [
                                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                                  Text(
                                    'NRC',
                                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: _contactNrc.isEmpty ? Colors.grey : Colors.teal[600]),
                                  ),
                                  TextButtonWidget(
                                    text: _contactNrc.isEmpty ? "CREATE" : "EDIT",
                                    iconData: _contactNrc.isEmpty ? Icons.add : Icons.edit,
                                    onTap: _createContactNrc,
                                  )
                                ]),
                                _contactNrc.isEmpty
                                    ? SizedBox()
                                    : Column(children: [
                                        Divider(
                                          height: 10,
                                          thickness: 0.5,
                                        ),
                                        // NRC Number //
                                        ItemInfoWidget(
                                          title: 'NRC Number',
                                          value: "${_contactNrc['natRegCardNo'] ?? '-/-'}",
                                        ),
                                        Divider(
                                          height: 10,
                                          thickness: 0.5,
                                        ),

                                        // Issuance Date //
                                        ItemInfoWidget(
                                          title: 'Issuance Date',
                                          value: "${_contactNrc['natRegCardIssDate'] == null ? '-/-' : DateFormat('dd/MM/yyyy').format(DateTime.parse(_contactNrc['natRegCardIssDate'].toString()))}",
                                        ),
                                        Divider(
                                          height: 10,
                                          thickness: 0.5,
                                        ),
                                      ]),
                              ]),
                            ),
                      SizedBox(
                        height: 5,
                      ),

                      // INCOME //
                      _contactIdentity.isEmpty || _contactIdentity['contactRole'] != 'guarantor'
                          ? SizedBox()
                          : Container(
                              padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
                              decoration: BoxDecoration(
                                border: Border.all(color: Colors.grey),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Column(children: [
                                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                                  Text(
                                    'INCOME',
                                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: _contactIncome.isEmpty ? Colors.grey : Colors.teal[600]),
                                  ),
                                  TextButtonWidget(
                                    text: _contactIncome.isEmpty ? "CREATE" : "EDIT",
                                    iconData: _contactIncome.isEmpty ? Icons.add : Icons.edit,
                                    onTap: _createContactIncome,
                                  )
                                ]),
                                _contactIncome.isEmpty
                                    ? SizedBox()
                                    : Column(children: [
                                        Divider(
                                          height: 10,
                                          thickness: 0.5,
                                        ),
                                        _contactIdentity['contactRole'] == 'referee'
                                            ? SizedBox()
                                            : Column(
                                                children: [
                                                  // Employment Status //
                                                  ItemInfoWidget(
                                                    title: 'Employment Status',
                                                    value: "${_contactIncome['selfemployed'] == 2 ? 'No job / Un-employed' : (_contactIncome['selfemployed'] == 1 ? 'Self-employed' : (_contactIncome['selfemployed'] == 0 ? 'Employee' : '-/-'))}",
                                                  ),
                                                  Divider(
                                                    height: 10,
                                                    thickness: 0.5,
                                                  ),

                                                  // businessTypeName //
                                                  ItemInfoWidget(
                                                    title: 'Sector',
                                                    value: "${_contactIncome['businessTypeName'] ?? '-/-'}",
                                                  ),
                                                  Divider(
                                                    height: 10,
                                                    thickness: 0.5,
                                                  ),

                                                  // jobCategoryName //
                                                  ItemInfoWidget(
                                                    title: 'Job Category',
                                                    value: "${_contactIncome['jobCategoryName'] ?? '-/-'}",
                                                  ),
                                                  Divider(
                                                    height: 10,
                                                    thickness: 0.5,
                                                  ),

                                                  _contactIncome['selfemployed'] == 2
                                                      ? SizedBox()
                                                      : Column(
                                                          children: [
                                                            // workplaceName //
                                                            ItemInfoWidget(
                                                              title: 'Company/Employer Name',
                                                              value: "${_contactIncome['workplaceName'] ?? '-/-'}",
                                                            ),
                                                            Divider(
                                                              height: 10,
                                                              thickness: 0.5,
                                                            ),

                                                            // workplaceAddress //
                                                            ItemInfoWidget(
                                                              title: 'Company/Employer Address',
                                                              value: "${_contactIncome['workplaceAddress'] ?? '-/-'}",
                                                            ),
                                                            Divider(
                                                              height: 10,
                                                              thickness: 0.5,
                                                            ),

                                                            // workplaceFixedTel //
                                                            ItemInfoWidget(
                                                              title: 'Company/Employer Fixed Telephone',
                                                              value: "${_contactIncome['workplaceFixedTel'] ?? '-/-'}",
                                                            ),
                                                            Divider(
                                                              height: 10,
                                                              thickness: 0.5,
                                                            ),
                                                          ],
                                                        ),

                                                  // Income Periodicity //
                                                  ItemInfoWidget(
                                                    title: 'Income Periodicity',
                                                    value: "${_contactIncome['incomePeriodicityTitle'] ?? '-/-'}",
                                                  ),
                                                  Divider(
                                                    height: 10,
                                                    thickness: 0.5,
                                                  ),

                                                  // Income Amount//
                                                  ItemInfoWidget(
                                                    title: 'Income Amount',
                                                    value: "${_contactIncome['incomeAmount'] == null ? '-/-' : (NumberFormat('#,###').format(int.parse(_contactIncome['incomeAmount'].toString())) + " MMK")}",
                                                  ),
                                                  Divider(
                                                    height: 10,
                                                    thickness: 0.5,
                                                  ),

                                                  // Income Periodicity //
                                                  ItemInfoWidget(
                                                    title: 'Income Remark',
                                                    value: "${_contactIncome['incomeSourceRemark'] ?? '-/-'}",
                                                  ),
                                                  Divider(
                                                    height: 10,
                                                    thickness: 0.5,
                                                  ),
                                                ],
                                              ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                      ]),
                              ]),
                            ),
                      SizedBox(
                        height: 5,
                      ),
                      SizedBox(
                        height: 5,
                      ),
                    ],
                  ),
                ),
              ),
              widget.contactDetId != null
                  ? SizedBox()
                  : Column(
                      children: [
                        Divider(
                          color: Colors.teal,
                          height: 10,
                          thickness: 1.0,
                        ),
                        _message != ""
                            ? Text(
                                _message,
                                style: TextStyle(color: Colors.red),
                              )
                            : SizedBox(),
                        Container(
                          color: Colors.white,
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(0, 5, 0, 0),
                            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
                              Expanded(
                                child: ButtonWidget(
                                  text: "SAVE CONTACT",
                                  isWhiteBackgroundColor: false,
                                  onPressed: _saveContact,
                                ),
                              ),
                            ]),
                          ),
                        ),
                      ],
                    ),
            ],
          ),
        ),
      ),
    );
  }
}
