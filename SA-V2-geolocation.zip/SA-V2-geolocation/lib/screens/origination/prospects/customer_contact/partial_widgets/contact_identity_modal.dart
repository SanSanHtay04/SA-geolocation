import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:provider/provider.dart';
import 'package:sales/data/local/db_sqlite_helper.dart';
import 'package:sales/providers/providers.dart';
import 'package:sales/utils/utils.dart';

import 'package:sales/widgets/waiting_modal_bottom_widget.dart';
import '../../../../../widgets/confirmation_modal_bottom_widget.dart';
import '../../../../../widgets/deprecated/alert_modal_bottom_widget.dart';
import '../../../../../widgets/deprecated/button_widget.dart';
import '../../../../../widgets/deprecated/text_form_input.dart';

class ContactIdentityModal extends StatefulWidget {
  final int? customerId;
  final int? contactDetId;
  final int? userId;
  final String? connectionType;
  final Map<String, dynamic> initialContactIdentity;
  final Function(Map<String, dynamic>) setContactIdentity;

  ContactIdentityModal({required this.customerId, required this.contactDetId, required this.userId, required this.connectionType, required this.initialContactIdentity, required this.setContactIdentity});

  @override
  _ContactIdentityModalState createState() => _ContactIdentityModalState();
}

class _ContactIdentityModalState extends State<ContactIdentityModal> {
  bool _isLoading = false;

  final GlobalKey<FormState> _formKey = GlobalKey();
  String? _genderSelected = 'm';
  String? _contactRoleSelected = "referee";
  // Map<String, dynamic> _contactIdentity = {};
  Map<String, dynamic> _contactIdentity = {
    'contactRole': 'referee',
    'relationFullName': null,
    'relationGender': 'm',
    'relationDetail': null,
    'contactValue': null,
    'otherContactValue': null,
    'homeAddress': null,
  };

  // ROLE //
  void _onChangeRoleSelection(String? role) {
    setState(() {
      _contactIdentity['contactRole'] = role;
      _contactRoleSelected = role;
    });
  }

  // GENDER //
  void _onChangeGenderSelection(String? gender) {
    setState(() {
      _genderSelected = gender;
      _contactIdentity['relationGender'] = gender;
    });
  }

  // relationFullName //
  final _relationFullNameFocusNode = FocusNode();
  final _relationFullNameController = TextEditingController();

  void _setRelationFullName(String? value) {
    _contactIdentity['relationFullName'] = value!.trim().toUpperCase();
  }

  // relationDetail //
  final _relationDetailFocusNode = FocusNode();
  final _relationDetailController = TextEditingController();

  void _setRelationDetail(String? value) {
    _contactIdentity['relationDetail'] = value!.trim();
  }

  // contactValue //
  final _contactValueFocusNode = FocusNode();
  final _contactValueController = TextEditingController();

  void _seContactValue(String? value) {
    _contactIdentity['contactValue'] = value!.trim();
  }

  // otherContactValue //
  final _otherContactValueFocusNode = FocusNode();
  final _otherContactValueController = TextEditingController();

  void _setOtherContactValue(String? value) {
    _contactIdentity['otherContactValue'] = value!.trim();
  }

  // homeAddress //
  final _homeAddressFocusNode = FocusNode();
  final _homeAddressController = TextEditingController();

  void _setHomeAddress(String? value) {
    _contactIdentity['homeAddress'] = value!.trim();
  }

  // contactDetRemark //
  final _contactDetRemarkFocusNode = FocusNode();
  final _contactDetRemarkController = TextEditingController();

  void _setContactDetRemark(String? value) {
    _contactIdentity['contactDetRemark'] = value!.trim();
  }

  void _clearAllFields() {
    _initData();
  }

  void _confirmContactIdentity() {
    if (!_formKey.currentState!.validate()) {
      // Invalid!
      return;
    }
    _formKey.currentState!.save();
    if (widget.contactDetId == null) {
      _contactIdentity['contactRole'] = _contactRoleSelected;
      _contactIdentity['relationGender'] = _genderSelected;
      widget.setContactIdentity(_contactIdentity);
      Navigator.of(context).pop();
    } else {
      showConfirmation(
          context: context,
          message: "Are you sure you want to edit contact information?",
          onYes: () async {
            String? _message = 'Something went wrong.';
            await showWaitingModal(
                context: context,
                message: "Contact information is updating...",
                onWaiting: () async {
                  try {
                    Map<String, dynamic> recContactIdentity = {
                      // IDENTITY //
                      'contactRole': _contactIdentity['contactRole'],
                      'relationFullName': _contactIdentity['relationFullName'],
                      'relationDetail': _contactIdentity['relationDetail'],
                      'relationGender': _contactIdentity['relationGender'],
                      'contactValue': _contactIdentity['contactValue'],
                      'contactTypeId': 1,
                      'otherContactValue': _contactIdentity['otherContactValue'],
                      'homeAddress': _contactIdentity['homeAddress'],
                      'contactDetRemark': _contactIdentity['contactDetRemark'],
                    };

                    if (widget.connectionType == 'online') {
                      await Provider.of<CustomerContactDetailProvider>(context, listen: false).editRecord(widget.customerId, widget.contactDetId, recContactIdentity).then((value) {
                        _message = Provider.of<CustomerContactDetailProvider>(context, listen: false).responseMessage;
                      });
                    } else {
                      Map<String, dynamic> offlineContactIdentity = Map<String, dynamic>.from(recContactIdentity);
                      offlineContactIdentity.addAll({"personUpdated": widget.userId});
                      offlineContactIdentity.addAll({"dtUpdated": DateFormat("yyyy-MM-dd HH:mm:ss").format(DateTime.now())});

                      _message = 'New customer contact is successfully created.';
                      await DBSqliteHelper().updateCustomerContactDetail(offlineContactIdentity, widget.contactDetId);
                      _isLoading = false;
                    }
                  } catch (error) {
                    _message = error.toString();
                  }
                });
            await showAlertModal(
                context: context,
                message: _message,
                onDismiss: () {
                  Navigator.pop(context);
                });
          });
    }
  }

  void _initData() {
    // EDIT //
    if (widget.initialContactIdentity.isNotEmpty) {
      setState(() {
        _contactIdentity = Map<String, dynamic>.from(widget.initialContactIdentity);
        _genderSelected = _contactIdentity['relationGender'];
        _contactRoleSelected = _contactIdentity['contactRole'];
      });
      _relationFullNameController.text = _contactIdentity['relationFullName'] ?? '';
      _relationDetailController.text = _contactIdentity['relationDetail'] ?? '';
      _contactValueController.text = _contactIdentity['contactValue'] ?? '';
      _otherContactValueController.text = _contactIdentity['otherContactValue'] ?? '';
      _homeAddressController.text = _contactIdentity['homeAddress'] ?? '';
      _contactDetRemarkController.text = _contactIdentity['contactDetRemark'] ?? '';
    } else {
      setState(() {
        _genderSelected = "m";
        _contactRoleSelected = "referee";
      });
      _relationFullNameController.text = "";
      _relationDetailController.text = "";
      _contactValueController.text = "";
      _otherContactValueController.text = "";
      _homeAddressController.text = "";
      _contactDetRemarkController.text = "";

      _contactIdentity = Map<String, dynamic>.from(widget.initialContactIdentity);
    }
  }

  @override
  void initState() {
    _initData();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
    _relationFullNameFocusNode.dispose();
    _relationDetailFocusNode.dispose();
    _contactValueFocusNode.dispose();
    _otherContactValueFocusNode.dispose();
    _homeAddressFocusNode.dispose();
    _contactDetRemarkFocusNode.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ModalProgressHUD(
      inAsyncCall: _isLoading,
      opacity: 0.5,
      progressIndicator: CircularProgressIndicator(
        valueColor: new AlwaysStoppedAnimation<Color>(
          context.getColorScheme().primary,
        ),
      ),
      child: Container(
        child: DraggableScrollableSheet(
          initialChildSize: 0.95,
          //set this as you want
          maxChildSize: 0.95,
          //set this as you want
          minChildSize: 0.95,
          //set this as you want
          expand: true,
          builder: (context, scrollController) {
            return ClipRRect(
              borderRadius: BorderRadius.only(topLeft: Radius.circular(20.0), topRight: Radius.circular(20.0)),
              child: Container(
                padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
                color: Colors.white,
                child: Column(
                  children: [
                    Container(
                      color: Colors.teal,
                      child: Stack(children: [
                        Container(
                          width: double.infinity,
                          height: 50.0,
                          child: Center(
                            child: Text(
                              "${widget.initialContactIdentity.isEmpty ? 'CREATE' : 'EDIT'} IDENTITY",
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white),
                            ), // Your desired title
                          ),
                        ),
                        Positioned(
                          left: 0.0,
                          top: 0.0,
                          child: IconButton(
                            icon: Icon(
                              Icons.arrow_back,
                              color: Colors.white,
                            ), // Your desired icon
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          ),
                        ),
                      ]),
                    ),
                    // Divider(),
                    Expanded(
                      child: Container(
                        padding: EdgeInsets.fromLTRB(15, 5, 15, 10),
                        child: Form(
                          key: _formKey,
                          autovalidateMode: AutovalidateMode.always,
                          child: SingleChildScrollView(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  height: 10,
                                ),

                                // CONTACT ROLE //
                                Container(
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      new Radio(
                                        value: 'referee',
                                        groupValue: _contactRoleSelected,
                                        onChanged: _onChangeRoleSelection,
                                      ),
                                      new InkWell(
                                        child: Text(
                                          'Referee',
                                          style: new TextStyle(fontSize: 16.0),
                                        ),
                                        onTap: () {
                                          _onChangeRoleSelection('referee');
                                        },
                                      ),
                                      new Radio(
                                        value: 'guarantor',
                                        groupValue: _contactRoleSelected,
                                        onChanged: _onChangeRoleSelection,
                                      ),
                                      new InkWell(
                                        child: new Text(
                                          'Guarantor',
                                          style: new TextStyle(
                                            fontSize: 16.0,
                                          ),
                                        ),
                                        onTap: () {
                                          _onChangeRoleSelection('guarantor');
                                        },
                                      ),
                                      new Radio(
                                        value: 'broker',
                                        groupValue: _contactRoleSelected,
                                        onChanged: _onChangeRoleSelection,
                                      ),
                                      new InkWell(
                                        child: new Text(
                                          'Broker',
                                          style: new TextStyle(
                                            fontSize: 16.0,
                                          ),
                                        ),
                                        onTap: () {
                                          _onChangeRoleSelection('broker');
                                        },
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  height: 5,
                                ),

                                // relationFullName //
                                TextFormInput(
                                  controller: _relationFullNameController,
                                  focusNode: _relationFullNameFocusNode,
                                  label: "Full Name",
                                  textInputAction: TextInputAction.done,
                                  isRequired: true,
                                  requiredMessage: "This field is required.",
                                  onSaved: _setRelationFullName,
                                ),
                                SizedBox(
                                  height: 10,
                                ),

                                // GENDER //
                                Container(
                                  padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
                                  decoration: BoxDecoration(
                                    border: Border.all(color: Colors.grey),
                                    borderRadius: BorderRadius.circular(5),
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      SizedBox(
                                        height: 5,
                                      ),

                                      // Card Type //
                                      Text(
                                        "Gender",
                                        textAlign: TextAlign.left,
                                      ),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: <Widget>[
                                          new Radio(
                                            value: 'm',
                                            groupValue: _genderSelected,
                                            onChanged: _onChangeGenderSelection,
                                          ),
                                          new InkWell(
                                            child: Text(
                                              'Male',
                                              style: new TextStyle(fontSize: 16.0),
                                            ),
                                            onTap: () {
                                              _onChangeGenderSelection('m');
                                            },
                                          ),
                                          new Radio(
                                            value: 'f',
                                            groupValue: _genderSelected,
                                            onChanged: _onChangeGenderSelection,
                                          ),
                                          new InkWell(
                                            child: new Text(
                                              'Female',
                                              style: new TextStyle(
                                                fontSize: 16.0,
                                              ),
                                            ),
                                            onTap: () {
                                              _onChangeGenderSelection('f');
                                            },
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  height: 10,
                                ),

                                // relationDetail //
                                TextFormInput(
                                  controller: _relationDetailController,
                                  focusNode: _relationDetailFocusNode,
                                  label: "Relation Detail",
                                  textInputAction: TextInputAction.next,
                                  nextFocusNode: _contactValueFocusNode,
                                  isRequired: true,
                                  requiredMessage: "This field is required.",
                                  onSaved: _setRelationDetail,
                                ),
                                SizedBox(
                                  height: 10,
                                ),

                                // contactValue //
                                TextFormInput(
                                  controller: _contactValueController,
                                  focusNode: _contactValueFocusNode,
                                  label: "Mobile (Number only)",
                                  nextFocusNode: _otherContactValueFocusNode,
                                  textInputAction: TextInputAction.next,
                                  keyboardType: TextInputType.number,
                                  isRequired: true,
                                  requiredMessage: "This field is required.",
                                  onSaved: _seContactValue,
                                ),
                                SizedBox(
                                  height: 10,
                                ),

                                // otherContactValue //
                                TextFormInput(
                                  controller: _otherContactValueController,
                                  focusNode: _otherContactValueFocusNode,
                                  label: "Other Mobile (Number only)",
                                  nextFocusNode: _homeAddressFocusNode,
                                  textInputAction: TextInputAction.next,
                                  keyboardType: TextInputType.number,
                                  isRequired: false,
                                  onSaved: _setOtherContactValue,
                                ),
                                SizedBox(
                                  height: 10,
                                ),

                                // homeAddress //
                                TextFormInput(
                                  controller: _homeAddressController,
                                  focusNode: _homeAddressFocusNode,
                                  label: "Home Address",
                                  textInputAction: TextInputAction.next,
                                  nextFocusNode: _contactDetRemarkFocusNode,
                                  isRequired: false,
                                  onSaved: _setHomeAddress,
                                  maxLines: 2,
                                ),
                                SizedBox(
                                  height: 10,
                                ),

                                // contactDetRemark //
                                TextFormInput(
                                  controller: _contactDetRemarkController,
                                  focusNode: _contactDetRemarkFocusNode,
                                  label: "Remark",
                                  textInputAction: TextInputAction.done,
                                  isRequired: false,
                                  onSaved: _setContactDetRemark,
                                  maxLines: 2,
                                ),

                                SizedBox(
                                  height: 10,
                                ),
                                Divider(),
                                Row(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
                                  Expanded(
                                    child: ButtonWidget(
                                      text: "CLEAR",
                                      isWhiteBackgroundColor: true,
                                      onPressed: _clearAllFields,
                                    ),
                                  ),
                                  Expanded(
                                    child: ButtonWidget(
                                      text: widget.contactDetId == null ? "CONFIRM" : "SAVE CHANGES",
                                      isWhiteBackgroundColor: false,
                                      onPressed: _confirmContactIdentity,
                                    ),
                                  ),
                                ]),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
