import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:provider/provider.dart';
import 'package:sales/data/local/db_sqlite_helper.dart';
import 'package:sales/providers/providers.dart';
import 'package:sales/utils/utils.dart';

import 'package:sales/widgets/waiting_modal_bottom_widget.dart';
import '../../../../../widgets/confirmation_modal_bottom_widget.dart';
import '../../../../../widgets/deprecated/alert_modal_bottom_widget.dart';
import '../../../../../widgets/deprecated/button_widget.dart';
import '../../../../../widgets/deprecated/date_picker_widget.dart';
import '../../../../../widgets/deprecated/text_form_input.dart';

class ContactNrcModal extends StatefulWidget {
  final int? customerId;
  final int? contactDetId;
  final int? userId;
  final String? contactRole;
  final String? connectionType;
  final Map<String, dynamic> initialContactNrc;
  final Function(Map<String, dynamic>) setContactNrc;

  ContactNrcModal({required this.customerId, required this.contactDetId, required this.userId, required this.contactRole, required this.connectionType, required this.initialContactNrc, required this.setContactNrc});

  @override
  _ContactNrcModalState createState() => _ContactNrcModalState();
}

class _ContactNrcModalState extends State<ContactNrcModal> {
  bool _isLoading = false;

  final GlobalKey<FormState> _formKey = GlobalKey();
  List<Map<String, dynamic>> _nrc1s = [];
  List<Map<String, dynamic>> _nrc2s = [];

  static String? _cardTypeSelected = 'nrc';
  static String? _nrcTypeSelected = 'N';
  static int? _nrc1IdSelected;
  static int? _nrc2IdSelected;

  Map<String, dynamic> _contactNrc = {
    'cardType': 'nrc',
    'nrc1Id': null,
    'nrc1Name': null,
    'nrc2Id': null,
    'nrc2Name': null,
    'nrcType': null,
    'nonNrcPrefix': null,
    'nrcDetail': null,
    'natRegCardNo': null,
    'natRegCardIssDate': null,
    'nrcNumber': null,
  };

  // nrcNumber //
  final _nrcNumberFocusNode = FocusNode();
  final _nrcNumberController = TextEditingController();

  void _setNrcNumber(String? value) {
    _contactNrc['nrcDetail'] = _cardTypeSelected != 'na' ? value!.trim() : null;
  }

  // Issuance Date //
  static DateTime? _issuanceDateSelected = DateTime.now();
  final _issuanceDateController = TextEditingController();

  void _setIssuanceDate(String value) {
    setState(() {
      _issuanceDateSelected = DateFormat('yyyy-MM-dd').parse(value);
      _contactNrc['natRegCardIssDate'] = value;
    });
  }

  // nonNrcPrefix //
  final _nonNrcPrefixFocusNode = FocusNode();
  final _nonNrcPrefixController = TextEditingController();

  void _setNonNrcPrefix(String? value) {
    _contactNrc['nonNrcPrefix'] = value!.trim();
  }

  void _onChangeCardTypeSelection(String? strCardType) {
    setState(() {
      _cardTypeSelected = strCardType;
      _contactNrc['cardType'] = _cardTypeSelected;
    });
  }

  void _onChangeNrcTypeSelection(String? strNrcType) {
    setState(() {
      _nrcTypeSelected = strNrcType;
      _contactNrc['nrcType'] = strNrcType;
    });
  }

  Future<void> _getNrc1s() async {
    setState(() {
      _isLoading = true;
    });

    try {
      if (widget.connectionType == 'online') {
        await Provider.of<Nrc1Provider>(context, listen: false).getRecords().then((value) {
          setState(() {
            _nrc1s = Provider.of<Nrc1Provider>(context, listen: false).items;
            _isLoading = false;
          });
        });
      } else {
        List<Map<String, dynamic>> offlineNrc1s = await DBSqliteHelper().getNrc1s();
        setState(() {
          _nrc1s = List<Map<String, dynamic>>.from(offlineNrc1s);
          _isLoading = false;
        });
      }
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _getNrc2s(int? nrc1Id) async {
    setState(() {
      _isLoading = true;
    });

    try {
      if (widget.connectionType == 'online') {
        await Provider.of<Nrc2Provider>(context, listen: false).getRecords(nrc1Id).then((value) {
          setState(() {
            _nrc2IdSelected = null;
            _nrc2s = Provider.of<Nrc2Provider>(context, listen: false).items;
            _isLoading = false;
          });
        });
      } else {
        List<Map<String, dynamic>> offlineNrc2s = await DBSqliteHelper().getNrc2s(nrc1Id);
        setState(() {
          _nrc2IdSelected = null;
          _nrc2s = List<Map<String, dynamic>>.from(offlineNrc2s);
          _isLoading = false;
        });
      }
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  void _initData() async {
    print('widget.initialContactNrc: ${widget.initialContactNrc.length}');
    await _getNrc1s();
    // EDIT //
    if (widget.initialContactNrc.length != 0) {
      setState(() {
        _contactNrc = widget.initialContactNrc;
        _nrc1IdSelected = _contactNrc['nrc1Id'];
      });
      await _getNrc2s(_nrc1IdSelected);
      setState(() {
        _nrc2IdSelected = _contactNrc['nrc2Id'];
        _nrcTypeSelected = _contactNrc['nrcType'];
      });

      setState(() {
        if (_nrc1IdSelected != null) {
          _cardTypeSelected = 'nrc';
        } else {
          if (_contactNrc['nrcDetail'] != "" && _contactNrc['nrcDetail'] != null) {
            _cardTypeSelected = 'nonNrc';
          } else {
            _cardTypeSelected = 'na';
          }
        }
      });

      if (_contactNrc['natRegCardIssDate'] != null) {
        setState(() {
          _issuanceDateSelected = DateTime.parse(_contactNrc['natRegCardIssDate'].toString());
        });
        _issuanceDateController.text = DateFormat('dd/MM/yyyy').format(_issuanceDateSelected!);
      }
      _nonNrcPrefixController.text = _contactNrc['nonNrcPrefix'] ?? '';
      _nrcNumberController.text = _contactNrc['nrcDetail'] ?? '';
    } else {
      setState(() {
        _cardTypeSelected = 'nrc';
        _nrcTypeSelected = 'N';
        _nrc1IdSelected = null;
        _nrc2IdSelected = null;
        _issuanceDateSelected = null;
        _issuanceDateController.text = "";
        _nonNrcPrefixController.text = "";
        _nrcNumberController.text = "";
      });
    }
  }

  void _clearAllFields() {
    _initData();
  }

  void _confirmContactNrc() {
    if (!_formKey.currentState!.validate()) {
      // Invalid!
      return;
    }
    _formKey.currentState!.save();
    // assign value //
    _contactNrc['nrcType'] = _nrcTypeSelected;
    if (_cardTypeSelected == 'nrc') {
      _nrc1s.forEach((element) {
        if (element['nrc1Id'] == _nrc1IdSelected) {
          _contactNrc['nrc1Id'] = element['nrc1Id'];
          _contactNrc['nrc1Name'] = element['nrc1Name'];
        }
      });

      _nrc2s.forEach((element) {
        if (element['nrc2Id'] == _nrc2IdSelected) {
          _contactNrc['nrc2Id'] = element['nrc2Id'];
          _contactNrc['nrc2Name'] = element['nrc2Name'];
        }
      });
    } else {
      _contactNrc['nrc1Id'] = null;
      _contactNrc['nrc1Name'] = null;

      _contactNrc['nrc2Id'] = null;
      _contactNrc['nrc2Name'] = null;
    }

    _contactNrc['nrcDetail'] = _cardTypeSelected != 'na' ? _contactNrc['nrcDetail'] : null;
    _contactNrc['natRegCardNo'] = _cardTypeSelected == 'nrc' ? "${_contactNrc['nrc1Id']}/${_contactNrc['nrc2Name']}(${_contactNrc['nrcType']})${_contactNrc['nrcDetail']}" : (_cardTypeSelected == 'nonNrc' ? "${_contactNrc['nonNrcPrefix']}-${_contactNrc['nrcDetail']}" : null);
    _contactNrc['natRegCardIssDate'] = (_cardTypeSelected == 'nrc' || _cardTypeSelected == 'nonNrc') && _contactNrc['natRegCardIssDate'] != "" ? _contactNrc['natRegCardIssDate'] : null;

    if (widget.contactDetId == null) {
      widget.setContactNrc(_contactNrc);
      Navigator.of(context).pop();
    } else {
      showConfirmation(
          context: context,
          message: "Are you sure you want to edit NRC information?",
          onYes: () async {
            String? _message = 'Something went wrong.';
            await showWaitingModal(
                context: context,
                message: "NRC information is updating...",
                onWaiting: () async {
                  try {
                    Map<String, dynamic> recContactNrc = {'nrc2Id': _contactNrc['nrc2Id'], 'nrcType': _contactNrc['nrcType'], 'nonNrcPrefix': _cardTypeSelected == 'nonNrc' ? _contactNrc['nonNrcPrefix'] : null, 'nrcDetail': _cardTypeSelected != 'na' ? _contactNrc['nrcDetail'] : null, 'natRegCardNo': _contactNrc['natRegCardNo'], 'natRegCardIssDate': _contactNrc['natRegCardIssDate']};

                    if (widget.connectionType == 'online') {
                      await Provider.of<CustomerContactDetailProvider>(context, listen: false).editRecord(widget.customerId, widget.contactDetId, recContactNrc).then((value) {
                        _message = Provider.of<CustomerContactDetailProvider>(context, listen: false).responseMessage;
                      });
                    } else {
                      Map<String, dynamic> offlineContactNrc = Map<String, dynamic>.from(recContactNrc);
                      offlineContactNrc.addAll({"personUpdated": widget.userId});
                      offlineContactNrc.addAll({"dtUpdated": DateFormat("yyyy-MM-dd HH:mm:ss").format(DateTime.now())});

                      _message = 'New customer contact NRC is successfully created.';
                      await DBSqliteHelper().updateCustomerContactDetail(offlineContactNrc, widget.contactDetId);
                    }
                  } catch (error) {
                    _message = error.toString();
                  }
                });
            await showAlertModal(
                context: context,
                message: _message,
                onDismiss: () {
                  Navigator.pop(context);
                });
          });
    }
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _initData();
  }

  @override
  Widget build(BuildContext context) {
    // NRC Region //
    Widget _buildNrc1DropdownButton() {
      return DropdownButtonFormField<dynamic>(
        dropdownColor: Colors.white,
        decoration: InputDecoration(
          contentPadding: EdgeInsets.fromLTRB(15, 13, 12, 13),
          labelText: "NRC Region",
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
          ),
        ),
        items: _nrc1s.map((item) {
          return DropdownMenuItem<int>(
            value: item["nrc1Id"],
            child: Text("${item["nrc1Name"]}/${item["nrc1Id"]}"),
          );
        }).toList(),
        value: _nrc1IdSelected ?? null,
        onChanged: (newValue) {
          setState(() {
            _nrc1IdSelected = newValue;
          });
          _getNrc2s(_nrc1IdSelected);
        },
        validator: (value) {
          if (_nrc1IdSelected == null) {
            return "NRC Region is required";
          }
          return null;
        },
        onSaved: (value) {
          print('onSaved $_nrc1IdSelected');
        },
      );
    }

    // NRC Prefix //
    Widget _buildNrc2DropdownButton() {
      return DropdownButtonFormField<dynamic>(
        dropdownColor: Colors.white,
        decoration: InputDecoration(
          contentPadding: EdgeInsets.fromLTRB(15, 13, 12, 13),
          labelText: "NRC Prefix",
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
          ),
        ),
        items: _nrc2s.map((item) {
          return DropdownMenuItem<int>(
            value: item["nrc2Id"],
            child: Text(item["nrc2Name"]),
          );
        }).toList(),
        value: _nrc2IdSelected ?? null,
        onChanged: (newValue) {
          setState(() {
            _nrc2IdSelected = newValue;
          });
        },
        validator: (value) {
          if (_nrc2IdSelected == null) {
            return "NRC Prefix is required";
          }
          return null;
        },
        onSaved: (value) {},
      );
    }

    return ModalProgressHUD(
      inAsyncCall: _isLoading,
      opacity: 0.5,
      progressIndicator: CircularProgressIndicator(
        valueColor: new AlwaysStoppedAnimation<Color>(
          context.getColorScheme().primary,
        ),
      ),
      child: Container(
        child: DraggableScrollableSheet(
          initialChildSize: 0.95,
          //set this as you want
          maxChildSize: 0.95,
          //set this as you want
          minChildSize: 0.95,
          //set this as you want
          expand: true,
          builder: (context, scrollController) {
            return ClipRRect(
              borderRadius: BorderRadius.only(topLeft: Radius.circular(20.0), topRight: Radius.circular(20.0)),
              child: Container(
                padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
                color: Colors.white,
                child: Column(
                  children: [
                    Container(
                      color: Colors.teal,
                      child: Stack(children: [
                        Container(
                          width: double.infinity,
                          height: 50.0,
                          child: Center(
                            child: Text(
                              "${widget.initialContactNrc.isEmpty ? 'CREATE' : 'EDIT'} NRC",
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white),
                            ), // Your desired title
                          ),
                        ),
                        Positioned(
                          left: 0.0,
                          top: 0.0,
                          child: IconButton(
                            icon: Icon(
                              Icons.arrow_back,
                              color: Colors.white,
                            ), // Your desired icon
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          ),
                        ),
                      ]),
                    ),
                    // Divider(),
                    Expanded(
                      child: Container(
                        child: Form(
                          key: _formKey,
                          autovalidateMode: AutovalidateMode.always,
                          child: SingleChildScrollView(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                    border: Border(bottom: BorderSide(color: Colors.grey)),
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      SizedBox(
                                        height: 5,
                                      ),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: <Widget>[
                                          new Radio(
                                            value: 'na',
                                            groupValue: _cardTypeSelected,
                                            onChanged: _onChangeCardTypeSelection,
                                          ),
                                          new InkWell(
                                            child: Text(
                                              'Not Available',
                                              style: new TextStyle(fontSize: 16.0),
                                            ),
                                            onTap: () {
                                              _onChangeCardTypeSelection('na');
                                            },
                                          ),
                                          new Radio(
                                            value: 'nrc',
                                            groupValue: _cardTypeSelected,
                                            onChanged: _onChangeCardTypeSelection,
                                          ),
                                          new InkWell(
                                            child: Text(
                                              'NRC',
                                              style: new TextStyle(fontSize: 16.0),
                                            ),
                                            onTap: () {
                                              _onChangeCardTypeSelection('nrc');
                                            },
                                          ),
                                          new Radio(
                                            value: 'nonNrc',
                                            groupValue: _cardTypeSelected,
                                            onChanged: _onChangeCardTypeSelection,
                                          ),
                                          new InkWell(
                                            child: new Text(
                                              'FRC/NVC',
                                              style: new TextStyle(
                                                fontSize: 16.0,
                                              ),
                                            ),
                                            onTap: () {
                                              _onChangeCardTypeSelection('nonNrc');
                                            },
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  padding: EdgeInsets.fromLTRB(15, 15, 15, 10),
                                  child: Column(
                                    children: [
                                      SizedBox(
                                        height: 5,
                                      ),

                                      _cardTypeSelected != 'nrc'
                                          ? SizedBox()
                                          : Column(
                                              children: [
                                                // Nrc Region //
                                                _buildNrc1DropdownButton(),
                                                SizedBox(
                                                  height: 10,
                                                ),

                                                // Nrc Refix //
                                                _buildNrc2DropdownButton(),

                                                // NRC Type //
                                                Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Row(
                                                      mainAxisAlignment: MainAxisAlignment.center,
                                                      children: <Widget>[
                                                        Text(
                                                          "Type",
                                                          textAlign: TextAlign.left,
                                                        ),
                                                        new Radio(
                                                          value: 'N',
                                                          groupValue: _nrcTypeSelected,
                                                          onChanged: _onChangeNrcTypeSelection,
                                                        ),
                                                        new InkWell(
                                                          child: Text(
                                                            '(N)',
                                                            style: new TextStyle(fontSize: 16.0),
                                                          ),
                                                          onTap: () {
                                                            _onChangeNrcTypeSelection('N');
                                                          },
                                                        ),
                                                        new Radio(
                                                          value: 'P',
                                                          groupValue: _nrcTypeSelected,
                                                          onChanged: _onChangeNrcTypeSelection,
                                                        ),
                                                        new InkWell(
                                                          child: new Text(
                                                            '(P)',
                                                            style: new TextStyle(
                                                              fontSize: 16.0,
                                                            ),
                                                          ),
                                                          onTap: () {
                                                            _onChangeNrcTypeSelection('P');
                                                          },
                                                        ),
                                                      ],
                                                    ),
                                                  ],
                                                ),
                                                SizedBox(
                                                  height: 5,
                                                ),
                                              ],
                                            ),

                                      _cardTypeSelected != 'nonNrc'
                                          ? SizedBox()
                                          : Column(
                                              children: [
                                                // FRC/NVC Prefix //
                                                TextFormInput(
                                                  controller: _nonNrcPrefixController,
                                                  focusNode: _nonNrcPrefixFocusNode,
                                                  label: "FRC/NVC Prefix (3-5 characters)",
                                                  textInputAction: TextInputAction.next,
                                                  nextFocusNode: _nrcNumberFocusNode,
                                                  isRequired: true,
                                                  requiredMessage: "NRC number is required.",
                                                  minimumLength: 3,
                                                  minimumLengthMessage: "You have not met this field's minimum length.",
                                                  maximumLength: 5,
                                                  maximumLengthMessage: "You have not met this field's maximum length.",
                                                  onSaved: _setNonNrcPrefix,
                                                ),
                                                SizedBox(
                                                  height: 10,
                                                ),
                                              ],
                                            ),

                                      // nrcNumber //
                                      _cardTypeSelected == 'na'
                                          ? SizedBox()
                                          : Column(
                                              children: [
                                                TextFormInput(
                                                  controller: _nrcNumberController,
                                                  focusNode: _nrcNumberFocusNode,
                                                  label: "NRC Number (6 digits)",
                                                  textInputAction: TextInputAction.done,
                                                  isRequired: true,
                                                  requiredMessage: "NRC number is required.",
                                                  minimumLength: 6,
                                                  maximumLength: 6,
                                                  minimumLengthMessage: "You have not met this field's minimum length.",
                                                  maximumLengthMessage: "You have not met this field's maximum length.",
                                                  keyboardType: TextInputType.number,
                                                  onSaved: _setNrcNumber,
                                                ),
                                                SizedBox(
                                                  height: 10,
                                                ),

                                                // issuanceDate //
                                                DatePickerWidget(
                                                  controller: _issuanceDateController,
                                                  labelText: "Issuance Date",
                                                  isRequired: false,
                                                  initialDateTime: _issuanceDateSelected,
                                                  setFormDataValue: _setIssuanceDate,
                                                ),
                                                SizedBox(
                                                  height: 10,
                                                ),
                                              ],
                                            ),

                                      Divider(),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: <Widget>[
                                          Expanded(
                                            child: ButtonWidget(
                                              text: "CLEAR",
                                              isWhiteBackgroundColor: true,
                                              onPressed: _clearAllFields,
                                            ),
                                          ),
                                          Expanded(
                                            child: ButtonWidget(
                                              text: widget.contactDetId == null ? "CONFIRM" : "SAVE CHANGES",
                                              isWhiteBackgroundColor: false,
                                              onPressed: _confirmContactNrc,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
