import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:pattern_formatter/pattern_formatter.dart';
import 'package:provider/provider.dart';
import 'package:sales/data/local/db_sqlite_helper.dart';
import 'package:sales/providers/providers.dart';
import 'package:sales/utils/utils.dart';

import 'package:sales/widgets/waiting_modal_bottom_widget.dart';
import '../../../../../widgets/confirmation_modal_bottom_widget.dart';
import '../../../../../widgets/deprecated/alert_modal_bottom_widget.dart';
import '../../../../../widgets/deprecated/button_widget.dart';
import '../../../../../widgets/deprecated/text_form_input.dart';

class ContactIncomeModal extends StatefulWidget {
  final int? customerId;
  final int? contactDetId;
  final int? userId;
  final String? connectionType;
  final String? contactRole;
  final Map<String, dynamic> initialContactIncome;
  final Function(Map<String, dynamic>) setContactIncome;

  ContactIncomeModal({required this.customerId, required this.contactDetId, required this.userId, required this.connectionType, required this.contactRole, required this.initialContactIncome, required this.setContactIncome});

  @override
  _ContactIncomeModalState createState() => _ContactIncomeModalState();
}

class _ContactIncomeModalState extends State<ContactIncomeModal> {
  bool _isLoading = false;

  final GlobalKey<FormState> _formKey = GlobalKey();
  int? _selfEmployedSelected = 0;
  int? _businessTypeIdSelected;
  int? _jobCategoryIdSelected;
  int? _incomePeriodicitySelected;

  List<Map<String, dynamic>> _businessTypes = [];
  List<Map<String, dynamic>> _jobCategories = [];

  var _incomePeriodicities = [
    {'id': 1, 'title': 'Monthly (Every 1 month)'},
    {'id': 3, 'title': 'Quarterly (Every 3 months)'},
    {'id': 12, 'title': 'Yearly (Every 12 months)'}
  ];

  Map<String, dynamic> _contactIncome = {
    'contactRole': 'referee',
    'selfemployed': 0,
    'businessTypeId': null,
    'businessTypeName': null,
    'jobCategoryId': null,
    'jobCategoryName': null,
    'workplaceName': null,
    'workplaceFixedTel': null,
    'workplaceAddress': null,
    'incomePeriodicity': null,
    'incomePeriodicityTitle': null,
    'incomeAmount': null,
    'incomeSourceRemark': null,
  };

  // workplaceName //
  final _workplaceNameFocusNode = FocusNode();
  final _workplaceNameController = TextEditingController();

  void _setWorkplaceName(String? value) {}

  // workplaceFixedTel //
  final _workplaceFixedTelFocusNode = FocusNode();
  final _workplaceFixedTelController = TextEditingController();

  void _setWorkplaceFixedTel(String? value) {}

  // workplaceAddress //
  final _workplaceAddressFocusNode = FocusNode();
  final _workplaceAddressController = TextEditingController();

  void _setWorkplaceAddress(String? value) {}

  // incomeAmount //
  final _incomeAmountFocusNode = FocusNode();
  final _incomeAmountController = TextEditingController();

  // incomeSourceRemark //
  final _incomeSourceRemarkFocusNode = FocusNode();
  final _incomeSourceRemarkController = TextEditingController();

  void _setIncomeSourceRemark(String? value) {}

  Future<void> _getBusinessTypeByEmpStatus(int? status) async {
    setState(() {
      _isLoading = true;
      _businessTypeIdSelected = null;
      _jobCategoryIdSelected = null;
    });

    try {
      if (widget.connectionType == 'online') {
        await Provider.of<BusinessTypeProvider>(context, listen: false).getBusinessTypeByEmpStatus(status).then((value) {
          setState(() {
            _businessTypes = Provider.of<BusinessTypeProvider>(context, listen: false).items;
            _isLoading = false;
          });
        });
      } else {
        List<Map<String, dynamic>> offlineBusinessTypes = await DBSqliteHelper().getBusinessTypesByEmpStatus(status);
        setState(() {
          _businessTypes = List<Map<String, dynamic>>.from(offlineBusinessTypes);
          _isLoading = false;
        });
      }
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }
  }

  Future<void> _getJobCategoriesWithType(int? busTypeId, int? empStatus) async {
    setState(() {
      _isLoading = true;
      _jobCategoryIdSelected = null;
    });

    try {
      if (widget.connectionType == 'online') {
        await Provider.of<JobCategoryProvider>(context, listen: false).getAllByEmpStatus(busTypeId, empStatus).then((value) {
          setState(() {
            _jobCategories = Provider.of<JobCategoryProvider>(context, listen: false).items;
            _isLoading = false;
          });
        });
      } else {
        List<Map<String, dynamic>> offlineJobCategories = await DBSqliteHelper().getJobCategoriesByEmpStatus(busTypeId, empStatus);
        setState(() {
          _jobCategories = List<Map<String, dynamic>>.from(offlineJobCategories);
          _isLoading = false;
        });
      }
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }
  }

  void _initData() async {
    await _getBusinessTypeByEmpStatus(_selfEmployedSelected);
    if (widget.initialContactIncome.isNotEmpty) {
      setState(() {
        _contactIncome = widget.initialContactIncome;
        _selfEmployedSelected = _contactIncome['selfemployed'] ?? 0;
        _businessTypeIdSelected = _contactIncome['businessTypeId'];
      });

      if (_businessTypeIdSelected != null) {
        await _getJobCategoriesWithType(_businessTypeIdSelected, _selfEmployedSelected);
      }
      setState(() {
        _jobCategoryIdSelected = _contactIncome['jobCategoryId'];
        _incomePeriodicitySelected = _contactIncome['incomePeriodicity'];
      });

      _workplaceNameController.text = _selfEmployedSelected == 2 ? '' : (_contactIncome['workplaceName'] ?? '');
      _workplaceFixedTelController.text = _selfEmployedSelected == 2 ? '' : (_contactIncome['workplaceFixedTel'] ?? '');
      _workplaceAddressController.text = _selfEmployedSelected == 2 ? '' : (_contactIncome['workplaceAddress'] ?? '');
      _incomeAmountController.text = _contactIncome['incomeAmount'] == null ? "" : NumberFormat('#,###').format(int.parse(_contactIncome['incomeAmount'].toString()));
      _incomeSourceRemarkController.text = _contactIncome['incomeSourceRemark'] ?? '';
    } else {
      setState(() {
        _selfEmployedSelected = 0;
        _businessTypeIdSelected = null;
        _jobCategoryIdSelected = null;
        _incomePeriodicitySelected = null;

        _workplaceNameController.text = "";
        _workplaceFixedTelController.text = "";
        _workplaceAddressController.text = "";
        _incomeAmountController.text = "";
        _incomeSourceRemarkController.text = "";
      });
    }
  }

  void _onChangeEmploymentStatusSelection(int? status) async {
    setState(() {
      _selfEmployedSelected = status;
      _businessTypeIdSelected = null;
      _jobCategoryIdSelected = null;
      _businessTypes = [];
      _jobCategories = [];
    });
    await _getBusinessTypeByEmpStatus(_selfEmployedSelected);
  }

  void _clearAllFields() {
    _initData();
  }

  void _confirmContactIncome() {
    if (!_formKey.currentState!.validate()) {
      // Invalid!
      return;
    }
    _formKey.currentState!.save();

    _contactIncome['selfemployed'] = _selfEmployedSelected;
    _contactIncome['businessTypeId'] = _selfEmployedSelected == 2 ? null : _businessTypeIdSelected;
    _contactIncome['jobCategoryId'] = _selfEmployedSelected == 2 ? null : _jobCategoryIdSelected;
    _contactIncome['workplaceName'] = _selfEmployedSelected == 2 ? null : _workplaceNameController.text.trim();
    _contactIncome['workplaceFixedTel'] = _selfEmployedSelected == 2 ? null : _workplaceFixedTelController.text.trim();
    _contactIncome['workplaceAddress'] = _selfEmployedSelected == 2 ? null : _workplaceAddressController.text.trim();
    _contactIncome['incomePeriodicity'] = _incomePeriodicitySelected;
    _contactIncome['incomeAmount'] = _incomeAmountController.text.trim().replaceAll(",", "");
    _contactIncome['incomeSourceRemark'] = _incomeSourceRemarkController.text.trim();

    // businessType //
    _businessTypes.forEach((element) {
      if (element['businessTypeId'] == _businessTypeIdSelected) {
        _contactIncome['businessTypeName'] = element['businessTypeName'];
      }
    });

    // jobCategory //
    _jobCategories.forEach((element) {
      if (element['jobCategoryId'] == _jobCategoryIdSelected) {
        _contactIncome['jobCategoryName'] = element['jobCategoryName'];
      }
    });

    // incomePeriodicity //
    _incomePeriodicities.forEach((element) {
      if (element['id'] == _incomePeriodicitySelected) {
        _contactIncome['incomePeriodicityTitle'] = element['title'];
      }
    });

    if (widget.contactDetId == null) {
      widget.setContactIncome(_contactIncome);
      Navigator.of(context).pop();
    } else {
      showConfirmation(
          context: context,
          message: "Are you sure you want to edit income of the selected contact?",
          onYes: () async {
            String? _message = 'Something went wrong.';
            await showWaitingModal(
                context: context,
                message: "The selected income is updating",
                onWaiting: () async {
                  try {
                    Map<String, dynamic> recCustomerContact = {
                      // INCOME //
                      'selfemployed': _contactIncome['selfemployed'],
                      'businessTypeId': _contactIncome['businessTypeId'],
                      'jobCategoryId': _contactIncome['jobCategoryId'],
                      'workplaceName': _contactIncome['workplaceName'],
                      'workplaceFixedTel': _contactIncome['workplaceFixedTel'],
                      'workplaceAddress': _contactIncome['workplaceAddress'],
                      'incomePeriodicity': _contactIncome['incomePeriodicity'],
                      'incomeAmount': _contactIncome['incomeAmount'],
                      'incomeSourceRemark': _contactIncome['incomeSourceRemark'],
                    };

                    if (widget.connectionType == 'online') {
                      await Provider.of<CustomerContactDetailProvider>(context, listen: false).editRecord(widget.customerId, widget.contactDetId, recCustomerContact).then((value) {
                        _message = Provider.of<CustomerContactDetailProvider>(context, listen: false).responseMessage;
                      });
                    } else {
                      Map<String, dynamic> offlineContactIncome = Map<String, dynamic>.from(recCustomerContact);
                      offlineContactIncome.addAll({"personUpdated": widget.userId});
                      offlineContactIncome.addAll({"dtUpdated": DateFormat("yyyy-MM-dd HH:mm:ss").format(DateTime.now())});

                      _message = 'New customer contact income is successfully updated.';
                      await DBSqliteHelper().updateCustomerContactDetail(offlineContactIncome, widget.contactDetId);
                    }
                  } catch (error) {
                    _message = error.toString();
                  }
                });
            await showAlertModal(
                context: context,
                message: _message,
                onDismiss: () {
                  Navigator.pop(context);
                });
          });
    }
  }

  @override
  void initState() {
    super.initState();
    _initData();
    print('widget.contactRole : ${widget.contactRole}');
  }

  @override
  void dispose() {
    super.dispose();

    _workplaceNameFocusNode.dispose();
    _workplaceFixedTelFocusNode.dispose();
    _workplaceAddressFocusNode.dispose();
    _incomeAmountFocusNode.dispose();
    _incomeSourceRemarkFocusNode.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Business Type //
    Widget _buildBusinessTypeDropdownButton() {
      return DropdownButtonFormField<int>(
        isExpanded: true,
        dropdownColor: Colors.white,
        decoration: InputDecoration(
          contentPadding: EdgeInsets.fromLTRB(15, 13, 12, 13),
          labelText: "Sector",
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
          ),
        ),
        items: _businessTypes.map((item) {
          return DropdownMenuItem<int>(
            value: item["businessTypeId"],
            child: Container(
              // width: _deviceSize.width - 60,
              child: Text(
                item["businessTypeName"],
                overflow: TextOverflow.ellipsis,
              ),
            ),
          );
        }).toList(),
        value: _businessTypeIdSelected ?? null,
        onChanged: (newValue) async {
          setState(() {
            _businessTypeIdSelected = newValue;
          });
          await _getJobCategoriesWithType(_businessTypeIdSelected, _selfEmployedSelected);
        },
        validator: (value) {
          if (_businessTypeIdSelected == null) {
            return "Sector is required.";
          }
          return null;
        },
        onSaved: (newValue) {},
      );
    }

    // Job Category //
    Widget _buildJobCategoryDropdownButton() {
      return DropdownButtonFormField<int>(
        isExpanded: true,
        dropdownColor: Colors.white,
        decoration: InputDecoration(
          contentPadding: EdgeInsets.fromLTRB(15, 13, 12, 13),
          labelText: "Job Category",
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
          ),
        ),
        items: _jobCategories.map((item) {
          return DropdownMenuItem<int>(
            value: item["jobCategoryId"],
            child: Container(
              child: Text(
                item["jobCategoryName"],
                overflow: TextOverflow.ellipsis,
              ),
            ),
          );
        }).toList(),
        value: _jobCategoryIdSelected ?? null,
        onChanged: (newValue) {
          setState(() {
            _jobCategoryIdSelected = newValue;
          });
        },
        validator: (value) {
          if (_jobCategoryIdSelected == null) {
            return "Sector is required.";
          }
          return null;
        },
        onSaved: (newValue) {},
      );
    }

    // Income Periodicity //
    Widget _buildIncomePeriodicityDropdownButton() {
      return DropdownButtonFormField<int>(
        isExpanded: true,
        dropdownColor: Colors.white,
        decoration: InputDecoration(
          contentPadding: EdgeInsets.fromLTRB(15, 13, 12, 13),
          labelText: "Income Periodicity",
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
          ),
        ),
        items: _incomePeriodicities.map((item) {
          return DropdownMenuItem<int>(
            value: item["id"] as int?,
            child: Container(
              child: Text(
                item["title"] as String,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          );
        }).toList(),
        value: _incomePeriodicitySelected ?? null,
        onChanged: (newValue) {
          setState(() {
            _incomePeriodicitySelected = newValue;
          });
        },
        validator: (value) {
          if (_incomePeriodicitySelected == null) {
            return "Sector is required.";
          }
          return null;
        },
        onSaved: (newValue) {},
      );
    }

    // Income Amount //
    var _incomeAmountFormField = TextFormField(
      textInputAction: TextInputAction.next,
      controller: _incomeAmountController,
      focusNode: _incomeAmountFocusNode,
      onFieldSubmitted: (value) {
        FocusScope.of(context).requestFocus(_incomeSourceRemarkFocusNode);
      },
      decoration: InputDecoration(
        contentPadding: EdgeInsets.all(15),
        labelText: "Income Amount",
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.grey, width: 1),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.grey, width: 1),
        ),
        border: OutlineInputBorder(
          borderSide: BorderSide(color: Theme.of(context).primaryColor, width: 1),
        ),
        suffixIcon: IconButton(
          icon: Icon(Icons.clear),
          onPressed: () => _incomeAmountController.clear(),
        ),
      ),
      keyboardType: TextInputType.numberWithOptions(signed: true, decimal: true),
      inputFormatters: [
        ThousandsFormatter(),
      ],
      validator: (value) {
        if (value!.isEmpty) {
          return "This field is required.";
        }
        if (int.parse(value.replaceAll(',', '')) == 0) {
          return "Amount must be greater than 0.";
        }
        return null;
      },
      onSaved: (String? value) {},
    );

    return ModalProgressHUD(
      inAsyncCall: _isLoading,
      opacity: 0.5,
      progressIndicator: CircularProgressIndicator(
        valueColor: new AlwaysStoppedAnimation<Color>(
          context.getColorScheme().primary,
        ),
      ),
      child: Container(
        child: DraggableScrollableSheet(
          initialChildSize: 0.95,
          //set this as you want
          maxChildSize: 0.95,
          //set this as you want
          minChildSize: 0.95,
          //set this as you want
          expand: true,
          builder: (context, scrollController) {
            return ClipRRect(
              borderRadius: BorderRadius.only(topLeft: Radius.circular(20.0), topRight: Radius.circular(20.0)),
              child: Container(
                padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
                color: Colors.white,
                child: Column(
                  children: [
                    Container(
                      color: Colors.teal,
                      child: Stack(children: [
                        Container(
                          width: double.infinity,
                          height: 50.0,
                          child: Center(
                            child: Text(
                              "${widget.initialContactIncome.isEmpty ? 'CREATE' : 'EDIT'} INCOME",
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white),
                            ), // Your desired title
                          ),
                        ),
                        Positioned(
                          left: 0.0,
                          top: 0.0,
                          child: IconButton(
                            icon: Icon(
                              Icons.arrow_back,
                              color: Colors.white,
                            ), // Your desired icon
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          ),
                        ),
                      ]),
                    ),
                    // Divider(),
                    Expanded(
                      child: Container(
                        child: Form(
                          key: _formKey,
                          autovalidateMode: AutovalidateMode.always,
                          child: SingleChildScrollView(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  padding: EdgeInsets.fromLTRB(15, 5, 15, 10),
                                  child: Column(
                                    children: [
                                      Column(
                                        children: [
                                          Container(
                                            decoration: BoxDecoration(
                                              border: Border.all(color: Colors.grey),
                                              borderRadius: BorderRadius.circular(5),
                                            ),
                                            child: Column(
                                              children: [
                                                // EMP STATUS //
                                                SizedBox(
                                                  height: 10,
                                                ),
                                                Text('EMPLOYMENT STATUS', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey)),
                                                Row(
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  children: <Widget>[
                                                    new Radio(
                                                      value: 2,
                                                      groupValue: _selfEmployedSelected,
                                                      onChanged: _onChangeEmploymentStatusSelection,
                                                    ),
                                                    new InkWell(
                                                      child: Text(
                                                        'No job / Un-employed',
                                                        style: new TextStyle(fontSize: 16.0),
                                                      ),
                                                      onTap: () {
                                                        _onChangeEmploymentStatusSelection(2);
                                                      },
                                                    ),
                                                  ],
                                                ),
                                                Row(
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  children: [
                                                    new Radio(
                                                      value: 1,
                                                      groupValue: _selfEmployedSelected,
                                                      onChanged: _onChangeEmploymentStatusSelection,
                                                    ),
                                                    new InkWell(
                                                      child: new Text(
                                                        'Self-employed',
                                                        style: new TextStyle(
                                                          fontSize: 16.0,
                                                        ),
                                                      ),
                                                      onTap: () {
                                                        _onChangeEmploymentStatusSelection(1);
                                                      },
                                                    ),
                                                    SizedBox(
                                                      width: 5,
                                                    ),
                                                    new Radio(
                                                      value: 0,
                                                      groupValue: _selfEmployedSelected,
                                                      onChanged: _onChangeEmploymentStatusSelection,
                                                    ),
                                                    new InkWell(
                                                      child: Text(
                                                        'Employed',
                                                        style: new TextStyle(fontSize: 16.0),
                                                      ),
                                                      onTap: () {
                                                        _onChangeEmploymentStatusSelection(0);
                                                      },
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),

                                          SizedBox(
                                            height: 10,
                                          ),

                                          // Business Type //
                                          _buildBusinessTypeDropdownButton(),
                                          SizedBox(
                                            height: 10,
                                          ),

                                          // Job Category //
                                          _buildJobCategoryDropdownButton(),
                                          SizedBox(
                                            height: 10,
                                          ),

                                          // workplaceName //
                                          _selfEmployedSelected == 2
                                              ? SizedBox()
                                              : TextFormInput(
                                                  controller: _workplaceNameController,
                                                  focusNode: _workplaceNameFocusNode,
                                                  label: "Company/Employer Name",
                                                  nextFocusNode: _workplaceFixedTelFocusNode,
                                                  textInputAction: TextInputAction.next,
                                                  isRequired: _selfEmployedSelected == 0 ? true : false,
                                                  requiredMessage: "This field is required.",
                                                  onSaved: _setWorkplaceName,
                                                  maxLines: 2,
                                                ),
                                          _selfEmployedSelected == 2
                                              ? SizedBox()
                                              : SizedBox(
                                                  height: 10,
                                                ),

                                          // workplaceFixedTel //
                                          _selfEmployedSelected == 2
                                              ? SizedBox()
                                              : TextFormInput(
                                                  controller: _workplaceFixedTelController,
                                                  focusNode: _workplaceFixedTelFocusNode,
                                                  label: "Fixed Telephone",
                                                  nextFocusNode: _workplaceAddressFocusNode,
                                                  textInputAction: TextInputAction.next,
                                                  keyboardType: TextInputType.number,
                                                  isRequired: false,
                                                  onSaved: _setWorkplaceFixedTel,
                                                ),
                                          _selfEmployedSelected == 2
                                              ? SizedBox()
                                              : SizedBox(
                                                  height: 10,
                                                ),

                                          // workplaceAddress //
                                          _selfEmployedSelected == 2
                                              ? SizedBox()
                                              : TextFormInput(
                                                  controller: _workplaceAddressController,
                                                  focusNode: _workplaceAddressFocusNode,
                                                  label: "Company/Employer Address",
                                                  textInputAction: TextInputAction.done,
                                                  isRequired: false,
                                                  maxLines: 2,
                                                  onSaved: _setWorkplaceAddress,
                                                ),
                                          _selfEmployedSelected == 2
                                              ? SizedBox()
                                              : SizedBox(
                                                  height: 10,
                                                ),

                                          // incomePeriodicity //
                                          _buildIncomePeriodicityDropdownButton(),
                                          SizedBox(
                                            height: 10,
                                          ),

                                          // incomeAmount //
                                          _incomeAmountFormField,
                                          SizedBox(
                                            height: 10,
                                          ),

                                          // incomeSourceRemark //
                                          TextFormInput(
                                            controller: _incomeSourceRemarkController,
                                            focusNode: _incomeSourceRemarkFocusNode,
                                            label: "Remark",
                                            textInputAction: TextInputAction.done,
                                            isRequired: false,
                                            onSaved: _setIncomeSourceRemark,
                                            maxLines: 2,
                                          ),
                                        ],
                                      ),
                                      SizedBox(
                                        height: 10,
                                      ),
                                      Divider(),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: <Widget>[
                                          Expanded(
                                            child: ButtonWidget(
                                              text: "CLEAR",
                                              isWhiteBackgroundColor: true,
                                              onPressed: _clearAllFields,
                                            ),
                                          ),
                                          Expanded(
                                            child: ButtonWidget(
                                              text: widget.contactDetId == null ? "CONFIRM" : "SAVE CHANGES",
                                              isWhiteBackgroundColor: false,
                                              onPressed: _confirmContactIncome,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
