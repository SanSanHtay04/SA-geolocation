import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class ProspectItemWidget extends StatefulWidget {
  final String connectionType;
  final Map<String, dynamic> prospect;
  final Function onPressProspect;
  final Function onDeleteProspect;

  ProspectItemWidget({
    Key? key,
    required this.connectionType,
    required this.prospect,
    required this.onPressProspect,
    required this.onDeleteProspect,
  });
  @override
  @override
  State<ProspectItemWidget> createState() => _ProspectItemWidgetState();
}

class _ProspectItemWidgetState extends State<ProspectItemWidget> {
  @override
  Widget build(BuildContext context) {
    return ListTile(
      isThreeLine: true,
      title: Row(
        children: [
          Text(
            '${widget.prospect['prospectName']}',
            style: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold),
          ),
          SizedBox(
            width: 5,
          ),
          Text(
            '(${widget.prospect['prospectGender'] == 'f' ? 'Female' : 'Male'})',
            style: TextStyle(color: Colors.blue, fontSize: 12),
          ),
        ],
      ),
      subtitle: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '- Merchant Name: ${widget.prospect['merchantName'] != null ? widget.prospect['merchantName'] : ''}',
            style: TextStyle(fontSize: 13),
          ),
          Text(
            '- POS Name: ${widget.prospect['posName'] != null ? widget.prospect['posName'] : ''}',
            style: TextStyle(fontSize: 13),
          ),
          Text(
            '- Mob: ${widget.prospect['prospectMobile']} ${(widget.prospect['prospectOtherMobile'] != null && widget.prospect['prospectOtherMobile'] != "") ? ('- ' + widget.prospect['prospectOtherMobile']) : ''}',
            style: TextStyle(fontSize: 13),
          ),
          widget.connectionType == 'online'
              ? Text(
                  '- Created at: ${DateFormat('dd/MM/yyyy HH:mm').format(DateTime.parse(widget.prospect['dtCreated'].toString()))}',
                  style: TextStyle(fontSize: 13),
                )
              : SizedBox(),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              OutlinedButton.icon(
                icon: Icon(
                  Icons.delete,
                  size: 20,
                  color: Colors.red,
                ),
                label: Text(
                  'Delete',
                  style: TextStyle(color: Colors.red),
                ),
                style: OutlinedButton.styleFrom(
                  side: BorderSide(width: 1.0, color: Colors.red),
                ),
                onPressed: () {
                  widget.onDeleteProspect(widget.prospect);
                },
              ),
              SizedBox(
                width: 5,
              ),
              OutlinedButton.icon(
                icon: Icon(
                  Icons.arrow_circle_right,
                  size: 20,
                  color: Colors.blue,
                ),
                label: Text(
                  'Proceed',
                  style: TextStyle(color: Colors.blue),
                ),
                style: OutlinedButton.styleFrom(
                  side: BorderSide(width: 1.0, color: Colors.blue),
                ),
                onPressed: () {
                  widget.onPressProspect(widget.prospect['prospectId']);
                },
              ),
            ],
          ),
          Divider(),
        ],
      ),
    );
  }
}
