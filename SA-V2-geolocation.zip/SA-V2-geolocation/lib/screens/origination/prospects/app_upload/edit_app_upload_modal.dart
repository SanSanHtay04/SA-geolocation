import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:provider/provider.dart';
import 'package:sales/data/local/db_sqlite_helper.dart';
import 'package:sales/providers/providers.dart';
import 'package:sales/data/local/models/models.dart';

import '../../../../widgets/confirmation_modal_bottom_widget.dart';
import '../../../../widgets/deprecated/alert_modal_bottom_widget.dart';
import '../../../../widgets/deprecated/button_widget.dart';
import '../../../../widgets/deprecated/image_input_widger.dart';
import '../../../../widgets/deprecated/text_form_input.dart';

class EditAppUploadModal extends StatefulWidget {
  final int? applicationId;
  final int? uploadId;
  final String? connectionType;

  EditAppUploadModal({required this.applicationId, required this.uploadId, required this.connectionType});

  @override
  _EditAppUploadModalState createState() => _EditAppUploadModalState();
}

class _EditAppUploadModalState extends State<EditAppUploadModal> {
  bool _isInit = true;
  bool _isLoading = false;
  bool? _isChangePhoto = false;

  int? _documentIdSelected;
  String? _documentUploadSelected = 'document';
  String? _docProductTypeSelected = 'not_car';
  File? _pickedFile;
  late Image _image;

  Map<String, dynamic>? _appUpload;
  List<Map<String, dynamic>> _docTypes = [];

  final GlobalKey<FormState> _formKey = GlobalKey();

  final _uploadNameFocusNode = FocusNode();
  final _uploadDescFocusNode = FocusNode();

  final _uploadNameController = TextEditingController();
  final _uploadDescController = TextEditingController();

  void _setUploadName(String? value) {}

  void _setDocDetRemark(String? value) {}

  void _onChangeDocumentUploadSelection(String? strDocumentUpload) async {
    setState(() {
      _documentUploadSelected = strDocumentUpload;
    });

    if (strDocumentUpload == 'customerphoto') {
      setState(() {
        _docProductTypeSelected = 'not_car';
      });
    }
    await _getAppDocuments(_docProductTypeSelected, widget.applicationId);
  }

  void _onChangeDocProductTypeSelection(String? strProdType) async {
    setState(() {
      _docProductTypeSelected = strProdType;
    });
    await _getAppDocuments(strProdType, widget.applicationId);
  }

  void _onSelectPickedImage(File pickImage) async {
    setState(() {
      _pickedFile = pickImage;
    });
  }

  Future<void> _getAppDocuments(String? strProductType, int? applicationId) async {
    setState(() {
      _isLoading = true;
      _documentIdSelected = null;
    });

    try {
      if (widget.connectionType == 'online') {
        await Provider.of<AppDocumentProvider>(context, listen: false).getAllAppDocsByProductType(strProductType).then((value) {
          setState(() {
            _docTypes = Provider.of<AppDocumentProvider>(context, listen: false).items;
            _isLoading = false;
          });
        });
      } else {
        List<Map<String, dynamic>> offlineAppDocuments = await DBSqliteHelper().getAllAppDocuments(_docProductTypeSelected);
        setState(() {
          _docTypes = List<Map<String, dynamic>>.from(offlineAppDocuments);
          _isLoading = false;
        });
      }
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  void _clearAllFields() {
    setState(() {
      _documentUploadSelected = 'document';
      _docProductTypeSelected = 'not_car';
      _documentIdSelected = null;
      _pickedFile = null;
    });
    _uploadNameController.text = "";
    _uploadDescController.text = "";
  }

  void _saveAppUpload() {
    if (!_formKey.currentState!.validate()) {
      // Invalid!
      return;
    }
    _formKey.currentState!.save();

    if (widget.uploadId == null) {
      // create //
      if (_pickedFile != null) {
        showModalBottomSheet(
            context: context,
            isScrollControlled: true,
            builder: (context) {
              String? _message = 'Something went wrong.';
              return ConfirmationModalBottomSheet("Are you sure you want to create new app upload?", () async {
                try {
                  setState(() {
                    _isLoading = true;
                  });

                  Map<String, dynamic> recAppUpload = {
                    'applicationId': widget.applicationId,
                    'documentId': _documentIdSelected,
                    'uploadName': _documentUploadSelected == 'customerphoto' ? 'Customer Photo' : _uploadNameController.text.trim(),
                    'uploadDesc': _documentUploadSelected == 'customerphoto' ? null : _uploadDescController.text.trim(),
                    'fileData': base64.encode(_pickedFile!.readAsBytesSync()),
                  };

                  if (widget.connectionType == 'online') {
                    await Provider.of<AppUploadProvider>(context, listen: false).createRecord(widget.applicationId, recAppUpload).then((value) async {
                      setState(() {
                        _message = Provider.of<AppUploadProvider>(context, listen: false).responseMessage;
                      });
                      await _getAppDocuments(_docProductTypeSelected, widget.applicationId);
                    });
                  } else {
                    Map<String, dynamic> offlineAppUpload = Map<String, dynamic>.from(recAppUpload);
                    _message = 'New upload is successfully created.';
                    await DBSqliteHelper().createAppUpload(AppUpload.fromMap(offlineAppUpload), widget.applicationId);

                    await _getAppDocuments(_docProductTypeSelected, widget.applicationId);
                    _uploadDescController.text = "";
                  }
                  _clearAllFields();
                } catch (error) {
                  _message = error.toString();
                }

                setState(() {
                  _isLoading = false;
                });

                Navigator.pop(context);
                showModalBottomSheet(
                    context: context,
                    isScrollControlled: true,
                    builder: (context) {
                      return AlertModalBottomWidget(_message, () {
                        Navigator.pop(context);
                        Navigator.pop(context);
                      });
                    });
              });
            });
      } else {}
    } else {
      // edit //
      showModalBottomSheet(
          context: context,
          isScrollControlled: true,
          builder: (context) {
            String? _message = 'Something went wrong.';
            return ConfirmationModalBottomSheet("Are you sure you want to edit the selected of upload?", () async {
              try {
                setState(() {
                  _isLoading = true;
                });

                Map<String, dynamic> recAppUpload = {
                  'documentId': _documentIdSelected,
                  'uploadName': _documentUploadSelected == 'customerphoto' ? 'Customer Photo' : _uploadNameController.text.trim(),
                  'uploadDesc': _uploadDescController.text.trim(),
                  'fileData': _pickedFile == null ? null : base64.encode(_pickedFile!.readAsBytesSync()),
                };

                if (widget.connectionType == 'online') {
                  await Provider.of<AppUploadProvider>(context, listen: false).editRecord(widget.applicationId, widget.uploadId, recAppUpload).then((value) async {
                    setState(() {
                      _message = Provider.of<AppUploadProvider>(context, listen: false).responseMessage;
                      _isLoading = false;
                    });
                  });
                } else {
                  _message = "App upload is successfully updated.";
                  Map<String, dynamic> offlineAppUpload = Map<String, dynamic>.from(recAppUpload);

                  await DBSqliteHelper().updateAppUpload(offlineAppUpload, widget.uploadId);
                  _isLoading = false;
                }
              } catch (error) {
                setState(() {
                  _message = error.toString();
                  _isLoading = false;
                });
              }

              Navigator.pop(context);
              showModalBottomSheet(
                  context: context,
                  isScrollControlled: true,
                  builder: (context) {
                    return AlertModalBottomWidget(_message, () {
                      Navigator.pop(context);
                      Navigator.pop(context);
                    });
                  });
            });
          });
    }
  }

  Future<void> _getAppUpload(int? applicationId, int? uploadId) async {
    setState(() {
      _isLoading = true;
    });

    try {
      if (widget.connectionType == 'online') {
        await Provider.of<AppUploadProvider>(context, listen: false).getRecord(applicationId, uploadId).then((value) {
          setState(() {
            _appUpload = Provider.of<AppUploadProvider>(context, listen: false).item;
            _isLoading = false;
          });
        });
      } else {
        Map<String, dynamic>? offlineDocUpload = await DBSqliteHelper().getAppUpload(uploadId);
        setState(() {
          _appUpload = Map<String, dynamic>.from(offlineDocUpload!);
          _image = Image.memory(base64Decode(_appUpload!['fileData']));
          _isLoading = false;
        });
      }
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  void _initData() async {
    if (widget.uploadId == null) {
      setState(() {
        _isChangePhoto = true;
      });
      await _getAppDocuments(_docProductTypeSelected, widget.applicationId);
    } else {
      await _getAppUpload(widget.applicationId, widget.uploadId);
      if (_appUpload != null) {
        if (_appUpload!['docProductType'] == null) {
          _docProductTypeSelected = 'not_car';
        } else {
          _docProductTypeSelected = 'car';
        }
        await _getAppDocuments(_docProductTypeSelected, widget.applicationId);
        _uploadNameController.text = _appUpload!['uploadName'];
        _uploadDescController.text = _appUpload!['uploadDesc'];

        setState(() {
          _documentIdSelected = _appUpload!['documentId'];
        });
      }
    }
  }

  @override
  void initState() {
    super.initState();
    _uploadNameController.addListener(() {});
    _uploadDescController.addListener(() {});
  }

  @override
  void dispose() {
    _uploadNameController.dispose();
    _uploadDescController.dispose();
    super.dispose();
  }

  @override
  void didChangeDependencies() async {
    super.didChangeDependencies();
    if (_isInit) {
      _initData();
      setState(() {
        _isInit = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    var _deviceSize = MediaQuery.of(context).size;

    // App Doc Type //
    Widget _buildAppDocDropdownButton() {
      return DropdownButtonFormField<int>(
        isExpanded: true,
        dropdownColor: Colors.white,
        decoration: InputDecoration(
          contentPadding: EdgeInsets.fromLTRB(15, 13, 12, 13),
          labelText: "Upload Document",
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
          ),
        ),
        items: _docTypes.map((item) {
          return DropdownMenuItem<int>(
            value: item["documentId"],
            child: Container(
              // width: _deviceSize.width - 60,
              child: Text(
                "${item["docTypeName"]} / ${item["documentName"]}",
                overflow: TextOverflow.ellipsis,
              ),
            ),
          );
        }).toList(),
        value: _documentIdSelected ?? null,
        onChanged: (newValue) {
          print("DocumentIdSelected : $newValue");
          setState(() {
            _documentIdSelected = newValue;
          });
        },
        validator: (value) {
          if (_documentUploadSelected == 'document' && _documentIdSelected == null) {
            return "This field is required.";
          }
          return null;
        },
      );
    }

    return ModalProgressHUD(
      inAsyncCall: _isLoading,
      opacity: 0.5,
      progressIndicator: CircularProgressIndicator(
        valueColor: new AlwaysStoppedAnimation<Color>(Theme.of(context).primaryColor),
      ),
      child: Container(
        child: DraggableScrollableSheet(
            initialChildSize: 0.95,
            //set this as you want
            maxChildSize: 0.95,
            //set this as you want
            minChildSize: 0.95,
            //set this as you want
            expand: true,
            builder: (context, scrollController) {
              return ClipRRect(
                borderRadius: BorderRadius.only(topLeft: Radius.circular(20.0), topRight: Radius.circular(20.0)),
                child: Container(
                  color: Colors.white,
                  child: Column(children: [
                    Container(
                      color: Colors.teal,
                      child: Stack(children: [
                        Container(
                          width: double.infinity,
                          height: 50.0,
                          child: Center(
                            child: Text(
                              "${widget.uploadId == null ? 'ADD NEW' : 'EDIT'} FILE",
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white),
                            ), // Your desired title
                          ),
                        ),
                        Positioned(
                          left: 0.0,
                          top: 0.0,
                          child: IconButton(
                            icon: Icon(
                              Icons.arrow_back,
                              color: Colors.white,
                            ), // Your desired icon
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          ),
                        ),
                      ]),
                    ),

                    // Document Upload //
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.grey[200],
                        border: Border(bottom: BorderSide(color: Colors.grey)),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          new Radio(
                            value: 'document',
                            groupValue: _documentUploadSelected,
                            onChanged: widget.uploadId != null ? null : _onChangeDocumentUploadSelection,
                          ),
                          new InkWell(
                            child: Text(
                              'Document',
                              style: new TextStyle(fontSize: 16.0),
                            ),
                            onTap: widget.uploadId != null
                                ? null
                                : () {
                                    _onChangeDocumentUploadSelection('document');
                                  },
                          ),
                          new Radio(
                            value: 'customerphoto',
                            groupValue: _documentUploadSelected,
                            onChanged: widget.uploadId != null ? null : _onChangeDocumentUploadSelection,
                          ),
                          new InkWell(
                            child: new Text(
                              'Customer Photo',
                              style: new TextStyle(
                                fontSize: 16.0,
                              ),
                            ),
                            onTap: widget.uploadId != null
                                ? null
                                : () {
                                    _onChangeDocumentUploadSelection('customerphoto');
                                  },
                          ),
                        ],
                      ),
                    ),

                    // product type //
                    _documentUploadSelected == 'document'
                        ? Container(
                            decoration: BoxDecoration(
                              border: Border(bottom: BorderSide(color: Colors.grey)),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                new Radio(
                                  value: 'not_car',
                                  groupValue: _docProductTypeSelected,
                                  onChanged: _onChangeDocProductTypeSelection,
                                ),
                                new InkWell(
                                  child: Text(
                                    'NOT 4-wheeler ',
                                    style: new TextStyle(fontSize: 16.0),
                                  ),
                                  onTap: () {
                                    _onChangeDocProductTypeSelection('not_car');
                                  },
                                ),
                                new Radio(
                                  value: 'car',
                                  groupValue: _docProductTypeSelected,
                                  onChanged: _onChangeDocProductTypeSelection,
                                ),
                                new InkWell(
                                  child: new Text(
                                    '4-wheeler',
                                    style: new TextStyle(
                                      fontSize: 16.0,
                                    ),
                                  ),
                                  onTap: () {
                                    _onChangeDocProductTypeSelection('car');
                                  },
                                ),
                              ],
                            ),
                          )
                        : SizedBox(),

                    Expanded(
                      child: Container(
                        padding: EdgeInsets.fromLTRB(15, 5, 15, 10),
                        child: Form(
                          key: _formKey,
                          autovalidateMode: AutovalidateMode.always,
                          child: SingleChildScrollView(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  height: 10,
                                ),

                                _buildAppDocDropdownButton(),
                                SizedBox(
                                  height: 10,
                                ),

                                // uploadName //
                                _documentUploadSelected == 'document'
                                    ? TextFormInput(
                                        controller: _uploadNameController,
                                        focusNode: _uploadNameFocusNode,
                                        label: "Upload Name",
                                        nextFocusNode: _uploadDescFocusNode,
                                        textInputAction: TextInputAction.next,
                                        isRequired: _documentUploadSelected == 'document' ? true : false,
                                        requiredMessage: "This field is required.",
                                        onSaved: _setUploadName,
                                      )
                                    : SizedBox(),
                                _documentUploadSelected == 'document'
                                    ? SizedBox(
                                        height: 10,
                                      )
                                    : SizedBox(),

                                // uploadDesc //
                                _documentUploadSelected == 'document'
                                    ? TextFormInput(
                                        focusNode: _uploadDescFocusNode,
                                        controller: _uploadDescController,
                                        label: "Upload Description",
                                        textInputAction: TextInputAction.done,
                                        isRequired: false,
                                        onSaved: _setDocDetRemark,
                                        maxLines: 2,
                                      )
                                    : SizedBox(),
                                _documentUploadSelected == 'document'
                                    ? SizedBox(
                                        height: 10,
                                      )
                                    : SizedBox(),

                                widget.uploadId == null
                                    ? SizedBox()
                                    : InkWell(
                                        onTap: () {
                                          setState(() {
                                            _isChangePhoto = !_isChangePhoto!;
                                          });
                                        },
                                        child: Padding(
                                          padding: const EdgeInsets.all(12.0),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              SizedBox(
                                                width: 15,
                                                height: 15,
                                                child: Checkbox(
                                                  value: _isChangePhoto,
                                                  activeColor: Theme.of(context).primaryColor,
                                                  onChanged: (newValue) {
                                                    setState(() {
                                                      _isChangePhoto = newValue;
                                                    });
                                                  },
                                                ),
                                              ),
                                              SizedBox(
                                                width: 20,
                                              ),
                                              Text(
                                                "Change Other File",
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),

                                widget.uploadId != null && _isChangePhoto == false && _appUpload != null
                                    ? Container(
                                        height: 260,
                                        width: double.infinity,
                                        decoration: BoxDecoration(
                                          image: widget.connectionType == 'online' ? DecorationImage(image: NetworkImage("${_appUpload!['uploadDomain']}/${_appUpload!['uploadPath']}")) : DecorationImage(image: _image.image),
                                          border: Border.all(
                                            width: 1,
                                            color: Colors.grey,
                                          ),
                                          borderRadius: BorderRadius.circular(10),
                                        ),
                                      )
                                    : SizedBox(),

                                _isChangePhoto == false
                                    ? SizedBox()
                                    : ImageInputWidget(
                                        fileTitle: "Title",
                                        fileUrl: _appUpload == null ? null : "${_appUpload!['uploadDomain']}/${_appUpload!['uploadPath']}",
                                        pickedFile: _pickedFile,
                                        onSelectImage: _onSelectPickedImage,
                                        showGallery: (_documentIdSelected == 57 || _documentIdSelected == 58),
                                      ),

                                Divider(),
                                Container(
                                  color: Colors.white,
                                  child: Padding(
                                    padding: const EdgeInsets.all(10),
                                    child: Row(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
                                      Expanded(
                                        child: ButtonWidget(
                                          text: "CLEAR",
                                          isWhiteBackgroundColor: true,
                                          onPressed: _clearAllFields,
                                        ),
                                      ),
                                      Expanded(
                                        child: ButtonWidget(
                                          text: "SAVE",
                                          isWhiteBackgroundColor: false,
                                          onPressed: _saveAppUpload,
                                        ),
                                      ),
                                    ]),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ]),
                ),
              );
            }),
      ),
    );
  }
}
