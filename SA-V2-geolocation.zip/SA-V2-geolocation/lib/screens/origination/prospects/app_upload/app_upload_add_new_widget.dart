import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import 'package:sales/providers/app_upload_provider.dart';
import 'package:sales/utils/permission_helper.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/widgets/confirmation_modal_bottom_widget.dart';
import 'package:sales/widgets/deprecated/alert_modal_bottom_widget.dart';
import 'package:sales/widgets/permission_required_widget.dart';
import 'package:sales/widgets/waiting_modal_bottom_widget.dart';

class AppUploadAddNewWidget extends StatefulWidget {
  final int applicationId;
  final Map<String, dynamic> appDocument;
  final Function() getAppUploadList;
  final Function() getProspect;

  AppUploadAddNewWidget({
    Key? key,
    required this.applicationId,
    required this.appDocument,
    required this.getAppUploadList,
    required this.getProspect,
  });

  @override
  State<AppUploadAddNewWidget> createState() => _AppUploadAddNewWidgetState();
}

class _AppUploadAddNewWidgetState extends State<AppUploadAddNewWidget> {
  final _aspectRatioPresets = [
    CropAspectRatioPreset.square,
    CropAspectRatioPreset.ratio3x2,
    CropAspectRatioPreset.original,
    CropAspectRatioPreset.ratio4x3,
    CropAspectRatioPreset.ratio16x9,
  ];

  List<PlatformUiSettings> get _cropUiSettings => [
        AndroidUiSettings(
          toolbarTitle: 'Cropper',
          toolbarColor: Theme.of(context).primaryColor,
          toolbarWidgetColor: Colors.white,
          initAspectRatio: CropAspectRatioPreset.original,
          lockAspectRatio: false,
        ),
        IOSUiSettings(
          minimumAspectRatio: 1.0,
        )
      ];

  Future<void> _choosePicture(ImageSource source) async {
    final _pickedImage = await ImagePicker().pickImage(
      source: source,
      imageQuality: 50,
    );

    if (_pickedImage != null) {
      debugPrint((await _pickedImage.length()).toString());
      final imageCropper = new ImageCropper();
      CroppedFile? croppedFile = await imageCropper.cropImage(
        sourcePath: _pickedImage.path,
        aspectRatioPresets: _aspectRatioPresets,
        uiSettings: _cropUiSettings,
      );

      if (croppedFile == null) {
        return;
      }


    await PermissionHelper().requestStoragePermission(
      onGranted: () async {
         // Save the picked image in external storage instead of temporary memory
        var pngBytes = await croppedFile.readAsBytes();
        // await ImageGallerySaver.saveImage(pngBytes);

        String? resultMessage = 'Something went wrong.';
        showConfirmation(
            context: context,
            message: "Are you sure you want to upload the selected image?",
            onYes: () async {
              await showWaitingModal(
                  context: context,
                  message: "New upload is creating...",
                  onWaiting: () async {
                    try {
                      Map<String, dynamic> recAppUpload = {
                        'applicationId': widget.applicationId,
                        'documentId': widget.appDocument['documentId'],
                        'uploadName': widget.appDocument['documentName'],
                        'fileData': base64.encode(pngBytes),
                      };

                      await Provider.of<AppUploadProvider>(context, listen: false).createRecord(widget.applicationId, recAppUpload).then((value) async {
                        setState(() {
                          resultMessage = Provider.of<AppUploadProvider>(context, listen: false).responseMessage;
                        });
                      });
                    } catch (error) {
                      resultMessage = error.toString();
                    }
                    await widget.getProspect();
                  });
              await showAlertModal(context: context, message: resultMessage, onDismiss: () async {});
            });
      },
      onNotGranted: () async { await showStoragePermissionRequired(context); },
    );

  
    }
  }

  @override
  Widget build(BuildContext context) {
    List<String> listImageSourceApplied = widget.appDocument['appliedImageSources'].toString().split(",");

    final cameraIndex = listImageSourceApplied.indexWhere((element) => element == "camera");
    final galleryIndex = listImageSourceApplied.indexWhere((element) => element == "gallery");

    return Row(
      children: [
        Container(
          padding: EdgeInsets.all(6),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.teal.shade300, style: BorderStyle.solid),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Container(
            width: 100,
            height: 100,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                cameraIndex >= 0
                    ? IconButton(
                        onPressed: () async {
                          await _choosePicture(ImageSource.camera);
                        },
                        icon: Icon(
                          Icons.camera_alt_rounded,
                          color: Colors.blue,
                        ),
                      )
                    : SizedBox(),
                galleryIndex >= 0
                    ? IconButton(
                        onPressed: () async {
                          await _choosePicture(ImageSource.gallery);
                        },
                        icon: Icon(Icons.image_rounded, color: Colors.blue),
                      )
                    : SizedBox(),
              ],
            ),
          ),
        ),
        SizedBox(
          width: 5,
        ),
      ],
    );
  }
}
