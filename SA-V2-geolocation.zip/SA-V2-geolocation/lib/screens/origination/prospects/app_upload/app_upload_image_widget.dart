import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/providers/app_upload_provider.dart';
import 'package:sales/widgets/confirmation_modal_bottom_widget.dart';
import 'package:sales/widgets/deprecated/alert_modal_bottom_widget.dart';
import 'package:sales/widgets/waiting_modal_bottom_widget.dart';

class AppUploadImageWidget extends StatefulWidget {
  final Map<String, dynamic> appUpload;
  final Function() getAppUploadList;
  final Function() getProspect;

  AppUploadImageWidget({ Key? key,
    required this.appUpload,
    required this.getAppUploadList,
    required this.getProspect,
  });

  @override
  State<AppUploadImageWidget> createState() => _AppUploadImageWidgetState();
}

class _AppUploadImageWidgetState extends State<AppUploadImageWidget> {

  _deleteAppUpload() {
    String? resultMessage = 'Something went wrong.';
    showConfirmation(context: context, message: "Are you sure you want to delete the selected upload?", onYes: () async {
      await showWaitingModal(context: context, message: "The selected upload is deleting...", onWaiting: () async {
        try {
          await Provider.of<AppUploadProvider>(context, listen: false)
              .deleteRecord(widget.appUpload['applicationId'], widget.appUpload['uploadId'])
              .then((value) async {
            setState(() {
              resultMessage = Provider.of<AppUploadProvider>(context, listen: false).responseMessage;
            });
          });
        } catch (error) {
          resultMessage = error.toString();
        }   

        await widget.getProspect();
      });
      await showAlertModal(context: context, message: resultMessage, onDismiss: () async {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          padding: EdgeInsets.all(6),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.teal.shade300, style: BorderStyle.solid),
            borderRadius: BorderRadius.circular(10),
          ), 
          child: Stack(
            children: [
              Container(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: widget.appUpload['uploadFullPath'] != null && widget.appUpload['uploadFullPath'] != ""
                      ? SizedBox(width: 100, height: 100, child: Image.network(widget.appUpload['uploadFullPath'], fit: BoxFit.fill,),)
                      : Center(child: Text("No Image", textAlign: TextAlign.center, style: TextStyle(color: Colors.grey),),)
                ),
              ),
              Positioned(
                top: 6.0,
                right: 6.0,
                child: Align(
                  child: InkWell(
                    onTap: _deleteAppUpload,
                    child: CircleAvatar(
                      radius: 10,
                      backgroundColor: Colors.red,
                      child: Icon(Icons.close, color: Colors.white, size: 14,),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(width: 5,),
      ],
    );
  }
}