import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:provider/provider.dart';
import 'package:sales/data/local/db_sqlite_helper.dart';
import 'package:sales/providers/providers.dart';
import 'package:sales/utils/utils.dart';

import '../../../../widgets/item_info_widget.dart';

class CustomerIncomeModal extends StatefulWidget {
  final int? customerId;
  final int incomeSourceId;
  final String? connectionType;

  CustomerIncomeModal({required this.customerId, required this.incomeSourceId, required this.connectionType});

  @override
  _CustomerIncomeModalState createState() => _CustomerIncomeModalState();
}

class _CustomerIncomeModalState extends State<CustomerIncomeModal> {
  bool _isLoading = false;
  Map<String, dynamic>? _incomeSource;

  Future<void> _getCustIncomeSource(int? customerId, int incomeSourceId) async {
    setState(() {
      _isLoading = true;
    });

    try {
      if (widget.connectionType == 'online') {
        await Provider.of<CustomerIncomeSourceProvider>(context, listen: false).getRecord(customerId, incomeSourceId).then((value) {
          setState(() {
            _incomeSource = Provider.of<CustomerIncomeSourceProvider>(context, listen: false).item;
            _isLoading = false;
          });
        });
      } else {
        Map<String, dynamic>? offlineIncomeSource = await DBSqliteHelper().getCustomerIncomeSource(incomeSourceId);
        setState(() {
          _incomeSource = Map<String, dynamic>.from(offlineIncomeSource!);
          _isLoading = false;
        });
      }
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  @override
  void initState() {
    _getCustIncomeSource(widget.customerId, widget.incomeSourceId);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var _deviceSize = MediaQuery.of(context).size;

    return ModalProgressHUD(
      inAsyncCall: _isLoading,
      opacity: 0.5,
      progressIndicator: CircularProgressIndicator(
        valueColor: new AlwaysStoppedAnimation<Color>(
          context.getColorScheme().primary,
        ),
      ),
      child: Container(
        child: DraggableScrollableSheet(
            initialChildSize: 0.95,
            //set this as you want
            maxChildSize: 0.95,
            //set this as you want
            minChildSize: 0.95,
            //set this as you want
            expand: true,
            builder: (context, scrollController) {
              return ClipRRect(
                borderRadius: BorderRadius.only(topLeft: Radius.circular(20.0), topRight: Radius.circular(20.0)),
                child: Container(
                  color: Colors.white,
                  child: Column(
                    children: [
                      Container(
                        color: Colors.teal,
                        child: Stack(children: [
                          Container(
                            width: double.infinity,
                            height: 50.0,
                            child: Center(
                              child: Text(
                                "INCOME SOURCE INFORMATION",
                                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white),
                              ), // Your desired title
                            ),
                          ),
                          Positioned(
                            left: 0.0,
                            top: 0.0,
                            child: IconButton(
                              icon: Icon(
                                Icons.arrow_back,
                                color: Colors.white,
                              ), // Your desired icon
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                            ),
                          ),
                        ]),
                      ),
                      Expanded(
                        child: Container(
                          padding: EdgeInsets.fromLTRB(15, 5, 15, 10),
                          child: SingleChildScrollView(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // CARD Type //
                                Container(
                                  width: _deviceSize.width,
                                  // padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
                                  // decoration: BoxDecoration(
                                  //   border: Border.all(color: Colors.grey),
                                  //   borderRadius: BorderRadius.circular(5),
                                  // ),
                                  child: _incomeSource != null
                                      ? SingleChildScrollView(
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              SizedBox(
                                                height: 5,
                                              ),
                                              Divider(
                                                height: 10,
                                                thickness: 0.5,
                                              ),

                                              // Employment Status //
                                              ItemInfoWidget(
                                                title: 'Employment Status',
                                                value: _incomeSource!['selfemployed'] == 2 ? 'No job / Un-employed' : (_incomeSource!['selfemployed'] == 1 ? 'Self-employed' : 'Employed'),
                                              ),
                                              Divider(
                                                height: 10,
                                                thickness: 0.5,
                                              ),

                                              // Sector //
                                              ItemInfoWidget(
                                                title: 'Sector',
                                                value: _incomeSource!['businessTypeName'].toString(),
                                              ),
                                              Divider(
                                                height: 10,
                                                thickness: 0.5,
                                              ),

                                              // Sector //
                                              ItemInfoWidget(
                                                title: 'Job Category',
                                                value: _incomeSource!['jobCategoryName'].toString(),
                                              ),
                                              Divider(
                                                height: 10,
                                                thickness: 0.5,
                                              ),

                                              // Company/Employer Name //
                                              ItemInfoWidget(
                                                title: 'Company/Employer Name',
                                                value: _incomeSource!['workplaceName'] ?? '-/-',
                                              ),
                                              Divider(
                                                height: 10,
                                                thickness: 0.5,
                                              ),

                                              // Fixed Telephone //
                                              ItemInfoWidget(
                                                title: 'Fixed Telephone',
                                                value: _incomeSource!['workplaceFixedTel'] ?? '-/-',
                                              ),
                                              Divider(
                                                height: 10,
                                                thickness: 0.5,
                                              ),

                                              // Company/Employer Address //
                                              ItemInfoWidget(
                                                title: 'Company/Employer Address',
                                                value: _incomeSource!['workplaceAddress'] ?? '-/-',
                                              ),
                                              Divider(
                                                height: 10,
                                                thickness: 0.5,
                                              ),

                                              // Income Periodicity //
                                              ItemInfoWidget(
                                                title: 'Income Periodicity',
                                                value: _incomeSource!['incomePeriodicity'] == 1 ? 'MONTHLY' : (_incomeSource!['incomePeriodicity'] == 3 ? 'QUARTERLY' : 'YEARLY'),
                                              ),
                                              Divider(
                                                height: 10,
                                                thickness: 0.5,
                                              ),

                                              // Income Amount //
                                              ItemInfoWidget(
                                                title: 'Income Amount',
                                                value: NumberFormat('#,###').format(_incomeSource!['incomeAmount']) + " MMK",
                                              ),
                                              Divider(
                                                height: 10,
                                                thickness: 0.5,
                                              ),

                                              // Remark //
                                              ItemInfoWidget(
                                                title: 'Remark',
                                                value: _incomeSource!['incomeSourceRemark'] ?? '-/-',
                                              ),
                                              Divider(
                                                height: 10,
                                                thickness: 0.5,
                                              ),

                                              // Exclusion List //
                                              ItemInfoWidget(
                                                title: 'Exclusion List',
                                                value: _incomeSource!['exclusionList'] == 1 ? 'YES' : 'NO',
                                              ),
                                              Divider(
                                                height: 10,
                                                thickness: 0.5,
                                              ),

                                              // Exclusion List Remark //
                                              ItemInfoWidget(
                                                title: 'Exclusion List Remark',
                                                value: _incomeSource!['exclusionListRemark'] ?? '-/-',
                                              ),
                                              Divider(
                                                height: 10,
                                                thickness: 0.5,
                                              ),
                                            ],
                                          ),
                                        )
                                      : Text('Cannot load the income source.'),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
      ),
    );
  }
}
