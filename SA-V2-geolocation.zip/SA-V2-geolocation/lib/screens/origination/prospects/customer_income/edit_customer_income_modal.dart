import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:pattern_formatter/pattern_formatter.dart';
import 'package:provider/provider.dart';
import 'package:sales/data/local/db_sqlite_helper.dart';
import 'package:sales/data/local/models/models.dart';
import 'package:sales/providers/providers.dart';
import 'package:sales/utils/utils.dart';

import 'package:sales/widgets/waiting_modal_bottom_widget.dart';

import '../../../../widgets/confirmation_modal_bottom_widget.dart';
import '../../../../widgets/deprecated/alert_modal_bottom_widget.dart';
import '../../../../widgets/deprecated/button_widget.dart';
import '../../../../widgets/deprecated/text_form_input.dart';

class EditCustomerIncomeModal extends StatefulWidget {
  final int? customerId;
  final int? incomeSourceId;
  final int? userId;
  final String? connectionType;

  EditCustomerIncomeModal({required this.customerId, required this.incomeSourceId, required this.userId, required this.connectionType});

  @override
  _EditCustomerIncomeModalState createState() => _EditCustomerIncomeModalState();
}

class _EditCustomerIncomeModalState extends State<EditCustomerIncomeModal> {
  bool _isLoading = false;
  int? _selfEmployedSelected = 0;
  int? _businessTypeIdSelected;
  int? _jobCategoryIdSelected;
  int? _officeHourSelected = 1;
  String? _timeShiftSelected;
  int? _incomePeriodicitySelected;
  int? _exclusionListSelected = 0;

  List<Map<String, dynamic>> _businessTypes = [];
  List<Map<String, dynamic>> _jobCategories = [];
  Map<String, dynamic>? _incomeSource;

  final GlobalKey<FormState> _formKey = GlobalKey();
  late Map<String, dynamic> _formData;
  Map<String, dynamic> _formDataDefault = {'customerId': null, 'selfemployed': 0, 'businessTypeId': null, 'jobCategoryId': null, 'workplaceName': null, 'workplaceFixedTel': null, 'workplaceAddress': null, 'incomePeriodicity': 1, 'incomeAmount': 0, 'incomeSourceRemark': null, 'exclusionList': 0, 'exclusionListRemark': null, 'callAvailableDuringOfficeHour': null, 'callAvailableTime': null};

  var incomePeriodicities = [
    {'id': 1, 'title': 'Monthly (Every 1 month)'},
    {'id': 3, 'title': 'Quarterly (Every 3 months)'},
    {'id': 12, 'title': 'Yearly (Every 12 months)'}
  ];

  var _timeShifts = [
    {'id': 'morning', 'title': 'Morning Shift'},
    {'id': 'evening', 'title': 'Evening Shift'},
  ];

  // workplaceName //
  final _workplaceNameFocusNode = FocusNode();
  final _workplaceNameController = TextEditingController();

  void _setWorkplaceName(String? value) {
    setState(() {
      _formData['workplaceName'] = value;
    });
  }

  // workplaceFixedTel //
  final _workplaceFixedTelFocusNode = FocusNode();
  final _workplaceFixedTelController = TextEditingController();

  void _setWorkplaceFixedTel(String? value) {
    setState(() {
      _formData['workplaceFixedTel'] = value;
    });
  }

  // workplaceAddress //
  final _workplaceAddressFocusNode = FocusNode();
  final _workplaceAddressController = TextEditingController();

  void _setWorkplaceAddress(String? value) {
    setState(() {
      _formData['workplaceAddress'] = value;
    });
  }

  // incomeAmount //
  final _incomeAmountFocusNode = FocusNode();
  final _incomeAmountController = TextEditingController();

  // incomeSourceRemark //
  final _incomeSourceRemarkFocusNode = FocusNode();
  final _incomeSourceRemarkController = TextEditingController();

  void _setIncomeSourceRemark(String? value) {
    setState(() {
      _formData['incomeSourceRemark'] = value;
    });
  }

  // exclusionListRemark //
  final _exclusionListRemarkFocusNode = FocusNode();
  final _exclusionListRemarkController = TextEditingController();

  void _setExclusionListRemark(String? value) {
    setState(() {
      _formData['exclusionListRemark'] = value;
    });
  }

  void _onChangeEmploymentStatusSelection(int? status) async {
    setState(() {
      _selfEmployedSelected = status;
      _formData['selfemployed'] = status;
      _businessTypeIdSelected = null;
      _jobCategoryIdSelected = null;
    });
    await _getBusinessTypeByEmpStatus(_selfEmployedSelected);
  }

  void _onChangeExclusionListSelection(int? status) async {
    setState(() {
      _exclusionListSelected = status;
      _formData['exclusionList'] = status;
    });
  }

  void _onChangeOfficeHourSelection(int? value) {
    setState(() {
      _officeHourSelected = value;
      _formData['callAvailableDuringOfficeHour'] = value;
    });
  }

  Future<void> _getBusinessTypeByEmpStatus(int? status) async {
    setState(() {
      _isLoading = true;
      _businessTypeIdSelected = null;
      _jobCategoryIdSelected = null;
    });

    try {
      if (widget.connectionType == 'online') {
        await Provider.of<BusinessTypeProvider>(context, listen: false).getBusinessTypeByEmpStatus(status).then((value) {
          setState(() {
            _businessTypes = Provider.of<BusinessTypeProvider>(context, listen: false).items;
            _isLoading = false;
          });
        });
      } else {
        List<Map<String, dynamic>> offlineBusinessTypes = await DBSqliteHelper().getBusinessTypesByEmpStatus(status);
        setState(() {
          _businessTypes = List<Map<String, dynamic>>.from(offlineBusinessTypes);
          _isLoading = false;
        });
      }
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _getJobCategoriesWithType(int? busTypeId, int? empStatus) async {
    setState(() {
      _isLoading = true;
      _jobCategoryIdSelected = null;
    });

    try {
      if (widget.connectionType == 'online') {
        await Provider.of<JobCategoryProvider>(context, listen: false).getAllByEmpStatus(busTypeId, empStatus).then((value) {
          setState(() {
            _jobCategories = Provider.of<JobCategoryProvider>(context, listen: false).items;
            _isLoading = false;
          });
        });
      } else {
        List<Map<String, dynamic>> offlineJobCategories = await DBSqliteHelper().getJobCategoriesByEmpStatus(busTypeId, empStatus);
        setState(() {
          _jobCategories = List<Map<String, dynamic>>.from(offlineJobCategories);
          _isLoading = false;
        });
      }
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _getCustIncomeSource(int? customerId, int? incomeSourceId) async {
    setState(() {
      _isLoading = true;
    });

    try {
      if (widget.connectionType == 'online') {
        await Provider.of<CustomerIncomeSourceProvider>(context, listen: false).getRecord(customerId, incomeSourceId).then((value) {
          setState(() {
            _incomeSource = Provider.of<CustomerIncomeSourceProvider>(context, listen: false).item;
            _isLoading = false;
          });
        });
      } else {
        Map<String, dynamic>? offlineIncomeSource = await DBSqliteHelper().getCustomerIncomeSource(incomeSourceId);
        setState(() {
          _incomeSource = Map<String, dynamic>.from(offlineIncomeSource!);
          _isLoading = false;
        });
      }
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  void _clearAllFields() {
    _initData();
  }

  void _saveIncomeSource() {
    print('_formData: $_formData');
    if (!_formKey.currentState!.validate()) {
      // Invalid!
      return;
    }
    _formKey.currentState!.save();
    if (widget.incomeSourceId == null) {
      showConfirmation(
          context: context,
          message: "Are you sure you want to create new income source?",
          onYes: () async {
            String? _message = 'Something went wrong.';
            await showWaitingModal(
                context: context,
                message: "New income source is creating...",
                onWaiting: () async {
                  try {
                    Map<String, dynamic> recIncomeSource = {
                      'customerId': widget.customerId,
                      'selfemployed': _formData['selfemployed'],
                      'businessTypeId': _formData['businessTypeId'],
                      'jobCategoryId': _formData['jobCategoryId'],
                      'workplaceName': _selfEmployedSelected == 2 ? null : _formData['workplaceName'],
                      'workplaceFixedTel': _selfEmployedSelected == 2 ? null : _formData['workplaceFixedTel'],
                      'workplaceAddress': _selfEmployedSelected == 2 ? null : _formData['workplaceAddress'],
                      'incomePeriodicity': _formData['incomePeriodicity'],
                      'incomeAmount': int.parse(_incomeAmountController.text.trim().trim().replaceAll(",", "")),
                      'incomeSourceRemark': _formData['incomeSourceRemark'],
                      'exclusionList': _formData['exclusionList'],
                      'exclusionListRemark': _formData['exclusionListRemark'],
                      'callAvailableDuringOfficeHour': _formData['businessTypeId'] == 15 && _selfEmployedSelected == 0 ? _officeHourSelected : null,
                      'callAvailableTime': _officeHourSelected == 0 ? _timeShiftSelected : null,
                    };

                    if (widget.connectionType == 'online') {
                      await Provider.of<CustomerIncomeSourceProvider>(context, listen: false).createRecord(widget.customerId, recIncomeSource).then((value) {
                        _message = Provider.of<CustomerIncomeSourceProvider>(context, listen: false).responseMessage;
                      });
                    } else {
                      Map<String, dynamic> offlineIncomeSource = Map<String, dynamic>.from(recIncomeSource);
                      offlineIncomeSource.addAll({"personCreated": widget.userId});
                      offlineIncomeSource.addAll({"dtCreated": DateFormat("yyyy-MM-dd HH:mm:ss").format(DateTime.now())});
                      offlineIncomeSource.addAll({"personUpdated": widget.userId});
                      offlineIncomeSource.addAll({"dtUpdated": DateFormat("yyyy-MM-dd HH:mm:ss").format(DateTime.now())});

                      _message = 'New income source is successfully created.';
                      await DBSqliteHelper().createCustomerIncomeSource(CustomerIncomeSource.fromMap(offlineIncomeSource), widget.customerId);
                    }
                  } catch (error) {
                    _message = error.toString();
                  }
                });
            await showAlertModal(
                context: context,
                message: _message,
                onDismiss: () {
                  Navigator.pop(context);
                });
          });
    } else {
      // update //
      showConfirmation(
          context: context,
          message: "Are you sure you want to update the selected income source?",
          onYes: () async {
            String? _message = 'Something went wrong.';
            await showWaitingModal(
                context: context,
                message: "The selected income source is updating...",
                onWaiting: () async {
                  try {
                    Map<String, dynamic> recIncomeSource = {
                      'selfemployed': _formData['selfemployed'],
                      'businessTypeId': _formData['businessTypeId'],
                      'jobCategoryId': _formData['jobCategoryId'],
                      'workplaceName': _selfEmployedSelected == 2 ? null : _formData['workplaceName'],
                      'workplaceFixedTel': _selfEmployedSelected == 2 ? null : _formData['workplaceFixedTel'],
                      'workplaceAddress': _selfEmployedSelected == 2 ? null : _formData['workplaceAddress'],
                      'incomePeriodicity': _formData['incomePeriodicity'],
                      'incomeAmount': int.parse(_incomeAmountController.text.toString().trim().replaceAll(",", "")),
                      'incomeSourceRemark': _formData['incomeSourceRemark'],
                      'exclusionList': _formData['exclusionList'],
                      'exclusionListRemark': _formData['exclusionListRemark'],
                      'callAvailableDuringOfficeHour': _formData['businessTypeId'] == 15 && _selfEmployedSelected == 0 ? _officeHourSelected : null,
                      'callAvailableTime': _officeHourSelected == 0 ? _timeShiftSelected : null,
                    };

                    if (widget.connectionType == 'online') {
                      await Provider.of<CustomerIncomeSourceProvider>(context, listen: false).editRecord(widget.customerId, widget.incomeSourceId, recIncomeSource).then((value) {
                        _message = Provider.of<CustomerIncomeSourceProvider>(context, listen: false).responseMessage;
                      });
                    } else {
                      Map<String, dynamic> offlineIncomeSource = Map<String, dynamic>.from(recIncomeSource);

                      _message = 'The selected income source is successfully updated.';
                      await DBSqliteHelper().updateCustomerIncomeSource(offlineIncomeSource, widget.incomeSourceId);
                    }
                  } catch (error) {
                    _message = error.toString();
                  }
                });
            await showAlertModal(
                context: context,
                message: _message,
                onDismiss: () {
                  Navigator.pop(context);
                });
          });
    }
  }

  void _initData() async {
    if (widget.incomeSourceId != null) {
      await _getCustIncomeSource(widget.customerId, widget.incomeSourceId);
      if (_incomeSource != null) {
        setState(() {
          _selfEmployedSelected = _incomeSource!['selfemployed'];
        });
        await _getBusinessTypeByEmpStatus(_selfEmployedSelected);
        setState(() {
          _businessTypeIdSelected = _incomeSource!['businessTypeId'];
        });
        await _getJobCategoriesWithType(_businessTypeIdSelected, _selfEmployedSelected);
        setState(() {
          _jobCategoryIdSelected = _incomeSource!['jobCategoryId'];
        });
        _workplaceNameController.text = _incomeSource!['workplaceName'] ?? '';
        _workplaceFixedTelController.text = _incomeSource!['workplaceFixedTel'] ?? '';
        _workplaceAddressController.text = _incomeSource!['workplaceAddress'] ?? '';
        setState(() {
          _incomePeriodicitySelected = _incomeSource!['incomePeriodicity'];
          _exclusionListSelected = _incomeSource!['exclusionList'];
          _officeHourSelected = _incomeSource!['callAvailableDuringOfficeHour'];
          _timeShiftSelected = _incomeSource!['callAvailableTime'];
        });
        _incomeAmountController.text = NumberFormat('#,###').format(_incomeSource!['incomeAmount']);
        _incomeSourceRemarkController.text = _incomeSource!['incomeSourceRemark'] ?? '';
        _exclusionListRemarkController.text = _incomeSource!['exclusionListRemark'] ?? '';

        _formDataDefault = Map<String, dynamic>.from(_incomeSource!);
        _formData = Map<String, dynamic>.from(_formDataDefault);
      }
    } else {
      setState(() {
        _selfEmployedSelected = 0;
      });
      await _getBusinessTypeByEmpStatus(_selfEmployedSelected);
      setState(() {
        _businessTypeIdSelected = null;
      });
      setState(() {
        _jobCategoryIdSelected = null;
      });
      _workplaceNameController.text = "";
      _workplaceFixedTelController.text = "";
      _workplaceAddressController.text = "";
      setState(() {
        _incomePeriodicitySelected = null;
        _exclusionListSelected = 0;
      });
      _incomeAmountController.text = "";
      _incomeSourceRemarkController.text = "";
      _exclusionListRemarkController.text = "";

      _formData = Map<String, dynamic>.from(_formDataDefault);
    }
  }

  @override
  void initState() {
    _initData();
    super.initState();
  }

  @override
  void dispose() {
    // workplaceName //
    _workplaceNameFocusNode.dispose();

    // workplaceFixedTel //
    _workplaceFixedTelFocusNode.dispose();

    // workplaceAddress //
    _workplaceAddressFocusNode.dispose();

    // incomeAmount //
    _incomeAmountFocusNode.dispose();

    // incomeSourceRemark //
    _incomeSourceRemarkFocusNode.dispose();

    // exclusionListRemark //
    _exclusionListRemarkFocusNode.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var _deviceSize = MediaQuery.of(context).size;
    // Business Type //
    Widget _buildBusinessTypeDropdownButton() {
      return DropdownButtonFormField<int>(
        isExpanded: true,
        dropdownColor: Colors.white,
        decoration: InputDecoration(
          contentPadding: EdgeInsets.fromLTRB(15, 13, 12, 13),
          labelText: "Sector",
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
          ),
        ),
        items: _businessTypes.map((item) {
          return DropdownMenuItem<int>(
            value: item["businessTypeId"],
            child: Container(
              // width: _deviceSize.width - 60,
              child: Text(
                item["businessTypeName"],
                overflow: TextOverflow.ellipsis,
              ),
            ),
          );
        }).toList(),
        value: _businessTypeIdSelected ?? null,
        onChanged: (newValue) {
          setState(() {
            _businessTypeIdSelected = newValue;
            _formData['businessTypeId'] = newValue;
            _officeHourSelected = 1;
          });
          _getJobCategoriesWithType(_businessTypeIdSelected, _selfEmployedSelected);
        },
        validator: (value) {
          if (_businessTypeIdSelected == null) {
            return "Sector is required.";
          }
          return null;
        },
        onSaved: (newValue) {
          _formData['businessTypeId'] = newValue;
        },
      );
    }

    // Job Category //
    Widget _buildJobCategoryDropdownButton() {
      return DropdownButtonFormField<int>(
        isExpanded: true,
        dropdownColor: Colors.white,
        decoration: InputDecoration(
          contentPadding: EdgeInsets.fromLTRB(15, 13, 12, 13),
          labelText: "Job Category",
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
          ),
        ),
        items: _jobCategories.map((item) {
          return DropdownMenuItem<int>(
            value: item["jobCategoryId"],
            child: Container(
              child: Text(
                item["jobCategoryName"],
                overflow: TextOverflow.ellipsis,
              ),
            ),
          );
        }).toList(),
        value: _jobCategoryIdSelected ?? null,
        onChanged: (newValue) {
          setState(() {
            _jobCategoryIdSelected = newValue;
            _formData['jobCategoryId'] = newValue;
          });
        },
        validator: (value) {
          if (_jobCategoryIdSelected == null) {
            return "Sector is required.";
          }
          return null;
        },
        onSaved: (newValue) {
          _formData['jobCategoryId'] = newValue;
        },
      );
    }

    // Income Periodicity //
    Widget _buildIncomePeriodicityDropdownButton() {
      return DropdownButtonFormField<int>(
        isExpanded: true,
        dropdownColor: Colors.white,
        decoration: InputDecoration(
          contentPadding: EdgeInsets.fromLTRB(15, 13, 12, 13),
          labelText: "Income Periodicity",
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
          ),
        ),
        items: incomePeriodicities.map((item) {
          return DropdownMenuItem<int>(
            value: item["id"] as int?,
            child: Container(
              child: Text(
                item["title"] as String,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          );
        }).toList(),
        value: _incomePeriodicitySelected ?? null,
        onChanged: (newValue) {
          setState(() {
            _incomePeriodicitySelected = newValue;
            _formData['incomePeriodicity'] = newValue;
          });
        },
        validator: (value) {
          if (_incomePeriodicitySelected == null) {
            return "Sector is required.";
          }
          return null;
        },
        onSaved: (newValue) {
          _formData['incomePeriodicity'] = newValue;
        },
      );
    }

    // Available Time //
    Widget _buildAvailableTimeDropdownButton() {
      return DropdownButtonFormField<String>(
        isExpanded: true,
        dropdownColor: Colors.white,
        decoration: InputDecoration(
          contentPadding: EdgeInsets.fromLTRB(15, 13, 12, 13),
          labelText: "Available Time",
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
          ),
        ),
        items: _timeShifts.map((item) {
          return DropdownMenuItem<String>(
            value: item["id"] as String,
            child: Container(
              child: Text(
                item["title"] as String,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          );
        }).toList(),
        value: _timeShiftSelected,
        onChanged: (newValue) {
          setState(() {
            _timeShiftSelected = newValue;
            _formData['callAvailableTime'] = newValue;
          });
        },
        validator: (value) {
          if (_officeHourSelected == 0 && _timeShiftSelected == null) {
            return "Available Time is required.";
          }
          return null;
        },
        onSaved: (newValue) {
          _formData['callAvailableTime'] = newValue;
        },
      );
    }

    // Income Amount //
    var _incomeAmountFormField = TextFormField(
      textInputAction: TextInputAction.next,
      controller: _incomeAmountController,
      focusNode: _incomeAmountFocusNode,
      onFieldSubmitted: (value) {
        FocusScope.of(context).requestFocus(_incomeSourceRemarkFocusNode);
      },
      decoration: InputDecoration(
        contentPadding: EdgeInsets.all(15),
        labelText: "Income Amount",
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.grey, width: 1),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.grey, width: 1),
        ),
        border: OutlineInputBorder(
          borderSide: BorderSide(color: Theme.of(context).primaryColor, width: 1),
        ),
        suffixIcon: IconButton(
          icon: Icon(Icons.clear),
          onPressed: () => _incomeAmountController.clear(),
        ),
      ),
      keyboardType: TextInputType.numberWithOptions(signed: true, decimal: true),
      inputFormatters: [
        ThousandsFormatter(),
      ],
      validator: (value) {
        if (value!.isEmpty) {
          return "This field is required.";
        }
        if (int.parse(value.replaceAll(',', '')) == 0) {
          return "Amount must be greater than 0.";
        }
        return null;
      },
      onSaved: (String? value) {
        setState(() {
          _formData['incomeAmount'] = value;
        });
      },
    );

    return ModalProgressHUD(
      inAsyncCall: _isLoading,
      opacity: 0.5,
      progressIndicator: CircularProgressIndicator(
        valueColor: new AlwaysStoppedAnimation<Color>(
          context.getColorScheme().primary,
        ),
      ),
      child: Container(
        child: DraggableScrollableSheet(
            initialChildSize: 0.95,
            //set this as you want
            maxChildSize: 0.95,
            //set this as you want
            minChildSize: 0.95,
            //set this as you want
            expand: true,
            builder: (context, scrollController) {
              return ClipRRect(
                borderRadius: BorderRadius.only(topLeft: Radius.circular(20.0), topRight: Radius.circular(20.0)),
                child: Container(
                  padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
                  color: Colors.white,
                  child: Column(children: [
                    Container(
                      color: Colors.teal,
                      child: Stack(children: [
                        Container(
                          width: double.infinity,
                          height: 50.0,
                          child: Center(
                            child: Text(
                              "${widget.incomeSourceId == null ? 'CREATE' : 'EDIT'} INCOME SOURCE",
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white),
                            ), // Your desired title
                          ),
                        ),
                        Positioned(
                          left: 0.0,
                          top: 0.0,
                          child: IconButton(
                            icon: Icon(
                              Icons.arrow_back,
                              color: Colors.white,
                            ), // Your desired icon
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          ),
                        ),
                      ]),
                    ),
                    Expanded(
                      child: Container(
                        padding: EdgeInsets.fromLTRB(15, 5, 15, 10),
                        child: Form(
                          key: _formKey,
                          autovalidateMode: AutovalidateMode.always,
                          child: SingleChildScrollView(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  height: 10,
                                ),

                                // CARD Type //
                                Container(
                                  width: _deviceSize.width,
                                  padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
                                  decoration: BoxDecoration(
                                    border: Border.all(color: Colors.grey),
                                    borderRadius: BorderRadius.circular(5),
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      SizedBox(
                                        height: 5,
                                      ),

                                      // Card Type //
                                      Text(
                                        "CARD Type",
                                        textAlign: TextAlign.left,
                                      ),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: <Widget>[
                                          new Radio(
                                            value: 2,
                                            groupValue: _selfEmployedSelected,
                                            onChanged: _onChangeEmploymentStatusSelection,
                                          ),
                                          new InkWell(
                                            child: Text(
                                              'No job / Un-employed',
                                              style: new TextStyle(fontSize: 16.0),
                                            ),
                                            onTap: () {
                                              _onChangeEmploymentStatusSelection(2);
                                            },
                                          ),
                                        ],
                                      ),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: [
                                          new Radio(
                                            value: 1,
                                            groupValue: _selfEmployedSelected,
                                            onChanged: _onChangeEmploymentStatusSelection,
                                          ),
                                          new InkWell(
                                            child: new Text(
                                              'Self-employed',
                                              style: new TextStyle(
                                                fontSize: 16.0,
                                              ),
                                            ),
                                            onTap: () {
                                              _onChangeEmploymentStatusSelection(1);
                                            },
                                          ),
                                        ],
                                      ),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: [
                                          new Radio(
                                            value: 0,
                                            groupValue: _selfEmployedSelected,
                                            onChanged: _onChangeEmploymentStatusSelection,
                                          ),
                                          new InkWell(
                                            child: Text(
                                              'Employed',
                                              style: new TextStyle(fontSize: 16.0),
                                            ),
                                            onTap: () {
                                              _onChangeEmploymentStatusSelection(0);
                                            },
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  height: 10,
                                ),

                                // Business Type //
                                _buildBusinessTypeDropdownButton(),
                                SizedBox(
                                  height: 10,
                                ),

                                // Job Category //
                                _buildJobCategoryDropdownButton(),
                                SizedBox(
                                  height: 10,
                                ),

                                // CALL AVAILABLE DURING OFFICE HOUR //
                                _businessTypeIdSelected == 15 && _selfEmployedSelected == 0
                                    ? Column(children: [
                                        Container(
                                          width: _deviceSize.width,
                                          padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
                                          decoration: BoxDecoration(
                                            border: Border.all(color: Colors.grey),
                                            borderRadius: BorderRadius.circular(5),
                                          ),
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              SizedBox(
                                                height: 5,
                                              ),

                                              // CALL AVAILABLE DURING OFFICE HOUR //
                                              Text(
                                                "Call Available During Office Hour",
                                                textAlign: TextAlign.left,
                                              ),
                                              Row(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                children: [
                                                  Row(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    children: <Widget>[
                                                      new Radio(
                                                        value: 1,
                                                        groupValue: _officeHourSelected,
                                                        onChanged: _onChangeOfficeHourSelection,
                                                      ),
                                                      new InkWell(
                                                        child: Text(
                                                          'YES',
                                                          style: new TextStyle(fontSize: 16.0),
                                                        ),
                                                        onTap: () {
                                                          _onChangeOfficeHourSelection(1);
                                                        },
                                                      ),
                                                    ],
                                                  ),
                                                  Row(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    children: [
                                                      new Radio(value: 0, groupValue: _officeHourSelected, onChanged: _onChangeOfficeHourSelection),
                                                      new InkWell(
                                                        child: new Text(
                                                          'NO',
                                                          style: new TextStyle(
                                                            fontSize: 16.0,
                                                          ),
                                                        ),
                                                        onTap: () {
                                                          _onChangeOfficeHourSelection(0);
                                                        },
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(height: 15),
                                      ])
                                    : SizedBox(),

                                // AvailableTime //
                                _officeHourSelected == 0
                                    ? Column(
                                        children: [
                                          _buildAvailableTimeDropdownButton(),
                                          SizedBox(
                                            height: 10,
                                          ),
                                        ],
                                      )
                                    : SizedBox(),

                                // workplaceName //
                                _selfEmployedSelected == 2
                                    ? SizedBox()
                                    : TextFormInput(
                                        controller: _workplaceNameController,
                                        focusNode: _workplaceNameFocusNode,
                                        label: "Company/Employer Name",
                                        nextFocusNode: _workplaceFixedTelFocusNode,
                                        textInputAction: TextInputAction.next,
                                        isRequired: _selfEmployedSelected == 0 ? true : false,
                                        requiredMessage: "This field is required.",
                                        onSaved: _setWorkplaceName,
                                        maxLines: 2,
                                      ),
                                _selfEmployedSelected == 2
                                    ? SizedBox()
                                    : SizedBox(
                                        height: 10,
                                      ),

                                // workplaceFixedTel //
                                _selfEmployedSelected == 2
                                    ? SizedBox()
                                    : TextFormInput(
                                        controller: _workplaceFixedTelController,
                                        focusNode: _workplaceFixedTelFocusNode,
                                        label: "Fixed Telephone",
                                        nextFocusNode: _workplaceAddressFocusNode,
                                        textInputAction: TextInputAction.next,
                                        keyboardType: TextInputType.number,
                                        isRequired: false,
                                        onSaved: _setWorkplaceFixedTel,
                                      ),
                                _selfEmployedSelected == 2
                                    ? SizedBox()
                                    : SizedBox(
                                        height: 10,
                                      ),

                                // workplaceAddress //
                                _selfEmployedSelected == 2
                                    ? SizedBox()
                                    : TextFormInput(
                                        controller: _workplaceAddressController,
                                        focusNode: _workplaceAddressFocusNode,
                                        label: "Company/Employer Address",
                                        textInputAction: TextInputAction.done,
                                        isRequired: false,
                                        maxLines: 2,
                                        onSaved: _setWorkplaceAddress,
                                      ),
                                _selfEmployedSelected == 2
                                    ? SizedBox()
                                    : SizedBox(
                                        height: 10,
                                      ),

                                // incomePeriodicity //
                                _buildIncomePeriodicityDropdownButton(),
                                SizedBox(
                                  height: 10,
                                ),

                                // incomeAmount //
                                _incomeAmountFormField,
                                SizedBox(
                                  height: 10,
                                ),

                                // incomeSourceRemark //
                                TextFormInput(
                                  controller: _incomeSourceRemarkController,
                                  focusNode: _incomeSourceRemarkFocusNode,
                                  label: "Remark",
                                  textInputAction: TextInputAction.done,
                                  isRequired: false,
                                  onSaved: _setIncomeSourceRemark,
                                  maxLines: 2,
                                ),
                                SizedBox(
                                  height: 10,
                                ),

                                // exclusionList //
                                Container(
                                  padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
                                  decoration: BoxDecoration(
                                    border: Border.all(color: Colors.grey),
                                    borderRadius: BorderRadius.circular(5),
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      SizedBox(
                                        height: 5,
                                      ),
                                      Text(
                                        "Exclusion List",
                                        textAlign: TextAlign.left,
                                      ),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: <Widget>[
                                          new Radio(
                                            value: 1,
                                            groupValue: _exclusionListSelected,
                                            onChanged: _onChangeExclusionListSelection,
                                          ),
                                          new InkWell(
                                            child: Text(
                                              'YES',
                                              style: new TextStyle(fontSize: 16.0),
                                            ),
                                            onTap: () {
                                              _onChangeExclusionListSelection(1);
                                            },
                                          ),
                                          new Radio(
                                            value: 0,
                                            groupValue: _exclusionListSelected,
                                            onChanged: _onChangeExclusionListSelection,
                                          ),
                                          new InkWell(
                                            child: new Text(
                                              'NO',
                                              style: new TextStyle(
                                                fontSize: 16.0,
                                              ),
                                            ),
                                            onTap: () {
                                              _onChangeExclusionListSelection(0);
                                            },
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  height: 10,
                                ),

                                // exclusionListRemark //
                                TextFormInput(
                                  controller: _exclusionListRemarkController,
                                  focusNode: _exclusionListRemarkFocusNode,
                                  label: "Exclusion List Remark",
                                  textInputAction: TextInputAction.done,
                                  isRequired: false,
                                  onSaved: _setExclusionListRemark,
                                  maxLines: 2,
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    Divider(
                      color: Colors.teal,
                      height: 0,
                      thickness: 1.0,
                    ),
                    Container(
                      color: Colors.white,
                      child: Padding(
                        padding: const EdgeInsets.all(10),
                        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
                          Expanded(
                            child: ButtonWidget(
                              text: "CLEAR",
                              isWhiteBackgroundColor: true,
                              onPressed: _clearAllFields,
                            ),
                          ),
                          Expanded(
                            child: ButtonWidget(
                              text: "SAVE",
                              isWhiteBackgroundColor: false,
                              onPressed: _saveIncomeSource,
                            ),
                          ),
                        ]),
                      ),
                    ),
                  ]),
                ),
              );
            }),
      ),
    );
  }
}
