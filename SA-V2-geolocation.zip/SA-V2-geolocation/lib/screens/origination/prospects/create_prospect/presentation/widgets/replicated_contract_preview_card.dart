import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/models/replicated_contract.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/widgets/data_row.dart';
import 'package:sales/widgets/preview_card.dart';

import '../notifiers/viewmodel/prospect_view_model.dart';

class ReplicatedContractPreviewCard extends StatelessWidget {
  const ReplicatedContractPreviewCard({super.key, required this.data});

  final ReplicatedContract data;

  @override
  Widget build(BuildContext context) {
    return PreviewCard(
      suffixIcon: const Icon(CupertinoIcons.delete, color: Colors.red),
      onIconButtonTapped: () {
        context.read<ProspectViewModel>().clearContract();
      },
      primaryLabel: 'Contract',
      primaryContent: Text(data.contract?.number ?? ''),
      children: [
        DataRowWidget(
          label: 'Contract Type',
          value: data.contract?.type ?? '',
        ),
        kSpaceVertical10,
        DataRowWidget(
          label: 'Contract Status',
          value: data.contract?.statusName ?? '',
        ),
        kSpaceVertical10,
        if (data.contract?.contractDate != null) ...[
          DataRowWidget(
            label: 'Contract Date',
            value: data.contractDateText,
          ),
          kSpaceVertical10,
        ],
        if (data.contract?.expiryDate != null) ...[
          DataRowWidget(
            label: 'Expired Date',
            value: data.expiryDateText,
          ),
          kSpaceVertical10,
        ],
        if (data.contract?.terminationDate != null) ...[
          DataRowWidget(
            label: 'Terminated Date',
            value: data.terminationDateText,
          ),
          kSpaceVertical10,
        ],
        kSpaceVertical10,
        ProductCard(data: data),
        if (!(data.canDuplicated ?? false)) ...[
          Text(
            data.duplicatedReason ?? '',
            style: const TextStyle(
              fontSize: 12,
              color: Colors.red,
            ),
          )
        ],
      ],
    );
  }
}

class ProductCard extends StatelessWidget {
  const ProductCard({super.key, required this.data});

  final ReplicatedContract? data;

  @override
  Widget build(BuildContext context) {
    return PreviewCard(
      primaryLabel: 'Product Info',
      primaryContent: Text(data?.product?.name ?? ''),
      primaryLabelStyle: const TextStyle(fontSize: 14),
      isViewCard: false,
      children: [
        DataRowWidget(
          label: 'Product Category',
          value: data?.product?.categoryName ?? '',
        ),
        kSpaceVertical10,
        DataRowWidget(
          label: 'Product Price',
          value: data?.priceText,
        ),
        kSpaceVertical10,
        DataRowWidget(
          label: 'Amount Financed',
          value: data?.amountFinancedText,
        ),
        kSpaceVertical10,
        DataRowWidget(label: 'Tenure', value: data?.durationText),
        kSpaceVertical10,
        DataRowWidget(
          label: 'Installment Payment',
          value: data?.installmentText,
        ),
        kSpaceVertical10,
        Text(
          data?.customerFullName ?? '',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontWeight: FontWeight.w600,
            color: context.getColorScheme().secondary,
            fontSize: 16,
          ),
        ),
        kSpaceVertical10,
      ],
    );
  }
}
