import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:sales/models/models.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/form_card.dart';
import 'package:sales/widgets/search_text_field.dart';
import 'package:sales/widgets/selected_field/selected_field.dart';
import 'package:sales/widgets/text_form_field/clearable_text_form_field.dart';
import 'package:sales/widgets/text_form_field/phone_text_form_field.dart';
import 'package:sales/widgets/text_form_field/text_area_field.dart';

import '../notifiers/form/prospect_form_notifier.dart';
import '../notifiers/viewmodel/prospect_view_model.dart';

class ProspectFromInputs extends StatelessWidget {
  const ProspectFromInputs({
    Key? key,
    required GlobalKey<FormState> formKey,
    required AutovalidateMode mode,
  })  : _formKey = formKey,
        _mode = mode,
        super(key: key);

  final GlobalKey<FormState> _formKey;
  final AutovalidateMode _mode;

  @override
  Widget build(BuildContext context) {
    final state = context.watch<ProspectFormNotifier>().state;

    return Form(
      key: _formKey,
      autovalidateMode: _mode,
      child: FormCard(
        title: 'PROSPECT',
        content: Column(
          children: [
            ClearableTextFormField(
              initialValue: state.name,
              labelText: 'Prospect Name',
              required: true,
              prefixIcon: const Icon(Icons.person_rounded),
              inputFormatters: [FilteringTextInputFormatter.allow(RegExp("[a-zA-Z ]"))],
              textCapitalization: TextCapitalization.words,
              onChanged: (name) {
                context.read<ProspectFormNotifier>().updateName(name);
              },
            ),
            kSpaceVertical8,
            SelectedField<GenderType>(
              title: "Gender Status",
              required: true,
              items: GenderType.values,
              labelParser: (item) => item.name,
              selectedItem: state.gender,
              onSelected: (type) {
                context.read<ProspectFormNotifier>().updateGenderType(type);
              },
            ),
            kSpaceVertical8,
            PhoneTextFormField(
              initialValue: state.mobile,
              labelText: 'Mobile 1',
              required: true,
              onChanged: (number) {
                context.read<ProspectFormNotifier>().updateMobileNo(number);
              },
            ),
            kSpaceVertical8,
            PhoneTextFormField(
              initialValue: state.otherMobile,
              labelText: 'Mobile 2',
              onChanged: (number) {
                context.read<ProspectFormNotifier>().updateOtherMobileNo(number);
              },
            ),
            kSpaceVertical8,
            TextAreaField(
              initialValue: state.remark,
              labelText: 'Remark',
              onChanged: (remark) {
                context.read<ProspectFormNotifier>().updateRemark(remark);
              },
            ),
            kSpaceVertical8,
            if (state.isNewProspect) ...[
              SearchTextField(
                initialValue: state.contractSequence,
                labelText: 'Contract Sequence....',
                maxLength: 6,
                keyboardType: TextInputType.number,
                onSubmitted: (value) {
                  context.read<ProspectViewModel>().searchContract(value);
                },
                onChanged: (value) {
                  context.read<ProspectFormNotifier>().updateContractSequence(value);
                },
              )
            ],
          ],
        ),
      ),
    );
  }
}
