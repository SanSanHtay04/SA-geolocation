import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/app_snack_bar.dart';
import 'package:sales/widgets/copyright_notice.dart';
import 'package:sales/widgets/save_button.dart';
import '../notifiers/form/prospect_form_notifier.dart';
import '../notifiers/viewmodel/prospect_view_model.dart';
import 'prospect_form_inputs.dart';
import 'replicated_contract_preview_card.dart';

class ProspectForm extends StatefulWidget {
  const ProspectForm({super.key, required this.vm});

  final ProspectViewModel vm;

  @override
  State<ProspectForm> createState() => _ProspectFormState();
}

class _ProspectFormState extends State<ProspectForm> {
  final _formKey = GlobalKey<FormState>();
  AutovalidateMode _mode = AutovalidateMode.disabled;

  onButtonPressed() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_formKey.currentState?.validate() ?? false) {
        FocusScope.of(context).unfocus();
        final formState = context.read<ProspectFormNotifier>().state;

        context.showConfirmDialog(
          title: formState.titleText,
          message: formState.descriptionText,
          onConfirmPressed: () => widget.vm.submit(formState),
        );
      } else {
        setState(() {
          _mode = AutovalidateMode.onUserInteraction;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Flexible(
          child: ListView(
            children: [
              ProspectFromInputs(formKey: _formKey, mode: _mode),
              kSpaceVertical8,
              if (widget.vm.contract != null) ReplicatedContractPreviewCard(data: widget.vm.contract!),
            ],
          ),
        ),
        kSpaceVertical8,
        SaveButton(onPressed: onButtonPressed),
        CopyrightNotice(),
      ],
    );
  }
}
