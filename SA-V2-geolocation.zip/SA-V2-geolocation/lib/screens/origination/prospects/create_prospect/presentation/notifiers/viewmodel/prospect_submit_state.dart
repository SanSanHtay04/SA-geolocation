import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/base/error.dart';

part 'prospect_submit_state.freezed.dart';

@freezed
class ProspectSubmitState with _$ProspectSubmitState {
  const factory ProspectSubmitState.initial() = ProspectSubmitStateInitial;

  const factory ProspectSubmitState.loading() = ProspectSubmitStateLoading;

  const factory ProspectSubmitState.failed(String message, {AppError? error}) = ProspectSubmitStateFailed;

  const factory ProspectSubmitState.success(String message) = ProspectSubmitStateSuccess;
}
