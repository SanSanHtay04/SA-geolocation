import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/base/error.dart';
import 'package:sales/data/repositories/repositories.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/app_snack_bar.dart';
import 'package:sales/widgets/simple_toolbar.dart';
import 'package:sales/widgets/work_layout.dart';
import 'notifiers/form/prospect_form_notifier.dart';
import 'notifiers/viewmodel/prospect_view_model.dart';
import 'widgets/prospect_form.dart';

class ProspectScreen extends StatefulWidget {
 static const routeName = '/edit-prospect';

  ProspectScreen({
    super.key,
    required this.posId,
    required this.prospectId,
  });

  final int? posId;

  /// prospectId can be empty value for creating new prospect
  final int? prospectId;

  static Widget create({int? prospectId, int? posId}) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) => ProspectViewModel(
            repo: ProspectRepository(context.read()),
            contractRepo: ContractRepository(context.read()),
          )..getProspect(prospectId, posId),
        ),
        ChangeNotifierProvider(create: (context) => ProspectFormNotifier()),
      ],
      child: ProspectScreen(prospectId: prospectId, posId: posId),
    );
  }

  @override
  _ProspectScreenState createState() => _ProspectScreenState();
}

class _ProspectScreenState extends State<ProspectScreen> {
  @override
  Widget build(BuildContext context) {
    return Consumer<ProspectViewModel>(
      builder: (_, vm, __) {
        Future.delayed(Duration.zero, (() {
          vm.state.maybeWhen(
            initial: (prospect, _) => context.read<ProspectFormNotifier>().loadData(prospect),
            failed: (message, error) => context.showErrorDialog(
              error.errorMessage(context, message),
              onClosePressed: () {},
            ),
            orElse: () {},
          );
        }));

        Future.delayed(Duration.zero, (() {
          vm.submitState.maybeWhen(
            success: (msg) => context.showMessageDialog(
              message: msg,
              onClosePressed: () => Navigator.pop(context),
            ),
            failed: (message, error) => context.showErrorDialog(
              error.errorMessage(context, message),
              onClosePressed: () => vm.resetSubmitState(),
            ),
            orElse: () {},
          );
        }));

        return WorkLayout(
          appBar: SimpleToolbar(title: widget.prospectId == null ? 'Create Prospect' : 'Edit Prospect'),
          isBusy: vm.isLoading,
          child: Padding(
            padding: kPadding8,
            child: ProspectForm(vm: vm),
          ),
        );
      },
    );
  }
}
