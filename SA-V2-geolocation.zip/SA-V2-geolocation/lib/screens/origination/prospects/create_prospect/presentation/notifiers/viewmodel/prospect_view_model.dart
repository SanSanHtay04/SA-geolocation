import 'package:flutter/foundation.dart';
import 'package:sales/data/repositories/repositories.dart';
import 'package:sales/models/models.dart';
import 'package:sales/models/replicated_contract.dart';

import '../form/prospect_form_state.dart';
import 'prospect_data_state.dart';
import 'prospect_submit_state.dart';

class ProspectViewModel extends ChangeNotifier {
  final ProspectRepository repo;
  final ContractRepository contractRepo;

  ProspectViewModel({required this.repo, required this.contractRepo});

  ProspectDataState state = ProspectDataState.initial();
  ProspectSubmitState submitState = const ProspectSubmitState.initial();

  bool get isLoading => (state is ProspectDataStateLoading) || (submitState is ProspectSubmitStateLoading);

  ProspectDataStateInitial? get _data => (state is ProspectDataStateInitial) ? (state as ProspectDataStateInitial) : null;
  Prospect? get prospect => _data?.prospect ?? null;
  ReplicatedContract? get contract => _data?.contract ?? null;

  setDataState(ProspectDataState data) {
    state = data;
    notifyListeners();
  }

  clearContract() => setDataState(ProspectDataState.initial(prospect: prospect));

  getProspect(int? prospectId, int? posId) async {
    // If new prospect, do not need to get the prospect information
    if (prospectId == null) {
      setDataState(ProspectDataState.initial(prospect: Prospect(posId: posId)));
      return;
    }

    setDataState(const ProspectDataState.loading());
    final res = await repo.getProspect(prospectId);
    final newState = res.when(
      success: (data) => ProspectDataState.initial(prospect: data),
      failed: (message, error) => ProspectDataState.failed(message, error: error),
    );
    setDataState(newState);
  }

  searchContract(String? contractSequence) async {
    if (contractSequence == null || contractSequence.isEmpty) return;
    setDataState(const ProspectDataState.loading());
    final res = await contractRepo.getContract(contractSequence);
    final newState = res.when(
      success: (data) => ProspectDataState.initial(
        prospect: prospect,
        contract: data,
      ),
      failed: (message, error) => ProspectDataState.failed(
        message,
        error: error,
      ),
    );
    setDataState(newState);
  }

  setSubmitState(ProspectSubmitState data) {
    submitState = data;
    notifyListeners();
  }

  resetSubmitState() => setSubmitState(const ProspectSubmitState.initial());

  void submit(ProspectFormState data) {
    (data.isNewProspect) ? _create(data) : _edit(data);
  }

  _create(ProspectFormState data) async {
    setSubmitState(const ProspectSubmitState.loading());

    final res = (contract != null && contract!.canDuplicated)
        ? await repo.createProspect(
            data,
            contractId: contract?.contractId,
            customerId: contract?.customerId,
            applicationId: contract?.applicationId,
          )
        : await repo.createProspect(data);

    final newState = res.when(
      success: (data) => ProspectSubmitState.success(data),
      failed: (message, error) => ProspectSubmitState.failed(message, error: error),
    );
    setSubmitState(newState);
  }

  _edit(ProspectFormState data) async {
    setSubmitState(const ProspectSubmitState.loading());
    final res = await repo.editProspect(data.prospectId!, data);
    final newState = res.when(
      success: (data) => ProspectSubmitState.success(data),
      failed: (message, error) => ProspectSubmitState.failed(message, error: error),
    );
    setSubmitState(newState);
  }
}
