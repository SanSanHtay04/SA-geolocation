import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/models/models.dart';

part 'prospect_form_state.freezed.dart';

@freezed
class ProspectFormState with _$ProspectFormState {
  const ProspectFormState._();

  const factory ProspectFormState({
    @Default(false) bool loaded,
    int? prospectId,
    int? posId,
    String? name,
    GenderType? gender,
    String? mobile,
    String? otherMobile,
    String? remark,
    String? contractSequence,
  }) = _ProspectFormState;

  String get titleText =>
      prospectId == null ? 'Create Prospect' : 'Edit Prospect';

  String get descriptionText => prospectId == null
      ? 'Are you sure you want to create new prospect?'
      : 'Are you sure you want to edit prospect information?';

  bool get isNewProspect => prospectId == null;
}
