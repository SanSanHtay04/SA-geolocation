import 'package:flutter/foundation.dart';
import 'package:sales/models/models.dart';
import 'prospect_form_state.dart';

class ProspectFormNotifier extends ChangeNotifier {
  ProspectFormState state = const ProspectFormState();

  void emit(ProspectFormState data) {
    state = data;
    notifyListeners();
  }

  void loadData(Prospect? prospect) {
    /// Need to add this line to make sure that prospect is loaded once
    if (prospect == null || state.loaded) return;
    emit(prospect.toDomain());
  }

  void updateName(String? name) => emit(state.copyWith(name: name));

  void updateGenderType(GenderType type) => emit(state.copyWith(gender: type));

  void updateMobileNo(String? mobile) => emit(state.copyWith(mobile: mobile));

  void updateOtherMobileNo(String? otherMobile) =>
      emit(state.copyWith(otherMobile: otherMobile));

  void updateRemark(String? remark) => emit(state.copyWith(remark: remark));

  void updateContractSequence(String? sequence) =>
      emit(state.copyWith(contractSequence: sequence));
}
