import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/base/error.dart';
import 'package:sales/models/models.dart';
import 'package:sales/models/replicated_contract.dart';

part 'prospect_data_state.freezed.dart';

@freezed
class ProspectDataState with _$ProspectDataState {
  const factory ProspectDataState.initial({
    Prospect? prospect,
    ReplicatedContract? contract,
  }) = ProspectDataStateInitial;

  const factory ProspectDataState.loading() = ProspectDataStateLoading;
  const factory ProspectDataState.failed(String msg, {AppError? error}) = ProspectDataStateFailed;
}
