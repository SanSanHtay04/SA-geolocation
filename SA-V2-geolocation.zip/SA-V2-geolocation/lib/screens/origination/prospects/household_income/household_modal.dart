import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:provider/provider.dart';
import 'package:sales/data/local/db_sqlite_helper.dart';
import 'package:sales/providers/providers.dart';
import 'package:sales/utils/utils.dart';

import 'package:sales/widgets/waiting_modal_bottom_widget.dart';
import '../../../../widgets/item_info_widget.dart';

class HouseholdModal extends StatefulWidget {
  final int? customerId;
  final int householdId;
  final String? connectionType;

  HouseholdModal({required this.customerId, required this.householdId, required this.connectionType});

  @override
  _HouseholdModalState createState() => _HouseholdModalState();
}

class _HouseholdModalState extends State<HouseholdModal> {
  bool _isLoading = false;
  Map<String, dynamic>? _custHousehold;

  Future<void> _getCustHousehold(int? customerId, int householdId) async {
    showWaitingModal(
        context: context,
        message: "Household income is loading...",
        onWaiting: () async {
          try {
            if (widget.connectionType == 'online') {
              await Provider.of<CustomerHouseholdProvider>(context, listen: false).getRecord(customerId, householdId).then((value) {
                setState(() {
                  _custHousehold = Provider.of<CustomerHouseholdProvider>(context, listen: false).item;
                });
              });
            } else {
              Map<String, dynamic>? offlineHousehold = await DBSqliteHelper().getHousehold(householdId);
              setState(() {
                _custHousehold = Map<String, dynamic>.from(offlineHousehold!);
              });
            }
          } catch (error) {
            print(error.toString());
          }
        });
  }

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      _getCustHousehold(widget.customerId, widget.householdId);
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var _deviceSize = MediaQuery.of(context).size;

    return ModalProgressHUD(
      inAsyncCall: _isLoading,
      opacity: 0.5,
      progressIndicator: CircularProgressIndicator(
        valueColor: new AlwaysStoppedAnimation<Color>(
          context.getColorScheme().primary,
        ),
      ),
      child: Container(
        child: DraggableScrollableSheet(
            initialChildSize: 0.95,
            //set this as you want
            maxChildSize: 0.95,
            //set this as you want
            minChildSize: 0.95,
            //set this as you want
            expand: true,
            builder: (context, scrollController) {
              return ClipRRect(
                borderRadius: BorderRadius.only(topLeft: Radius.circular(20.0), topRight: Radius.circular(20.0)),
                child: Container(
                  color: Colors.white,
                  child: Column(
                    children: [
                      Container(
                        color: Colors.teal,
                        child: Stack(children: [
                          Container(
                            width: double.infinity,
                            height: 50.0,
                            child: Center(
                              child: Text(
                                "HH INCOME",
                                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white),
                              ), // Your desired title
                            ),
                          ),
                          Positioned(
                            left: 0.0,
                            top: 0.0,
                            child: IconButton(
                              icon: Icon(
                                Icons.arrow_back,
                                color: Colors.white,
                              ), // Your desired icon
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                            ),
                          ),
                        ]),
                      ),
                      Expanded(
                        child: Container(
                          padding: EdgeInsets.fromLTRB(15, 5, 15, 10),
                          child: SingleChildScrollView(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  width: _deviceSize.width,
                                  child: _custHousehold != null
                                      ? SingleChildScrollView(
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              SizedBox(
                                                height: 5,
                                              ),
                                              Divider(
                                                height: 10,
                                                thickness: 0.5,
                                              ),

                                              // Employment Status //
                                              ItemInfoWidget(
                                                title: 'Member',
                                                value: _custHousehold!['householdName'],
                                              ),
                                              Divider(
                                                height: 10,
                                                thickness: 0.5,
                                              ),

                                              // householdMobileNo //
                                              ItemInfoWidget(
                                                title: 'Mobile',
                                                value: _custHousehold!['householdMobileNo'],
                                              ),
                                              Divider(
                                                height: 10,
                                                thickness: 0.5,
                                              ),

                                              // otherMobileNo //
                                              ItemInfoWidget(
                                                title: 'Other Mobile',
                                                value: _custHousehold!['otherMobileNo'] ?? '-/-',
                                              ),
                                              Divider(
                                                height: 10,
                                                thickness: 0.5,
                                              ),

                                              // natRegCardNo //
                                              ItemInfoWidget(
                                                title: 'NRC No.',
                                                value: _custHousehold!['natRegCardNo'] ?? '-/-',
                                              ),
                                              Divider(
                                                height: 10,
                                                thickness: 0.5,
                                              ),

                                              // natRegCardNo //
                                              ItemInfoWidget(
                                                title: "NRC's Issuance Date",
                                                value: _custHousehold!['natRegCardIssDate'] != null ? DateFormat('dd/MM/yyyy').format(_custHousehold!['natRegCardIssDate']) : '-/-',
                                              ),
                                              Divider(
                                                height: 10,
                                                thickness: 0.5,
                                              ),

                                              // incomeEarner //
                                              ItemInfoWidget(
                                                title: 'Income Earner',
                                                value: _custHousehold!['incomeEarner'] == 1 ? 'YES' : 'NO',
                                              ),
                                              Divider(
                                                height: 10,
                                                thickness: 0.5,
                                              ),

                                              // Income Periodicity //
                                              ItemInfoWidget(
                                                title: 'Income Periodicity',
                                                value: _custHousehold!['incomePeriodicity'] == 1 ? 'MONTHLY' : (_custHousehold!['incomePeriodicity'] == 3 ? 'QUARTERLY' : 'YEARLY'),
                                              ),
                                              Divider(
                                                height: 10,
                                                thickness: 0.5,
                                              ),

                                              // Income Amount //
                                              ItemInfoWidget(
                                                title: 'Income Amount',
                                                value: "${NumberFormat('#,###').format(_custHousehold!['incomeAmount'])} MMK",
                                              ),
                                              Divider(
                                                height: 10,
                                                thickness: 0.5,
                                              ),

                                              // householdRemark //
                                              ItemInfoWidget(
                                                title: 'Remark',
                                                value: _custHousehold!['householdRemark'] ?? '-/-',
                                              ),
                                              Divider(
                                                height: 10,
                                                thickness: 0.5,
                                              ),
                                            ],
                                          ),
                                        )
                                      : SizedBox(),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
      ),
    );
  }
}
