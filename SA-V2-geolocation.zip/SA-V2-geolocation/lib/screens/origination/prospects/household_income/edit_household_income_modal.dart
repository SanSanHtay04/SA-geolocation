import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:provider/provider.dart';
import 'package:sales/models/nrc_number_type.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/utils/logging.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/widgets/text_form_field/currency_text_form_field.dart';
import 'package:sales/widgets/text_form_field/date_picker_field.dart';
import 'package:sales/widgets/waiting_modal_bottom_widget.dart';

import '../../../../providers/customer_household_provider.dart';
import '../../../../providers/nrc1_provider.dart';
import '../../../../providers/nrc2_provider.dart';
import '../../../../widgets/confirmation_modal_bottom_widget.dart';
import '../../../../widgets/deprecated/alert_modal_bottom_widget.dart';
import '../../../../widgets/deprecated/button_widget.dart';
import '../../../../widgets/selected_field/selected_field.dart';
import '../../../../widgets/selected_group/single_selected_group.dart';
import '../../../../widgets/text_form_field/clearable_text_form_field.dart';
import '../../../../widgets/text_form_field/phone_text_form_field.dart';
import '../../../../widgets/text_form_field/text_area_field.dart';

class EditHouseholdIncomeModal extends StatefulWidget {
  final int? customerId;
  final int? householdId;
  final int? userId;
  final String? connectionType;

  EditHouseholdIncomeModal({required this.customerId, required this.householdId, required this.userId, required this.connectionType});

  @override
  _EditHouseholdIncomeModalState createState() => _EditHouseholdIncomeModalState();
}

class _EditHouseholdIncomeModalState extends State<EditHouseholdIncomeModal> {
  bool _isLoading = false;
  final GlobalKey<FormState> _formKey = GlobalKey();
  Map<String, dynamic> _formData = {};
  Map<String, dynamic> _formDataDefault = {
    'customerId': null,
    'householdName': null,
    'relationDetail': null,
    'householdMobileNo': null,
    'otherMobileNo': null,
    'incomeEarner': 1,
    'incomePeriodicity': 1,
    'incomeAmount': '0',
    'nrc2Id': null,
    'nrcType': 'N',
    'nonNrcPrefix': null,
    'nrcDetail': null,
    'natRegCardNo': null,
    'natRegCardIssDate': null,
    'householdRemark': null,
  };

  List<Map<String, dynamic>> incomePeriodicities = [
    {'id': 1, 'title': 'Monthly'},
    {'id': 3, 'title': 'Quarterly'},
    {'id': 12, 'title': 'Yearly'}
  ];

  // Domain Data
  Map<String, dynamic>? _household;
  List<Map<String, dynamic>> _nrc1s = [];
  List<Map<String, dynamic>> _nrc2s = [];

  // App-State Data
  NRCNumberType? _cardTypeSelected = NRCNumberType.nrc;
  String? _nrcTypeSelected = 'N';
  Map<String, dynamic>? _nrc1IdSelected;
  Map<String, dynamic>? _nrc2IdSelected;
  Map<String, dynamic>? _incomePeriodicitySelected;
  DateTime? _issuanceDateSelected = DateTime.now();

  void _setHouseHoldName(String? value) {
    setState(() {
      _formData['householdName'] = value;
    });
  }

  void _setHouseHoldRelationDetail(String? value) {
    setState(() {
      _formData['relationDetail'] = value;
    });
  }

  void _setHouseholdMobileNo(String? value) {
    setState(() {
      _formData['householdMobileNo'] = value;
    });
  }

  void _setOtherMobileNo(String? value) {
    setState(() {
      _formData['otherMobileNo'] = value;
    });
  }

  void _setNrcNumber(String? value) {
    setState(() {
      _formData['nrcDetail'] = value;
    });
  }

  void _setIssuanceDate(DateTime value) {
    setState(() {
      _formData['natRegCardIssDate'] = DateFormat('yyyy-MM-dd').format(value);
      _issuanceDateSelected = value;
    });
  }

  void _setNonNrcPrefix(String? value) {
    setState(() {
      _formData['nonNrcPrefix'] = value;
    });
  }

  void _setHouseholdRemark(String? value) {
    setState(() {
      _formData['householdRemark'] = value;
    });
  }

  void _onChangeCardTypeSelection(NRCNumberType? strCardType) {
    setState(() {
      _cardTypeSelected = strCardType;
      _formData['cardType'] = strCardType;
    });
  }

  void _onChangeNrcTypeSelection(String? strNrcType) {
    setState(() {
      _nrcTypeSelected = strNrcType;
      _formData['nrcType'] = strNrcType;
    });
  }

  Future<void> _getCustHousehold(int? customerId, int? householdId) async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<CustomerHouseholdProvider>(context, listen: false).getRecord(customerId, householdId).then((value) {
        setState(() {
          _household = Provider.of<CustomerHouseholdProvider>(context, listen: false).item;
        });
      });
    } catch (error) {
      print(error.toString());
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _getNrc1s() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<Nrc1Provider>(context, listen: false).getRecords().then((value) {
        setState(() {
          _nrc1s = Provider.of<Nrc1Provider>(context, listen: false).items;
        });
      });
    } catch (error) {
      print(error.toString());
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _getNrc2s(int? nrc1Id) async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<Nrc2Provider>(context, listen: false).getRecords(nrc1Id).then((value) {
        setState(() {
          _nrc2IdSelected = null;
          _nrc2s = Provider.of<Nrc2Provider>(context, listen: false).items;
        });
      });
    } catch (error) {
      print(error.toString());
    }

    setState(() {
      _isLoading = false;
    });
  }

  void _initData() async {
    if (widget.householdId != null) {
      await _getCustHousehold(widget.customerId, widget.householdId);
      if (_household != null) {
        await _getNrc1s();

        setState(() {
          _cardTypeSelected = _household!['natRegCardNo'] == null ? NRCNumberType.noNrc : (_household!['nrc2Id'] != null ? NRCNumberType.nrc : NRCNumberType.frc);

          _nrc1IdSelected = _household!['nrc1Id'] != null ? _nrc1s.firstWhere((element) => element['nrc1Id'] == _household!['nrc1Id']) : null;
        });

        if (_nrc1IdSelected != null) {
          await _getNrc2s(_nrc1IdSelected!['nrc1Id']);
        }

        setState(() {
          _nrc2IdSelected = _household!['nrc2Id'] != null ? _nrc2s.firstWhere((element) => element['nrc2Id'] == _household!['nrc2Id']) : null;

          _nrcTypeSelected = _household!['nrcType'];

          _issuanceDateSelected = _household!['natRegCardIssDate'] != null ? DateFormat('yyyy-MM-dd').parse(_household!['natRegCardIssDate']) : DateTime.now();

          _incomePeriodicitySelected = _household!['nrc2Id'] != null ? incomePeriodicities.firstWhere((element) => element['id'] == _household!['incomePeriodicity']) : incomePeriodicities.first;
        });

        _formDataDefault = Map<String, dynamic>.from(_household!);
        _formData = Map<String, dynamic>.from(_formDataDefault);
      }
    } else {
      await _getNrc1s();

      setState(() {
        _cardTypeSelected = NRCNumberType.noNrc;
        _nrc1IdSelected = null;
        _nrc2IdSelected = null;
        _nrcTypeSelected = "N";
        _issuanceDateSelected = DateTime.now();
        _incomePeriodicitySelected = incomePeriodicities.first;
      });

      _formData = Map<String, dynamic>.from(_formDataDefault);
    }
  }

  Future<void> _clearAllFields() async {
    _initData();
  }

  void _saveHouseholdIncome() {
    AppLogger.i('_formData: $_formData');
    if (!_formKey.currentState!.validate()) {
      return;
    }
    _formKey.currentState!.save();
    if (widget.householdId == null) {
      // create //
      showConfirmation(
          context: context,
          message: "Are you sure you want to create new household income?",
          onYes: () async {
            String? _message = 'Something went wrong.';
            await showWaitingModal(
                context: context,
                message: "Household income is updating",
                onWaiting: () async {
                  try {
                    Map<String, dynamic> recHousehold = {
                      'customerId': widget.customerId,
                      'householdName': _formData['householdName']..toString().toUpperCase(),
                      'relationDetail': _formData['relationDetail'],
                      'householdMobileNo': _formData['householdMobileNo'],
                      'otherMobileNo': _formData['otherMobileNo'],
                      'incomeEarner': _formData['incomeEarner'],
                      'incomePeriodicity': _formData['incomePeriodicity'],
                      'incomeAmount': int.parse(_formData['incomeAmount'].toString().trim().replaceAll(",", "")),
                      'nrc2Id': _cardTypeSelected == NRCNumberType.nrc ? _formData['nrc2Id'] : null,
                      'nrcType': _cardTypeSelected == NRCNumberType.nrc ? _formData['nrcType'] : null,
                      'nonNrcPrefix': _cardTypeSelected == NRCNumberType.frc ? _formData['nonNrcPrefix'] : null,
                      'nrcDetail': _cardTypeSelected == NRCNumberType.noNrc ? null : _formData['nrcDetail'],
                      'natRegCardNo': _cardTypeSelected == NRCNumberType.nrc ? "${_formData['nrc1Id']}/${_formData['nrc2Name']}(${_formData['nrcType']})${_formData['nrcDetail']}" : (_cardTypeSelected == NRCNumberType.frc ? "${_formData['nonNrcPrefix']}-${_formData['nrcDetail']}" : null),
                      'natRegCardIssDate': _formData['natRegCardIssDate'],
                      'householdRemark': _formData['householdRemark'],
                    };

                    await Provider.of<CustomerHouseholdProvider>(context, listen: false).createRecord(widget.customerId, recHousehold).then((value) {
                      _message = Provider.of<CustomerHouseholdProvider>(context, listen: false).responseMessage;
                    });
                  } catch (error) {
                    _message = error.toString();
                  }
                });
            await showAlertModal(
                context: context,
                message: _message,
                onDismiss: () {
                  Navigator.pop(context);
                });
          });
    } else {
      showConfirmation(
          context: context,
          message: "Are you sure you want to update the selected income source?",
          onYes: () async {
            String? _message = 'Something went wrong.';
            await showWaitingModal(
                context: context,
                message: "The selected income source is updating...",
                onWaiting: () async {
                  try {
                    Map<String, dynamic> recHousehold = {
                      'householdName': _formData['householdName'].toString().toUpperCase(),
                      'relationDetail': _formData['relationDetail'],
                      'householdMobileNo': _formData['householdMobileNo'],
                      'otherMobileNo': _formData['otherMobileNo'],
                      'incomeEarner': _formData['incomeEarner'],
                      'incomePeriodicity': _formData['incomePeriodicity'],
                      'incomeAmount': int.parse(_formData['incomeAmount'].toString().trim().replaceAll(",", "")),
                      'nrc2Id': _cardTypeSelected == NRCNumberType.nrc ? _formData['nrc2Id'] : null,
                      'nrcType': _cardTypeSelected == NRCNumberType.nrc ? _formData['nrcType'] : null,
                      'nonNrcPrefix': _cardTypeSelected == NRCNumberType.frc ? _formData['nonNrcPrefix'] : null,
                      'nrcDetail': _cardTypeSelected == NRCNumberType.noNrc ? null : _formData['nrcDetail'],
                      'natRegCardNo': _cardTypeSelected == NRCNumberType.nrc ? "${_formData['nrc1Id']}/${_formData['nrc2Name']}(${_formData['nrcType']})${_formData['nrcDetail']}" : (_cardTypeSelected == NRCNumberType.frc ? "${_formData['nonNrcPrefix']}-${_formData['nrcDetail']}" : null),
                      'natRegCardIssDate': _formData['natRegCardIssDate'],
                      'householdRemark': _formData['householdRemark'],
                    };

                    await Provider.of<CustomerHouseholdProvider>(context, listen: false).editRecord(widget.customerId, widget.householdId, recHousehold).then((value) {
                      _message = Provider.of<CustomerHouseholdProvider>(context, listen: false).responseMessage;
                    });
                  } catch (error) {
                    _message = error.toString();
                  }
                });
            await showAlertModal(
                context: context,
                message: _message,
                onDismiss: () {
                  Navigator.pop(context);
                });
          });
    }
  }

  @override
  void initState() {
    _initData();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ModalProgressHUD(
      inAsyncCall: _isLoading,
      opacity: 0.5,
      progressIndicator: CircularProgressIndicator(
        valueColor: new AlwaysStoppedAnimation<Color>(
          Theme.of(context).primaryColor,
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.only(topLeft: Radius.circular(20.0), topRight: Radius.circular(20.0)),
        child: Container(
          padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          color: Colors.white,
          child: Column(children: [
            Container(
              color: Colors.teal,
              child: Stack(children: [
                Container(
                  width: double.infinity,
                  height: 50.0,
                  child: Center(
                    child: Text(
                      "${widget.householdId == null ? 'CREATE' : 'EDIT'} HOUSEHOLD INCOME",
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white),
                    ), // Your desired title
                  ),
                ),
                Positioned(
                  left: 0.0,
                  top: 0.0,
                  child: IconButton(
                    icon: Icon(
                      Icons.arrow_back,
                      color: Colors.white,
                    ), // Your desired icon
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                  ),
                ),
              ]),
            ),
            Expanded(
              child: Container(
                padding: EdgeInsets.fromLTRB(18, 10, 18, 10),
                child: Form(
                  key: _formKey,
                  //autovalidateMode: AutovalidateMode.,
                  child: SingleChildScrollView(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      ClearableTextFormField(
                        initialValue: _formData['householdName'] ?? '',
                        inputFormatters: [FilteringTextInputFormatter.allow(RegExp("[a-zA-Z ]"))],
                        textCapitalization: TextCapitalization.words,
                        required: true,
                        labelText: "Member Name",
                        onChanged: _setHouseHoldName,
                      ),
                      kSpaceVertical10,
                      ClearableTextFormField(
                        initialValue: _formData['relationDetail'] ?? '',
                        required: true,
                        labelText: "Relation Detail",
                        onChanged: _setHouseHoldRelationDetail,
                      ),
                      kSpaceVertical10,
                      PhoneTextFormField(
                        initialValue: _formData['householdMobileNo'] ?? '',
                        required: true,
                        labelText: 'Household Mobile Number',
                        onChanged: _setHouseholdMobileNo,
                      ),
                      kSpaceVertical10,
                      PhoneTextFormField(
                        initialValue: _formData['otherMobileNo'] ?? '',
                        labelText: 'Other Mobile Number',
                        onChanged: _setOtherMobileNo,
                      ),
                      kSpaceVertical10,
                      SingleSelectedGroup<NRCNumberType>(
                        items: NRCNumberType.values,
                        label: 'Card Type',
                        labelParser: (item) => item.getName(),
                        selectedItem: _cardTypeSelected,
                        onSelectChanged: _onChangeCardTypeSelection,
                      ),
                      kSpaceVertical10,

                      if (_cardTypeSelected == NRCNumberType.nrc) ...[
                        Column(
                          children: [
                            SelectedField<Map<String, dynamic>>(
                              title: 'NRC Region',
                              labelParser: (item) => '${item["nrc1Id"]} (${item["nrc1Name"]})',
                              required: true,
                              items: _nrc1s,
                              selectedItem: _nrc1IdSelected,
                              onSelected: (item) {
                                setState(() {
                                  _nrc1IdSelected = item;
                                  _formData["nrc1Id"] = item["nrc1Id"];
                                });
                                _getNrc2s(_nrc1IdSelected!['nrc1Id']);
                              },
                            ),
                            kSpaceVertical10,
                            SelectedField<Map<String, dynamic>>(
                              title: 'NRC Prefix',
                              labelParser: (item) => item["nrc2Name"],
                              required: true,
                              items: _nrc2s,
                              selectedItem: _nrc2IdSelected,
                              onSelected: (item) {
                                setState(() {
                                  _nrc2IdSelected = item;
                                  _formData["nrc2Id"] = item["nrc2Id"];
                                  _formData["nrc2Name"] = item["nrc2Name"];
                                });
                              },
                            ),
                            kSpaceVertical10,
                            SingleSelectedGroup<String>(
                              items: ['N', 'P'],
                              label: 'NRC Type',
                              labelParser: (item) => item.toUpperCase(),
                              selectedItem: _nrcTypeSelected,
                              onSelectChanged: _onChangeNrcTypeSelection,
                            ),
                            kSpaceVertical10,
                          ],
                        ),
                      ],

                      if (_cardTypeSelected == NRCNumberType.frc) ...[
                        Column(
                          children: [
                            ClearableTextFormField(
                              initialValue: _formData['nonNrcPrefix'] ?? '',
                              required: true,
                              labelText: 'FRC/NVC Prefix (3-5 characters)',
                              maxLength: 5,
                              validator: (text) {
                                if (text!.length < 3) return "You have not met this field's minimum length.";
                                return null;
                              },
                              onChanged: _setNonNrcPrefix,
                            ),
                            kSpaceVertical10,
                          ],
                        ),
                      ],

                      if (_cardTypeSelected == NRCNumberType.nrc || _cardTypeSelected == NRCNumberType.frc) ...[
                        Column(
                          children: [
                            ClearableTextFormField(
                              initialValue: _formData['nrcDetail'] ?? '',
                              labelText: 'NRC Number (6 digits)',
                              keyboardType: TextInputType.number,
                              maxLength: 6,
                              validator: (text) {
                                if (text!.length != 6) return "You have not met this field's length.";
                                return null;
                              },
                              onChanged: _setNrcNumber,
                            ),
                            kSpaceVertical10,
                            DatePickerField(
                              labelText: 'Issuance Date',
                              selectedDateTime: _issuanceDateSelected,
                              onConfirm: (date) => date == null ? null : _setIssuanceDate(date),
                            ),
                            kSpaceVertical10,
                          ],
                        ),
                      ],

                      // exclusionList //
                      // Container(
                      //   padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
                      //   decoration: BoxDecoration(
                      //     border: Border.all(color: Colors.grey),
                      //     borderRadius: BorderRadius.circular(5),
                      //   ),
                      //   child: Column(
                      //     crossAxisAlignment: CrossAxisAlignment.start,
                      //     children: [
                      //       SizedBox(
                      //         height: 5,
                      //       ),
                      //       Text(
                      //         "Income Earner",
                      //         textAlign: TextAlign.left,
                      //       ),
                      //       Row(
                      //         mainAxisAlignment: MainAxisAlignment.start,
                      //         children: <Widget>[
                      //           new Radio(
                      //             value: 1,
                      //             groupValue: _incomeEarnerSelected,
                      //             onChanged: _onChangeIncomeEarnerSelection,
                      //           ),
                      //           new InkWell(
                      //             child: Text(
                      //               'YES',
                      //               style: new TextStyle(fontSize: 16.0),
                      //             ),
                      //             onTap: () {
                      //               _onChangeIncomeEarnerSelection(1);
                      //             },
                      //           ),
                      //           new Radio(
                      //             value: 0,
                      //             groupValue: _incomeEarnerSelected,
                      //             onChanged: _onChangeIncomeEarnerSelection,
                      //           ),
                      //           new InkWell(
                      //             child: new Text(
                      //               'NO',
                      //               style: new TextStyle(
                      //                 fontSize: 16.0,
                      //               ),
                      //             ),
                      //             onTap: () {
                      //               _onChangeIncomeEarnerSelection(0);
                      //             },
                      //           ),
                      //         ],
                      //       ),
                      //     ],
                      //   ),
                      // ),
                      // SizedBox(
                      //   height: 10,
                      // ),

                      SelectedField<Map<String, dynamic>>(
                        title: 'Income Periodicity',
                        labelParser: (item) => item['title'],
                        required: true,
                        items: incomePeriodicities,
                        selectedItem: _incomePeriodicitySelected,
                        onSelected: (item) {
                          setState(() {
                            _incomePeriodicitySelected = item;
                            _formData['incomePeriodicity'] = item['id'];
                          });
                        },
                      ),
                      kSpaceVertical10,
                      CurrencyTextFormField(
                        initialValue: (_formData['incomeAmount']).toString(),
                        labelText: 'Income Amount',
                        required: true,
                        onChanged: (number) {
                          setState(() {
                            _formData['incomeAmount'] = number;
                          });
                        },
                      ),
                      kSpaceVertical10,
                      TextAreaField(
                        initialValue: _formData['householdRemark'] ?? '',
                        labelText: 'Remark',
                        onChanged: _setHouseholdRemark,
                      ),
                      kSpaceVertical10,
                    ]),
                  ),
                ),
              ),
            ),
            Container(
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Row(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
                  Expanded(
                    child: ButtonWidget(
                      text: "CLEAR",
                      isWhiteBackgroundColor: true,
                      onPressed: _clearAllFields,
                    ),
                  ),
                  Expanded(
                    child: ButtonWidget(
                      text: "SAVE",
                      isWhiteBackgroundColor: false,
                      onPressed: _saveHouseholdIncome,
                    ),
                  ),
                ]),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
