import 'package:flutter/material.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:provider/provider.dart';
import 'package:sales/data/local/db_sqlite_helper.dart';
import 'package:sales/providers/providers.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/widgets/confirmation_modal_bottom_widget.dart';
import 'package:sales/widgets/copyright_notice.dart';
import 'package:sales/widgets/deprecated/alert_modal_bottom_widget.dart';
import 'package:sales/widgets/waiting_modal_bottom_widget.dart';
import 'create_prospect/presentation/prospect_screen.dart';
import 'prospect_info_screen.dart';
import 'prospect_item_widget.dart';

class ProspectsScreen extends StatefulWidget {
  ProspectsScreen({
    super.key,
    required this.currentPosId,
    required this.userId,
    required this.userWorkPlaceId,
    required this.connectionType,
  });

  final int? currentPosId;
  final int? userId;
  final int? userWorkPlaceId;
  final String? connectionType;

  @override
  State<ProspectsScreen> createState() => _ProspectsScreenState();
}

class _ProspectsScreenState extends State<ProspectsScreen> {
  bool _isLoading = false;

  String? filter;
  TextEditingController searchController = new TextEditingController();

  List<Map<String, dynamic>> prospects = [];

  Future<void> _getProspects() async {
    showWaitingModal(
        context: context,
        message: "List of prospects are loading...",
        onWaiting: () async {
          try {
            await Provider.of<ProspectProvider>(context, listen: false).getProspects().then((value) {
              setState(() {
                prospects = Provider.of<ProspectProvider>(context, listen: false).items;
              });
            });
          } catch (error) {
            print(error.toString());
          }
        });
  }

  Future<void> _getOfflineProspects() async {
    setState(() {
      _isLoading = true;
      prospects = [];
    });

    try {
      List<Map<String, dynamic>> _offlineProspectList = await DBSqliteHelper().getProspects();
      setState(() {
        prospects = _offlineProspectList;
        _isLoading = false;
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _reloadData() async {
    if (widget.connectionType == 'online') {
      await this._getProspects();
    } else {
      await this._getOfflineProspects();
    }
  }

  void _onPressProspect(int? _prospectId) {
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => ProspectInfoScreen(
                prospectId: _prospectId,
                currentPosId: widget.currentPosId,
                userId: widget.userId,
                userWorkPlaceId: widget.userWorkPlaceId,
                connectionType: widget.connectionType,
                applicationType: 'new',
              )),
    ).then((value) async {
      await _reloadData();
    });
  }

  void _onPressAddProspect() {
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => ProspectScreen.create(
                prospectId: null,
                posId: widget.currentPosId,
              )),
    ).then((value) async {
      await _reloadData();
    });
  }

  _deleteProspect(Map<String, dynamic> prospect) {
    String? resultMessage = "No message";
    showConfirmation(
        context: context,
        message: "Are you sure you want to delete prospect '${prospect['prospectName']}'?",
        onYes: () async {
          await showWaitingModal(
              context: context,
              message: "The selected prospect is deleting...",
              onWaiting: () async {
                try {
                  await Provider.of<ProspectProvider>(context, listen: false).deleteProspect(prospect['prospectId']).then((value) {
                    resultMessage = Provider.of<ProspectProvider>(context, listen: false).responseMessage;
                    print('resultMessage: $resultMessage');
                  });
                } catch (error) {
                  resultMessage = error.toString();
                }
              });
          await showAlertModal(context: context, message: resultMessage, onDismiss: _reloadData);
        });
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      _reloadData();
      searchController.addListener(() {
        setState(() {
          filter = searchController.text;
        });
      });
      print('prospects_screen: posId ${widget.currentPosId}');
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('PROSPECTS (${prospects.length})'),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.refresh_rounded),
            onPressed: () async {
              this._getProspects();
            },
          ),
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () async {
              this._onPressAddProspect();
            },
          ),
        ],
      ),
      body: ModalProgressHUD(
        inAsyncCall: _isLoading,
        opacity: 0.5,
        progressIndicator: CircularProgressIndicator(
          valueColor: new AlwaysStoppedAnimation<Color>(
            context.getColorScheme().primary,
          ),
        ),
        child: Padding(
          padding: EdgeInsets.fromLTRB(5, 10, 5, 5),
          child: Column(children: <Widget>[
            new Padding(
              padding: new EdgeInsets.fromLTRB(10, 0, 10, 5),
              child: new TextField(
                controller: searchController,
                decoration: InputDecoration(
                  hintText: 'Search Prospect',
                  prefixIcon: Icon(Icons.search),
                  contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 15.0, 20.0),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15.0),
                  ),
                  suffixIcon: IconButton(
                    icon: Icon(Icons.clear),
                    onPressed: () => searchController.clear(),
                  ),
                ),
              ),
            ),
            Divider(),
            Expanded(
              child: Container(
                child: RefreshIndicator(
                  onRefresh: () => _reloadData(),
                  child: ListView.builder(
                      itemCount: prospects.length,
                      itemBuilder: (context, i) {
                        return filter == null || filter == ""
                            ? ProspectItemWidget(
                                connectionType: widget.connectionType!,
                                prospect: prospects[i],
                                onPressProspect: this._onPressProspect,
                                onDeleteProspect: this._deleteProspect,
                              )
                            : '${prospects[i]['prospectName']}'.toLowerCase().contains(filter!.toLowerCase())
                                ? ProspectItemWidget(
                                    connectionType: widget.connectionType!,
                                    prospect: prospects[i],
                                    onPressProspect: this._onPressProspect,
                                    onDeleteProspect: this._deleteProspect,
                                  )
                                : new Container();
                      }),
                ),
              ),
            ),
            kSpaceVertical8,
            CopyrightNotice(),
          ]),
        ),
      ),
    );
  }
}
