import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/data/local/db_sqlite_helper.dart';
import 'package:sales/providers/providers.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/widgets/waiting_modal_bottom_widget.dart';
import './app_doc/edit_app_doc_modal.dart';
import './customer_contact/edit_cust_contact_screen.dart';
import './customer_income/customer_income_modal.dart';
import './customer_income/edit_customer_income_modal.dart';
import './household_income/edit_household_income_modal.dart';
import './household_income/household_modal.dart';
import '../presentation/partial_widgets/app_application_widget.dart';
import '../presentation/partial_widgets/app_customer_widget.dart';
import '../presentation/partial_widgets/app_doc_detail_widget.dart';
import '../presentation/partial_widgets/contact_detail_widget.dart';
import '../presentation/partial_widgets/income_customer_widget.dart';
import '../presentation/partial_widgets/income_household_widget.dart';
import '../presentation/partial_widgets/sim_product_widget.dart';
import '../presentation/partial_widgets/sim_prospect_widget.dart';
import '../presentation/partial_widgets/sim_simulation_widget.dart';
import './product/choose_product_screen.dart';
import '../../../widgets/confirmation_modal_bottom_widget.dart';
import '../../../widgets/deprecated/alert_modal_bottom_widget.dart';
import '../../../widgets/deprecated/button_widget.dart';
import 'application/edit_application_screen.dart';
import 'create_prospect/presentation/prospect_screen.dart';
import 'customer/customer_screen.dart';
import '../presentation/partial_widgets/app_upload_new_widget.dart';
import 'simulation/choose_simulation_screen.dart';

class ProspectInfoScreen extends StatefulWidget {
  static const routeName = '/prospect';

  final int? prospectId;
  final int? currentPosId;
  final int? userId;
  final int? userWorkPlaceId;
  final String? connectionType;
  final String? applicationType;

  ProspectInfoScreen({
    Key? key,
    required this.prospectId,
    required this.currentPosId,
    required this.userId,
    required this.userWorkPlaceId,
    required this.connectionType,
    required this.applicationType,
  });

  @override
  _ProspectInfoScreenState createState() => _ProspectInfoScreenState();
}

class _ProspectInfoScreenState extends State<ProspectInfoScreen> with SingleTickerProviderStateMixin {
  bool _isLoading = false;
  late TabController _tabController;
  Map<String, dynamic>? _prospect;
  List<Map<String, dynamic>> _attachedProducts = [];
  List<dynamic> _incomeSources = [];
  List<dynamic> _custHouseHolds = [];
  List<dynamic> _custContacts = [];
  List<Map<String, dynamic>> _appDocs = [];
  List<Map<String, dynamic>> _appDocuments = [];

  bool _isAppUploadCompleted = false;

  TabBar get _tabBar => TabBar(
        labelColor: Colors.teal,
        unselectedLabelColor: Colors.grey,
        tabs: [
          Tab(
            text: "SIM",
          ),
          Tab(
            text: "APP",
          ),
          Tab(
            text: "INC",
          ),
          Tab(
            text: "REF",
          ),
          Tab(
            text: "DOC",
          ),
          Tab(
            text: "PIC",
          ),
        ],
      );

  Future<void> loadProspect(int? prospectId) async {
    try {
      if (widget.connectionType == 'online') {
        await Provider.of<ProspectProvider>(context, listen: false).getProspect(prospectId).then((value) {
          setState(() {
            _prospect = Provider.of<ProspectProvider>(context, listen: false).item;
          });
        });
        if (_prospect != null) {
          setState(() {
            _incomeSources = _prospect!['cust_incomes'];
            _custHouseHolds = _prospect!['cust_households'];
            _custContacts = _prospect!['cust_contacts'];
          });
          if (_prospect!['applicationId'] != null) {
            await _getAppDocs(_prospect!['applicationId']);
            await _getAppUploadList();
          }
          await _getAttachedProducts(_prospect!['packageId']);
        }
      } else {
        _prospect = await DBSqliteHelper().getProspect(widget.prospectId);

        if (_prospect != null) {
          await _getIncomeResources(_prospect!['createdCustId']);
          await _getCustHouseHolds(_prospect!['createdCustId']);
          await _getCustContacts(_prospect!['createdCustId']);
        }

        if (_prospect!['applicationId'] != null) {
          await _getAppDocs(_prospect!['applicationId']);
          await _getAppUploadList();
        }
        await _getAttachedProducts(_prospect!['packageId']);
      }

      // Navigator.pop(context);
    } catch (error) {
      print(error.toString());
    }
  }

  Future<void> _getProspect(int? prospectId, bool withWaitingModal) async {
    if (withWaitingModal) {
      await showWaitingModal(
        context: context,
        message: "Prospect information is loading...",
        onWaiting: () async {
          await loadProspect(prospectId);
        },
      );
    } else {
      await loadProspect(prospectId);
    }
  }

  Future<void> _getAttachedProducts(int? packageId) async {
    setState(() {
      _isLoading = true;
    });

    try {
      if (widget.connectionType == 'online') {
        await Provider.of<AttachedProductProvider>(context, listen: false).getRecords(packageId).then((value) {
          setState(() {
            _attachedProducts = Provider.of<AttachedProductProvider>(context, listen: false).items;
            _isLoading = false;
          });
        });
      } else {
        List<Map<String, dynamic>> offlineAttachedProducts = await DBSqliteHelper().getAttachedProducts(packageId);
        setState(() {
          _attachedProducts = List<Map<String, dynamic>>.from(offlineAttachedProducts);
          _isLoading = false;
        });
      }
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _getIncomeResources(int? customerId) async {
    setState(() {
      _isLoading = true;
    });

    try {
      if (widget.connectionType == 'online') {
        await Provider.of<CustomerIncomeSourceProvider>(context, listen: false).getRecords(customerId).then((value) {
          setState(() {
            _incomeSources = Provider.of<CustomerIncomeSourceProvider>(context, listen: false).items;
            _isLoading = false;
          });
        });
      } else {
        List<Map<String, dynamic>> offlineIncomeSources = await DBSqliteHelper().getCustomerIncomeSources(customerId);
        setState(() {
          _incomeSources = List<Map<String, dynamic>>.from(offlineIncomeSources);
          _isLoading = false;
        });
      }
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _getCustHouseHolds(int? customerId) async {
    setState(() {
      _isLoading = true;
    });

    try {
      if (widget.connectionType == 'online') {
        await Provider.of<CustomerHouseholdProvider>(context, listen: false).getRecords(customerId).then((value) {
          setState(() {
            _custHouseHolds = Provider.of<CustomerHouseholdProvider>(context, listen: false).items;
            _isLoading = false;
          });
        });
      } else {
        List<Map<String, dynamic>> offlineHouseholds = await DBSqliteHelper().getHouseholds(customerId);
        setState(() {
          _custHouseHolds = List<Map<String, dynamic>>.from(offlineHouseholds);
          _isLoading = false;
        });
      }
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _getCustContacts(int? customerId) async {
    setState(() {
      _isLoading = true;
    });

    try {
      if (widget.connectionType == 'online') {
        await Provider.of<CustomerContactDetailProvider>(context, listen: false).getRecords(customerId).then((value) {
          setState(() {
            _custContacts = Provider.of<CustomerContactDetailProvider>(context, listen: false).items;
            _isLoading = false;
          });
        });
      } else {
        List<Map<String, dynamic>> offlineCustContacts = await DBSqliteHelper().getCustomerContactDetails(customerId);
        setState(() {
          _custContacts = List<Map<String, dynamic>>.from(offlineCustContacts);
          _isLoading = false;
        });
      }
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  void _editProspect() {
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => ProspectScreen.create(
                prospectId: widget.prospectId,
                posId: widget.currentPosId,
              )),
    ).then((value) async {
      await _getProspect(widget.prospectId, true);
    });
  }

  void _chooseProduct() {
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => ChooseProductScreen(
                prospectId: widget.prospectId,
                prospectPosId: _prospect!['posId'],
                connectionType: widget.connectionType,
              )),
    ).then((value) async {
      await _getProspect(widget.prospectId, true);
    });
  }

  void _chooseSimulation() {
    AppLogger.i("_chooseSimulation ${_prospect!['packageId']}");
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ChooseSimulationScreen(
          prospectId: widget.prospectId,
          packageId: _prospect!['packageId'],
        ),
      ),
    ).then((value) async {
      await _getProspect(widget.prospectId, true);
    });
  }

  void _createApplication() {
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => EditApplicationScreen(
                prospect: _prospect,
              )),
    ).then((value) async {
      await _getProspect(widget.prospectId, true);
    });
  }

  void _editApplication() {
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => EditApplicationScreen(
                prospect: _prospect,
              )),
    ).then((value) async {
      await _getProspect(widget.prospectId, true);
    });
  }

  void _createCustomer() {
    Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) =>
              // EditCustomerScreen(prospect: _prospect!, userId: null, connectionType: widget.connectionType,)
              CustomerScreen.create(prospect: _prospect!),
        )).then((value) async {
      await _getProspect(widget.prospectId, true);
    });
  }

  void _createCustIncomeSource() {
    showModalBottomSheet(
        isScrollControlled: true,
        context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (BuildContext context, StateSetter setModalState /*You can rename this!*/) {
            return EditCustomerIncomeModal(
              customerId: _prospect!['createdCustId'],
              incomeSourceId: null,
              userId: widget.userId,
              connectionType: widget.connectionType,
            );
          });
        }).then((value) async {
      await _getProspect(widget.prospectId, false);
    });
  }

  void _editCustIncomeSource(int incomeSourceId) {
    showModalBottomSheet(
        isScrollControlled: true,
        context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (BuildContext context, StateSetter setModalState /*You can rename this!*/) {
            return EditCustomerIncomeModal(
              customerId: _prospect!['createdCustId'],
              incomeSourceId: incomeSourceId,
              userId: widget.userId,
              connectionType: widget.connectionType,
            );
          });
        }).then((value) async {
      await _getProspect(widget.prospectId, false);
    });
  }

  void _deleteCustIncomeSource(int incomeSourceId) {
    showConfirmation(
        context: context,
        message: "Are you sure you want to delete the selected income source?",
        onYes: () async {
          String? _message = 'Something went wrong.';
          await showWaitingModal(
              context: context,
              message: "The selected income source is deleting...",
              onWaiting: () async {
                try {
                  if (widget.connectionType == "online") {
                    await Provider.of<CustomerIncomeSourceProvider>(context, listen: false).deleteRecord(_prospect!['createdCustId'], incomeSourceId, {
                      'incomeSourceId': incomeSourceId,
                    }).then((value) {
                      _message = Provider.of<CustomerIncomeSourceProvider>(context, listen: false).responseMessage;
                    });
                  } else {
                    _message = 'The selected income source is successfully deleted.';
                    await DBSqliteHelper().deleteCustomerIncomeSource(incomeSourceId);
                  }
                } catch (error) {
                  _message = error.toString();
                }
              });
          await showAlertModal(
              context: context,
              message: _message,
              onDismiss: () async {
                await _getProspect(widget.prospectId, false);
              });
        });
  }

  void _showCustIncomeSource(int incomeSourceId) {
    showModalBottomSheet(
        isScrollControlled: true,
        context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (BuildContext context, StateSetter setModalState /*You can rename this!*/) {
            return CustomerIncomeModal(
              customerId: _prospect!['createdCustId'],
              incomeSourceId: incomeSourceId,
              connectionType: widget.connectionType,
            );
          });
        }).then((value) async {});
  }

  // Household //
  void _createHouseholdIncome() {
    showModalBottomSheet(
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        context: context,
        builder: (BuildContext context) {
          return EditHouseholdIncomeModal(
            customerId: _prospect!['createdCustId'],
            householdId: null,
            userId: widget.userId,
            connectionType: widget.connectionType,
          );
        }).then((value) async {
      await _getProspect(widget.prospectId, false);
    });
  }

  // edit household //
  void _editCustHousehold(int householdId) {
    showModalBottomSheet(
        isScrollControlled: true,
        context: context,
        builder: (BuildContext context) {
          return EditHouseholdIncomeModal(
            customerId: _prospect!['createdCustId'],
            householdId: householdId,
            userId: widget.userId,
            connectionType: widget.connectionType,
          );
        }).then((value) async {
      await _getProspect(widget.prospectId, false);
    });
  }

  // delete Cust Household
  void _deleteCustHousehold(int householdId) {
    showConfirmation(
        context: context,
        message: "Are you sure you want to delete the selected household?",
        onYes: () async {
          String? _message = 'Something went wrong.';
          await showWaitingModal(
              context: context,
              message: "Household income is deleting...",
              onWaiting: () async {
                try {
                  if (widget.connectionType == 'online') {
                    await Provider.of<CustomerHouseholdProvider>(context, listen: false).deleteRecord(_prospect!['createdCustId'], householdId, {
                      'householdId': householdId,
                    }).then((value) {
                      _message = Provider.of<CustomerHouseholdProvider>(context, listen: false).responseMessage;
                    });
                  } else {
                    _message = 'The selected household is successfully deleted.';
                    await DBSqliteHelper().deleteHousehold(householdId);
                  }
                } catch (error) {
                  _message = error.toString();
                }
              });
          await showAlertModal(
              context: context,
              message: _message,
              onDismiss: () async {
                await _getProspect(widget.prospectId, false);
              });
        });
  }

  void _showCustHousehold(int householdId) {
    showModalBottomSheet(
        isScrollControlled: true,
        context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (BuildContext context, StateSetter setModalState /*You can rename this!*/) {
            return HouseholdModal(
              customerId: _prospect!['createdCustId'],
              householdId: householdId,
              connectionType: widget.connectionType,
            );
          });
        }).then((value) async {});
  }

  // create cust contact //
  void _createCustContact() {
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => EditCustContactScreen(
                customerId: _prospect!['createdCustId'],
                contactDetId: null,
                userId: widget.userId,
                connectionType: widget.connectionType,
              )),
    ).then((value) async {
      await _getProspect(widget.prospectId, false);
    });
  }

  // edit cust contact //
  void _editCustContact(int contactDetId) {
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => EditCustContactScreen(
                customerId: _prospect!['createdCustId'],
                contactDetId: contactDetId,
                userId: widget.userId,
                connectionType: widget.connectionType,
              )),
    ).then((value) async {
      await _getProspect(widget.prospectId, false);
    });
  }

  // delete cust contact //
  void _deleteCustContact(int contactDetId) {
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        builder: (context) {
          String? _message = 'Something went wrong.';
          return ConfirmationModalBottomSheet("Are you sure you want to delete the selected contact?", () async {
            try {
              setState(() {
                _isLoading = true;
              });

              if (widget.connectionType == 'online') {
                await Provider.of<CustomerContactDetailProvider>(context, listen: false).deleteRecord(_prospect!['createdCustId'], contactDetId, {
                  'contactDetId': contactDetId,
                }).then((value) {
                  setState(() {
                    _message = Provider.of<CustomerContactDetailProvider>(context, listen: false).responseMessage;
                    _isLoading = false;
                  });
                });
              } else {
                _message = 'The selected contact NRC is successfully deleted.';
                await DBSqliteHelper().deleteCustomerContactDetail(contactDetId);
                _isLoading = false;
              }
            } catch (error) {
              setState(() {
                _message = error.toString();
                _isLoading = false;
              });
            }

            Navigator.pop(context);
            showModalBottomSheet(
                context: context,
                isScrollControlled: true,
                builder: (context) {
                  return AlertModalBottomWidget(_message, () async {
                    await _getProspect(widget.prospectId, false);
                    Navigator.pop(context);
                  });
                });
          });
        });
  }

  // get app contract //
  Future<void> _getAppDocs(int? applicationId) async {
    setState(() {
      _isLoading = true;
    });

    try {
      if (widget.connectionType == 'online') {
        await Provider.of<AppDocDetProvider>(context, listen: false).getRecords(applicationId).then((value) {
          setState(() {
            _appDocs = Provider.of<AppDocDetProvider>(context, listen: false).items;
            print('_appDocs: $_appDocs');
            _isLoading = false;
          });
        });
      } else {
        List<Map<String, dynamic>> offDocDetails = await DBSqliteHelper().getAppDocDetails(applicationId);
        setState(() {
          _appDocs = List<Map<String, dynamic>>.from(offDocDetails);
          _isLoading = false;
        });
      }
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  // create app doc //
  void _createAppDoc() {
    showModalBottomSheet(
        isScrollControlled: true,
        context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (BuildContext context, StateSetter setModalState /*You can rename this!*/) {
            return EditAppDocModal(
              applicationId: _prospect!['applicationId'],
              docDetId: null,
              userId: widget.userId,
              connectionType: widget.connectionType,
            );
          });
        }).then((value) async {
      await _getProspect(widget.prospectId, true);
      await _getAppDocs(_prospect!['applicationId']);
    });
  }

  // edit app doc //
  void _editAppDoc(int docDetId) {
    showModalBottomSheet(
        isScrollControlled: true,
        context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (BuildContext context, StateSetter setModalState /*You can rename this!*/) {
            return EditAppDocModal(
              applicationId: _prospect!['applicationId'],
              docDetId: docDetId,
              userId: widget.userId,
              connectionType: widget.connectionType,
            );
          });
        }).then((value) async {
      await _getProspect(widget.prospectId, true);
      await _getAppDocs(_prospect!['applicationId']);
    });
  }

  // delete app doc //
  void _deleteAppDoc(int docDetId) {
    showConfirmation(
        context: context,
        message: "Are you sure you want to delete the selected doc detail?",
        onYes: () async {
          String? _message = 'Something went wrong.';
          await showWaitingModal(
              context: context,
              message: "The selected document is deleting...",
              onWaiting: () async {
                try {
                  if (widget.connectionType == 'online') {
                    await Provider.of<AppDocDetProvider>(context, listen: false).deleteRecord(_prospect!['applicationId'], docDetId, {
                      'docDetId': docDetId,
                    }).then((value) {
                      _message = Provider.of<AppDocDetProvider>(context, listen: false).responseMessage;
                    });
                  } else {
                    _message = 'The selected document is successfully deleted.';
                    await DBSqliteHelper().deleteAppDocDetail(docDetId);
                  }
                } catch (error) {
                  _message = error.toString();
                }
              });
          await showAlertModal(
              context: context,
              message: _message,
              onDismiss: () async {
                await _getAppDocs(_prospect!['applicationId']);
              });
        });
  }

  Future<void> _getAppUploadList() async {
    try {
      await Provider.of<AppUploadProvider>(context, listen: false).getAppUploadList(_prospect!['applicationId'], _prospect!['packageId']).then((value) {
        setState(() {
          _appDocuments = Provider.of<AppUploadProvider>(context, listen: false).items;
        });

        _isAppUploadCompleted = false;
        int docRequiredCount = 0;
        int docUploadRequiredCount = 0;
        _appDocuments.forEach((appDocument) {
          if (appDocument['documentRequired'] == 1) {
            docRequiredCount += 1;
            if (appDocument['appUploads'].length > 0) {
              docUploadRequiredCount += 1;
            }
          }
        });

        print(
          '_appDocuments: $_appDocuments',
        );

        _isAppUploadCompleted = docRequiredCount == docUploadRequiredCount ? true : false;
      });
    } catch (error) {
      print(error.toString());
    }
  }

  void _submitApp() {
    String? _message = 'Something went wrong.';
    showConfirmation(
        context: context,
        message: "Are you sure you want to submit this application?",
        onYes: () async {
          await showWaitingModal(
              context: context,
              message: "The application is submitting...",
              onWaiting: () async {
                try {
                  await Provider.of<ApplicationProvider>(context, listen: false).submit(_prospect!['prospectId'], _prospect!['applicationId'], {
                    'prospectId': _prospect!['prospectId'],
                    'applicationId': _prospect!['applicationId'],
                  }).then((value) {
                    setState(() {
                      _message = Provider.of<ApplicationProvider>(context, listen: false).responseMessage;
                    });
                  });
                } catch (error) {
                  setState(() {
                    _message = error.toString();
                  });
                }
              });
          await showAlertModal(
              context: context,
              message: _message,
              onDismiss: () {
                Navigator.pop(context);
              });
        });
  }

  void _resubmitApplication() {
    String? _message = 'Something went wrong.';
    showConfirmation(
        context: context,
        message: "Are you sure you want to re-submit this application?",
        onYes: () async {
          await showWaitingModal(
              context: context,
              message: _message,
              onWaiting: () async {
                try {
                  await Provider.of<ApplicationProvider>(context, listen: false).resubmit(_prospect!['prospectId'], _prospect!['applicationId'], {
                    'prospectId': _prospect!['prospectId'],
                    'applicationId': _prospect!['applicationId'],
                  }).then((value) {
                    setState(() {
                      _message = Provider.of<ApplicationProvider>(context, listen: false).responseMessage;
                    });
                  });
                } catch (error) {
                  setState(() {
                    _message = error.toString();
                  });
                }
              });

          await showAlertModal(
              context: context,
              message: _message,
              onDismiss: () {
                Navigator.pop(context);
              });
        });
  }

  @override
  void initState() {
    _tabController = new TabController(length: 2, vsync: this);

    print('prospect_screen: posId ${widget.currentPosId}');
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      this._getProspect(widget.prospectId, true);
    });
    super.initState();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 6,
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            '${widget.applicationType == 'new' ? 'PROSPECT' : 'PROSPECT (CP)'}',
          ),
          bottom: PreferredSize(
            preferredSize: _tabBar.preferredSize,
            child: ColoredBox(
              color:context.getColorScheme().onPrimary,
              child: _tabBar,
            ),
          ),
          actions: <Widget>[
            IconButton(
              icon: Icon(Icons.refresh_rounded),
              onPressed: () async {
                this._getProspect(widget.prospectId, true);
              },
            ),
          ],
        ),
        body: Padding(
          padding: EdgeInsets.all(8),
          child: Column(
            children: [
              Expanded(
                child: TabBarView(children: [
                  Container(
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          if (_prospect != null) ...[
                            SimProspectWidget(
                              prospect: _prospect,
                              editProspect: _editProspect,
                              connectionType: widget.connectionType,
                            ),
                            kSpaceVertical4,
                            SimProductWidget(
                              prospect: _prospect,
                              attachedProducts: _attachedProducts,
                              chooseProduct: _chooseProduct,
                            ),
                            kSpaceVertical4,
                            if (_prospect!['packageId'] != null || _prospect!['packageId'] != "")
                              SimSimulationWidget(
                                prospect: _prospect,
                                chooseSimulation: _chooseSimulation,
                              ),
                          ],
                        ],
                      ),
                    ),
                  ),
                  Container(
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          if (_prospect != null && (_prospect!['simulationId'] != null || _prospect!['applicationId'] != null)) ...[
                            AppApplicationWidget(
                              prospect: _prospect,
                              createApplication: _createApplication,
                              editApplication: _editApplication,
                            ),
                            kSpaceVertical4,
                            if (_prospect!['applicationId'] != null)
                              AppCustomerWidget(
                                prospect: _prospect,
                                createApplication: _createCustomer,
                              ),
                          ],
                        ],
                      ),
                    ),
                  ),
                  Container(
                    child: Column(
                      children: [
                        if (_prospect != null && _prospect!['createdCustId'] != null) ...[
                          Expanded(
                            child: IncomeCustomerWidget(
                              prospect: _prospect,
                              incomeSources: _incomeSources,
                              createCustIncomeSource: _createCustIncomeSource,
                              editCustIncomeSource: _editCustIncomeSource,
                              deleteCustIncomeSource: _deleteCustIncomeSource,
                              showCustIncomeSource: _showCustIncomeSource,
                            ),
                          ),
                          kSpaceVertical4,
                          Expanded(
                            child: IncomeHouseholdWidget(
                              prospect: _prospect,
                              householdIncomes: _custHouseHolds,
                              createCustHousehold: _createHouseholdIncome,
                              editCustHousehold: _editCustHousehold,
                              deleteCustHousehold: _deleteCustHousehold,
                              showCustHousehold: _showCustHousehold,
                            ),
                          ),
                          kSpaceVertical4,
                        ],
                      ],
                    ),
                  ),
                  Container(
                    child: Column(
                      children: [
                        if (_prospect != null && _prospect!['createdCustId'] != null)
                          Expanded(
                            child: ContactDetailWidget(
                              prospect: _prospect,
                              custContacts: _custContacts,
                              createCustContact: _createCustContact,
                              editCustContact: _editCustContact,
                              deleteCustContact: _deleteCustContact,
                              showCustContact: null,
                            ),
                          ),
                      ],
                    ),
                  ),
                  Container(
                    child: _prospect != null && _prospect!['applicationId'] != null
                        ? AppDocDetailWidget(
                            prospect: _prospect,
                            appDocs: _appDocs,
                            createAppDoc: _createAppDoc,
                            editAppDoc: _editAppDoc,
                            deleteAppDoc: _deleteAppDoc,
                          )
                        : SizedBox(),
                  ),
                  Container(
                    child: _prospect != null && _prospect!['applicationId'] != null
                        ? AppUploadNewWidget(
                            applicationId: _prospect!['applicationId'],
                            appDocuments: _appDocuments,
                            getAppUploadList: this._getAppUploadList,
                            getProspect: () {
                              this._getProspect(_prospect!['prospectId'], false);
                            },
                          )
                        : SizedBox(),
                  ),
                ]),
              ),
              kSpaceVertical4,
              if (_incomeSources.length > 0 && _custHouseHolds.length > 0 && _isAppUploadCompleted == true && widget.connectionType == "online") ...[
                if (widget.applicationType == 'new' && _prospect!['simulationId'] != null)
                  Container(
                    color: Colors.white,
                    child: Padding(
                      padding: const EdgeInsets.all(0),
                      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
                        Expanded(
                          child: ButtonWidget(
                            text: "SUBMIT APPLICATION",
                            isWhiteBackgroundColor: false,
                            onPressed: _submitApp,
                          ),
                        ),
                      ]),
                    ),
                  ),
                if (widget.applicationType == 'cp')
                  Container(
                    color: Colors.white,
                    child: Padding(
                      padding: const EdgeInsets.all(0),
                      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
                        Expanded(
                          child: ButtonWidget(
                            text: "RE-SUBMIT APPLICATION",
                            isWhiteBackgroundColor: false,
                            onPressed: _resubmitApplication,
                          ),
                        ),
                      ]),
                    ),
                  )
              ],
            ],
          ),
        ),
      ),
    );
  }
}
