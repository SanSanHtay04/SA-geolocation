import 'package:flutter/material.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:provider/provider.dart';
import 'package:sales/data/local/prefs_store.dart';
import 'package:sales/providers/application_provider.dart';
import 'package:sales/providers/user_provider.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/widgets/confirmation_modal_bottom_widget.dart';
import 'package:sales/widgets/deprecated/alert_modal_bottom_widget.dart';
import 'package:sales/widgets/deprecated/button_widget.dart';
import 'package:sales/widgets/selected_field/selected_field.dart';
import 'package:sales/widgets/selected_group/single_selected_group.dart';
import 'package:sales/widgets/waiting_modal_bottom_widget.dart';
import 'package:shared_preferences/shared_preferences.dart';

class EditApplicationScreen extends StatefulWidget {
  final Map<String, dynamic>? prospect;

  EditApplicationScreen({
    required this.prospect,
  });

  @override
  _EditApplicationScreenState createState() => _EditApplicationScreenState();
}

class _EditApplicationScreenState extends State<EditApplicationScreen> {
  bool _isLoading = false;
  var _designationTypeSelected = 'self-designated';
  var _designationPersonSelected;
  var prefsStore;
  List<Map<String, dynamic>> _cas = [];
  List<Map<String, dynamic>> _casTemp = [];

  final GlobalKey<FormState> _formKey = GlobalKey();
  late Map<String, dynamic> _formData;
  Map<String, dynamic> _formDataDefault = {
    'personDesignatedTo': null,
  };

  _onChangeDesignationSelection(String? strDesignationType) async {
    setState(() {
      _designationTypeSelected = strDesignationType!;
    });

    if (_designationTypeSelected == 'self-designated') {
      _formData['personDesignatedTo'] = null;
    }
  }

  Future<void> _getCAs(int? posId) async {
    try {
      await Provider.of<UserProvider>(context, listen: false).getUserAssignedToPOS(posId!).then(
        (value) {
          _casTemp = Provider.of<UserProvider>(context, listen: false).items;
          if (_casTemp.length > 0) {
            _casTemp.forEach((ca) {
              if (ca["userId"] != prefsStore.accountInfo?.user.userId) {
                _cas.add(ca);
              }
            });
          }
        },
      );
    } catch (error) {
      print(error.toString());
    }
  }

  void _createApplication() {
    if (!_formKey.currentState!.validate()) {
      // Invalid!
      return;
    }
    _formKey.currentState!.save();

    showConfirmation(
        context: context,
        message: "Are you sure you want to create application?",
        onYes: () async {
          String? _message = 'Something went wrong.';
          await showWaitingModal(
              context: context,
              message: "New application is creating...",
              onWaiting: () async {
                try {
                  Map<String, dynamic> _recApplication = {
                    'personDesignatedTo': _formData['personDesignatedTo'],
                    'prospectId': widget.prospect!['prospectId'],
                  };

                  await Provider.of<ApplicationProvider>(context, listen: false).createRecord(widget.prospect!['prospectId'], _recApplication).then((value) {
                    _message = Provider.of<ApplicationProvider>(context, listen: false).responseMessage;
                  });
                } catch (error) {
                  setState(() {
                    _message = error.toString();
                  });
                }
              });
          await showAlertModal(
              context: context,
              message: _message,
              onDismiss: () {
                Navigator.pop(context);
              });
        });
  }

  void _editApplication() {
    if (!_formKey.currentState!.validate()) {
      // Invalid!
      return;
    }
    _formKey.currentState!.save();

    showConfirmation(
        context: context,
        message: "Are you sure you want to edit application information?",
        onYes: () async {
          String? _message = 'Something went wrong.';
          await showWaitingModal(
              context: context,
              message: "The selected application is updating...",
              onWaiting: () async {
                try {
                  Map<String, dynamic> _recApplication = {'personDesignatedTo': _formData['personDesignatedTo']};

                  await Provider.of<ApplicationProvider>(context, listen: false).updatePersonDesignatedTo(widget.prospect!['applicationId'], _recApplication).then((value) {
                    _message = Provider.of<ApplicationProvider>(context, listen: false).responseMessage;
                  });
                } catch (error) {
                  _message = error.toString();
                }
              });
          await showAlertModal(
              context: context,
              message: _message,
              onDismiss: () {
                Navigator.pop(context);
              });
        });
    // showModalBottomSheet(
    //   context: context,
    //   isScrollControlled: true,
    //   builder: (context) {
    //     String? _message = 'Something went wrong.';
    //     return ConfirmationModalBottomSheet(
    //         "Are you sure you want to edit application information?", () async {
    //       try {
    //         setState(() {
    //           _isLoading = true;
    //         });

    //         Map<String, dynamic> _recApplication = {
    //           'personDesignatedTo': _formData['personDesignatedTo']
    //         };

    //         await Provider.of<ApplicationProvider>(context, listen: false)
    //               .updatePersonDesignatedTo(widget.prospect!['applicationId'], _recApplication)
    //               .then((value) {
    //             setState(() {
    //               _message =
    //                   Provider.of<ApplicationProvider>(context, listen: false)
    //                       .responseMessage;
    //             });
    //           });

    //         setState(() {
    //           _isLoading = false;
    //         });
    //       } catch (error) {
    //         setState(() {
    //           _message = error.toString();
    //           _isLoading = false;
    //         });
    //       }

    //       Navigator.pop(context);
    //       showModalBottomSheet(
    //           context: context,
    //           isScrollControlled: true,
    //           builder: (context) {
    //             return AlertModalBottomWidget(_message, () {
    //               Navigator.pop(context);
    //               Navigator.pop(context);
    //             });
    //           });
    //     });
    //   }
    // );
  }

  void _initData() async {
    showWaitingModal(
        context: context,
        message: "Application information is loading...",
        onWaiting: () async {
          prefsStore = PrefsStore(await SharedPreferences.getInstance());
          print("widget.prospect!['posId']: ${widget.prospect!['posId']}");
          await _getCAs(widget.prospect!['posId']);
          if (widget.prospect!['applicationId'] != null && widget.prospect!['applicationId'] != '') {
            setState(() {
              if (widget.prospect!['personDesignatedTo'] == null || widget.prospect!['personDesignatedTo'] == prefsStore.accountInfo?.user.userId) {
                _designationTypeSelected = 'self-designated';
              } else {
                _designationTypeSelected = 'ca-designated';
                this._cas.forEach((item) {
                  if (item['userId'] == widget.prospect!['personDesignatedTo']) {
                    _designationPersonSelected = item;
                  }
                });
              }

              _formDataDefault = Map<String, dynamic>.from({
                'personDesignatedTo': _designationTypeSelected == 'ca-designated' ? widget.prospect!['personDesignatedTo'] : null,
              });
              _formData = Map<String, dynamic>.from(_formDataDefault);
            });
          } else {
            _formData = Map<String, dynamic>.from(_formDataDefault);
          }
        });
  }

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      _initData();
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(
          "${widget.prospect!['applicationId'] == null ? "CREATE" : "EDIT"} APPLICATION",
          style: TextStyle(color: Colors.white),
        ),
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: ModalProgressHUD(
        inAsyncCall: _isLoading,
        opacity: 0.5,
        progressIndicator: CircularProgressIndicator(
          valueColor: new AlwaysStoppedAnimation<Color>(
            context.getColorScheme().primary,
          ),
        ),
        child: Padding(
          padding: EdgeInsets.all(10),
          child: Column(children: [
            Expanded(
              child: Container(
                child: Column(children: [
                  Container(
                    padding: EdgeInsets.fromLTRB(15, 15, 15, 15),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Form(
                      key: _formKey,
                      autovalidateMode: AutovalidateMode.always,
                      child: Column(
                        children: [
                          SingleSelectedGroup<String>(
                            items: ['self-designated', 'ca-designated'],
                            label: 'Designation',
                            labelParser: (item) => item == 'self-designated' ? 'Self-designated' : 'CA-designated',
                            selectedItem: _designationTypeSelected,
                            onSelectChanged: _onChangeDesignationSelection,
                          ),
                          _designationTypeSelected == 'ca-designated'
                              ? SelectedField<Map<String, dynamic>>(
                                  title: 'Designate To Person',
                                  labelParser: (item) => '${item["userFullName"]}',
                                  required: _designationTypeSelected == 'ca-designated' ? true : false,
                                  items: _cas,
                                  selectedItem: _designationPersonSelected,
                                  onSelected: (item) {
                                    setState(() {
                                      _designationPersonSelected = item;
                                      _formData["personDesignatedTo"] = item["userId"];
                                    });
                                  },
                                )
                              : SizedBox(),
                          SizedBox(
                            height: 10,
                          ),
                          Container(
                            color: Colors.white,
                            child: Padding(
                              padding: const EdgeInsets.all(0),
                              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
                                Expanded(
                                  child: ButtonWidget(
                                    text: widget.prospect!['applicationId'] == null ? "CREATE APPLICATION" : "SAVE CHANGES",
                                    isWhiteBackgroundColor: false,
                                    onPressed: widget.prospect!['applicationId'] == null ? _createApplication : _editApplication,
                                  ),
                                ),
                              ]),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ]),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
