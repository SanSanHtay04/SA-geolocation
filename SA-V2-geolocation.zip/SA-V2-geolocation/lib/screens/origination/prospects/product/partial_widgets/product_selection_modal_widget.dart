import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:provider/provider.dart';
import 'package:sales/data/local/db_sqlite_helper.dart';
import 'package:sales/providers/providers.dart';
import 'package:sales/utils/utils.dart';

class ProductSelectionModalWidget extends StatefulWidget {
  final int? prospectPosId;
  final int? merchantId;
  final int? brandId;
  final int? isZeroCost;
  final String? connectionType;
  final Function(Map<String, dynamic>) setProductSelected;

  ProductSelectionModalWidget({required this.merchantId, required this.prospectPosId, required this.brandId, required this.isZeroCost, required this.connectionType, required this.setProductSelected});

  @override
  _ProductSelectionModalWidgetState createState() => _ProductSelectionModalWidgetState();
}

class _ProductSelectionModalWidgetState extends State<ProductSelectionModalWidget> {
  bool _isLoading = false;
  List<Map<String, dynamic>> _products = [];
  List<Map<String, dynamic>> _filteredProducts = [];
  TextEditingController _searchController = new TextEditingController();

  Future<void> _getProducts() async {
    setState(() {
      _isLoading = true;
    });

    try {
      if (widget.connectionType == 'online') {
        await Provider.of<ProductProvider>(context, listen: false).getProducts(widget.merchantId, widget.prospectPosId, widget.brandId, widget.isZeroCost).then((value) {
          setState(() {
            _products = Provider.of<ProductProvider>(context, listen: false).items;
            _filteredProducts = List<Map<String, dynamic>>.from(_products);
            print('products length ${_products.length}');
            _isLoading = false;
          });
        });
      } else {
        List<Map<String, dynamic>> _productList = await DBSqliteHelper().getProducts(widget.prospectPosId, widget.brandId, widget.isZeroCost);
        setState(() {
          _products = _productList;
          _filteredProducts = List<Map<String, dynamic>>.from(_products);
          _isLoading = false;
        });
      }
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  void initData() async {
    print("modal widget.currentPosId: ${widget.prospectPosId} - widget.isZeroCost: ${widget.isZeroCost} ");
    await this._getProducts();
  }

  void _searchProducts(String text) {
    setState(() {
      _filteredProducts = List<Map<String, dynamic>>.from(_products);
      if (text.isNotEmpty) {
        _filteredProducts.clear();
        _products.forEach((item) {
          if (item['productName'].toLowerCase().contains(text.toLowerCase())) {
            _filteredProducts.add(item);
          }
        });
      }
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    this.initData();
    super.initState();
  }

  Widget brandListViewWidget() {
    return RefreshIndicator(
      onRefresh: () => _getProducts(),
      child: ListView.separated(
          padding: EdgeInsets.all(0),
          separatorBuilder: (context, index) => Divider(
                color: Colors.grey[300],
              ),
          itemCount: _filteredProducts.length,
          itemBuilder: (context, i) {
            return ListTile(
              contentPadding: EdgeInsets.symmetric(vertical: 0.0, horizontal: 0.0),
              visualDensity: VisualDensity(horizontal: 0, vertical: -4),
              title: Text(
                '${_filteredProducts[i]['productName']} (ID ${_filteredProducts[i]['financialSchemeId']})',
                style: TextStyle(
                  color: Colors.grey[800],
                ),
              ),
              trailing: Text('${NumberFormat('#,###').format(_filteredProducts[i]['productPrice'])}'),
              // leading: Text(
              //   '${_filteredProducts[i]['productCode']}',
              // ),
              subtitle: Text(
                '${_filteredProducts[i]['financialSchemeName']}',
              ),
              onTap: () {
                print('_filteredProducts[i]: ${_filteredProducts[i]}');
                setState(() {
                  widget.setProductSelected(_filteredProducts[i]);
                });
                Navigator.of(context).pop();
              },
            );
          }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ModalProgressHUD(
      inAsyncCall: _isLoading,
      opacity: 0.5,
      progressIndicator: CircularProgressIndicator(
        valueColor: new AlwaysStoppedAnimation<Color>(
          context.getColorScheme().primary,
        ),
      ),
      child: Container(
        child: DraggableScrollableSheet(
          initialChildSize: 0.95,
          //set this as you want
          maxChildSize: 0.95,
          //set this as you want
          minChildSize: 0.95,
          //set this as you want
          expand: true,
          builder: (context, scrollController) {
            return ClipRRect(
              borderRadius: BorderRadius.only(topLeft: Radius.circular(20.0), topRight: Radius.circular(20.0)),
              child: Container(
                color: Colors.white,
                child: Column(children: [
                  Container(
                      child: Stack(children: [
                    Container(
                      width: double.infinity,
                      height: 50.0,
                      child: Center(
                        child: Text(
                          "SELECT PRODUCT",
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.teal[600]),
                        ), // Your desired title
                      ),
                    ),
                    Positioned(
                      left: 0.0,
                      top: 0.0,
                      child: IconButton(
                        icon: Icon(Icons.arrow_back),
                        // Your desired icon
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      ),
                    ),
                    Positioned(
                      right: 0.0,
                      top: 0.0,
                      child: IconButton(
                          icon: Icon(
                            Icons.refresh_outlined,
                            color: Colors.teal,
                          ),
                          onPressed: () async {
                            await this._getProducts();
                          }),
                    ),
                  ])),
                  Divider(),
                  new Padding(
                    padding: new EdgeInsets.all(5.0),
                    child: new TextField(
                      controller: _searchController,
                      decoration: InputDecoration(
                        hintText: 'Product',
                        prefixIcon: Icon(
                          Icons.search,
                        ),
                        contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(32.0)),
                        suffixIcon: IconButton(
                          icon: Icon(Icons.clear),
                          onPressed: () => _searchController.clear(),
                        ),
                      ),
                      onChanged: _searchProducts,
                    ),
                  ),
                  Divider(),
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.fromLTRB(15, 5, 15, 10),
                      child: brandListViewWidget(),
                    ),
                  ),
                ]),
              ),
            );
          },
        ),
      ),
    );
  }
}
