import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:pattern_formatter/pattern_formatter.dart';
import 'package:provider/provider.dart';
import 'package:sales/data/local/db_sqlite_helper.dart';
import 'package:sales/providers/providers.dart';
import 'package:sales/utils/utils.dart';

import '../../../../../widgets/deprecated/button_widget.dart';
import '../../../../../widgets/deprecated/text_form_input.dart';
import '../../../../../widgets/item_info_widget.dart';

class AttachedProductModalWidget extends StatefulWidget {
  final String? connectionType;
  final int packageTotalQuantity;
  final int packageMaxQuantity;
  final Map<String, dynamic>? productSelected;
  final Function(Map<String, dynamic>) setAttachedProductSelected;

  AttachedProductModalWidget({required this.connectionType, required this.packageTotalQuantity, required this.packageMaxQuantity, required this.productSelected, required this.setAttachedProductSelected});

  @override
  _AttachedProductModalWidgetState createState() => _AttachedProductModalWidgetState();
}

class _AttachedProductModalWidgetState extends State<AttachedProductModalWidget> {
  bool _isLoading = false;
  int? _secProductIdSelected;
  int? _supplierBankAccountIdSelected;
  String? _secProductTypeSelected;
  String? _isFromListSelected = 'list';
  String? _merchantTypeSelected = 'same';
  int? _quantity = 0;
  int? _unitPrice = 0;
  int _packageTotalQuantity = 0;

  List<Map<String, dynamic>> _secondaryProducts = [];
  Map<String, dynamic>? _secondaryProductSelected;

  List<Map<String, dynamic>> _supplierBankAccounts = [];
  late Map<String, dynamic> _supplierBankAccountSelected;

  Map<String, dynamic>? _merchant;

  final GlobalKey<FormState> _formKey = GlobalKey();

  List<Map<String, dynamic>> _productTypes = [
    {'id': 'wg', 'title': 'WG'},
    {'id': 'bg', 'title': 'BG'},
    {'id': 'furniture', 'title': 'Furniture'},
    {'id': 'phone', 'title': 'Phone'},
    {'id': 'other', 'title': 'E-Bike / Bicycle'},
  ];

  // productName //
  final _productNameFocusNode = FocusNode();
  final _productNameController = TextEditingController();

  void _setProductName(String? value) {}

  // productQuantity //
  final _productQuantityFocusNode = FocusNode();
  final _productQuantityController = TextEditingController(text: "1");

  // productPrice //
  final _productPriceFocusNode = FocusNode();
  final _productPriceController = TextEditingController(text: "0");

  Future<void> _getSecondaryProducts() async {
    setState(() {
      _isLoading = true;
    });

    try {
      if (widget.connectionType == 'online') {
        await Provider.of<SecondaryProductProvider>(context, listen: false).getRecords().then((value) {
          setState(() {
            _secondaryProducts = Provider.of<SecondaryProductProvider>(context, listen: false).items;
            print('products length ${_secondaryProducts.length}');
            _isLoading = false;
          });
        });
      } else {
        List<Map<String, dynamic>> _productList = await DBSqliteHelper().getSecondaryProducts();
        setState(() {
          _secondaryProducts = List<Map<String, dynamic>>.from(_productList);
          _isLoading = false;
        });
      }
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _getSupllierBankAccounts() async {
    setState(() {
      _isLoading = true;
    });

    try {
      if (widget.connectionType == 'online') {
        await Provider.of<SupplierBankAccountProvider>(context, listen: false).getRecords().then((value) {
          setState(() {
            _supplierBankAccounts = Provider.of<SupplierBankAccountProvider>(context, listen: false).items;
            print('_supplierBankAccounts length ${_supplierBankAccounts.length}');
            _isLoading = false;
          });
        });
      } else {
        List<Map<String, dynamic>> _productList = await DBSqliteHelper().getSupplierBankAccounts();
        setState(() {
          _supplierBankAccounts = List<Map<String, dynamic>>.from(_productList);
          _isLoading = false;
        });
      }
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _getMerchant(int? merchantId) async {
    setState(() {
      _isLoading = true;
    });

    try {
      if (widget.connectionType == 'online') {
        await Provider.of<MerchantProvider>(context, listen: false).getRecord(merchantId).then((value) {
          setState(() {
            _merchant = Provider.of<MerchantProvider>(context, listen: false).item;
          });
        });
      } else {
        Map<String, dynamic>? _recMerchant = await DBSqliteHelper().getMerchant(merchantId);
        setState(() {
          _merchant = Map<String, dynamic>.from(_recMerchant!);
        });
      }
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  void _onChangeProductTypeSelection(String? strNewValue) {
    setState(() {
      _isFromListSelected = strNewValue;
    });
  }

  void _onChangeMerchantTypeSelection(strNewValue) {
    setState(() {
      _merchantTypeSelected = strNewValue;
    });
  }

  void _onClickAddProduct() {
    if (!_formKey.currentState!.validate()) {
      // Invalid!
      return;
    }
    _quantity = 0;
    _unitPrice = 0;
    if (_isFromListSelected == 'list') {
      _quantity = 1;
      _unitPrice = int.tryParse(_secondaryProductSelected!['secProductRetalPrice'].toString()) ?? 0;
    } else {
      _quantity = int.tryParse(_productQuantityController.text.trim().replaceAll(",", ""));
      _unitPrice = int.tryParse(_productPriceController.text.trim().replaceAll(",", ""));
    }

    _formKey.currentState!.save();
    if (_isFromListSelected == 'list') {
      int merchantDiscountRate = int.tryParse(_secondaryProductSelected!['secProductMerchantDiscountRate'].toString()) ?? 0;
      double merchantDiscountAmount = (_unitPrice! * merchantDiscountRate) / 100;

      var _secProd = {
        'secProductId': _secondaryProductSelected!['secProductId'],
        'productName': _secondaryProductSelected!['secProductName'],
        'productType': _secondaryProductSelected!['secProductType'],
        'productTypeDetail': _secondaryProductSelected!['productTypeDetail'],
        'quantity': 1,
        'productPrice': _unitPrice,
        'totalPrice': _unitPrice,
        'productRemark': _secondaryProductSelected!['secProductRemark'],
        'merchantDiscountRate': merchantDiscountRate,
        'merchantDiscountAmount': merchantDiscountAmount,
        'merchantPaymentAmount': _unitPrice! - merchantDiscountAmount,
        'bankAccountId': _secondaryProductSelected!['bankAccountId'],
        'supplierName': _secondaryProductSelected!['supplierName'],
        'bankName': _secondaryProductSelected!['bankName'],
        'beneficiary': _secondaryProductSelected!['beneficiary'],
        'accountNo': _secondaryProductSelected!['accountNo'],
        'accountRemark': _secondaryProductSelected!['accountRemark'],
      };
      widget.setAttachedProductSelected(_secProd);
      Navigator.pop(context);
    } else {
      var _secProd = {
        'productName': _productNameController.text.trim(),
        'productType': _secProductTypeSelected,
        'quantity': _quantity,
        'productPrice': _unitPrice,
        'totalPrice': _quantity! * _unitPrice!,
        'merchantDiscountRate': 0,
        'merchantDiscountAmount': 0,
        'merchantPaymentAmount': _quantity! * _unitPrice!,
        'merchantId': _merchantTypeSelected == 'same' ? widget.productSelected!['merchantId'] : null,
        'bankAccountId': _merchantTypeSelected == 'same' ? (_merchant!['bankAccountId'] ?? null) : (_supplierBankAccountSelected['bankAccountId'] ?? null),
        'supplierName': _merchantTypeSelected == 'same' ? (_merchant!['merchantName'] ?? null) : (_supplierBankAccountSelected['supplierName'] ?? null),
        'bankName': _merchantTypeSelected == 'same' ? (_merchant!['bankName'] ?? null) : (_supplierBankAccountSelected['bankName'] ?? null),
        'beneficiary': _merchantTypeSelected == 'same' ? (_merchant!['bankAccountName'] ?? null) : (_supplierBankAccountSelected['beneficiary'] ?? null),
        'accountNo': _merchantTypeSelected == 'same' ? (_merchant!['bankAccountNo'] ?? null) : (_supplierBankAccountSelected['accountNo'] ?? null),
        'accountRemark': _merchantTypeSelected == 'same' ? null : (_supplierBankAccountSelected['accountRemark'] ?? null),
      };

      widget.setAttachedProductSelected(_secProd);
      Navigator.pop(context);
    }
  }

  void initData() async {
    await this._getSecondaryProducts();
    await this._getSupllierBankAccounts();
    await this._getMerchant(widget.productSelected!['merchantId']);
    _packageTotalQuantity = widget.packageTotalQuantity;
  }

  @override
  void dispose() {
    _productNameFocusNode.dispose();
    _productNameController.dispose();

    _productPriceFocusNode.dispose();
    _productPriceController.dispose();

    _productQuantityFocusNode.dispose();
    _productQuantityController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    this.initData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    // Secondary Product //
    Widget _buildSecondaryProductDropdownButton() {
      return DropdownButtonFormField<int>(
        isExpanded: true,
        dropdownColor: Colors.white,
        decoration: InputDecoration(
          contentPadding: EdgeInsets.fromLTRB(15, 13, 12, 13),
          labelText: "Secondary Product",
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
          ),
        ),
        items: _secondaryProducts.map((item) {
          return DropdownMenuItem<int>(
            value: item["secProductId"],
            child: Container(
              child: Text(
                item["secProductName"],
                overflow: TextOverflow.ellipsis,
              ),
            ),
          );
        }).toList(),
        value: _secProductIdSelected ?? null,
        onChanged: (newValue) {
          setState(() {
            _secProductIdSelected = newValue;
            _secondaryProducts.forEach((secProduct) {
              if (_secProductIdSelected == secProduct['secProductId']) {
                _secondaryProductSelected = secProduct;
              }
            });
          });
        },
        validator: (value) {
          if (_secProductIdSelected == null) {
            return "This filed is required.";
          }
          return null;
        },
        onSaved: (newValue) {},
      );
    }

    // Product Type //
    Widget _buildProductTypeDropdownButton() {
      return DropdownButtonFormField<String>(
        isExpanded: true,
        dropdownColor: Colors.white,
        decoration: InputDecoration(
          contentPadding: EdgeInsets.fromLTRB(15, 13, 12, 13),
          labelText: "Product Type",
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
          ),
        ),
        items: _productTypes.map((item) {
          return DropdownMenuItem<String>(
            value: item["id"],
            child: Container(
              child: Text(
                item["title"],
                overflow: TextOverflow.ellipsis,
              ),
            ),
          );
        }).toList(),
        value: _secProductTypeSelected ?? null,
        onChanged: (newValue) {
          setState(() {
            _secProductTypeSelected = newValue;
          });
        },
        validator: (value) {
          if (_secProductTypeSelected == null) {
            return "This filed is required.";
          }
          return null;
        },
        onSaved: (newValue) {},
      );
    }

    // Bank Accounts //
    Widget _buildSupplierBankAccountDropdownButton() {
      return DropdownButtonFormField<int>(
        isExpanded: true,
        dropdownColor: Colors.white,
        decoration: InputDecoration(
          contentPadding: EdgeInsets.fromLTRB(15, 13, 12, 13),
          labelText: "Supplier Bank Account",
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
          ),
        ),
        items: _supplierBankAccounts.map((item) {
          return DropdownMenuItem<int>(
            value: item["bankAccountId"],
            child: Container(
              child: Text(
                item["supplierName"],
                overflow: TextOverflow.ellipsis,
              ),
            ),
          );
        }).toList(),
        value: _supplierBankAccountIdSelected ?? null,
        onChanged: (newValue) {
          setState(() {
            _supplierBankAccountIdSelected = newValue;
            _supplierBankAccounts.forEach((bankAcc) {
              if (_supplierBankAccountIdSelected == bankAcc['bankAccountId']) {
                _supplierBankAccountSelected = bankAcc;
              }
            });
          });
        },
        validator: (value) {
          if (_supplierBankAccountIdSelected == null) {
            return "This field is required.";
          }
          return null;
        },
        onSaved: (newValue) {},
      );
    }

    // Product Quantity //
    var _productQuantityFormField = TextFormField(
      textInputAction: TextInputAction.next,
      controller: _productQuantityController,
      focusNode: _productQuantityFocusNode,
      onFieldSubmitted: (value) {
        FocusScope.of(context).requestFocus(_productPriceFocusNode);
      },
      decoration: InputDecoration(
        contentPadding: EdgeInsets.all(15),
        labelText: "Quantity",
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.grey, width: 1),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.grey, width: 1),
        ),
        border: OutlineInputBorder(
          borderSide: BorderSide(color: Theme.of(context).primaryColor, width: 1),
        ),
        suffixIcon: IconButton(
          icon: Icon(Icons.clear),
          onPressed: () => _productQuantityController.clear(),
        ),
      ),
      keyboardType: TextInputType.numberWithOptions(signed: true, decimal: true),
      inputFormatters: [
        ThousandsFormatter(),
      ],
      onChanged: (value) {
        _packageTotalQuantity = widget.packageTotalQuantity;
        if (value.trim().replaceAll(",", "") != "") {
          _quantity = int.tryParse(_productQuantityController.text.trim().replaceAll(",", ""));
          _packageTotalQuantity += _quantity!;
        }
      },
      validator: (value) {
        if (value!.isEmpty) {
          return "This field is required.";
        }
        if (int.parse(value.replaceAll(',', '')) == 0) {
          return "Quantity must be greater than 0.";
        }
        if (_packageTotalQuantity > widget.packageMaxQuantity) {
          return "You can only add up to ${widget.packageMaxQuantity} products to the bundle.";
        }
        return null;
      },
      onSaved: (String? value) {},
    );

    // Product Unit Price //
    var _productPriceFormField = TextFormField(
      textInputAction: TextInputAction.done,
      controller: _productPriceController,
      focusNode: _productPriceFocusNode,
      decoration: InputDecoration(
        contentPadding: EdgeInsets.all(15),
        labelText: "Unit Price",
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.grey, width: 1),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.grey, width: 1),
        ),
        border: OutlineInputBorder(
          borderSide: BorderSide(color: Theme.of(context).primaryColor, width: 1),
        ),
        suffixIcon: IconButton(
          icon: Icon(Icons.clear),
          onPressed: () => _productPriceController.clear(),
        ),
      ),
      keyboardType: TextInputType.numberWithOptions(signed: true, decimal: true),
      inputFormatters: [
        ThousandsFormatter(),
      ],
      validator: (value) {
        if (value!.isEmpty) {
          return "This field is required.";
        }
        if (int.parse(value.replaceAll(',', '')) == 0) {
          return "Amount must be greater than 0.";
        }
        return null;
      },
      onSaved: (String? value) {},
    );

    return ModalProgressHUD(
      inAsyncCall: _isLoading,
      opacity: 0.5,
      progressIndicator: CircularProgressIndicator(
        valueColor: new AlwaysStoppedAnimation<Color>(
          context.getColorScheme().primary,
        ),
      ),
      child: Container(
        child: DraggableScrollableSheet(
            initialChildSize: 0.95,
            //set this as you want
            maxChildSize: 0.95,
            //set this as you want
            minChildSize: 0.95,
            //set this as you want
            expand: true,
            builder: (context, scrollController) {
              return ClipRRect(
                borderRadius: BorderRadius.only(topLeft: Radius.circular(20.0), topRight: Radius.circular(20.0)),
                child: Container(
                  color: Colors.white,
                  child: Column(children: [
                    Container(
                      color: Colors.teal,
                      child: Stack(children: [
                        Container(
                          width: double.infinity,
                          height: 50.0,
                          child: Center(
                            child: Text(
                              "ADD ATTACHED PRODUCT",
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white),
                            ), // Your desired title
                          ),
                        ),
                        Positioned(
                          left: 0.0,
                          top: 0.0,
                          child: IconButton(
                            icon: Icon(
                              Icons.arrow_back,
                              color: Colors.white,
                            ), // Your desired icon
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          ),
                        ),
                      ]),
                    ),
                    Expanded(
                      child: Container(
                        child: Form(
                          key: _formKey,
                          autovalidateMode: AutovalidateMode.always,
                          child: SingleChildScrollView(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              // PROUCT TYPE //
                              Container(
                                decoration: BoxDecoration(
                                  color: Colors.grey[200],
                                  border: Border(bottom: BorderSide(color: Colors.grey)),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    new Radio(
                                      value: 'list',
                                      groupValue: _isFromListSelected,
                                      onChanged: _onChangeProductTypeSelection,
                                    ),
                                    new InkWell(
                                        child: Text(
                                          'Select From List',
                                          style: new TextStyle(fontSize: 16.0),
                                        ),
                                        onTap: () {
                                          _onChangeProductTypeSelection('list');
                                        }),
                                    new Radio(
                                      value: 'newproduct',
                                      groupValue: _isFromListSelected,
                                      onChanged: _onChangeProductTypeSelection,
                                    ),
                                    new InkWell(
                                        child: new Text(
                                          'Type New Product',
                                          style: new TextStyle(
                                            fontSize: 16.0,
                                          ),
                                        ),
                                        onTap: () {
                                          _onChangeProductTypeSelection('newproduct');
                                        }),
                                  ],
                                ),
                              ),

                              _isFromListSelected == 'list'
                                  ? Padding(
                                      padding: EdgeInsets.all(10),
                                      child: Column(
                                        children: [
                                          SizedBox(
                                            height: 10,
                                          ),
                                          _buildSecondaryProductDropdownButton(),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          _secondaryProductSelected == null
                                              ? SizedBox()
                                              : Container(
                                                  padding: EdgeInsets.all(15),
                                                  decoration: BoxDecoration(border: Border.all(color: Colors.grey), borderRadius: BorderRadius.circular(10), color: Colors.grey[200]),
                                                  child: Column(
                                                    children: [
                                                      ItemInfoWidget(
                                                        title: "Type",
                                                        value: _secondaryProductSelected!['secProductType'].toString().toUpperCase(),
                                                      ),
                                                      Divider(),
                                                      ItemInfoWidget(
                                                        title: "Name",
                                                        value: _secondaryProductSelected!['secProductName'],
                                                      ),
                                                      Divider(),
                                                      ItemInfoWidget(
                                                        title: "Detail",
                                                        value: _secondaryProductSelected!['secProductRemark'],
                                                      ),
                                                      Divider(),
                                                      ItemInfoWidget(
                                                        title: "Price",
                                                        value: "${NumberFormat('#,###').format(_secondaryProductSelected!['secProductRetalPrice'])} MMK",
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                        ],
                                      ),
                                    )
                                  : SizedBox(),

                              _isFromListSelected == 'newproduct'
                                  ? Padding(
                                      padding: EdgeInsets.all(10),
                                      child: Column(
                                        children: [
                                          SizedBox(
                                            height: 10,
                                          ),

                                          // productName //
                                          TextFormInput(
                                            controller: _productNameController,
                                            focusNode: _productNameFocusNode,
                                            label: "Product Name",
                                            textInputAction: TextInputAction.done,
                                            isRequired: true,
                                            requiredMessage: "This field is required.",
                                            onSaved: _setProductName,
                                            maxLines: 2,
                                          ),

                                          SizedBox(
                                            height: 10,
                                          ),
                                          _buildProductTypeDropdownButton(),

                                          SizedBox(
                                            height: 10,
                                          ),
                                          _productQuantityFormField,

                                          SizedBox(
                                            height: 10,
                                          ),
                                          _productPriceFormField,

                                          Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children: [
                                              Row(
                                                children: [
                                                  new Radio(
                                                    value: 'same',
                                                    groupValue: _merchantTypeSelected,
                                                    onChanged: _onChangeMerchantTypeSelection,
                                                  ),
                                                  new InkWell(
                                                    child: new Text(
                                                      'Same Merchant',
                                                      style: new TextStyle(
                                                        fontSize: 16.0,
                                                      ),
                                                    ),
                                                    onTap: () {
                                                      _onChangeMerchantTypeSelection('same');
                                                    },
                                                  ),
                                                ],
                                              ),
                                              Row(
                                                children: [
                                                  new Radio(
                                                    value: 'different',
                                                    groupValue: _merchantTypeSelected,
                                                    onChanged: _onChangeMerchantTypeSelection,
                                                  ),
                                                  new InkWell(
                                                    child: Text(
                                                      'Different Merchant / Supplier',
                                                      style: new TextStyle(fontSize: 16.0),
                                                    ),
                                                    onTap: () {
                                                      _onChangeMerchantTypeSelection('different');
                                                    },
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),

                                          SizedBox(
                                            height: 10,
                                          ),
                                          // Supplier Bank Account //
                                          _merchantTypeSelected == 'same' ? SizedBox() : _buildSupplierBankAccountDropdownButton(),
                                        ],
                                      ),
                                    )
                                  : SizedBox(),
                              Padding(
                                padding: const EdgeInsets.fromLTRB(5.0, 10, 5, 10),
                                child: Row(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
                                  new Expanded(
                                    child: ButtonWidget(
                                      text: "ADD PRODUCT",
                                      isWhiteBackgroundColor: false,
                                      onPressed: _onClickAddProduct,
                                    ),
                                  ),
                                ]),
                              ),
                            ]),
                          ),
                        ),
                      ),
                    ),
                  ]),
                ),
              );
            }),
      ),
    );
  }
}
