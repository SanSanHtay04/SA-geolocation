import 'package:flutter/material.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:provider/provider.dart';
import 'package:sales/data/local/db_sqlite_helper.dart';
import 'package:sales/providers/providers.dart';
import 'package:sales/utils/utils.dart';

class BrandSelectionModalWidget extends StatefulWidget {
  final int? prospectPosId;
  final int? isZeroCost;
  final String? connectionType;
  final Function(Map<String, dynamic>) setBrandSelected;

  BrandSelectionModalWidget({required this.prospectPosId, required this.isZeroCost, required this.connectionType, required this.setBrandSelected});

  @override
  _BrandSelectionModalWidgetState createState() => _BrandSelectionModalWidgetState();
}

class _BrandSelectionModalWidgetState extends State<BrandSelectionModalWidget> {
  bool _isLoading = false;
  List<Map<String, dynamic>> _brands = [];
  List<Map<String, dynamic>> _filteredBrands = [];
  TextEditingController _searchController = new TextEditingController();

  Future<void> _getBrands() async {
    setState(() {
      _isLoading = true;
    });

    try {
      if (widget.connectionType == 'online') {
        await Provider.of<BrandProvider>(context, listen: false).getBrands(widget.prospectPosId, widget.isZeroCost).then((value) {
          setState(() {
            _brands = Provider.of<BrandProvider>(context, listen: false).items;
            _filteredBrands = List<Map<String, dynamic>>.from(_brands);
            print('brands length ${_brands.length}');
            _isLoading = false;
          });
        });
      } else {
        List<Map<String, dynamic>> _brandList = await DBSqliteHelper().getBrands(widget.prospectPosId, widget.isZeroCost);
        setState(() {
          _brands = _brandList;
          _filteredBrands = List<Map<String, dynamic>>.from(_brands);
          _isLoading = false;
        });
      }
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  void initData() async {
    print("modal widget.currentPosId: ${widget.prospectPosId} - widget.isZeroCost: ${widget.isZeroCost} ");
    await this._getBrands();
  }

  void _searchBrands(String text) {
    setState(() {
      _filteredBrands = List<Map<String, dynamic>>.from(_brands);
      if (text.isNotEmpty) {
        _filteredBrands.clear();
        _brands.forEach((item) {
          if (item['brandName'].toLowerCase().contains(text.toLowerCase())) {
            _filteredBrands.add(item);
          }
        });
      }
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    this.initData();
    super.initState();
  }

  Widget brandListViewWidget() {
    print('_filteredBrands: ${_filteredBrands.length}');
    return RefreshIndicator(
      onRefresh: () => _getBrands(),
      child: ListView.separated(
          padding: EdgeInsets.all(0),
          separatorBuilder: (context, index) => Divider(
                color: Colors.grey[300],
              ),
          itemCount: _filteredBrands.length,
          itemBuilder: (context, i) {
            return ListTile(
              contentPadding: EdgeInsets.symmetric(vertical: 0.0, horizontal: 0.0),
              visualDensity: VisualDensity(horizontal: 0, vertical: -4),
              title: Text(
                '${_filteredBrands[i]['brandName']}',
                style: TextStyle(
                  color: Colors.grey[800],
                ),
              ),
              trailing: Text('${_filteredBrands[i]['brandCategory']}'),
              leading: new CircleAvatar(
                backgroundColor: Colors.blue,
                child: Text(
                  '${_filteredBrands[i]['brandName'].toString().substring(0, 1).toUpperCase()}',
                  style: TextStyle(color: Colors.white),
                ),
              ),
              onTap: () {
                print('_filteredBrands[i]: ${_filteredBrands[i]}');
                setState(() {
                  widget.setBrandSelected(_filteredBrands[i]);
                });
                Navigator.of(context).pop();
              },
            );
          }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ModalProgressHUD(
      inAsyncCall: _isLoading,
      opacity: 0.5,
      progressIndicator: CircularProgressIndicator(
        valueColor: new AlwaysStoppedAnimation<Color>(
          context.getColorScheme().primary,
        ),
      ),
      child: Container(
        child: DraggableScrollableSheet(
            initialChildSize: 0.95,
            //set this as you want
            maxChildSize: 0.95,
            //set this as you want
            minChildSize: 0.95,
            //set this as you want
            expand: true,
            builder: (context, scrollController) {
              return ClipRRect(
                borderRadius: BorderRadius.only(topLeft: Radius.circular(20.0), topRight: Radius.circular(20.0)),
                child: Container(
                  color: Colors.white,
                  child: Column(children: [
                    Container(
                      child: Stack(
                        children: [
                          Container(
                            width: double.infinity,
                            height: 50.0,
                            child: Center(
                              child: Text(
                                "SELECT BRAND",
                                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.teal[600]),
                              ), // Your desired title
                            ),
                          ),
                          Positioned(
                            left: 0.0,
                            top: 0.0,
                            child: IconButton(
                                icon: Icon(Icons.arrow_back),
                                // Your desired icon
                                onPressed: () {
                                  Navigator.of(context).pop();
                                }),
                          ),
                          Positioned(
                            right: 0.0,
                            top: 0.0,
                            child: IconButton(
                                icon: Icon(
                                  Icons.refresh_outlined,
                                  color: Colors.teal,
                                ),
                                onPressed: () async {
                                  await this._getBrands();
                                }),
                          ),
                        ],
                      ),
                    ),
                    Divider(),
                    new Padding(
                      padding: new EdgeInsets.all(5.0),
                      child: new TextField(
                        controller: _searchController,
                        decoration: InputDecoration(
                          hintText: 'Brand',
                          prefixIcon: Icon(
                            Icons.search,
                          ),
                          contentPadding: EdgeInsets.fromLTRB(20.0, 15.0, 20.0, 15.0),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(32.0)),
                          suffixIcon: IconButton(
                            icon: Icon(Icons.clear),
                            onPressed: () => _searchController.clear(),
                          ),
                        ),
                        onChanged: _searchBrands,
                      ),
                    ),
                    Divider(),
                    Expanded(
                      child: Container(
                        padding: EdgeInsets.fromLTRB(15, 5, 15, 10),
                        child: brandListViewWidget(),
                      ),
                    ),
                  ]),
                ),
              );
            }),
      ),
    );
  }
}
