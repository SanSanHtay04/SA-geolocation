import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:pattern_formatter/pattern_formatter.dart';
import 'package:provider/provider.dart';
import 'package:sales/providers/providers.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/widgets/copyright_notice.dart';

import 'package:sales/widgets/labeled_checkbox.dart';
import 'package:sales/widgets/waiting_modal_bottom_widget.dart';
import './partial_widgets/attached_product_modal_widget.dart';
import './partial_widgets/brand_selection_modal_widget.dart';
import './partial_widgets/product_selection_modal_widget.dart';
import '../../../../providers/product_package_provider.dart';
import '../../../../widgets/confirmation_modal_bottom_widget.dart';
import '../../../../widgets/deprecated/alert_modal_bottom_widget.dart';
import '../../../../widgets/deprecated/button_widget.dart';
import '../../../../widgets/deprecated/text_button_widget.dart';
import '../../../../widgets/item_info_widget.dart';

class ChooseProductScreen extends StatefulWidget {
  static const routeName = "/choose-product-main";

  final int? prospectId;
  final int? prospectPosId;
  final String? connectionType;

  ChooseProductScreen(
      {Key? key,
      required this.prospectId,
      required this.prospectPosId,
      required this.connectionType})
      : super(key: key);

  @override
  _ChooseProductScreenState createState() => _ChooseProductScreenState();
}

class _ChooseProductScreenState extends State<ChooseProductScreen> {
  bool _isLoading = false;
  int? _isZeroCost = 0;

  bool? _lifeInsCovered = false;
  bool? _assetInsCovered = false;
  bool? _isSecondHandProduct = false;
  bool? _isSelfRegistered = false;

  bool? _maintenanceCovered = false;
  bool? _isBundle = false;
  bool _isInvalidAttachedProduct = false;

  int _packageTotalPrice = 0;
  int _packageTotalQuantity = 0;
  int _primaryUnitPrice = 0;
  int _primaryQuantity = 1;
  int _packageMaxQuantity = 2;
  List<Map<String, dynamic>> _attachedProducts = [];

  // productPrice //
  final _productPriceFocusNode = FocusNode();
  final _productPriceController = TextEditingController();

  // productQuantity //
  final _productQuantityFocusNode = FocusNode();
  final _productQuantityController = TextEditingController(text: "1");

  Map<String, dynamic>? _brandSelected;
  Map<String, dynamic> _defaultBrandSelected = {
    "brandId": 0,
    "brandName": "",
    "brandCategory": "",
    "merchantId": "",
  };

  Map<String, dynamic>? _productSelected;
  Map<String, dynamic>? _defaultProductSelected;

  final GlobalKey<FormState> _formKey = GlobalKey();
  Map<String, dynamic> _productFormData = {
    'posId': '',
    'productId': 'm',
    'assetPrice': '',
    'productQuantity': 1,
  };

  void _resetData() {
    setState(() {
      _brandSelected = Map.from(_defaultBrandSelected);
      _productSelected = _defaultProductSelected != null
          ? Map.from(_defaultProductSelected!)
          : null;
      _attachedProducts = [];
      _isBundle = false;
      _packageTotalPrice = 0;
      _packageTotalQuantity = 0;
    });
  }

  void _setBrandSelected(Map<String, dynamic> item) {
    setState(() {
      _brandSelected = Map.from(item);
      _productSelected = _defaultProductSelected != null
          ? Map.from(_defaultProductSelected!)
          : null;
    });
  }

  void _setProductSelected(Map<String, dynamic> item) {
    setState(() {
      _productSelected = Map.from(item);
      AppLogger.i('_productSelected : $_productSelected');

      _packageMaxQuantity = _productSelected != null &&
              _productSelected!["productCategoryId"] != 1 &&
              _productSelected!["productCategoryId"] != 2 &&
              _productSelected!["productCategoryId"] != 17
          ? 5
          : 2;
      _productPriceController.text =
          NumberFormat("#,###").format(_productSelected!["productPrice"]);

      _calculatePackage();
    });
  }

  void _setAttachedProductListSelected(Map<String, dynamic> item) {
    setState(() {
      _attachedProducts.add(item);
    });
    _calculatePackage();
  }

  void _onChangeIsZeroCost(int? isZeroCost) async {
    setState(() {
      _isZeroCost = isZeroCost;
      _resetData();
    });
  }

  onChangeProductBundleSelection(bool newValue) {
    setState(() {
      _isBundle = newValue;
    });
    if (newValue == false) {
      _productQuantityController.text = "1";
    }
  }

  void _calculatePackage() {
    _primaryUnitPrice =
        _productPriceController.text.trim().replaceAll(",", "") != ""
            ? int.parse(_productPriceController.text.trim().replaceAll(",", ""))
            : 0;
    if (_isBundle!) {
      _primaryQuantity =
          _productQuantityController.text.trim().replaceAll(",", "") != ""
              ? int.parse(
                  _productQuantityController.text.trim().replaceAll(",", ""))
              : 0;
    } else {
      _productQuantityController.text = "1";
      _primaryQuantity = 1;
    }

    _packageTotalPrice = _primaryUnitPrice * _primaryQuantity;
    _packageTotalQuantity = _primaryQuantity;

    if (_attachedProducts.length > 0) {
      _attachedProducts.forEach((prod) {
        final attachedProductQuantity =
            int.tryParse(prod['quantity'].toString()) ?? 0;
        final attachedProductPrice =
            int.tryParse(prod['productPrice'].toString()) ?? 0;
        final attachedProductAmount =
            attachedProductQuantity * attachedProductPrice;
        _packageTotalQuantity += attachedProductQuantity;
        _packageTotalPrice += attachedProductAmount;
      });
    }
  }

  void _saveProduct() {
    _isInvalidAttachedProduct = false;
    ;

    if (_productSelected == null) {
      showAlertModal(
          context: context, message: "No product selected.", onDismiss: () {});
    } else {
      if (!_formKey.currentState!.validate()) {
        // Invalid!
        return;
      }

      if (_isBundle! && _attachedProducts.length == 0) {
        _isInvalidAttachedProduct = true;
        return;
      }

      _formKey.currentState!.save();
      String? _message = 'Something went wrong.';
      showConfirmation(
          context: context,
          message: "Are you sure you want to create new product package?",
          onYes: () async {
            await showWaitingModal(
                context: context,
                message: "New product package is creating...",
                onWaiting: () async {
                  try {
                    _calculatePackage();
                    var _totalMonthlyMaintCostPerVisit = _maintenanceCovered!
                        ? (_productSelected!["costPerVisit"] *
                            1 /
                            _productSelected!["intervalOfVisit"] *
                            1)
                        : 0;
                    var _zeroCostTotalMaintCost = (_isZeroCost! > 0 &&
                            _maintenanceCovered!)
                        ? (((_totalMonthlyMaintCostPerVisit *
                                        _productSelected!['zeroCostPmtTimes']) /
                                    100)
                                .ceil() *
                            100)
                        : 0;

                    Map<String, dynamic> _recProductPackage = {
                      'prospectId': widget.prospectId,

                      'productId': _productSelected!['productId'],
                      'isBundle': _isBundle! ? 1 : 0,
                      'quantity': _productQuantityController.text.trim(),
                      'primaryUnitPrice': _primaryUnitPrice,
                      'primaryTotalPrice': _primaryUnitPrice * _primaryQuantity,
                      'packageTotalPrice': _packageTotalPrice,
                      'isPriceLocked': _productSelected!['isPriceLocked'],

                      'financialSchemeId':
                          _productSelected!['financialSchemeId'],
                      'financialSchemeName':
                          _productSelected!['financialSchemeName'],

                      'paymentAtEnd':
                          _productSelected!['pmtType'] == 'end' ? 1 : 0,
                      'minAmountFinanced':
                          _productSelected!['minAmountFinanced'],
                      'minInstallmentAmount':
                          _productSelected!['minInstallmentAmount'],
                      'otpFeePercentage': _productSelected!['otpFeePercentage'],
                      'merchantDiscountRate':
                          _productSelected!['merchantDiscountRate'],

                      // Maintenance //
                      'maintenanceCovered': _maintenanceCovered,
                      'maintSchemeId': _productSelected!['maintSchemeId'],
                      'maintSchemeName': _productSelected!['maintSchemeName'],
                      'costPerVisit': _productSelected!['costPerVisit'],
                      'intervalOfVisit': _productSelected!['intervalOfVisit'],
                      'totalMonthlyMaintCostPerVisit':
                          _totalMonthlyMaintCostPerVisit,

                      // Insurance //
                      'insLifeCovered': _lifeInsCovered,
                      'insAssetCovered': _assetInsCovered,
                      'isSecondHandProduct': _isSecondHandProduct,
                      'isSelfRegistered': _isSelfRegistered,

                      // zeroCost //
                      'isZeroCost': _isZeroCost,
                      'zeroCostPmtTimes': _productSelected!['zeroCostPmtTimes'],
                      'zeroCostTotalMaintCost': _zeroCostTotalMaintCost,

                      'allowedDurationMin':
                          _productSelected!['pmtType'] == 'end'
                              ? _productSelected!['endDurationMin']
                              : _productSelected!['durationMin'],
                      'allowedDurationInterval':
                          _productSelected!['pmtType'] == 'end'
                              ? _productSelected!['endDurationInterval']
                              : _productSelected!['durationInterval'],
                      'allowedDurationMax':
                          _productSelected!['pmtType'] == 'end'
                              ? _productSelected!['endDurationMax']
                              : _productSelected!['durationMax'],
                      'allowedPmtPeriodicity':
                          _productSelected!['pmtPeriodicity'],
                      'allowedDepositPercentageMin':
                          _productSelected!['pmtType'] == 'end'
                              ? _productSelected!['endDepositPercentageMin']
                              : _productSelected!['depositPercentageMin'],
                      'allowedDepositPercentageInterval':
                          _productSelected!['pmtType'] == 'end'
                              ? _productSelected![
                                  'endDepositPercentageInterval']
                              : _productSelected!['depositPercentageInterval'],
                      'allowedDepositPercentageMax':
                          _productSelected!['pmtType'] == 'end'
                              ? _productSelected!['endDepositPercentageMax']
                              : _productSelected!['depositPercentageMax'],
                      'allowedAdminFeePercentage':
                          _productSelected!['adminFeePercentage'],
                      'allowedInterestRate': _productSelected!['interestRate'],

                      'packageRemark': "From ca app of prospect id " +
                          widget.prospectId.toString(),

                      'attachedProduct': _attachedProducts,
                    };

                    await Provider.of<ProductPackageProvider>(context,
                            listen: false)
                        .createRecord(widget.prospectId, _recProductPackage)
                        .then((value) {
                      _message = Provider.of<ProductPackageProvider>(context,
                              listen: false)
                          .responseMessage;
                    });
                  } catch (error) {
                    _message = error.toString();
                    print(_message);
                  }
                });
            await showAlertModal(
                context: context,
                message: _message,
                onDismiss: () {
                  Navigator.pop(context);
                });
          });
    }
  }

  void initData() async {
    _resetData();
  }

  @override
  void initState() {
    initData();

    super.initState();
  }

  @override
  void dispose() {
    _productPriceFocusNode.dispose();
    _productPriceController.dispose();

    _productQuantityFocusNode.dispose();
    _productQuantityController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final deviceSize = MediaQuery.of(context).size;

    // Product Price //
    var _productPriceFormField = TextFormField(
      decoration: InputDecoration(
        labelText: "Indicated Price",
        contentPadding: EdgeInsets.all(0),
      ),
      textInputAction: TextInputAction.done,
      focusNode: _productPriceFocusNode,
      keyboardType:
          TextInputType.numberWithOptions(signed: true, decimal: true),
      inputFormatters: [
        ThousandsFormatter(),
      ],
      controller: _productPriceController,
      onSaved: (String? value) {
        setState(() {
          _productFormData['indicatedPrice'] = value;
        });
      },
      validator: (value) {
        if (value!.isEmpty) {
          return "Please enter a price";
        }
        if (int.parse(value.replaceAll(',', '')) == 0) {
          return "Product price must be greater than 0.";
        }
        return null;
      },
      textAlign: TextAlign.right,
      style: TextStyle(fontWeight: FontWeight.bold, color: Colors.red),
      enabled: _productSelected == null
          ? false
          : _productSelected!["isPriceLocked"] == 0,
    );

    // Product Quantity //
    var _productQuantityFormField = TextFormField(
      decoration: InputDecoration(
        labelText: "Quantity",
        contentPadding: EdgeInsets.all(0),
      ),
      textInputAction: TextInputAction.done,
      focusNode: _productQuantityFocusNode,
      keyboardType:
          TextInputType.numberWithOptions(signed: true, decimal: true),
      inputFormatters: [
        ThousandsFormatter(),
      ],
      controller: _productQuantityController,
      onSaved: (String? value) {
        setState(() {
          _productFormData['quantity'] = value;
        });
      },
      onChanged: (value) {
        _calculatePackage();
      },
      validator: (value) {
        if (value!.isEmpty) {
          return "Please enter product quantity.";
        } else {
          if (int.parse(value.replaceAll(',', '')) == 0) {
            return "Quantity must be greater than 0.";
          }
          if (int.parse(value.replaceAll(',', '')) > 5) {
            return "Quantity must be less than or equal to 5.";
          }
          if (_packageTotalQuantity > _packageMaxQuantity) {
            return "You can only add up to $_packageMaxQuantity products to the bundle.";
          }
        }

        return null;
      },
      textAlign: TextAlign.right,
      style: TextStyle(fontWeight: FontWeight.bold, color: Colors.red),
      enabled: _isBundle == true &&
              (_productSelected != null &&
                  _productSelected!["productCategoryId"] != 1 &&
                  _productSelected!["productCategoryId"] != 2 &&
                  _productSelected!["productCategoryId"] != 17)
          ? true
          : false,
    );

    return Scaffold(
      backgroundColor: Colors.white,
      // resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: Text(
          'CHOOSE PRODUCT',
          style: TextStyle(color: Colors.white),
        ),
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: Padding(
        padding: EdgeInsets.all(10),
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      // PRODUCT TYPE //
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          InkWell(
                            onTap: () async {
                              setState(() {
                                _isZeroCost = 0;
                                _resetData();
                              });
                            },
                            child: Stack(
                              children: <Widget>[
                                Container(
                                  height: 46,
                                  width: 150,
                                  decoration: BoxDecoration(
                                    border:
                                        Border.all(color: Colors.teal[500]!),
                                    color: _isZeroCost == 0
                                        ? Theme.of(context).primaryColor
                                        : Colors.white,
                                  ),
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    Radio(
                                      focusColor: Colors.white,
                                      groupValue: _isZeroCost,
                                      onChanged: _onChangeIsZeroCost,
                                      value: 0,
                                      activeColor: Colors.white,
                                    ),
                                    Text(
                                      "NORMAL",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: _isZeroCost != 0
                                              ? Theme.of(context).primaryColor
                                              : Colors.white),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          InkWell(
                            onTap: () async {
                              setState(() {
                                _isZeroCost = 1;
                                _resetData();
                              });
                            },
                            child: Stack(
                              children: <Widget>[
                                Container(
                                  height: 46,
                                  width: 150,
                                  decoration: BoxDecoration(
                                    border:
                                        Border.all(color: Colors.teal[500]!),
                                    color: _isZeroCost == 1
                                        ? Theme.of(context).primaryColor
                                        : Colors.white,
                                  ),
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    Radio(
                                      focusColor: Colors.white,
                                      groupValue: _isZeroCost,
                                      onChanged: _onChangeIsZeroCost,
                                      value: 1,
                                      activeColor: Colors.white,
                                    ),
                                    Text(
                                      "ZERO-COST",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: _isZeroCost != 1
                                              ? Theme.of(context).primaryColor
                                              : Colors.white),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          )
                        ],
                      ),

                      SizedBox(
                        height: 5,
                      ),

                      // BRAND //
                      Container(
                        width: deviceSize.width,
                        padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'BRAND',
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.teal[600]),
                              ),
                              TextButtonWidget(
                                text: _brandSelected!["brandId"] == 0
                                    ? "SELECT"
                                    : "CHANGE",
                                iconData: _brandSelected!["brandId"] == 0
                                    ? Icons.add
                                    : Icons.edit,
                                onTap: () {
                                  showModalBottomSheet(
                                      isScrollControlled: true,
                                      context: context,
                                      isDismissible: false,
                                      enableDrag: false,
                                      builder: (BuildContext context) {
                                        return StatefulBuilder(builder:
                                            (BuildContext context,
                                                StateSetter
                                                    setModalState /*You can rename this!*/) {
                                          return BrandSelectionModalWidget(
                                            isZeroCost: _isZeroCost,
                                            prospectPosId: widget.prospectPosId,
                                            connectionType:
                                                widget.connectionType,
                                            setBrandSelected: _setBrandSelected,
                                          );
                                        });
                                      });
                                },
                              ),
                            ],
                          ),
                          _brandSelected!["brandId"] == 0
                              ? SizedBox()
                              : Column(
                                  children: [
                                    Divider(
                                      height: 0,
                                    ),
                                    SizedBox(height: 5),
                                    ItemInfoWidget(
                                      title: "Category",
                                      value: _brandSelected!["brandCategory"],
                                    ),
                                    Divider(),
                                    ItemInfoWidget(
                                      title: "Name",
                                      value: _brandSelected!["brandName"],
                                    ),
                                    SizedBox(height: 10),
                                  ],
                                ),
                        ]),
                      ),

                      // PRODUCT //
                      _brandSelected!["brandId"] == 0
                          ? SizedBox()
                          : SizedBox(
                              height: 5,
                            ),
                      _brandSelected!["brandId"] == 0
                          ? SizedBox()
                          : Container(
                              width: deviceSize.width,
                              padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
                              decoration: BoxDecoration(
                                border: Border.all(color: Colors.grey),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Column(children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'PRODUCT',
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.teal[600]),
                                    ),
                                    TextButtonWidget(
                                      text: _productSelected == null
                                          ? "SELECT"
                                          : "CHANGE",
                                      iconData: _productSelected == null
                                          ? Icons.add
                                          : Icons.edit,
                                      onTap: () {
                                        showModalBottomSheet(
                                          isScrollControlled: true,
                                          context: context,
                                          isDismissible: false,
                                          enableDrag: false,
                                          builder: (BuildContext context) {
                                            return StatefulBuilder(builder:
                                                (BuildContext context,
                                                    StateSetter
                                                        setModalState /*You can rename this!*/) {
                                              return ProductSelectionModalWidget(
                                                isZeroCost: _isZeroCost,
                                                prospectPosId:
                                                    widget.prospectPosId,
                                                merchantId: _brandSelected![
                                                    "merchantId"],
                                                brandId:
                                                    _brandSelected!["brandId"],
                                                connectionType:
                                                    widget.connectionType,
                                                setProductSelected:
                                                    _setProductSelected,
                                              );
                                            });
                                          },
                                        );
                                      },
                                    ),
                                  ],
                                ),
                                _productSelected == null
                                    ? SizedBox()
                                    : Form(
                                        key: _formKey,
                                        autovalidateMode:
                                            AutovalidateMode.always,
                                        child: Column(
                                          children: [
                                            Divider(
                                              height: 0,
                                            ),
                                            SizedBox(height: 5),
                                            ItemInfoWidget(
                                              title: "Code",
                                              value: _productSelected![
                                                      "productCode"] ??
                                                  '',
                                            ),
                                            Divider(),
                                            ItemInfoWidget(
                                              title: "Name",
                                              value: _productSelected![
                                                  "productName"],
                                            ),
                                            Divider(),
                                            ItemInfoWidget(
                                              title: "Financial Scheme",
                                              value: _productSelected![
                                                  "financialSchemeName"],
                                            ),
                                            Divider(),
                                            _productPriceFormField,
                                            _productSelected != null &&
                                                    _productSelected![
                                                            "isPriceLocked"] ==
                                                        1
                                                ? Text(
                                                    'The price of this product is not adjustable.',
                                                    style: TextStyle(
                                                        color: Colors.red,
                                                        fontStyle:
                                                            FontStyle.italic),
                                                  )
                                                : SizedBox(),
                                            SizedBox(
                                              height: 5,
                                            ),
                                            _productQuantityFormField,
                                            SizedBox(
                                              height: 10,
                                            ),
                                            Visibility(
                                              visible: _productSelected !=
                                                      null &&
                                                  _productSelected![
                                                          "productCategoryType"] !=
                                                      null,
                                              child: LabeledCheckbox(
                                                label: 'Life Insurance',
                                                value: _lifeInsCovered ?? false,
                                                onChanged: (newValue) {
                                                  setState(() {
                                                    _lifeInsCovered = newValue;
                                                  });
                                                },
                                              ),
                                            ),
                                            Visibility(
                                              visible: _productSelected !=
                                                      null &&
                                                  _productSelected![
                                                          "productCategoryType"] ==
                                                      'moto',
                                              child: LabeledCheckbox(
                                                label: 'Asset Insurance',
                                                value:
                                                    _assetInsCovered ?? false,
                                                onChanged: (newValue) {
                                                  setState(() {
                                                    _assetInsCovered = newValue;
                                                  });
                                                },
                                              ),
                                            ),
                                            Visibility(
                                              visible: _productSelected !=
                                                      null &&
                                                  _productSelected![
                                                          "productCategoryType"] !=
                                                      null,
                                              child: LabeledCheckbox(
                                                label: 'Second Hand Product',
                                                value: _isSecondHandProduct ??
                                                    false,
                                                onChanged: (newValue) {
                                                  setState(() {
                                                    _isSecondHandProduct =
                                                        newValue;
                                                    AppLogger.d(
                                                        'isSecondHandProduct : $_isSecondHandProduct');
                                                  });
                                                },
                                              ),
                                            ),
                                            Visibility(
                                              visible: _productSelected !=
                                                      null &&
                                                  _productSelected![
                                                          "productCategoryType"] ==
                                                      'moto',
                                              child: LabeledCheckbox(
                                                label: 'Self Registered',
                                                value:
                                                    _isSelfRegistered ?? false,
                                                onChanged: (newValue) {
                                                  setState(() {
                                                    _isSelfRegistered =
                                                        newValue;
                                                    AppLogger.d(
                                                        '_isSelfRegistered : $_isSelfRegistered');
                                                  });
                                                },
                                              ),
                                            ),
                                            Visibility(
                                              visible: _productSelected !=
                                                      null &&
                                                  _productSelected![
                                                          "maintSchemeId"] !=
                                                      null,
                                              child: LabeledCheckbox(
                                                label: 'Maintenance Covered',
                                                value: _maintenanceCovered ??
                                                    false,
                                                onChanged: (newValue) {
                                                  setState(() {
                                                    _maintenanceCovered =
                                                        newValue;
                                                  });
                                                },
                                              ),
                                            ),
                                            LabeledCheckbox(
                                              label: 'PRODUCT BUNDLE',
                                              textStyle: TextStyle(
                                                  color: Colors.red,
                                                  fontWeight: FontWeight.bold),
                                              value: _isBundle ?? false,
                                              onChanged: (newValue) {
                                                setState(() {
                                                  _isBundle = newValue;
                                                  if (newValue == false) {
                                                    _productQuantityController
                                                        .text = "1";
                                                  }
                                                  _calculatePackage();
                                                });
                                              },
                                            ),
                                            SizedBox(
                                              height: 5,
                                            ),
                                          ],
                                        ),
                                      ),
                              ]),
                            ),

                      SizedBox(
                        height: 5,
                      ),

                      // PRODUCT BUNDLE //
                      _isBundle == false || _productSelected == null
                          ? SizedBox()
                          : Container(
                              width: deviceSize.width,
                              padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
                              decoration: BoxDecoration(
                                border: Border.all(color: Colors.grey),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Column(children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'PRODUCT BUNDLE',
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.teal[600]),
                                    ),
                                    TextButtonWidget(
                                      text: "ADD",
                                      iconData: Icons.add,
                                      onTap: _packageTotalQuantity >=
                                              _packageMaxQuantity
                                          ? null
                                          : () {
                                              showModalBottomSheet(
                                                  isScrollControlled: true,
                                                  context: context,
                                                  builder:
                                                      (BuildContext context) {
                                                    return StatefulBuilder(
                                                        builder: (BuildContext
                                                                context,
                                                            StateSetter
                                                                setModalState /*You can rename this!*/) {
                                                      return AttachedProductModalWidget(
                                                        connectionType: widget
                                                            .connectionType,
                                                        packageTotalQuantity:
                                                            _packageTotalQuantity,
                                                        packageMaxQuantity:
                                                            _packageMaxQuantity,
                                                        productSelected:
                                                            _productSelected,
                                                        setAttachedProductSelected:
                                                            _setAttachedProductListSelected,
                                                      );
                                                    });
                                                  });
                                            },
                                    ),
                                  ],
                                ),
                                Divider(
                                  height: 0,
                                ),
                                SizedBox(
                                  height: 8,
                                ),
                                _brandSelected!["productId"] == 0
                                    ? SizedBox()
                                    : Column(
                                        children: [
                                          // SUMMARY //
                                          Container(
                                            width: deviceSize.width,
                                            padding: EdgeInsets.all(15),
                                            decoration: BoxDecoration(
                                                border: Border.all(
                                                    color: Colors.grey),
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                                color: Colors.grey[200]),
                                            child: Column(
                                              children: [
                                                ItemInfoWidget(
                                                  title: "TOTAL BUNDLE PRICE",
                                                  value:
                                                      "${NumberFormat('#,###').format(_packageTotalPrice)} MMK",
                                                ),
                                                Divider(),
                                                ItemInfoWidget(
                                                  title:
                                                      "TOTAL BUNDLE QUANTITY",
                                                  value:
                                                      "$_packageTotalQuantity",
                                                ),
                                                _packageTotalQuantity !=
                                                        _packageMaxQuantity
                                                    ? SizedBox()
                                                    : SizedBox(
                                                        height: 10,
                                                      ),
                                                _packageTotalQuantity <=
                                                        _packageMaxQuantity
                                                    ? SizedBox()
                                                    : Align(
                                                        child: Text(
                                                          "You can only add up to $_packageMaxQuantity products to the bundle.",
                                                          style: TextStyle(
                                                              color:
                                                                  Colors.red),
                                                        ),
                                                        alignment: Alignment
                                                            .centerLeft),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                SizedBox(
                                  height: 10,
                                ),
                                _attachedProducts.length == 0
                                    ? SizedBox()
                                    : Align(
                                        child: Text("ATTACHED PRODUCTS",
                                            style: TextStyle(
                                              color: Colors.red,
                                              fontWeight: FontWeight.bold,
                                            )),
                                        alignment: Alignment.centerLeft,
                                      ),
                                _attachedProducts.length == 0
                                    ? SizedBox()
                                    : Divider(),
                                Container(
                                  child: ListView.separated(
                                      shrinkWrap: true,
                                      itemCount: _attachedProducts.length,
                                      separatorBuilder: (context, index) {
                                        return Divider();
                                      },
                                      itemBuilder: (context, i) {
                                        return ListTile(
                                          dense: true,
                                          // isThreeLine: true,
                                          contentPadding: EdgeInsets.zero,
                                          visualDensity: VisualDensity(
                                              horizontal: 0, vertical: -4),
                                          title: Wrap(
                                            children: [
                                              Text("${i + 1}. "),
                                              Text(
                                                "[${_attachedProducts[i]['productType'].toString().toUpperCase()}]",
                                                style: TextStyle(
                                                    fontWeight: FontWeight.bold,
                                                    color: Colors.grey[700]),
                                              ),
                                              Text(
                                                  " ${_attachedProducts[i]['productName']}"),
                                            ],
                                          ),
                                          subtitle: Padding(
                                            padding: EdgeInsets.only(
                                                left: 15,
                                                top: 0,
                                                right: 0,
                                                bottom: 0),
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                _attachedProducts[i][
                                                            'productTypeDetail'] !=
                                                        null
                                                    ? Text(_attachedProducts[i][
                                                            'productTypeDetail']
                                                        .toString())
                                                    : SizedBox(),
                                                Text(
                                                    "${NumberFormat('#,###').format(_attachedProducts[i]['productPrice'])} x ${_attachedProducts[i]['quantity'].toString()} = ${NumberFormat('#,###').format(_attachedProducts[i]['productPrice'] * _attachedProducts[i]['quantity'])} MMK"),
                                              ],
                                            ),
                                          ),
                                          trailing: IconButton(
                                            icon: Icon(Icons.delete,
                                                color: Colors.red),
                                            onPressed: () {
                                              showModalBottomSheet(
                                                  context: context,
                                                  isScrollControlled: true,
                                                  builder: (context) {
                                                    return ConfirmationModalBottomSheet(
                                                        "Are you sure you want to remove the selected secondary product?",
                                                        () async {
                                                      setState(() {
                                                        _isLoading = true;
                                                        _attachedProducts
                                                            .removeAt(i);
                                                        _calculatePackage();
                                                      });

                                                      _isLoading = false;
                                                      Navigator.pop(context);
                                                      showModalBottomSheet(
                                                          context: context,
                                                          isScrollControlled:
                                                              true,
                                                          builder: (context) {
                                                            return AlertModalBottomWidget(
                                                                "The selected secondary product is successfully removed.",
                                                                () {
                                                              Navigator.pop(
                                                                  context);
                                                            });
                                                          });
                                                    });
                                                  });
                                            },
                                          ),
                                        );
                                      }),
                                ),
                                SizedBox(
                                  height: 5,
                                ),
                                _isInvalidAttachedProduct
                                    ? Text(
                                        'Please add secondary products before saving.',
                                        style: TextStyle(
                                            color: Colors.red,
                                            fontStyle: FontStyle.italic),
                                      )
                                    : SizedBox(),
                                SizedBox(
                                  height: 10,
                                ),
                              ]),
                            ),

                      SizedBox(
                        height: 10,
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 5,
              ),
              Divider(),
              Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    new Expanded(
                      child: ButtonWidget(
                        text: "SAVE PRODUCT",
                        isWhiteBackgroundColor: false,
                        onPressed: _saveProduct,
                      ),
                    ),
                  ]),
              kSpaceVertical8,
              CopyrightNotice(),
            ]),
      ),
    );
  }
}
