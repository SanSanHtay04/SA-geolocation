import 'package:flutter/material.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:provider/provider.dart';
import 'package:sales/data/local/db_sqlite_helper.dart';
import 'package:sales/providers/providers.dart';
import 'package:sales/data/local/models/models.dart';

import 'package:sales/widgets/waiting_modal_bottom_widget.dart';
import '../../../../widgets/confirmation_modal_bottom_widget.dart';
import '../../../../widgets/deprecated/alert_modal_bottom_widget.dart';
import '../../../../widgets/deprecated/button_widget.dart';
import '../../../../widgets/deprecated/text_form_input.dart';

class EditAppDocModal extends StatefulWidget {
  final int? applicationId;
  final int? docDetId;
  final int? userId;
  final String? connectionType;

  EditAppDocModal(
      {required this.applicationId,
      required this.docDetId,
      required this.userId,
      required this.connectionType});

  @override
  _EditAppDocModalState createState() => _EditAppDocModalState();
}

class _EditAppDocModalState extends State<EditAppDocModal> {
  bool _isLoading = false;

  int? _documentIdSelected;
  String? _docProductTypeSelected = 'not_car';
  Map<String, dynamic>? _docDet;
  List<Map<String, dynamic>> _docTypes = [];

  final GlobalKey<FormState> _formKey = GlobalKey();

  // docDetRemark //
  final _docDetRemarkController = TextEditingController();

  void _setDocDetRemark(String? value) {}

  void _onChangeDocProductTypeSelection(String? strProdType) async {
    setState(() {
      _docProductTypeSelected = strProdType;
    });
    await _getAppDocuments(strProdType, widget.applicationId);
  }

  Future<void> _getAppDocuments(
      String? strProductType, int? applicationId) async {
    setState(() {
      _isLoading = true;
      _documentIdSelected = null;
    });

    try {
      if (widget.connectionType == 'online') {
        await Provider.of<AppDocumentProvider>(context, listen: false)
            .getAppDocsByProductType(strProductType, applicationId)
            .then((value) {
          setState(() {
            _docTypes =
                Provider.of<AppDocumentProvider>(context, listen: false).items;
            _isLoading = false;
          });
        });
      } else {
        List<Map<String, dynamic>> offlineAppDocuments = await DBSqliteHelper()
            .getAppDocuments(_docProductTypeSelected, applicationId);
        setState(() {
          _docTypes = List<Map<String, dynamic>>.from(offlineAppDocuments);
          _isLoading = false;
        });
      }
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  void _clearAllFields() {
    _initData();
  }

  void _saveDocDetail() {
    if (!_formKey.currentState!.validate()) {
      // Invalid!
      return;
    }
    _formKey.currentState!.save();
    if (widget.docDetId == null) {
      // create //
      showConfirmation(context: context, message: "Are you sure you want to add new doc?", onYes: () async {
        String? _message = 'Something went wrong.';
        await showWaitingModal(context: context, message: "New Document is creating...", onWaiting: () async {
          try {
            Map<String, dynamic> recAppDocDet = {
              'applicationId': widget.applicationId,
              'documentId': _documentIdSelected,
              'docDetRemark': _docDetRemarkController.text.trim(),
            };

            if (widget.connectionType == 'online') {
              await Provider.of<AppDocDetProvider>(context, listen: false)
                  .createRecord(widget.applicationId, recAppDocDet)
                  .then((value) async {
                _message = Provider.of<AppDocDetProvider>(context, listen: false).responseMessage;
                await _getAppDocuments(
                    _docProductTypeSelected, widget.applicationId);
                _docDetRemarkController.text = "";
              });
            } else {
              Map<String, dynamic> offlineAppDocDetail =
                  Map<String, dynamic>.from(recAppDocDet);

              _message = 'New document is successfully created.';
              await DBSqliteHelper().createAppDocDetail(
                  AppDocDetail.fromMap(offlineAppDocDetail),
                  widget.applicationId);
              await _getAppDocuments(
                  _docProductTypeSelected, widget.applicationId);
              _docDetRemarkController.text = "";
            }
          } catch (error) {
            _message = error.toString();
          }
        });
        await showAlertModal(context: context, message: _message, onDismiss: () {});
      });
    } else {
      // edit //
      showConfirmation(context: context, message: "Are you sure you want to edit the selected doc?", onYes: () async {
        String? _message = 'Something went wrong.';
        await showWaitingModal(context: context, message: "The selected document is updating...", onWaiting: () async {
          try {
            if (widget.connectionType == 'online') {
              await Provider.of<AppDocDetProvider>(context, listen: false)
                  .editRecord(widget.applicationId, widget.docDetId, {
                'docDetRemark': _docDetRemarkController.text.trim(),
              }).then((value) async {
                _message = Provider.of<AppDocDetProvider>(context, listen: false).responseMessage;
              });
            } else {
              _message = "Application's document is successfully updated.";
              Map<String, dynamic> offlineDocDet = {
                'docDetRemark': _docDetRemarkController.text.trim(),
              };

              await DBSqliteHelper()
                  .updateAppDocDetail(offlineDocDet, widget.docDetId);
            }
          } catch (error) {
            _message = error.toString();
          }
        });
        await showAlertModal(context: context, message: _message, onDismiss: () {
          Navigator.pop(context);
        });
      });
      // showModalBottomSheet(
      //     context: context,
      //     isScrollControlled: true,
      //     builder: (context) {
      //       String? _message = 'Something went wrong.';
      //       return ConfirmationModalBottomSheet(
      //           "Are you sure you want to edit the selected of doc?", () async {
      //         try {
      //           setState(() {
      //             _isLoading = true;
      //           });

      //           if (widget.connectionType == 'online') {
      //             await Provider.of<AppDocDetProvider>(context, listen: false)
      //                 .editRecord(widget.applicationId, widget.docDetId, {
      //               'docDetRemark': _docDetRemarkController.text.trim(),
      //             }).then((value) async {
      //               setState(() {
      //                 _message =
      //                     Provider.of<AppDocDetProvider>(context, listen: false)
      //                         .responseMessage;
      //                 _isLoading = false;
      //               });
      //             });
      //           } else {
      //             _message = "Application's document is successfully updated.";
      //             Map<String, dynamic> offlineDocDet = {
      //               'docDetRemark': _docDetRemarkController.text.trim(),
      //             };

      //             await DBSqliteHelper()
      //                 .updateAppDocDetail(offlineDocDet, widget.docDetId);
      //             _isLoading = false;
      //           }
      //         } catch (error) {
      //           setState(() {
      //             _message = error.toString();
      //             _isLoading = false;
      //           });
      //         }

      //         Navigator.pop(context);
      //         showModalBottomSheet(
      //             context: context,
      //             isScrollControlled: true,
      //             builder: (context) {
      //               return AlertModalBottomWidget(_message, () {
                      
      //                 Navigator.pop(context);
      //               });
      //             });
      //       });
      //     });
    }
  }

  Future<void> _getAppDoc(int? applicationId, int? docDetId) async {
    setState(() {
      _isLoading = true;
    });

    try {
      if (widget.connectionType == 'online') {
        await Provider.of<AppDocDetProvider>(context, listen: false)
            .getRecord(applicationId, docDetId)
            .then((value) {
          setState(() {
            _docDet =
                Provider.of<AppDocDetProvider>(context, listen: false).item;
            _isLoading = false;
          });
        });
      } else {
        Map<String, dynamic>? offlineDocDet =
            await DBSqliteHelper().getAppDocDetail(docDetId);
        setState(() {
          _docDet = Map<String, dynamic>.from(offlineDocDet!);
          _isLoading = false;
        });
      }
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  void _initData() async {
    if (widget.docDetId == null) {
      _docProductTypeSelected = "not_car";
      await _getAppDocuments(_docProductTypeSelected, widget.applicationId);
      _docDetRemarkController.text = "";
    } else {
      await _getAppDoc(widget.applicationId, widget.docDetId);
      if (_docDet != null) {
        _docDetRemarkController.text = _docDet!['docDetRemark'] ?? '';
      }
    }
  }

  @override
  void initState() {
    _initData();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var _deviceSize = MediaQuery.of(context).size;

    // App Doc Type //
    Widget _buildAppDocDropdownButton() {
      return DropdownButtonFormField<int>(
        isExpanded: true,
        dropdownColor: Colors.white,
        decoration: InputDecoration(
          contentPadding: EdgeInsets.fromLTRB(15, 13, 12, 13),
          labelText: "Document",
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
          ),
        ),
        items: _docTypes.map((item) {
          return DropdownMenuItem<int>(
            value: item["documentId"],
            child: Container(
              // width: _deviceSize.width - 60,
              child: Text(
                "${item["docTypeName"]} / ${item["documentName"]}",
                overflow: TextOverflow.ellipsis,
              ),
            ),
          );
        }).toList(),
        value: _documentIdSelected ?? null,
        onChanged: (newValue) {
          setState(() {
            _documentIdSelected = newValue;
          });
        },
        validator: (value) {
          if (_documentIdSelected == null) {
            return "This field is required.";
          }
          return null;
        },
      );
    }

    return ModalProgressHUD(
      inAsyncCall: _isLoading,
      opacity: 0.5,
      progressIndicator: CircularProgressIndicator(
        valueColor:
            new AlwaysStoppedAnimation<Color>(Theme.of(context).primaryColor),
      ),
      child: Container(
        child: DraggableScrollableSheet(
            initialChildSize: 0.95,
            //set this as you want
            maxChildSize: 0.95,
            //set this as you want
            minChildSize: 0.95,
            //set this as you want
            expand: true,
            builder: (context, scrollController) {
              return ClipRRect(
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(20.0),
                    topRight: Radius.circular(20.0)),
                child: Container(
                  color: Colors.white,
                  child: Column(children: [
                    Container(
                      color: Colors.teal,
                      child: Stack(children: [
                        Container(
                          width: double.infinity,
                          height: 50.0,
                          child: Center(
                            child: Text(
                              "${widget.docDetId == null ? 'ADD NEW' : 'EDIT'} DOCUMENT",
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                  color: Colors.white),
                            ), // Your desired title
                          ),
                        ),
                        Positioned(
                          left: 0.0,
                          top: 0.0,
                          child: IconButton(
                            icon: Icon(
                              Icons.arrow_back,
                              color: Colors.white,
                            ), // Your desired icon
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          ),
                        ),
                      ]),
                    ),
                    // product type //
                    widget.docDetId != null
                        ? SizedBox()
                        : Container(
                            decoration: BoxDecoration(
                              border: Border(
                                bottom: BorderSide(color: Colors.grey),
                              ),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                new Radio(
                                  value: 'not_car',
                                  groupValue: _docProductTypeSelected,
                                  onChanged: _onChangeDocProductTypeSelection,
                                ),
                                new InkWell(
                                  child: Text(
                                    'NOT 4-wheeler ',
                                    style: new TextStyle(fontSize: 16.0),
                                  ),
                                  onTap: () {
                                    _onChangeDocProductTypeSelection('not_car');
                                  },
                                ),
                                new Radio(
                                  value: 'car',
                                  groupValue: _docProductTypeSelected,
                                  onChanged: _onChangeDocProductTypeSelection,
                                ),
                                new InkWell(
                                  child: new Text(
                                    '4-wheeler',
                                    style: new TextStyle(
                                      fontSize: 16.0,
                                    ),
                                  ),
                                  onTap: () {
                                    _onChangeDocProductTypeSelection('car');
                                  },
                                ),
                              ],
                            ),
                          ),
                    Expanded(
                      child: Container(
                        padding: EdgeInsets.fromLTRB(15, 5, 15, 10),
                        child: Form(
                          key: _formKey,
                          autovalidateMode: AutovalidateMode.always,
                          child: SingleChildScrollView(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  height: 10,
                                ),

                                widget.docDetId != null
                                    ? SizedBox()
                                    : _buildAppDocDropdownButton(),
                                widget.docDetId != null
                                    ? SizedBox()
                                    : SizedBox(
                                        height: 10,
                                      ),

                                // incomeSourceRemark //
                                TextFormInput(
                                  controller: _docDetRemarkController,
                                  label: "Remark",
                                  textInputAction: TextInputAction.done,
                                  isRequired: false,
                                  onSaved: _setDocDetRemark,
                                  maxLines: 2,
                                ),
                                SizedBox(
                                  height: 10,
                                ),

                                // Divider(
                                //   color: Colors.teal,
                                //   height: 0,
                                //   thickness: 1.0,
                                // ),
                                Container(
                                  color: Colors.white,
                                  child: Padding(
                                    padding: const EdgeInsets.all(10),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: <Widget>[
                                          Expanded(
                                            child: ButtonWidget(
                                              text: "CLEAR",
                                              isWhiteBackgroundColor: true,
                                              onPressed: _clearAllFields,
                                            ),
                                          ),
                                          Expanded(
                                            child: ButtonWidget(
                                              text: "SAVE",
                                              isWhiteBackgroundColor: false,
                                              onPressed: _saveDocDetail,
                                            ),
                                          ),
                                        ]),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ]),
                ),
              );
            }),
      ),
    );
  }
}
