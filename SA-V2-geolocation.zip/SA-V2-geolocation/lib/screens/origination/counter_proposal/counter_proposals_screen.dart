import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:sales/providers/application_provider.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/copyright_notice.dart';
import 'package:sales/widgets/waiting_modal_bottom_widget.dart';

import '../prospects/prospect_info_screen.dart';

class CounterProposalsScreen extends StatefulWidget {
  CounterProposalsScreen({
    super.key,
    required this.currentPosId,
    required this.userId,
    required this.userWorkPlaceId,
    required this.connectionType,
  });

  final int? currentPosId;
  final int? userId;
  final int? userWorkPlaceId;
  final String? connectionType;

  @override
  State<CounterProposalsScreen> createState() => _CounterProposalsScreenState();
}

class _CounterProposalsScreenState extends State<CounterProposalsScreen> {
  String? filter;
  List<Map<String, dynamic>> counter_proposals = [];

  Future<void> _reloadData() async {
    await this._getCounterProposals();
  }

  Future<void> _getCounterProposals() async {
    showWaitingModal(
        context: context,
        message: "List of counter proposals are loading...",
        onWaiting: () async {
          try {
            await Provider.of<ApplicationProvider>(context, listen: false).getCounterProposals().then((value) {
              setState(() {
                counter_proposals = Provider.of<ApplicationProvider>(context, listen: false).items;
              });
            });
          } catch (error) {
            print(error.toString());
          }
        });
  }

  void _onClickDetail(int? _prospectId) {
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => ProspectInfoScreen(
                prospectId: _prospectId,
                currentPosId: widget.currentPosId,
                userId: widget.userId,
                userWorkPlaceId: widget.userWorkPlaceId,
                connectionType: widget.connectionType,
                applicationType: 'cp',
              )),
    ).then((value) async {
      await _reloadData();
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      _reloadData();
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final deviceSize = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'COUNTER PROPOSAL (${counter_proposals.length})',
        ),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.refresh_rounded),
            onPressed: () async {
              this._reloadData();
            },
          ),
        ],
      ),
      body: Padding(
        padding: EdgeInsets.fromLTRB(5, 10, 5, 5),
        child: Column(children: <Widget>[
          Expanded(
            child: Container(
              child: RefreshIndicator(
                onRefresh: () => _reloadData(),
                child: counter_proposals.length == 0
                    ? Text(
                        "There is no application found.",
                      )
                    : ListView.builder(
                        itemCount: counter_proposals.length,
                        itemBuilder: (context, i) {
                          return Container(
                            width: deviceSize.width,
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.blue),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            margin: EdgeInsets.only(bottom: 5),
                            padding: EdgeInsets.all(10),
                            child: Column(children: [
                              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                                Text(
                                  '${counter_proposals[i]['customerFullName']}',
                                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.blue),
                                ),
                              ]),
                              SizedBox(
                                height: 10,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Column(
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                            'Gender: ',
                                            style: TextStyle(fontWeight: FontWeight.bold),
                                          ),
                                          Text('${counter_proposals[i]['gender'] == 'm' ? 'Male' : 'Female'}'),
                                        ],
                                      ),
                                    ],
                                  ),
                                  Column(
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                            'Birth Date: ',
                                            style: TextStyle(fontWeight: FontWeight.bold),
                                          ),
                                          Text('${DateFormat('dd/MM/yyyy').format(DateTime.parse(counter_proposals[i]['birthDate'].toString()))}'),
                                        ],
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              Divider(
                                height: 10,
                                thickness: 0.5,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'Contact No.:',
                                    style: TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                  Text('${counter_proposals[i]['phoneNo1']} ${counter_proposals[i]['phoneNo2'] != '' && counter_proposals[i]['phoneNo2'] != null ? (' - ' + counter_proposals[i]['phoneNo2']) : ''}'),
                                ],
                              ),
                              Divider(
                                height: 10,
                                thickness: 0.5,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'Reason:',
                                    style: TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                  Text('${counter_proposals[i]['cpReasonName']}'),
                                ],
                              ),
                              Divider(
                                height: 10,
                                thickness: 0.5,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'Counter:',
                                    style: TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                  Text(
                                    'at ${DateFormat('dd/MM/yyyy HH:mm').format(DateTime.parse(counter_proposals[i]['dtSentBackOrigination'].toString()))} by ${counter_proposals[i]['person_counter_proposal']['userFullName']}',
                                  ),
                                ],
                              ),
                              Divider(
                                height: 10,
                                thickness: 0.5,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'Remark:',
                                    style: TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                  SizedBox(
                                    width: 10,
                                  ),
                                  Expanded(
                                    child: Text(
                                      '${counter_proposals[i]['sendBackOriginationRemark']}',
                                      textAlign: TextAlign.right,
                                    ),
                                  ),
                                ],
                              ),
                              Divider(
                                height: 10,
                                thickness: 0.5,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'APP ID:',
                                    style: TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                  Text("${counter_proposals[i]['applicationId']}"),
                                ],
                              ),
                              Divider(
                                height: 10,
                                thickness: 0.5,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'Designated To Person:',
                                    style: TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                  Text("${counter_proposals[i]['personDesignatedToName']}"),
                                ],
                              ),
                              Divider(
                                height: 10,
                                thickness: 0.5,
                              ),
                              Row(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
                                Expanded(
                                  // child: ButtonWidget(
                                  //   text: "APPLICATION DETAIL",
                                  //   isWhiteBackgroundColor: false,
                                  //   onPressed: () {
                                  //      _onClickDetail(counter_proposals[i]['prospectId']);
                                  //   },
                                  // ),
                                  child: ElevatedButton(
                                    // icon: Icon(Icons.arrow_circle_right, size: 20, color: Colors.blue,),
                                    child: Text(
                                      'APPLICATION DETAIL',
                                      style: TextStyle(color: Colors.white),
                                    ),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.blue,
                                    ),
                                    onPressed: () {
                                      _onClickDetail(counter_proposals[i]['prospectId']);
                                    },
                                  ),
                                ),
                              ]),
                            ]),
                          );
                        }),
              ),
            ),
          ),
          kSpaceVertical8,
          CopyrightNotice(),
        ]),
      ),
    );
  }
}
