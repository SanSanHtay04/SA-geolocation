import 'dart:convert';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:sales/routes.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:provider/provider.dart';
import 'package:sales/data/local/db_sqlite_helper.dart';
import 'package:sales/providers/providers.dart';


import '../../widgets/confirmation_modal_bottom_widget.dart';
import '../../widgets/deprecated/alert_modal_bottom_widget.dart';
import '../choose_current_pos_screen.dart';

import 'presentation/partial_widgets/origination_menu.dart';

class OriginationScreen extends StatefulWidget {
  static const routeName = '/main-menu';

  final String connectionType;

  OriginationScreen({required this.connectionType});

  @override
  _OriginationScreenState createState() => _OriginationScreenState();
}

class _OriginationScreenState extends State<OriginationScreen> {
  bool _isInit = true;
  bool _isLoading = false;
  Map<String, dynamic>? currentPos;
  List<Map<String, dynamic>> _localProspectList = [];

  List<MenuEntry> menuItems = [
    MenuEntry(
      Icons.list,
      "PROSPECTS",
      OriginationBottomTab.prospects,
    ),
    MenuEntry(
      Icons.list,
      "COUNTER PROPOSAL",
      OriginationBottomTab.counerProposals,
    ),
    MenuEntry(
      Icons.list,
      "RESULT",
      OriginationBottomTab.results,
    ),
    MenuEntry(
      Icons.list,
      "APP PROCESSING",
      OriginationBottomTab.appProcessings,
    ),
    MenuEntry(
      Icons.notifications,
      "NOTIFICATION",
      OriginationBottomTab.notifications,
    ),
    // MenuEntry(Icons.cloud_circle_outlined, "DATA CATEGORIES",
    //     DataSyncScreen.routeName),
  ];

  void initLoad() async {
    await updateFcmToken();
    await _loadCurrentPos();
    await _getLocalProspect();
  }

  Future<void> updateFcmToken() async {
    await FirebaseMessaging.instance.getToken().then((value) async {
      print("_token: $value");
      await Provider.of<UserProvider>(context, listen: false).updateFcmToken({'fcmToken': value});
    });
  }

  Future<void> _getLocalProspect() async {
    List<Map<String, dynamic>> localProspectList = await DBSqliteHelper().getProspects();
    Future.delayed(Duration.zero, () {
      setState(() {
        _localProspectList = List<Map<String, dynamic>>.from(localProspectList);
      });
    });
  }

  Future<void> _loadCurrentPos() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    if (prefs.containsKey('rto_origination_pos')) {
      setState(() {
        currentPos = json.decode(prefs.getString('rto_origination_pos')!);
      });
    }
  }

  void _onTapChooseCurrentPos() {
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => ChooseCurrentPosScreen(
            connectionType: widget.connectionType,
          )),
    ).then((value) async {
      await this._loadCurrentPos();
    });
  }

  Future<void> _onTapPushDataToServer() async {
    setState(() {
      _isLoading = true;
    });
    List<Map<String, dynamic>> localProspectList = await DBSqliteHelper().getAllProspects();
    List<Map<String, dynamic>> localProductPackageList = await DBSqliteHelper().getProductPackages();
    List<Map<String, dynamic>> localAttachedProductList = await DBSqliteHelper().getAllAttachedProducts();
    List<Map<String, dynamic>> localSimualationList = await DBSqliteHelper().getSimulations();
    List<Map<String, dynamic>> localPaymentScheduleList = await DBSqliteHelper().getPaymentSchedules();
    List<Map<String, dynamic>> localApplicationList = await DBSqliteHelper().getApplications();
    List<Map<String, dynamic>> localCustomerList = await DBSqliteHelper().getCustomers();
    List<Map<String, dynamic>> localCustomerIncomeSourceList = await DBSqliteHelper().getAllCustomerIncomeSources();
    List<Map<String, dynamic>> localCustomerHouseholdList = await DBSqliteHelper().getAllCustomerHouseholds();
    List<Map<String, dynamic>> localCustomerContactList = await DBSqliteHelper().getAllCustomerContacts();
    List<Map<String, dynamic>> localAppDocDetList = await DBSqliteHelper().getAllAppDocDetails();
    List<Map<String, dynamic>> localAppUploadList = await DBSqliteHelper().getAllAppUploads();

    if (localProspectList.length > 0) {
      showModalBottomSheet(
          context: context,
          isScrollControlled: true,
          builder: (context) {
            String? _message = 'Something went wrong.';
            return ConfirmationModalBottomSheet("Are you sure you want to push all local data to server?", () async {
              try {
                setState(() {
                  _isLoading = true;
                });
                Map<String, dynamic> _localData = {
                  'prospects': localProspectList,
                  'prodPackages': localProductPackageList,
                  'attachedProducts': localAttachedProductList,
                  'simulations': localSimualationList,
                  'paymentSchedules': localPaymentScheduleList,
                  'applications': localApplicationList,
                  'customers': localCustomerList,
                  'custIncomeSources': localCustomerIncomeSourceList,
                  'custHouseholds': localCustomerHouseholdList,
                  'custContacts': localCustomerContactList,
                  'appDocDetails': localAppDocDetList,
                  'appUploads': localAppUploadList,
                };
                await Provider.of<ProspectProvider>(context, listen: false).pushLocalDataToServer(_localData).then((value) {
                  setState(() {
                    _message = Provider.of<ProspectProvider>(context, listen: false).responseMessage;

                    if (_message!.contains("are successfully created.")) {
                      DBSqliteHelper().deleteAllProspects();
                      DBSqliteHelper().deleteAllProductPackages();
                      DBSqliteHelper().deleteAllAttachedProducts();
                      DBSqliteHelper().deleteAllSimulations();
                      DBSqliteHelper().deleteAllPaymentSchedules();
                      DBSqliteHelper().deleteAllApplications();
                      DBSqliteHelper().deleteAllCustomers();
                      DBSqliteHelper().deleteAllCustomerIncomeSources();
                      DBSqliteHelper().deleteAllCustomerHouseholds();
                      DBSqliteHelper().deleteAllCustomerContacts();
                      DBSqliteHelper().deleteAllAppDocDetails();
                      DBSqliteHelper().deleteAllAppUploads();
                    }

                    _isLoading = false;
                  });
                });
              } catch (error) {
                setState(() {
                  _message = error.toString();
                  _isLoading = false;
                });
              }

              Navigator.pop(context);
              showModalBottomSheet(
                  context: context,
                  isScrollControlled: true,
                  builder: (context) {
                    return AlertModalBottomWidget(_message, () async {
                      setState(() {
                        _isLoading = false;
                      });
                      await _getLocalProspect();
                      Navigator.pop(context);
                    });
                  });
            });
          });
    }
    setState(() {
      _isLoading = false;
    });
  }

  @override
  void initState() {
    initLoad();
    super.initState();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_isInit) {
      setState(() {
        _isInit = false;
      });
    }
  }



  @override
  Widget build(BuildContext context) {
    final deviceSize = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: AutoSizeText(
          "MAIN MENU",
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: ModalProgressHUD(
        inAsyncCall: _isLoading,
        opacity: 0.5,
        progressIndicator: CircularProgressIndicator(
          valueColor: new AlwaysStoppedAnimation<Color>(Theme.of(context).primaryColor),
        ),
        child: Padding(
          padding: EdgeInsets.fromLTRB(12, 10, 12, 5),
          child: Column(
            children: <Widget>[
              Container(
                width: deviceSize.width,
                padding: EdgeInsets.fromLTRB(10, 15, 5, 0),
                decoration: BoxDecoration(
                  border: Border.all(color: Theme.of(context).primaryColor, width: 1.5),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  children: [
                    currentPos == null
                        ? Text(
                      "Please select current POS before creating prospect!",
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.red),
                    )
                        : Text(
                      currentPos!['posName'],
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.teal),
                      textAlign: TextAlign.center,
                    ),
                    currentPos == null
                        ? SizedBox()
                        : Text(
                      currentPos!['posAddress'],
                      style: TextStyle(fontSize: 12),
                      textAlign: TextAlign.center,
                    ),
                    TextButton(
                      child: Text('Choose current POS...'),
                      onPressed: _onTapChooseCurrentPos,
                    )
                  ],
                ),
              ),
              SizedBox(
                height: 10,
              ),
              widget.connectionType == 'online'
                  ? Container(
                width: deviceSize.width,
                padding: EdgeInsets.fromLTRB(10, 15, 5, 0),
                decoration: BoxDecoration(
                  border: Border.all(color: Theme.of(context).primaryColor, width: 1.5),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  children: [
                    Text(
                      _localProspectList.length > 0 ? "YOU HAVE ${_localProspectList.length} PROSPECTS IN LOCAL MEMORY OF THIS DEVICE." : "THERE IS NO PROSPECT IN LOCAL MEMORY OF THIS DEVICE.",
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: _localProspectList.length > 0 ? Colors.teal : Colors.grey),
                      textAlign: TextAlign.center,
                    ),
                    _localProspectList.length > 0
                        ? TextButton(
                      child: Text('Do you want to push all to the server now?'),
                      onPressed: _onTapPushDataToServer,
                    )
                        : SizedBox(),
                    _localProspectList.length > 0
                        ? SizedBox()
                        : SizedBox(
                      height: 10,
                    ),
                  ],
                ),
              )
                  : SizedBox(),
              widget.connectionType == 'online'
                  ? SizedBox(
                height: 10,
              )
                  : SizedBox(),
              OriginationMenu(
                menuItems,
                currentPos,
                widget.connectionType,
              ),
            ],
          ),
        ),
      ),
    );
  }
}