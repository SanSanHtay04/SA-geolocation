import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/data/remote/models/responses/responses.dart';
import 'package:sales/models/address.dart';
import 'package:sales/screens/origination/presentation/widgets/address_view/notifiers/address_notifier.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/selected_field/selected_field.dart';

import 'address_widget.dart';

class RuralView extends StatelessWidget {
  const RuralView({super.key, required this.onAddressChanged});

  final Function(Address) onAddressChanged;

  @override
  Widget build(BuildContext context) {
    return Consumer<AddressNotifier>(
      builder: (context, notifier, _) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SelectedField<Town>.simple(
              title: 'Village Tract',
              required: true,
              items: notifier.state.villageTracts,
              selectedItem: notifier.state.address.villageTract,
              prefixIcon: prefixLocationSelectorIcon(notifier.state.address.villageTract?.isValidLocation ?? false),
              onSelected: (villageTract) {
                context.read<AddressNotifier>().updateVillageTract(villageTract);

                onAddressChanged.call(notifier.state.address.copyWith(villageTract: villageTract));
              },
            ),
            kSpaceVertical8,
            SelectedField<Village>.simple(
              title: 'Village',
              required: true,
              items: notifier.state.villages,
              selectedItem: notifier.state.address.village,
              prefixIcon: prefixLocationSelectorIcon(notifier.state.address.village?.isValidLocation ?? false),
              onSelected: (village) {
                context.read<AddressNotifier>().updateVillage(village);
                onAddressChanged.call(notifier.state.address.copyWith(village: village));
              },
            ),
          ],
        );
      },
    );
  }
}