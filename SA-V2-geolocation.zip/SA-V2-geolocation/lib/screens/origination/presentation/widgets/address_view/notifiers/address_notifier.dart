import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:sales/base/error.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/data/repositories/address_repository.dart';
import 'package:sales/models/models.dart';
import 'package:sales/screens/origination/presentation/widgets/address_view/notifiers/address_data_state.dart';

class AddressNotifier extends ChangeNotifier {
  final AddressRepository _repo;

  AddressNotifier(this._repo) {
    _fetchRegions();
  }

  AddressDataState state = const AddressDataState();
  bool get isBusy => (state.status == AddressStatus.loading);

  Future<List<District>> _loadDistricts(Region? region) async {
    if (region != null) {
      final res = await _repo.getDistricts(region);
      return res.when(success: (data) => data, failed: (_, $) => []);
    } else {
      return [];
    }
  }

  Future<List<Township>> _loadTownShips(District? district) async {
    if (district != null) {
      final res = await _repo.getTownships(district);
      return res.when(success: (data) => data, failed: (_, $) => []);
    } else {
      return [];
    }
  }

  Future<List<Town>> _loadVillageTracts(Township? township) async {
    if (township != null) {
      final res = await _repo.getVillageTracts(township);
      return res.when(success: (data) => data, failed: (_, $) => []);
    } else {
      return [];
    }
  }

  Future<List<Town>> _loadTowns(Township? township) async {
    if (township != null) {
      final res = await _repo.getTowns(township);
      return res.when(success: (data) => data, failed: (_, $) => []);
    } else {
      return [];
    }
  }

  Future<List<Village>> _loadVillages(Town? villageTract) async {
    if (villageTract != null) {
      final res = await _repo.getVillages(villageTract);
      return res.when(success: (data) => data, failed: (_, $) => []);
    } else {
      return [];
    }
  }

  Future<List<Ward>> _loadWards(Town? town) async {
    if (town != null) {
      final res = await _repo.getWards(town);
      return res.when(success: (data) => data, failed: (_, $) => []);
    } else {
      return [];
    }
  }

  resetAddress(Address? address) {
    emit(state.copyWith(address: address ?? const Address()));
  }

  setAddress(Address? address) async {
    emit(state.copyWith(address: address ?? const Address()));

    final districts = await _loadDistricts(address?.region);
    final townships = await _loadTownShips(address?.district);
    List<Town> villageTracts = [];
    List<Village> villages = [];
    List<Town> towns = [];
    List<Ward> wards = [];
    if (address?.type == AddressType.rural) {
      villageTracts = await _loadVillageTracts(address?.township);
      villages = await _loadVillages(address?.villageTract);
    } else {
      towns = await _loadTowns(address?.township);
      wards = await _loadWards(address?.town);
    }
    // if (address?.township != null) {
    //   if (address?.type == AddressType.rural) {
    //     apis.add(_repo.getVillageTracts(address!.township!));
    //   } else {
    //     apis.add(_repo.getTowns(address!.township!));
    //   }
    // }
    // if (address?.town != null) {
    //   apis.add(_repo.getWards(address!.town!));
    // } else if (address?.villageTract != null) {
    //   apis.add(_repo.getVillages(address!.villageTract!));
    // }

    emit(state.copyWith(
      districts: districts,
      townships: townships,
      villageTracts: villageTracts,
      villages: villages,
      towns: towns,
      wards: wards,
    ));
  }

  _fetchRegions() async {
    emit(AddressDataState(
      status: AddressStatus.loading,
      address: Address(
        homeStatus: state.address.homeStatus,
        address: state.address.address,
        type: state.address.type,
      ),
    ));
    final res = await _repo.getRegions();
    final newState = res.when(success: (regions) {
      return state.copyWith(
        status: AddressStatus.loaded,
        regions: regions,
      );
    }, failed: (message, _) {
      return state.copyWith(
        status: AddressStatus.failed,
        message: message,
      );
    });
    emit(newState);
  }

  _fetchDistricts(Region region) async {
    emit(AddressDataState(
      status: AddressStatus.loading,
      address: Address(
        homeStatus: state.address.homeStatus,
        address: state.address.address,
        type: state.address.type,
        region: region,
      ),
      regions: state.regions,
    ));
    final res = await _repo.getDistricts(region);
    final newState = res.when(success: (districts) {
      return state.copyWith(
        status: AddressStatus.loaded,
        districts: districts,
      );
    }, failed: (message, _) {
      return state.copyWith(
        status: AddressStatus.failed,
        message: message,
        address: state.address.copyWith(region: null),
      );
    });
    emit(newState);
  }

  _fetchTownships(District district) async {
    emit(AddressDataState(
      status: AddressStatus.loading,
      address: Address(
        homeStatus: state.address.homeStatus,
        address: state.address.address,
        type: state.address.type,
        region: state.address.region,
        district: district,
      ),
      regions: state.regions,
      districts: state.districts,
    ));
    final res = await _repo.getTownships(district);
    final newState = res.when(success: (townships) {
      return state.copyWith(
        status: AddressStatus.loaded,
        townships: townships,
      );
    }, failed: (message, _) {
      return state.copyWith(
        status: AddressStatus.failed,
        message: message,
        address: state.address.copyWith(district: null),
      );
    });
    emit(newState);
  }

  _fetchTowns({Township? township, AddressType? type}) async {
    final addressTownship = township ?? state.address.township;
    if (addressTownship == null) {
      emit(state.copyWith(
        status: AddressStatus.failed,
        error: AppError.defaultError(),
      ));
      return;
    }
    final addressType = type ?? state.address.type;
    final isUrban = addressType == AddressType.urban;
    emit(AddressDataState(
      status: AddressStatus.loading,
      address: Address(
        homeStatus: state.address.homeStatus,
        address: state.address.address,
        region: state.address.region,
        district: state.address.district,
        type: addressType,
        township: addressTownship,
      ),
      regions: state.regions,
      districts: state.districts,
      townships: state.townships,
    ));
    final res = isUrban ? (await _repo.getTowns(addressTownship)) : (await _repo.getVillageTracts(addressTownship));
    final newState = res.when(
      success: (towns) {
        return state.copyWith(
          status: AddressStatus.loaded,
          towns: isUrban ? towns : [],
          villageTracts: !isUrban ? towns : [],
        );
      },
      failed: (message, _) {
        return state.copyWith(
          status: AddressStatus.failed,
          message: message,
          address: state.address.copyWith(township: null),
        );
      },
    );
    emit(newState);
  }

  _fetchWards(Town town) async {
    emit(AddressDataState(
      status: AddressStatus.loading,
      address: Address(
        homeStatus: state.address.homeStatus,
        address: state.address.address,
        type: state.address.type,
        region: state.address.region,
        district: state.address.district,
        township: state.address.township,
        town: town,
      ),
      regions: state.regions,
      districts: state.districts,
      townships: state.townships,
      towns: state.towns,
    ));
    final res = await _repo.getWards(town);
    final newState = res.when(success: (wards) {
      return state.copyWith(
        status: AddressStatus.loaded,
        wards: wards,
      );
    }, failed: (message, _) {
      return state.copyWith(
        status: AddressStatus.failed,
        message: message,
        address: state.address.copyWith(town: null),
      );
    });
    emit(newState);
  }

  _fetchVillages(Town villageTract) async {
    emit(AddressDataState(
      status: AddressStatus.loading,
      address: Address(
        homeStatus: state.address.homeStatus,
        address: state.address.address,
        type: state.address.type,
        region: state.address.region,
        district: state.address.district,
        township: state.address.township,
        villageTract: villageTract,
      ),
      regions: state.regions,
      districts: state.districts,
      townships: state.townships,
      villageTracts: state.villageTracts,
    ));
    final res = await _repo.getVillages(villageTract);
    final newState = res.when(success: (villages) {
      return state.copyWith(
        status: AddressStatus.loaded,
        villages: villages,
      );
    }, failed: (message, _) {
      return state.copyWith(
        status: AddressStatus.failed,
        message: message,
        address: state.address.copyWith(villageTract: null),
      );
    });
    emit(newState);
  }

  void updateHomeStatus(HomeStatus value) {
    emit(state.copyWith.address(homeStatus: value));
  }

  void updateAddress(String value) {
    emit(state.copyWith.address(address: value));
  }

  Future<void> updateRegion(Region region) => _fetchDistricts(region);

  Future<void> updateDistrict(District district) => _fetchTownships(district);

  Future<void> updateTownship(Township township) => _fetchTowns(township: township);

  Future<void> updateAddressType(AddressType type) => _fetchTowns(type: type);

  Future<void> updateTown(Town town) => _fetchWards(town);

  Future<void> updateWard(Ward ward) async {
    emit(state.copyWith.address(ward: ward));
  }

  Future<void> updateVillageTract(Town villageTract) => _fetchVillages(villageTract);

  Future<void> updateVillage(Village village) async {
    emit(state.copyWith.address(village: village));
  }

  void emit(AddressDataState data) {
    state = data;
    notifyListeners();
  }
}
