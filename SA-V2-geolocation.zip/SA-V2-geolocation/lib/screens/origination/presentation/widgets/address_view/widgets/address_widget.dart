import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/data/repositories/address_repository.dart';
import 'package:sales/models/models.dart';
import 'package:sales/screens/origination/presentation/widgets/address_view/notifiers/address_data_state.dart';
import 'package:sales/screens/origination/presentation/widgets/address_view/notifiers/address_notifier.dart';
import 'package:sales/screens/origination/presentation/widgets/address_view/widgets/rural_view.dart';
import 'package:sales/screens/origination/presentation/widgets/address_view/widgets/urban_view.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/form_card.dart';
import 'package:sales/widgets/selected_field/selected_field.dart';
import 'package:sales/widgets/selected_group/single_selected_group.dart';
import 'package:sales/widgets/text_form_field/clearable_text_form_field.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';

prefixLocationSelectorIcon(bool isShown) => (isShown)
    ? Icon(
  Icons.check_circle,
  color: Colors.green,
)
    : null;

class AddressWidget extends StatelessWidget {
  const AddressWidget({
    super.key,
    this.address,
    required this.onAddressChanged,
  });

  final Address? address;
  final Function(Address) onAddressChanged;

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => AddressNotifier(AddressRepository(context.read()))..setAddress(address),
      child: Consumer<AddressNotifier>(
        //  listener: (context, state) {
        //   onAddressChanged.call(state.address);
        //   if (state.status == AddressStatus.loading) {
        //     EasyLoading.show(maskType: EasyLoadingMaskType.clear);
        //   } else {
        //     EasyLoading.dismiss();
        //   }
        // },

        builder: (context, notifier, _) {
          final state = notifier.state;

          // TODO : rather than calling onAddressChanged() in each changes, need to call it once
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (state.status == AddressStatus.loading) {
              EasyLoading.show(maskType: EasyLoadingMaskType.clear);
            } else {
              EasyLoading.dismiss();
            }
          });

          return FormCard(
            title: 'Address',
            content: Column(
              children: [
                SelectedField<HomeStatus>(
                  title: 'Home status',
                  items: HomeStatus.values,
                  required: true,
                  labelParser: (item) => item.getName(context),
                  selectedItem: state.address.homeStatus,
                  onSelected: (item) {
                    context.read<AddressNotifier>().updateHomeStatus(item);
                    onAddressChanged.call(state.address.copyWith(homeStatus: item));
                  },
                ),
                kSpaceVertical8,
                ClearableTextFormField(
                  initialValue: state.address.address,
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(
                      RegExp("[a-zA-Z0-9 (),/-]"),
                    )
                  ],
                  labelText: 'Address',
                  textCapitalization: TextCapitalization.words,
                  prefixIcon: const Icon(Icons.pin_drop_rounded),
                  required: true,
                  onChanged: (text) {
                    context.read<AddressNotifier>().updateAddress(text);
                    onAddressChanged.call(state.address.copyWith(address: text));
                  },
                ),
                kSpaceVertical8,
                SelectedField<Region>.simple(
                  title: 'Region',
                  required: true,
                  items: state.regions,
                  selectedItem: state.address.region,
                  prefixIcon: prefixLocationSelectorIcon(state.address.region?.isValidLocation ?? false),
                  onSelected: (region) {
                    context.read<AddressNotifier>().updateRegion(region);
                    onAddressChanged.call(state.address.copyWith(region: region));
                  },
                ),
                kSpaceVertical8,
                SelectedField<District>.simple(
                  title: 'District',
                  required: true,
                  items: state.districts,
                  selectedItem: state.address.district,
                  prefixIcon: prefixLocationSelectorIcon(state.address.district?.isValidLocation ?? false),
                  onSelected: (district) {
                    context.read<AddressNotifier>().updateDistrict(district);
                    onAddressChanged.call(state.address.copyWith(district: district));
                  },
                ),
                kSpaceVertical8,
                SelectedField<Township>.simple(
                  title: 'Township',
                  required: true,
                  items: state.townships,
                  selectedItem: state.address.township,
                  prefixIcon: prefixLocationSelectorIcon(state.address.township?.isValidLocation ?? false),
                  onSelected: (township) {
                    context.read<AddressNotifier>().updateTownship(township);
                    onAddressChanged.call(state.address.copyWith(township: township));
                  },
                ),
                kSpaceVertical8,
                SingleSelectedGroup<AddressType>(
                  items: AddressType.values,
                  labelParser: (item) => item.getName(context),
                  onSelectChanged: state.address.township == null
                      ? null
                      : (type) {
                    context.read<AddressNotifier>().updateAddressType(type);
                    onAddressChanged.call(state.address.copyWith(type: type));
                  },
                  selectedItem: state.address.type,
                ),
                kSpaceVertical8,
                state.address.type == AddressType.urban ? UrbanView(onAddressChanged: onAddressChanged) : RuralView(onAddressChanged: onAddressChanged),
              ],
            ),
          );
        },
      ),
    );
  }
}