

import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/base/error.dart';
import 'package:sales/data/remote/models/responses/responses.dart';
import 'package:sales/models/models.dart';

part 'address_data_state.freezed.dart';

enum AddressStatus { loading, loaded, failed }

@freezed
class AddressDataState with _$AddressDataState {
  const AddressDataState._();

  const factory AddressDataState({
    @Default(AddressStatus.loaded) AddressStatus status,
    String? message,
    AppError? error,
    @Default(Address()) Address address,
    @Default([]) List<Region> regions,
    @Default([]) List<District> districts,
    @Default([]) List<Township> townships,
    @Default([]) List<Town> towns,
    @Default([]) List<Ward> wards,
    @Default([]) List<Town> villageTracts,
    @Default([]) List<Village> villages,
  }) = _AddressDataState;
}
