import 'package:flutter/material.dart';

import 'package:provider/provider.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/models/address.dart';
import 'package:sales/screens/origination/presentation/widgets/address_view/notifiers/address_notifier.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/selected_field/selected_field.dart';

import 'address_widget.dart';

class UrbanView extends StatelessWidget {
  const UrbanView({super.key, required this.onAddressChanged});

  final Function(Address) onAddressChanged;

  @override
  Widget build(BuildContext context) {
    return Consumer<AddressNotifier>(
      builder: (context, notifier, _) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SelectedField<Town>.simple(
              title: 'Town',
              required: true,
              items: notifier.state.towns,
              selectedItem: notifier.state.address.town,
              prefixIcon: prefixLocationSelectorIcon(notifier.state.address.town?.isValidLocation ?? false),
              onSelected: (town) {
                context.read<AddressNotifier>().updateTown(town);
                onAddressChanged.call(notifier.state.address.copyWith(town: town));
              },
            ),
            kSpaceVertical8,
            SelectedField<Ward>.simple(
              title: 'Ward',
              required: true,
              items: notifier.state.wards,
              selectedItem: notifier.state.address.ward,
              prefixIcon: prefixLocationSelectorIcon(notifier.state.address.ward?.isValidLocation ?? false),
              onSelected: (ward) {
                context.read<AddressNotifier>().updateWard(ward);
                onAddressChanged.call(notifier.state.address.copyWith(ward: ward));
              },
            ),
          ],
        );
      },
    );
  }
}