import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:latlong2/latlong.dart';
import 'package:provider/provider.dart';
import 'package:sales/screens/origination/presentation/widgets/location_view/notifiers/location_notifier.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/widgets/search_text_field.dart';
import 'package:sliding_up_panel/sliding_up_panel.dart';

import '../notifiers/location_data_state.dart';
import 'bottom_bar_view.dart';

class SlidingUpPanelContainer extends StatelessWidget {
  const SlidingUpPanelContainer({
    Key? key,
    required double panelHeight,
    required PanelController panelController,
    required ScrollController scrollController,
  })  : _panelHeight = panelHeight,
        _panelController = panelController,
        _scrollController = scrollController,
        super(key: key);

  final double _panelHeight;
  final PanelController _panelController;
  final ScrollController _scrollController;

  @override
  Widget build(BuildContext context) {
    final state = context.watch<LocationNotifier>().state;
    final address = context.watch<LocationNotifier>().searchAddress;

    return MediaQuery.removePadding(
        context: context,
        removeTop: true,
        child: ListView(
          controller: _scrollController,
          children: <Widget>[
            SizedBox(height: _panelHeight),
            const BottomBarView(),
            kSpaceVertical16,
            Container(
              padding: kPadding8,
              child: SearchTextField(
                initialValue: address,
                prefixEnabled: false,
                icon: Icon(Icons.arrow_back),
                onIconClicked: () {
                  FocusScope.of(context).unfocus();
                  _panelController.close();
                },
                labelText: '( Latitude, Longitude )',
                onSubmitted: (value) {
                  if (!value.isNullOrEmpty) {
                    final List<String> data = value.contains(',') ? value.split(',') : [];

                    if (data.isNotEmpty) {
                      context.read<LocationNotifier>().updateGeoLocation(
                        LatLng(double.parse(data[0]), double.parse(data[1])),
                        MapEventType.search_action,
                      );
                      FocusScope.of(context).unfocus();
                      _panelController.close();
                    } else {
                      context.read<LocationNotifier>().getLocations(value);
                    }
                  }
                },
                onChanged: (value) {
                  context.read<LocationNotifier>().updateSearchAddress(value);
                },
              ),
            ),
            Divider(thickness: 0.5, color: Colors.grey),
            kSpaceVertical32,
            ListView.builder(
              shrinkWrap: true, // 1st add for nested list
              physics: ClampingScrollPhysics(), // 2nd add for nested list
              itemCount: state.placeMarks.length,
              itemBuilder: (context, index) {
                final searchAddress = state.placeMarks[index];
                return ListTile(
                  leading: Icon(Icons.location_on_outlined),
                  title: Text('${searchAddress.street}, ${searchAddress.name}'),
                  subtitle: Text('${searchAddress.subAdministrativeArea}, ${searchAddress.administrativeArea},${searchAddress.country}'),
                  onTap: () {
                    Fluttertoast.showToast(msg: "Under Development");
                    //AppLogger.i("GoTo Location Marker");
                    //_pc.close();
                  },
                );
              },
            ),
          ],
        ));
  }

  /// TODO : To add this widget to utils folder if there's further usage
  ///  // _button(
  //   "The location search is under the Rent2Own development.",
  //   Icons.home_work_sharp,
  //   context.getColorScheme().primary,
  // ),
  Widget _button(String label, IconData icon, Color color) {
    return Column(
      children: <Widget>[
        Container(
          padding: kPadding16,
          child: Icon(icon, color: Colors.white),
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
            boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0, 0.15), blurRadius: 8.0)],
          ),
        ),
        kSpaceVertical12,
        Text(label),
      ],
    );
  }
}