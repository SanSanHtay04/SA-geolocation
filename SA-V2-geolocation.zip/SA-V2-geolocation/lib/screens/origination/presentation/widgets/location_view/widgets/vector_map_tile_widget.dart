import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:sales/utils/utils.dart';
import 'package:vector_map_tiles/vector_map_tiles.dart';
import '../notifiers/location_data_state.dart';

 const double PIN_SIZE = 65;
 const double POINT_SIZE = 10;
class VectorMapTileWidget extends StatefulWidget {
  const VectorMapTileWidget({
    super.key,
    this.geoLocation,
    required this.mapCameraMoved,
    required this.onLocationChanged,
  });

  final LatLng? geoLocation;
  final bool mapCameraMoved;
  final Function(LatLng, MapEventType) onLocationChanged;

  @override
  State<VectorMapTileWidget> createState() => _VectorMapTileWidgetState();
}

class _VectorMapTileWidgetState extends State<VectorMapTileWidget> {

  final MapController _mapController = MapController();

  Style? _style;
  Object? _error;

  @override
  void initState() {
    _mapController.mapEventStream
        .where((event) => event is MapEventMoveEnd)
        .listen((event) {
      final location = LatLng(event.camera.center.latitude, event.camera.center.longitude);
      widget.onLocationChanged.call(location, MapEventType.user_movement);
    });
    _initMapStyle();
    super.initState();
  }

  void _initMapStyle() async {
    try {
      _style = await StyleReader(
        uri: '$MAP_STYLE_URL?api_key={key}',
        apiKey: STADIA_MAPS_API_KEY,
      ).read();
    } catch (e, stack) {
      AppLogger.e(e.toString(), stack);
      _error = e;
    }
    setState(() {});
  }

  @override
  void dispose() {
    super.dispose();
    _mapController.dispose();
  }

  // Position the marker pin at center point , not covered userMarkerPoint
  Widget _centerMarkerPin(BuildContext context) {
    return Positioned(
      top: _getPointY(context) - PIN_SIZE - POINT_SIZE,
      left: _getPointX(context) - PIN_SIZE / 2,
      child: const IgnorePointer(
        child: Icon(Icons.location_on, size: PIN_SIZE, color: Colors.red),
      ),
    );
  }

  // Position user's location point
  Marker _userMarkerPoint(LatLng point) {
    return Marker(
      point: point,
      child:  const IgnorePointer(
        child: Icon(Icons.circle, size: POINT_SIZE, color: Colors.blue),
      ),
    );
  }

  Widget _map(Style style) => FlutterMap(
    mapController: _mapController,
    options: MapOptions(
      initialCenter: style.center ?? LatLng(16.828689, 96.174724),
      initialZoom: style.zoom ?? 13,
      maxZoom: 22,
    ),
    children: [
      VectorTileLayer(
        tileProviders: style.providers,
        theme: style.theme,
        tileOffset: TileOffset.mapbox,
        layerMode: VectorTileLayerMode.vector,
        maximumZoom: 22,
      ),
      MarkerLayer(
        markers: [
          if (widget.geoLocation != null)
            _userMarkerPoint(widget.geoLocation!),
        ],
      ),

    ],
  );

  @override
  Widget build(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (widget.geoLocation != null && widget.mapCameraMoved)
        _mapController.move(widget.geoLocation!, 15);
    });

    // TODO : rather than handling loading/error at UI directly, should via state handler
    final child = (_error != null)
        ? Center(child: Text(_error!.toString()))
        : (_style == null)
        ? const Center(child: CircularProgressIndicator())
        : _map(_style!);

    return Scaffold(body: SafeArea(child: child));
  }

  double _getPointX(BuildContext context) => context.getScreenSize().width / 2;

  double _getPointY(BuildContext context) => context.getScreenSize().height / 2;
}