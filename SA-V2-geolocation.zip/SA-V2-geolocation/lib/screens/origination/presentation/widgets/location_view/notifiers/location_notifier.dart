
import 'package:flutter/cupertino.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';

import 'package:sales/utils/utils.dart';

import 'location_data_state.dart';

class LocationNotifier extends ChangeNotifier {
  LocationNotifier();

  LocationDataState state = const LocationDataState();
  String searchAddress = '';

  bool get isBusy => (state.status == LocationStatus.loading);

  updateSearchAddress(String value) {
    searchAddress = value;
    notifyListeners();
  }

  void emit(LocationDataState data) {
    state = data;
    notifyListeners();
  }

  void loadData(LatLng? location, String? name) {
    if (location == null)
      getCurrentLatLng();
    else
      emit(state.copyWith(
        geoAddress: name,
        geoLocation: location,
        eventType: MapEventType.current_location,
      ));
  }

  Future<void> getCurrentLatLng() async {
    emit(state.copyWith(status: LocationStatus.loading));
    try {
      final position = await Geolocator.getCurrentPosition();
      final addresses =
      await placemarkFromCoordinates(position.latitude, position.longitude);

      final address = addresses.first;

      emit(state.copyWith(
        geoLocation: LatLng(position.latitude, position.longitude),
        geoAddress:
        " ${address.name}, ${address.street}, ${address.subAdministrativeArea}, ${address.administrativeArea}",
        eventType: MapEventType.current_location,
        status: LocationStatus.loaded,
      ));

      AppLogger.i(
          "getCurrentLatLng : ${state.eventType.value()}\n${state.geoLocation}, ");
    } catch (e) {
      emit(
          state.copyWith(status: LocationStatus.failed, message: e.toString()));
    }
  }

  updateGeoAddress(String address) {
    emit(state.copyWith(geoAddress: address));
  }

  updateGeoLocation(LatLng location, MapEventType eventType) async {
    // emit(state.copyWith(status: LocationStatus.loading));
    try {
      final placeMarkers =
      await placemarkFromCoordinates(location.latitude, location.longitude);
      final place = placeMarkers.first;

      emit(state.copyWith(
        geoLocation: location,
        geoAddress: place.toAddress(),
        eventType: eventType,
        status: LocationStatus.loaded,
      ));

      AppLogger.i(
          "updateGeoLocation : ${state.eventType.value()}\n${state.geoLocation},\n${place}");
    } catch (e) {
      emit(
          state.copyWith(status: LocationStatus.failed, message: e.toString()));
    }
  }

  // TODO: later usage
  getPlaceMarkers(Location location) {
    // emit(state.copyWith(status: LocationStatus.loading));
    try {
      placemarkFromCoordinates(location.latitude, location.longitude)
          .then((value) {
        // emit(state.copyWith(placeMarks: value, status: LocationStatus.loaded));
        // final address = value.first;

        AppLogger.i("PlaeMarkers : ${value.first}");
      });
    } catch (e) {
      emit(
          state.copyWith(status: LocationStatus.failed, message: e.toString()));
    }
  }

  // TODO: later usage
  getLocations(String query) {
    emit(state.copyWith(status: LocationStatus.loading));
    try {
      locationFromAddress(query).then((value) async {

        List<Placemark> places = [];
        for( var location in value){

          final aa= await   placemarkFromCoordinates(location.latitude, location.longitude);
          places.add(aa.first);

        }

        AppLogger.i("getLocations : ${value.first.toString()}, ${value.length}");

        emit(state.copyWith(locations: value, placeMarks: places, status: LocationStatus.loaded));
      });
    } catch (e) {
      emit(
          state.copyWith(status: LocationStatus.failed, message: e.toString()));
    }
  }
}