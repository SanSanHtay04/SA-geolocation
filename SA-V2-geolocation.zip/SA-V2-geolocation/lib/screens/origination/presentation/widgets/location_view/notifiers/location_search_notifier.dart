import 'dart:ffi';

import 'package:flutter/cupertino.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';

import 'package:sales/data/repositories/repositories.dart';
import 'package:sales/utils/utils.dart';

import 'location_data_state.dart';
import 'location_search_state.dart';

class LocationSearchNotifier extends ChangeNotifier {
  LocationSearchNotifier();

  LocationSearchState state = const LocationSearchState.idle();
  String searchAddress = '';

  bool get isLoading => (state is LocationSearchStateLoading);

  updateSearchAddress(String value) {
    searchAddress = value;
    notifyListeners();
  }

  void emit(LocationSearchState data) {
    state = data;
    notifyListeners();
  }

  getLocations(String query) {
    emit(const LocationSearchState.loading());
    try {
      locationFromAddress(query).then((value) async {
        List<Map<Location, Placemark>> places = [];

        for (var location in value) {
          final aa = await placemarkFromCoordinates(
              location.latitude, location.longitude);
          places.add({location: aa.first});
        }
        AppLogger.i(
            "getLocations : ${value.first.toString()}, ${value.length}");
        emit(LocationSearchState.success(data: places));
      });
    } catch (e) {
      emit(LocationSearchState.failed(e.toString()));
    }
  }
}