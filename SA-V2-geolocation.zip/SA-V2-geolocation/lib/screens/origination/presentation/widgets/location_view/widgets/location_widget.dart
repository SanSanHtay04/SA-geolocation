import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:provider/provider.dart';
import 'package:sales/screens/origination/presentation/widgets/location_view/notifiers/location_data_state.dart';
import 'package:sales/screens/origination/presentation/widgets/location_view/notifiers/location_notifier.dart';
import 'package:sales/screens/origination/presentation/widgets/location_view/widgets/vector_map_tile_widget.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/utils/utils.dart';
import 'package:sliding_up_panel/sliding_up_panel.dart';
import 'package:latlong2/latlong.dart';
import 'collapsed_view.dart';
import 'sliding_up_panel_container.dart';

/// Location Widget with SlidingUpPanel in-order-to support searching the suggested addresses
class LocationWidget extends StatefulWidget {
  const LocationWidget({
    super.key,
    this.geoLocation,
    this.geoAddress,
    required this.onConfirmed,
  });

  final LatLng? geoLocation;
  final String? geoAddress;
  final Function(LatLng?, String?) onConfirmed;

  @override
  _LocationWidgetState createState() => _LocationWidgetState();
}

class _LocationWidgetState extends State<LocationWidget> {
  final PanelController _panelController = new PanelController();
  final double _initFabHeight = 200.0;
  double _fabHeight = 0;

  /// this inner panelHeight vary on where there panel is opened or closed
  double _panelHeight = 0;
  double _panelHeightOpen = 0;
  double _panelHeightClosed = 170.0;

  @override
  void initState() {
    super.initState();
    _fabHeight = _initFabHeight;
    _panelHeight = _panelHeightClosed;
  }

  onPanelSlided(double position) {
    /// position value :  closed 0.0, opened 1.0
    setState(() {
      _fabHeight = position * (_panelHeightOpen - _panelHeightClosed) + _initFabHeight;

      _panelHeight = (position == 1.0) ? 4 : _panelHeightClosed;
    });
  }

  @override
  Widget build(BuildContext context) {
    _panelHeightOpen = context.getScreenSize().height * .80;

    return ChangeNotifierProvider(
        create: (context) => LocationNotifier()..loadData(widget.geoLocation, widget.geoAddress),
        child: Consumer<LocationNotifier>(
          builder: (context, notifier, _) {
            return Material(
                child: Stack(alignment: Alignment.topCenter, children: <Widget>[
                  SlidingUpPanel(
                    controller: _panelController,
                    maxHeight: _panelHeightOpen,
                    minHeight: _panelHeightClosed,
                    borderRadius: kBorderRadiusGeometry20,
                    onPanelSlide: onPanelSlided,
                    isDraggable: false,
                    collapsed: CollapsedView(
                      onPanelOpened: () => _panelController.open(),
                      onButtonTapped: () {
                        final location = notifier.state.geoLocation;
                        final address = notifier.state.geoAddress;

                        widget.onConfirmed.call(location, address);
                        Navigator.pop(context);
                      },
                    ),
                    body: VectorMapTileWidget(
                      geoLocation: notifier.state.geoLocation,
                      mapCameraMoved: notifier.state.eventType.value(),
                      onLocationChanged: notifier.updateGeoLocation,
                    ),
                    panelBuilder: (sc) => SlidingUpPanelContainer(
                      panelHeight: _panelHeight,
                      panelController: _panelController,
                      scrollController: sc,
                    ),
                  ),
                  myLocationFab(context),
                  closedFab(context),
                  latlngTextPoint(context, notifier.state.geoLocation),
                 centerMarkerPin(context),
                ]));
          },
        ));
  }

  Widget latlngTextPoint(BuildContext context, LatLng? location) {
    return Positioned(
      top: 52.0,
      child: InkWell(
        onTap: () {
          Clipboard.setData(ClipboardData(text: location.format())).then(
                (value) => Fluttertoast.showToast(msg: "Location copied"),
          );
        },
        child: Container(
          padding: kPaddingHorizontal24 + kPaddingVertical16,
          child: Text(
            location.format(),
            style: TextStyle(fontWeight: FontWeight.w500),
          ),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: kBorderRadius24,
            boxShadow: [BoxShadow(color: Color.fromRGBO(0, 0, 0, .25), blurRadius: 16.0)],
          ),
        ),
      ),
    );
  }

  Widget closedFab(BuildContext context) => Positioned(
    top: 30.0,
    left: 20.0,
    child: FloatingActionButton(
      heroTag: "btnClose",
      mini: true,
      backgroundColor: Colors.white,
      onPressed: () => Navigator.pop(context),
      child: Icon(Icons.close, color: Theme.of(context).primaryColor),
    ),
  );

  Widget myLocationFab(BuildContext context) => Positioned(
    right: 20.0,
    bottom: _fabHeight,
    child: FloatingActionButton(
      heroTag: "btnMyLocation",
      mini: true,
      backgroundColor: Colors.white,
      onPressed: () => context.read<LocationNotifier>().getCurrentLatLng(),
      child: Icon(Icons.gps_fixed, color: Theme.of(context).primaryColor),
    ),
  );

  // Position the marker pin at center point , not covered userMarkerPoint
  Widget centerMarkerPin(BuildContext context) {
    return Positioned(
      top: _getPointY(context) - PIN_SIZE - POINT_SIZE,
      left: _getPointX(context) - PIN_SIZE / 2,
      child: const IgnorePointer(
        child: Icon(Icons.location_on, size: PIN_SIZE, color: Colors.red),
      ),
    );
  }
  double _getPointX(BuildContext context) => context.getScreenSize().width / 2;
  double _getPointY(BuildContext context) => context.getScreenSize().height / 2;

}