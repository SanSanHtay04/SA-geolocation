
import 'package:flutter/material.dart';
import 'package:sales/themes/dimensions.dart';

class BottomBarView extends StatelessWidget {
  const BottomBarView(
      {super.key, this.width = 50, this.height = 3, this.color = Colors.grey});

  final double? width;
  final double? height;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Container(
          width: width,
          height: height,
          decoration: BoxDecoration(
            color: color,
            borderRadius: kBorderRadius12,
          ),
        ),
      ],
    );
  }
}