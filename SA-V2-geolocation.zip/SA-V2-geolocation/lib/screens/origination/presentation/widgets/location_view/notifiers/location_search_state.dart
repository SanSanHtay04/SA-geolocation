
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:geocoding/geocoding.dart';
import 'package:sales/base/error.dart';

part 'location_search_state.freezed.dart';

@freezed
class LocationSearchState with _$LocationSearchState {
  const factory LocationSearchState.idle() = LocationSearchStateIdle;

  const factory LocationSearchState.loading() = LocationSearchStateLoading;

  const factory LocationSearchState.success({@Default([]) List<Map<Location,Placemark>> data}) =
  LocationSearchStateSuccess;

  const factory LocationSearchState.failed(String message, {AppError? error}) =
  LocationSearchStateFailed;
}