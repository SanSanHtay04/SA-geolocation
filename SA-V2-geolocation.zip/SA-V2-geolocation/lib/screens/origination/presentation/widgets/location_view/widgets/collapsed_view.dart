
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/screens/origination/presentation/widgets/location_view/notifiers/location_notifier.dart';
import 'package:sales/themes/dimensions.dart';

import 'bottom_bar_view.dart';

class CollapsedView extends StatelessWidget {
  const CollapsedView({
    super.key,
    required this.onPanelOpened,
    required this.onButtonTapped,
  });

  final VoidCallback onPanelOpened;
  final VoidCallback onButtonTapped;

  @override
  Widget build(BuildContext context) {
    final state = context.watch<LocationNotifier>().state;

    return Container(
      decoration: BoxDecoration(
        borderRadius: kBorderRadiusGeometry20,
      ),
      child: Column(
        children: [
          kSpaceVertical4,
          BottomBarView(),
          Padding(
            padding: kPadding16,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextField(
                  readOnly: true,
                  obscureText: true,
                  // maxLines: 2,
                  onTap: () => onPanelOpened.call(), //onPanelOpened,
                  decoration: InputDecoration(
                    hintText: state.geoAddress,
                    border: InputBorder.none,
                    prefixIcon: Icon(Icons.location_on_outlined),
                    suffixIcon: Icon(Icons.edit_outlined),
                  ),
                ),
                kSpaceVertical2,
                Divider(thickness: 0.5, color: Colors.grey),
                kSpaceVertical2,
                ElevatedButton(
                  child: const Text('Confirm Location'),
                  onPressed: onButtonTapped,
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
