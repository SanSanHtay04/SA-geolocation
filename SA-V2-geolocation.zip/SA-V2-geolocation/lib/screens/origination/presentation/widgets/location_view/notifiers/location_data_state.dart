import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:geocoding/geocoding.dart';
import 'package:latlong2/latlong.dart';
import 'package:sales/base/error.dart';

part 'location_data_state.freezed.dart';

enum LocationStatus { loading, loaded, failed }

@freezed
class LocationDataState with _$LocationDataState {
  const LocationDataState._();

  const factory LocationDataState({
    @Default(LocationStatus.loaded) LocationStatus status,
    String? message,
    AppError? error,
    LatLng? geoLocation,
    String? geoAddress,
    @Default(MapEventType.user_movement) MapEventType eventType,
    @Default([]) List<Location> locations,
    @Default([]) List<Placemark> placeMarks,
  }) = _LocationDataState;
}

@freezed
class GeoAddress with _$GeoAddress {
  const GeoAddress._();

  const factory GeoAddress({
    LatLng? location,
    String? address,
  }) = _GeoAddress;
}

enum MapEventType {
  current_location,
  search_action,
  user_movement,
}

extension MapEventTypeExtensions on MapEventType {
  bool value() {
    switch (this) {
      case MapEventType.current_location:
      case MapEventType.search_action:
        return true;
      case MapEventType.user_movement:
        return false;
    }
  }
}