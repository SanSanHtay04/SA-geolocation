import 'package:flutter/foundation.dart';
import 'package:sales/data/repositories/education_repo.dart';
import 'package:sales/screens/origination/presentation/widgets/education_view/notifiers/education_data_state.dart';



class EducationStatusNotifier extends ChangeNotifier {
  final EducationRepo _repo;

  EducationDataState state = const EducationDataState();

  EducationStatusNotifier(this._repo);

  void emit(EducationDataState data) {
    state = data;
    notifyListeners();
  }

  fetch() async {
    emit(EducationDataState(status: EducationStatus.loading, data: []));
    final res = await _repo.getEducations();
    final newState = res.when(success: (data) {
      return state.copyWith(
        status: EducationStatus.loaded,
        data: data,
      );
    }, failed: (message, _) {
      return state.copyWith(
        status: EducationStatus.failed,
        message: message,
      );
    });
    emit(newState);
  }
}
