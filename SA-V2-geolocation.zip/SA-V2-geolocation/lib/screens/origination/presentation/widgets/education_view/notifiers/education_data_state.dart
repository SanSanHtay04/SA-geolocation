import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/base/error.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/data/remote/models/responses/education_level.dart';

part 'education_data_state.freezed.dart';

enum EducationStatus { loading, loaded, failed }

@freezed
class EducationDataState with _$EducationDataState {
  const EducationDataState._();

  const factory EducationDataState({
    @Default(EducationStatus.loaded) EducationStatus status,
    String? message,
    AppError? error,
    @Default([]) List<EducationLevel> data,
   
  }) = _EducationDataState;
}
