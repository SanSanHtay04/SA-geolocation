import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/data/remote/models/responses/education_level.dart';
import 'package:sales/data/repositories/education_repo.dart';
import 'package:sales/screens/origination/presentation/widgets/education_view/notifiers/education_status_notifier.dart';

import 'package:sales/widgets/selected_field/selected_field.dart';

class EducationStatusView extends StatelessWidget {
  const EducationStatusView({
    super.key,
    this.selectedValue,
    required this.onChanged,
  });

  final EducationLevel? selectedValue;
  final Function(EducationLevel) onChanged;

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => EducationStatusNotifier(
        EducationRepo(context.read()),
      )..fetch(),
      child: Consumer<EducationStatusNotifier>(
        builder: (context, notifier, _) {
          EducationLevel? selectedItem;
          try {
            selectedItem = notifier.state.data.firstWhere(
              (e) => e.educationId == selectedValue?.educationId,
            );
          } catch (_) {
            selectedItem = null;
          }
          return Column(
            children: [
              SelectedField<EducationLevel>.simple(
                title: 'Education status',
                items: notifier.state.data ?? [],
                required: true,
                selectedItem: selectedItem,
                onSelected: onChanged,
              ),
            ],
          );
        },
      ),
    );
  }
}
