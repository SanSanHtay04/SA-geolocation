import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:sales/base/error.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/data/repositories/repositories.dart';
import 'package:sales/screens/origination/presentation/widgets/nrc_view/notifiers/nrc_state.dart';
import 'package:sales/utils/utils.dart';

class NrcNotifier extends ChangeNotifier {
  final NrcRepo _repo;
  late NrcState state;

  NrcNotifier(this._repo) {
    state = const NrcState.loading();
  }

  emit(NrcState data) {
    state = data;
    notifyListeners();
  }

  NRCNumberType _getNrcNumberType([NRCNumber? defaultNumber]) {
    if (defaultNumber != null) {
      return defaultNumber.type;
    } else {
      if (defaultNumber?.type != NRCNumberType.noNrc) {
        final frcPrefix = defaultNumber?.frcPrefix ?? '';
        return frcPrefix.isNotEmpty ? NRCNumberType.frc : NRCNumberType.nrc;
      }
      return NRCNumberType.noNrc;
    }
  }

  setDefaultNrc(bool noNrcEnabled, {NRCNumber? defaultNumber}) {
    final nrcNumberType = _getNrcNumberType(defaultNumber);
    final info = defaultNumber?.copyWith(
          type: nrcNumberType,
          nrcType: nrcNumberType == NRCNumberType.nrc && defaultNumber.nrcType == null ? NRCType.n : defaultNumber.nrcType,
        ) ??
        NRCNumber(
          type: noNrcEnabled ? NRCNumberType.noNrc : NRCNumberType.nrc,
          nrcType: noNrcEnabled ? null : NRCType.n,
        );
    if (info.type == NRCNumberType.nrc) {
      _getNrcRegions(info);
    } else {
      emit(NrcState.loaded(numberInfo: info));
    }
  }

  _getNrcRegions(NRCNumber info) async {
    emit(NrcState.loading(numberInfo: info));
    final res = await _repo.getNrcRegions();
    final newState = await res.when<FutureOr<NrcState>>(
      success: (regions) async {
        regions.sort((a, b) => a.nrc1Id.compareTo(b.nrc1Id));
        if (info.region != null) {
          final res = await _repo.getNrcPrefixes(info.region!.nrc1Id);
          return res.when(
            success: (prefixes) => NrcState.loaded(
              regions: regions,
              prefixes: prefixes,
              numberInfo: info,
            ),
            failed: (message, error) => NrcState.failed(message, error),
          );
        }
        return NrcState.loaded(
          numberInfo: info,
          regions: regions,
        );
      },
      failed: (message, error) => NrcState.failed(message, error),
    );
   
    emit(newState);
  }

  selectNumberType(NRCNumberType numberType) {
    if (numberType == NRCNumberType.nrc) {
      _getNrcRegions(
        state.numberInfo.copyWith(type: numberType, nrcType: NRCType.n, number:''),
      );
    } else {
      emit(
        state.copyWith(numberInfo: NRCNumber(type: numberType,number: '')),
      );
    }
  }

  selectRegion(NrcRegion region) async {
    emit(NrcState.loading(
      regions: state.regions,
      numberInfo: state.numberInfo.copyWith(region: region),
    ));

    final res = await _repo.getNrcPrefixes(region.nrc1Id);
    final newState = res.when(
      success: (prefixes) {
        return NrcState.loaded(
          regions: state.regions,
          prefixes: prefixes,
          numberInfo: state.numberInfo.copyWith(
            region: region,
            nrcPrefix: null,
          ),
        );
      },
      failed: (message, error) => NrcState.failed(message, error),
    );
    emit(newState);
  }

  selectPrefix(NrcPrefix prefix) {
    final newState = state.maybeMap(
      orElse: () => NrcState.failed('', AppError.defaultError()),
      loaded: (state) {
        return state.copyWith.numberInfo(nrcPrefix: prefix);
      },
    );
    emit(newState);
  }

  selectType(NRCType type) {
    final newState = state.maybeMap(
      orElse: () => NrcState.failed('', AppError.defaultError()),
      loaded: (state) {
        return state.copyWith.numberInfo(nrcType: type);
      },
    );
    emit(newState);
  }

  updateFrcPrefix(String prefix) {
    final newState = state.maybeMap(
      orElse: () => NrcState.failed('', AppError.defaultError()),
      loaded: (state) {
        return state.copyWith.numberInfo(frcPrefix: prefix);
      },
    );
    emit(newState);
  }

  updateNumber(String number) {
    final newState = state.maybeMap(
      orElse: () => NrcState.failed('', AppError.defaultError()),
      loaded: (state) {
        return state.copyWith.numberInfo(number: number);
      },
    );
    AppLogger.i("NRC Notifier: ${number}");
    emit(newState);
  }

  updateIssuanceDate(DateTime? date) {
    final newState = state.maybeMap(
      orElse: () => NrcState.failed('', AppError.defaultError()),
      loaded: (state) {
        return state.copyWith.numberInfo(issuanceDate: date);
      },
    );
    emit(newState);
  }
}
