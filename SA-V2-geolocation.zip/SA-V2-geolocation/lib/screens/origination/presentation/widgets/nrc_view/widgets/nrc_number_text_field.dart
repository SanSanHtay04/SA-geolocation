part of 'nrc_view.dart';

class NrcNumberTextField extends StatelessWidget {
  const NrcNumberTextField({
    super.key,
    required this.type,
    this.prefixLabel = '',
    this.initialValue,
    this.onChanged,
  });

  final NRCNumberType type;
  final String prefixLabel;
  final String? initialValue;
  final ValueChanged<String>? onChanged;

  @override
  Widget build(BuildContext context) {
    return ClearableTextFormField(
      maxLength: 6,
      required: true,
      initialValue: initialValue,
      keyboardType: TextInputType.number,
      inputFormatters: [
        FilteringTextInputFormatter.digitsOnly,
      ],
      validator: (text) {
        final length = text?.length ?? 0;
        if (length < 6) {
          return '$prefixLabel${type.getName(context)} Number must have 6 digits!';
        }
        return null;
      },
      onChanged: onChanged,
      labelText: '$prefixLabel${type.getName(context)} Number (6 digits)',
      decoration: const InputDecoration(counterText: ''),
    );
  }
}
