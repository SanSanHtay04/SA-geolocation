import 'package:flutter/material.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/screens/origination/presentation/widgets/nrc_view/widgets/nrc_view.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/utils/utils.dart';

class NrcInfoCard extends StatelessWidget {
  const NrcInfoCard({
    super.key,
    this.initialValue,
    this.onNrcInfoChanged,
  });

  final NRCNumber? initialValue;
  final OnNrcInfoChanged? onNrcInfoChanged;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: kPadding16,
        child: Column(
          children: [
            Text(
              'NRC Info',
              style: context.getTextTheme().titleLarge,
            ),
            const Divider(height: 32),
            NrcView(
              initialValue: initialValue,
              onNrcInfoChanged: onNrcInfoChanged,
            ),
          ],
        ),
      ),
    );
  }
}
