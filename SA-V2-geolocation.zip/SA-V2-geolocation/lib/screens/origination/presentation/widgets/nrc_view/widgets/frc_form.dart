part of 'nrc_view.dart';

class FRCForm extends StatelessWidget {
  const FRCForm({super.key, this.prefixLabel = '', required this.onChanged});

  final String prefixLabel;
  final OnNrcInfoChanged? onChanged;

  @override
  Widget build(BuildContext context) {
    return Consumer<NrcNotifier>(
      builder: (context, notifier, _) {
        final state = notifier.state;
        return Column(
          children: [
            ClearableTextFormField(
              maxLength: 5,
              required: true,
              textCapitalization: TextCapitalization.characters,
              initialValue: state.numberInfo.frcPrefix,
              labelText: '$prefixLabel FRC/NVC Prefix (3-5 characters)',
              validator: (text) {
                final length = text?.length ?? 0;
                if (length < 3 || length > 5) {
                  return '$prefixLabel FRC/NVC Prefix must have 3-5 characters!';
                }
                return null;
              },
              decoration: const InputDecoration(counterText: ''),
              onChanged: (text) {
                context.read<NrcNotifier>().updateFrcPrefix(text);
                onChanged?.call(state.numberInfo.copyWith(frcPrefix: text));
              },
            ),
             kSpaceVertical8,
                  NrcNumberTextField(
                    initialValue: state.numberInfo.number,
                    type: state.numberInfo.type,
                    prefixLabel: prefixLabel,
                    onChanged: (text) {
                      context.read<NrcNotifier>().updateNumber(text);

                     onChanged
                          ?.call(state.numberInfo.copyWith(number: text));
                    },
                  ),
          ],
        );
      },
    );
  }
}
