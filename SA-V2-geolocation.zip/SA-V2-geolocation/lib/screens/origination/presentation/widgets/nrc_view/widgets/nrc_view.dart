import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:provider/provider.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/data/repositories/repositories.dart';
import 'package:sales/screens/origination/presentation/widgets/nrc_view/notifiers/nrc_notifier.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/selected_field/selected_field.dart';
import 'package:sales/widgets/selected_group/single_selected_group.dart';
import 'package:sales/widgets/text_form_field/clearable_text_form_field.dart';
import 'package:sales/widgets/text_form_field/date_picker_field.dart';

part 'frc_form.dart';

part 'nrc_form.dart';

part 'nrc_number_text_field.dart';

typedef OnNrcInfoChanged = Function(NRCNumber info);
typedef OnNrcRegionChanged = Function(NrcRegion region);
typedef OnNrcPrefixChanged = Function(NrcPrefix prefix);
typedef OnNrcTypeChanged = Function(NRCType type);
typedef OnFrcPrefixChanged = Function(String prefix);
typedef OnNrcNumberChanged = Function(String number);

class NrcView extends StatelessWidget {
  const NrcView({
    super.key,
    this.prefixLabel = '',
    this.initialValue,
    this.onNrcInfoChanged,
    this.noNrcEnabled = false,
  });

  final String prefixLabel;
  final bool noNrcEnabled;

  final NRCNumber? initialValue;

  final OnNrcInfoChanged? onNrcInfoChanged;

  String get _prefix => prefixLabel.isNotEmpty ? '$prefixLabel ' : '';

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => NrcNotifier(NrcRepo(context.read()))
        ..setDefaultNrc(noNrcEnabled, defaultNumber: initialValue),
      child: Consumer<NrcNotifier>(
        // listener: (context, state) {
        //   state.maybeMap(orElse: () {
        //     EasyLoading.dismiss();
        //   }, loading: (_) {
        //     EasyLoading.show(maskType: EasyLoadingMaskType.clear);
        //   });
        //   final nrcDetail = state.numberInfo;
        //   final wrapperNrcDetail = nrcDetail.copyWith(
        //     nrcType:
        //         nrcDetail.type == NRCNumberType.nrc && nrcDetail.nrcType == null
        //             ? NRCType.n
        //             : nrcDetail.nrcType,
        //   );
        //   onNrcInfoChanged?.call(wrapperNrcDetail);
        // },
        builder: (context, notifier, _) {
          final state = notifier.state;


          // TODO : rather than calling onNrcInfoChanged() in each changes, need to call it once
          WidgetsBinding.instance.addPostFrameCallback((_) {
            state.maybeMap(
              loading: (_) {
                EasyLoading.show(maskType: EasyLoadingMaskType.clear);
              },
              orElse: () {
                EasyLoading.dismiss();
              },
            );
          });

          return IgnorePointer(
            ignoring: state.isLoading,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SingleSelectedGroup<NRCNumberType>(
                  label: '$_prefix NRC Number',
                  items: NRCNumberType.values
                      .where((type) =>
                          noNrcEnabled ? true : type != NRCNumberType.noNrc)
                      .toList(),
                  labelParser: (type) => type.getName(context),
                  onSelectChanged: (type) {
                    context.read<NrcNotifier>().selectNumberType(type);
                    onNrcInfoChanged
                        ?.call(state.numberInfo.copyWith(type: type, number: ''));
                  },
                  selectedItem: state.numberInfo.type,
                ),
                kSpaceVertical8,
                _buildNrcForm(state.numberInfo.type, onNrcInfoChanged),
                if (state.numberInfo.type != NRCNumberType.noNrc) ...[
                  // kSpaceVertical8,
                  // NrcNumberTextField(
                  //   initialValue: state.numberInfo.number,
                  //   type: state.numberInfo.type,
                  //   prefixLabel: prefixLabel,
                  //   onChanged: (text) {
                  //     context.read<NrcNotifier>().updateNumber(text);

                  //     onNrcInfoChanged
                  //         ?.call(state.numberInfo.copyWith(number: text));
                  //   },
                  // ),
                  kSpaceVertical8,
                  DatePickerField(
                    labelText: 'NRC Issuance Date',
                    maxTime: DateTime.now(),
                    onConfirm: (date) {
                      context.read<NrcNotifier>().updateIssuanceDate(date);
                      onNrcInfoChanged
                          ?.call(state.numberInfo.copyWith(issuanceDate: date));
                    },
                    selectedDateTime: state.numberInfo.issuanceDate,
                  ),
                ],
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildNrcForm(NRCNumberType type, OnNrcInfoChanged? onNrcInfoChanged) {
    switch (type) {
      case NRCNumberType.noNrc:
        return const SizedBox();
      case NRCNumberType.nrc:
        return NRCForm(prefixLabel: _prefix, onChanged: onNrcInfoChanged);
      case NRCNumberType.frc:
        return FRCForm(prefixLabel: _prefix, onChanged: onNrcInfoChanged);
    }
  }
}
