part of 'nrc_view.dart';

class NRCForm extends StatelessWidget {
  const NRCForm({
    super.key,
    this.prefixLabel = '',
    required this.onChanged,
  });

  final String prefixLabel;
  final OnNrcInfoChanged? onChanged;

  @override
  Widget build(BuildContext context) {
    return Consumer<NrcNotifier>(
      builder: (context, notifier, _) {
        final state = notifier.state;

        return Column(
          children: [
            SelectedField<NrcRegion>.simple(
              title: '$prefixLabel NRC Region',
              required: true,
              items: state.regions,
              selectedItem: state.numberInfo.region,
              onSelected: (region) {
                context.read<NrcNotifier>().selectRegion(region);
                onChanged?.call(state.numberInfo.copyWith(region: region));
              },
            ),
            kSpaceVertical8,
            SelectedField<NrcPrefix>(
              title: '$prefixLabel NRC Prefix',
              required: true,
              items: state.prefixes,
              labelParser: (item) => item.nrc2Name,
              selectedItem: state.numberInfo.nrcPrefix,
              onSelected: (prefix) {
                context.read<NrcNotifier>().selectPrefix(prefix);
                onChanged?.call(state.numberInfo.copyWith(nrcPrefix: prefix));
              },
            ),
            kSpaceVertical8,
            SingleSelectedGroup<NRCType>(
              label: '$prefixLabel NRC Type',
              items: NRCType.values,
              labelParser: (type) => '(${type.name.toUpperCase()})',
              onSelectChanged: (type) {
                context.read<NrcNotifier>().selectType(type);
                onChanged?.call(state.numberInfo.copyWith(nrcType: type));
              },
              selectedItem: state.numberInfo.nrcType,
            ),
             kSpaceVertical8,
                  NrcNumberTextField(
                    initialValue: state.numberInfo.number,
                    type: state.numberInfo.type,
                    prefixLabel: prefixLabel,
                    onChanged: (text) {
                      context.read<NrcNotifier>().updateNumber(text);

                     onChanged
                          ?.call(state.numberInfo.copyWith(number: text));
                    },
                  ),
          ],
        );
      },
    );
  }
}
