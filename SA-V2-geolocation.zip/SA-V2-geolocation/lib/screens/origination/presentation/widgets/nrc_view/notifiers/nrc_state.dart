import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/base/error.dart';
import 'package:sales/data/remote/models/models.dart';

part  'nrc_state.freezed.dart';

@freezed
class NrcState with _$NrcState {
  const NrcState._();

  const factory NrcState.loading({
    @Default(NRCNumber()) NRCNumber numberInfo,
    @Default([]) List<NrcRegion> regions,
    @Default([]) List<NrcPrefix> prefixes,
  }) = _loading;

  const factory NrcState.failed(
    String message,
    AppError? error, {
    @Default(NRCNumber()) NRCNumber numberInfo,
    @Default([]) List<NrcRegion> regions,
    @Default([]) List<NrcPrefix> prefixes,
  }) = _failed;

  const factory NrcState.loaded({
    @Default(NRCNumber()) NRCNumber numberInfo,
    @Default([]) List<NrcRegion> regions,
    @Default([]) List<NrcPrefix> prefixes,
  }) = _NrcState;

  bool get isLoading => maybeMap(
        orElse: () => false,
        loading: (_) => true,
      );
}
