import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/base/error.dart';
import 'package:sales/data/remote/models/models.dart';

part 'marital_data_state.freezed.dart';

enum Status { loading, loaded, failed }

@freezed
class MaritalDataState with _$MaritalDataState {
  const MaritalDataState._();

  const factory MaritalDataState({
    @Default(Status.loaded) Status status,
    String? message,
    AppError? error,
    @Default([]) List<MaritalStatus> data,
   
  }) = _MaritalDataState;
}
