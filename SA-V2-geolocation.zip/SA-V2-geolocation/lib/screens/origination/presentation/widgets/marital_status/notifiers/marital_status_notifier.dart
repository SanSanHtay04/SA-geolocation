import 'package:flutter/foundation.dart';
import 'package:sales/data/repositories/repositories.dart';
import 'package:sales/screens/origination/presentation/widgets/marital_status/notifiers/marital_data_state.dart';

class MaritalStatusNotifier extends ChangeNotifier {
  final MaritalStatusRepo _repo;

  MaritalDataState state = const MaritalDataState();

  MaritalStatusNotifier(this._repo);

  void emit(MaritalDataState data) {
    state = data;
    notifyListeners();
  }

  fetchStatuses() async {
    emit(MaritalDataState(status: Status.loading, data: []));
    final res = await _repo.getStatuses();
    final newState = res.when(success: (data) {
      return state.copyWith(
        status: Status.loaded,
        data: data,
      );
    }, failed: (message, _) {
      return state.copyWith(
        status: Status.failed,
        message: message,
      );
    });
    emit(newState);
  }
}
