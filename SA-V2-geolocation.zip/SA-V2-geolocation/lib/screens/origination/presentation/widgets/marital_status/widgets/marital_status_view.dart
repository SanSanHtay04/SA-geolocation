import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/models/phone_type.dart';
import 'package:sales/data/repositories/repositories.dart';
import 'package:sales/screens/origination/presentation/widgets/marital_status/notifiers/marital_status_notifier.dart';
import 'package:sales/screens/origination/presentation/widgets/marital_status/widgets/spouse_info_widget.dart';
import 'package:sales/widgets/selected_field/selected_field.dart';

class MaritalStatusView extends StatelessWidget {
  const MaritalStatusView({
    super.key,
    this.selectedValue,
    this.name,
    this.phone,
    this.status,
    this.nrcNumber,
    required this.onChanged,
    required this.onNameChanged,
    required this.onPhoneChanged,
    required this.onNrcChanged,
    required this.onStatusChanged,
  });

  final MaritalStatus? selectedValue;
  final String? name;
  final String? phone;
  final PhoneStatus? status;
  final NRCNumber? nrcNumber;

  final Function(MaritalStatus) onChanged;
  final Function(String) onNameChanged;
  final Function(String) onPhoneChanged;
  final Function(NRCNumber) onNrcChanged;
  final Function(PhoneStatus) onStatusChanged;

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => MaritalStatusNotifier(
        MaritalStatusRepo(context.read()),
      )..fetchStatuses(),
      child: Consumer<MaritalStatusNotifier>(
        builder: (context, notifier, _) {
          MaritalStatus? selectedItem;
          try {
            selectedItem = notifier.state.data.firstWhere(
              (e) => e.maritalStatusId == selectedValue?.maritalStatusId,
            );
          } catch (_) {
            selectedItem = null;
          }
          return Column(
            children: [
              SelectedField<MaritalStatus>.simple(
                title: 'Marital status',
                items: notifier.state.data ?? [],
                required: true,
                selectedItem: selectedItem,
                onSelected: onChanged,
              ),
              selectedValue?.isMarried ?? false
                  ? SpouseInfoWidget(
                      name: name,
                      phone: phone,
                      status: status,
                      nrcNumber: nrcNumber,

                      onNameChanged: onNameChanged,
                      onPhoneChanged: onPhoneChanged,
                onStatusChanged: onStatusChanged,
                      onNrcChanged: onNrcChanged,

                    )
                  : const SizedBox(),
            ],
          );
        },
      ),
    );
  }
}
