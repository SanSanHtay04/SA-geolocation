import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/models/phone_type.dart';
import 'package:sales/screens/origination/presentation/widgets/nrc_view/widgets/nrc_view.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/selected_field/selected_field.dart';
import 'package:sales/widgets/text_form_field/clearable_text_form_field.dart';
import 'package:sales/widgets/text_form_field/phone_text_form_field.dart';

class SpouseInfoWidget extends StatelessWidget {
  const SpouseInfoWidget({
    super.key,
    this.name,
    this.phone,
    this.status,
    this.nrcNumber,
    required this.onNameChanged,
    required this.onPhoneChanged,
    required this.onNrcChanged,
    required this.onStatusChanged,
  });

  final String? name;
  final String? phone;
  final PhoneStatus? status;
  final NRCNumber? nrcNumber;

  final Function(String) onNameChanged;
  final Function(String) onPhoneChanged;
  final Function(NRCNumber) onNrcChanged;
  final Function(PhoneStatus) onStatusChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        kSpaceVertical8,
        ClearableTextFormField(
          initialValue: name,
          labelText: 'Spouse Name',
          required: true,
          prefixIcon: const Icon(Icons.person_rounded),
          inputFormatters: [
            FilteringTextInputFormatter.allow(
              RegExp("[a-zA-Z ]"),
            )
          ],
          textCapitalization: TextCapitalization.words,
          onChanged: (name) {
            onNameChanged(name);
          },
        ),
        kSpaceVertical8,
        PhoneTextFormField(
          initialValue: phone,
          labelText: 'Spouse Phone Number',
          onChanged: (phone) {
            onPhoneChanged(phone);
          },
        ),
        kSpaceVertical8,
        SelectedField<PhoneStatus>(
          title: 'Spouse Phone Status',
          items: PhoneStatus.values,
          labelParser: (item) => item.getName(context),
          selectedItem: status,
          onSelected: (value) {
            onStatusChanged(value);
          },
        ),
        kSpaceVertical8,
        NrcView(
          initialValue: nrcNumber,
          prefixLabel: 'Spouse',
          noNrcEnabled: true,
          onNrcInfoChanged: (info) {
            onNrcChanged(info);
          },
        )
      ],
    );
  }
}
