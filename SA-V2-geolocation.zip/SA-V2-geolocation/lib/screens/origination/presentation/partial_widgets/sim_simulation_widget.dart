import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../../widgets/deprecated/text_button_widget.dart';
import '../../../../widgets/item_info_widget.dart';

class SimSimulationWidget extends StatelessWidget {
  final Map<String, dynamic>? prospect;
  final Function()? chooseSimulation;

  SimSimulationWidget({required this.prospect, required this.chooseSimulation});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(
            '3. SIMULATION',
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.teal[600]),
          ),
          this.chooseSimulation != null ? TextButtonWidget(
            text: prospect!['simulationId'] == null ? "SELECT" : "CHANGE",
            iconData:
                prospect!['simulationId'] == null ? Icons.add : Icons.edit,
            onTap: chooseSimulation,
          ) : SizedBox(height: 40,),
        ]),
        prospect!['simulationId'] == null
            ? SizedBox()
            : Column(children: [
                Divider(
                  height: 10,
                  thickness: 0.5,
                ),
                ItemInfoWidget(
                  title: 'Payment At',
                  value:
                      '${prospect!['paymentAtEnd'] == 1 ? 'END' : 'START'} of each period',
                ),
                Divider(
                  height: 10,
                  thickness: 0.5,
                ),
                ItemInfoWidget(
                  title: 'Product Price',
                  value:
                      '${NumberFormat('#,###').format(prospect!['totalPrice'] ?? 0)} MMK',
                ),
                Divider(
                  height: 10,
                  thickness: 0.5,
                ),
                ItemInfoWidget(
                  title: 'Deposit',
                  value:
                      '${NumberFormat('#,###').format(prospect!['depositAmount'])} MMK (${prospect!['depositPercentage']}%)',
                ),
                Divider(
                  height: 10,
                  thickness: 0.5,
                ),
                ItemInfoWidget(
                  title: 'Early Prepayment:',
                  value:
                      '${NumberFormat('#,###').format(prospect!['earlyPrepaymentAmount'])} MMK (${prospect!['earlyPrepaymentPercentage']}%)',
                ),
                Divider(
                  height: 10,
                  thickness: 0.5,
                ),
                ItemInfoWidget(
                  title: 'Amount Financed',
                  value:
                      '${NumberFormat('#,###').format(prospect!['amountFinanced'] ?? 0)} MMK',
                ),
                Divider(
                  height: 10,
                  thickness: 0.5,
                ),
                ItemInfoWidget(
                  title: 'Effective Amount Financed',
                  value:
                      '${NumberFormat('#,###').format(prospect!['effectiveAmountFinanced'])} MMK',
                ),
                Divider(
                  height: 10,
                  thickness: 0.5,
                ),
                ItemInfoWidget(
                  color: Colors.green,
                  title: 'Interest Rate',
                  value: '${prospect!['interestRate']}%',
                ),
                Divider(
                  height: 10,
                  thickness: 0.5,
                ),
                ItemInfoWidget(
                  title: 'Duration',
                  value: '${prospect!['duration']} months',
                ),
                Divider(
                  height: 10,
                  thickness: 0.5,
                ),
                ItemInfoWidget(
                  title: 'Periodicity',
                  value: prospect!['pmtPeriodicity'] == 'm'
                      ? 'Monthly'
                      : 'Quarterly',
                ),
                Divider(
                  height: 10,
                  thickness: 0.5,
                ),
                ItemInfoWidget(
                  title: 'MAINTENANCE Covered',
                  value: prospect!['maintenanceCovered'] == 1 ? 'YES' : 'NO',
                ),
                Divider(
                  height: 10,
                  thickness: 0.5,
                ),
                // ItemInfoWidget(
                //   title: 'INSURANCE Covered',
                //   value: prospect!['insuranceCovered'] == 1 ? 'YES' : 'NO',
                // ),
                // Divider(
                //   height: 10,
                //   thickness: 0.5,
                // ),

                ItemInfoWidget(
                  title: 'LIFE INSURANCE Covered',
                  value: //'TEST'
                      prospect!['insLifeCovered'] == 1 ? 'YES' : 'NO',
                ),
                Divider(
                  height: 10,
                  thickness: 0.5,
                ),
                ItemInfoWidget(
                  title: 'ASSET INSURANCE Covered',
                  value: //'TEST'
                      prospect!['insAssetCovered'] == 1 ? 'YES' : 'NO',
                ),
                Divider(
                  height: 10,
                  thickness: 0.5,
                ),

                ItemInfoWidget(
                  title: 'First Payment',
                  value:
                      '${NumberFormat('#,###').format(prospect!['actualFirstPayment'] - prospect!['amountFinancedAdminFeeAddUp'] + prospect!['zeroCostTotalInsCost'] + prospect!['zeroCostTotalMaintCost'] + prospect!['earlyPrepaymentAmount'])} MMK',
                ),
                Text(
                  "(including Deposit ${prospect!['adminFee'] > 0 ? ', Admin Fee' : ''}${prospect!['earlyPrepaymentAmount'] > 0 ? ', Early Prepayment' : ''}${prospect!['zeroCostTotalInsCost'] > 0 ? ', Upfront Insurance' : ''}${prospect!['zeroCostTotalMaintCost'] > 0 ? ', Upfront Maintenance' : ''})",
                  textAlign: TextAlign.right,
                  style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                ),
                Divider(
                  height: 10,
                  thickness: 0.5,
                ),
                ItemInfoWidget(
                  title:
                      "Following ${prospect!['isZeroCost'] > 0 ? '[Fall-Back] ' : ''}Payment",
                  value:
                      '${NumberFormat('#,###').format(prospect!['followingPayment'])} MMK',
                ),
                prospect!['isZeroCost'] == 0
                    ? SizedBox()
                    : Column(
                        children: [
                          SizedBox(
                            height: 10,
                          ),
                          Divider(),
                          Text(
                            'ZERO-COST SCHEME',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 16),
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          ItemInfoWidget(
                            title: "Installments",
                            value: '${prospect!['zeroCostPmtTimes']} times',
                          ),
                          Divider(
                            height: 10,
                            thickness: 0.5,
                          ),
                          ItemInfoWidget(
                            title: "Monthly Installment Amount",
                            value:
                                '${NumberFormat('#,###').format(prospect!['zeroCostMonthlyPaymentAmount'])} MMK',
                          ),
                        ],
                      ),
                Divider(
                  height: 10,
                  thickness: 0.5,
                ),
                SizedBox(
                  height: 5,
                ),
              ]),
      ]),
    );
  }
}
