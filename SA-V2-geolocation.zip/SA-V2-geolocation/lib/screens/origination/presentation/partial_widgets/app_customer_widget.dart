import 'package:flutter/material.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/widgets/info_preview_card.dart';

import '../../../../widgets/item_info_widget.dart';

/// TODO : need to request 'homeGeoLatitude, homeGeoLongitude, maritalStatusId, spouseName, spouseMobileNo,spouseNatRegCardNo'
/// at endpoint : /contract/prospect/{id}
class AppCustomerWidget extends StatelessWidget {
  AppCustomerWidget({required this.prospect, required this.createApplication});

  final Map<String, dynamic>? prospect;
  final Function() createApplication;

  String get birthDate => (prospect!['birthDate'] != null) ? DateTime.parse(prospect!['birthDate']).format() : '-/-';

  bool get isMarried => prospect!['maritalStatusId'] == 2;

  bool get hasViberAccount => prospect!['hasViberAccount'] == 1;

  bool get isViberAccountSameNo => prospect!['isViberAccountSameNo'] == 1;

  @override
  Widget build(BuildContext context) {
    return InfoPreviewCard(
      isViewCard: prospect!['createdCustId'] == null,
      onIconButtonTapped: createApplication,
      primaryLabel: '5. CUSTOMER',
      children: [
        ItemInfoWidget(
          title: 'Customer',
          value: prospect!['customerFullName'],
        ),
        ItemInfoWidget(
          title: 'Birth Date',
          value: birthDate,
        ),
        ItemInfoWidget(
          title: 'NRC Number',
          value: prospect!['natRegCardNo'],
        ),
        ItemInfoWidget(
          title: 'Father',
          value: prospect!['fatherName'],
        ),
        ItemInfoWidget(
          title: 'Marital Status',
          value: prospect!['maritalStatusName'],
        ),
        if (isMarried) ...[
          ItemInfoWidget(
            title: 'Spouse Name',
            value: prospect!['spouseName'],
          ),
          ItemInfoWidget(
            title: 'Spouse Phone Number',
            value: prospect!['spouseMobileNo'],
          ),
          ItemInfoWidget(
            title: 'Spouse NRC Number',
            value: prospect!['spouseNatRegCardNo'],
          ),
        ],
        ItemInfoWidget(
          title: 'Home Status',
          value: prospect!['homeStatus'],
        ),
        ItemInfoWidget(
          title: 'Home Address',
          value: prospect!['homeAddress'],
        ),
        Text(
          "${prospect!['geoVillageId'] != null ? (prospect!['geoVillageName'] ?? '') : ''}${prospect!['geoWardId'] != null ? (prospect!['geoWardName'] ?? '') : ''}, ${prospect!['geoTownName']}, ${prospect!['geoTownShipName']}, ${prospect!['geoDistrictName']}, ${prospect!['geoRegionName']}",
          style: TextStyle(color: Colors.grey),
        ),
        ItemInfoWidget(
          title: 'Geolocation',
          value: '(${prospect!['homeGeoLatitude']}, ${prospect!['homeGeoLongitude']})',
        ),
        ItemInfoWidget(
          title: 'Phone Number1',
          value: prospect?['phoneNo1'].toString(),
        ),
        ItemInfoWidget(
          title: 'Has VIBER Account',
          value: hasViberAccount.toYesNo(),
        ),
        if (hasViberAccount) ...[
          ItemInfoWidget(
            title: 'Same as Phone 1',
            value: isViberAccountSameNo.toYesNo(),
          ),
          if (!isViberAccountSameNo) ...[
            ItemInfoWidget(
              title: 'Account No (if different)',
              value: prospect!['viberAccountNo'].toString(),
            ),
          ],
          ItemInfoWidget(
            title: 'Viber account name',
            value:  prospect!['viberAccountName'].toString(),
          ),
        ],
        ItemInfoWidget(
          title: 'Total HH Members',
          value: prospect!['totalHousehold'].toString(),
        ),
      ],
    );
  }
}
