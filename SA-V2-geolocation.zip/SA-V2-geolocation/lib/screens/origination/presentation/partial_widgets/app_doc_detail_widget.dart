import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';

import '../../../../widgets/deprecated/text_button_widget.dart';

class AppDocDetailWidget extends StatefulWidget {
  final Map<String, dynamic>? prospect;
  final List<Map<String, dynamic>> appDocs;
  final Function() createAppDoc;
  final Function(int) editAppDoc;
  final Function(int) deleteAppDoc;

  AppDocDetailWidget(
      {required this.prospect,
      required this.appDocs,
      required this.createAppDoc,
      required this.editAppDoc,
      required this.deleteAppDoc});

  @override
  _AppDocDetailWidgetState createState() => _AppDocDetailWidgetState();
}

class _AppDocDetailWidgetState extends State<AppDocDetailWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(
            '9. SUPPORTING DOCS (${widget.appDocs.length})',
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.teal[600]),
          ),
          TextButtonWidget(
            text: "ADD",
            iconData: Icons.add,
            onTap: widget.createAppDoc,
          )
        ]),
        Divider(
          thickness: 1.5,
        ),
        Expanded(
          child: widget.prospect!['applicationId'] == null
              ? SizedBox()
              : Container(
                  child: ListView.separated(
                    itemCount: widget.appDocs.length,
                    separatorBuilder: (context, index) {
                      return Divider();
                    },
                    itemBuilder: (context, i) {
                      return Slidable(
                        child: ListTile(
                          contentPadding: EdgeInsets.zero,
                          dense: true,
                          visualDensity:
                              VisualDensity(horizontal: 0, vertical: -4),
                          title: Text(
                            "${(i + 1).toString()}. ${widget.appDocs[i]['documentName']}",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                          subtitle: Padding(
                            padding: EdgeInsets.only(left: 20, top: 10),
                            child: Text(
                                "Remark: ${widget.appDocs[i]['docDetRemark'] ?? '-/-'}"),
                          ),
                          trailing: Text(
                            "[${widget.appDocs[i]['docTypeName'].toString().toUpperCase()}]",
                            style: TextStyle(
                                fontSize: 12,
                                color: Colors.blue[800],
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                        endActionPane: ActionPane(
                          motion: const DrawerMotion(),
                          extentRatio: 0.25,
                          children: [
                            SlidableAction(
                              label: 'Edit',
                              backgroundColor: Colors.blue,
                              icon: Icons.edit,
                              onPressed: (context) {
                                widget
                                    .editAppDoc(widget.appDocs[i]['docDetId']);
                              },
                            ),
                            SlidableAction(
                              label: 'Delete',
                              backgroundColor: Colors.red,
                              icon: Icons.delete,
                              onPressed: (context) {
                                widget.deleteAppDoc(
                                    widget.appDocs[i]['docDetId']);
                              },
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                  // child: ListView.builder(
                  //     itemCount: widget.appDocs.length,
                  //     itemBuilder: (context, i) {
                  //       return Column(
                  //         mainAxisAlignment: MainAxisAlignment.start,
                  //         crossAxisAlignment: CrossAxisAlignment.start,
                  //         children: [
                  //           Row(
                  //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //             crossAxisAlignment: CrossAxisAlignment.start,
                  //             children: [
                  //               Text("${(i + 1).toString()}. ", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, ),),
                  //               Expanded(child: Text(
                  //                 "${widget.appDocs[i]['documentName']}",
                  //                 style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, ),
                  //               )),
                  //               Row(
                  //                 children: [
                  //                   Container(
                  //                     child: IconButton(
                  //                         icon: Icon(Icons.edit, color: Colors.blue),
                  //                         onPressed: () {
                  //                           widget.editAppDoc(widget.appDocs[i]['docDetId']);
                  //                         }),
                  //                   ),
                  //                   IconButton(
                  //                       icon: Icon(Icons.delete, color: Colors.red),
                  //                       onPressed: () {
                  //                         widget.deleteAppDoc(widget.appDocs[i]['docDetId']);
                  //                       }),
                  //                 ],
                  //               ),
                  //             ],
                  //           ),

                  //           Padding(
                  //             padding: const EdgeInsets.only(left: 18, right: 12),
                  //             child: Row(
                  //               mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //               children: [
                  //                 Text("Remark: ${widget.appDocs[i]['docDetRemark'] ?? '-/-'}"),
                  //                 Text(
                  //                   "[${widget.appDocs[i]['docTypeName'].toString().toUpperCase()}]",
                  //                   style: TextStyle(fontSize: 12, color: Colors.grey[700], fontWeight: FontWeight.bold),
                  //                 ),
                  //               ],
                  //             ),
                  //           ),
                  //           Divider(
                  //             thickness: 1.5,
                  //           ),
                  //         ],
                  //       );
                  //     }),
                ),
        ),
      ]),
    );
  }
}
