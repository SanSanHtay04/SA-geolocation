import 'package:flutter/material.dart';

import '../../../../widgets/deprecated/text_button_widget.dart';
import '../../../../widgets/item_info_widget.dart';

class SimProspectWidget extends StatefulWidget {
  final Map<String, dynamic>? prospect;
  final Function()? editProspect;
  final String? connectionType;

  SimProspectWidget(
      {required this.prospect,
      required this.editProspect,
      required this.connectionType});

  @override
  _SimProspectWidgetState createState() => _SimProspectWidgetState();
}

class _SimProspectWidgetState extends State<SimProspectWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(
              '1. PROSPECT',
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.teal[600]),
            ),
            widget.editProspect != null ? TextButtonWidget(
              text: "EDIT",
              iconData: Icons.edit,
              onTap: widget.editProspect,
            ) : SizedBox(height: 40,),
          ]),
          Divider(
            height: 10,
            thickness: 0.5,
          ),
          ItemInfoWidget(
            title: 'Merchant Name',
            value: widget.prospect!['merchantName'] ?? '',
          ),
          Divider(
            height: 10,
            thickness: 0.5,
          ),
          ItemInfoWidget(
            title: 'POS Name',
            value: widget.prospect!['posName'] ?? '',
          ),
          Divider(
            height: 10,
            thickness: 0.5,
          ),
          ItemInfoWidget(
            title: 'Prospect Name',
            value: widget.prospect!['prospectName'].toString(),
          ),
          Divider(
            height: 10,
            thickness: 0.5,
          ),
          ItemInfoWidget(
            title: 'Gender',
            value: widget.prospect!['prospectGender'].toString() == 'm'
                ? 'Male'
                : 'Female',
          ),
          Divider(
            height: 10,
            thickness: 0.5,
          ),
          ItemInfoWidget(
            title: 'Mobile 1',
            value: widget.prospect!['prospectMobile'].toString(),
          ),
          Divider(
            height: 10,
            thickness: 0.5,
          ),
          widget.prospect!['prospectOtherMobile'] == null
              ? SizedBox()
              : ItemInfoWidget(
                  title: 'Mobile 2',
                  value: widget.prospect!['prospectOtherMobile'].toString(),
                ),
          widget.prospect!['prospectOtherMobile'] == null
              ? SizedBox()
              : Divider(
                  height: 10,
                  thickness: 0.5,
                ),
          widget.prospect!['prospectRemark'] == null
              ? SizedBox()
              : ItemInfoWidget(
                  title: 'Remark',
                  value: widget.prospect!['prospectRemark'].toString(),
                ),
          widget.prospect!['prospectRemark'] == null
              ? SizedBox()
              : Divider(
                  height: 10,
                  thickness: 0.5,
                ),
          SizedBox(
            height: 10,
          ),
        ],
      ),
    );
  }
}
