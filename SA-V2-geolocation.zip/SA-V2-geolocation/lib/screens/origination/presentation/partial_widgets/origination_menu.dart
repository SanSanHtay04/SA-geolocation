import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/routes.dart';

import 'package:sales/screens/origination/counter_proposal/counter_proposals_screen.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/utils/utils.dart';

import '../../../../providers/auth_provider.dart';
import '../../../data_sync_screen.dart';
import '../../prospects/prospects_screen.dart';

// TODO : refactor later
class OriginationMenu extends StatelessWidget {
  final List<MenuEntry> menuItems;
  final Map<String, dynamic>? currentPos;
  final String connectionType;

  const OriginationMenu(
    this.menuItems,
    this.currentPos,
    this.connectionType,
  );

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: ListView.builder(
        itemCount: menuItems.length,
        itemBuilder: (context, index) {
          return _MenuButton(
              menuItem: menuItems[index],
              onTap: () {
                String routeName = menuItems[index].route;
                switch (routeName) {
                  case OriginationBottomTab.prospects:
                    {
                      if (currentPos != null) {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => ProspectsScreen(
                                    currentPosId: currentPos!["posId"],
                                    connectionType: connectionType,
                                    userId: context.read<AuthProvider>().accountInfo!.userId,
                                    userWorkPlaceId: context.read<AuthProvider>().accountInfo!.userWorkplaceId,
                                  )),
                        );
                      }
                    }
                    break;

                  case OriginationBottomTab.counerProposals:
                    {
                      if (currentPos != null) {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => CounterProposalsScreen(
                                    currentPosId: currentPos!["posId"],
                                    connectionType: connectionType,
                                    userId: context.read<AuthProvider>().accountInfo!.userId,
                                    userWorkPlaceId: context.read<AuthProvider>().accountInfo!.userWorkplaceId,
                                  )),
                        );
                      }
                    }
                    break;

                  case OriginationBottomTab.dataSync:
                    {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => DataSyncScreen(
                                  connectionType: connectionType,
                                )),
                      );
                    }
                    break;

                  default:
                    Navigator.pushNamed(context, routeName);
                    break;
                }
              });
        },
      ),
    );
  }
}

class _MenuButton extends StatelessWidget {
  final VoidCallback? onTap;
  final MenuEntry? menuItem;

  const _MenuButton({this.menuItem, this.onTap});

  @override
  Widget build(BuildContext context) => InkWell(
        child: Container(
          height: 80,
          margin: EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(20),
          child: Row(
            children: <Widget>[
              Container(
                alignment: Alignment.center,
                child: Icon(
                  menuItem!.icon,
                  color: Colors.orangeAccent[100],
                  size: 36,
                ),
              ),
              kSpaceHorizontal12,
              Expanded(
                child: Container(
                  alignment: Alignment.center,
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      menuItem!.title,
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: context.getColorScheme().onPrimary,
                      ),
                      textAlign: TextAlign.left,
                    ),
                  ),
                ),
              ),
            ],
          ),
          decoration: BoxDecoration(
            color: context.getColorScheme().primary,
            borderRadius: BorderRadius.circular(15),
          ),
        ),
        splashColor: context.getColorScheme().primary,
        onTap: onTap,
      );
}

class MenuEntry {
  final IconData icon;
  final String title;
  final String route;

  const MenuEntry(this.icon, this.title, this.route);
}
