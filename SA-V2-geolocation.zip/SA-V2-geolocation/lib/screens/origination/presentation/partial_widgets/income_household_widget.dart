import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:intl/intl.dart';

import '../../../../widgets/deprecated/text_button_widget.dart';

class IncomeHouseholdWidget extends StatefulWidget {
  final Map<String, dynamic>? prospect;
  final List<dynamic> householdIncomes;
  final Function()? createCustHousehold;
  final Function(int)? editCustHousehold;
  final Function(int)? deleteCustHousehold;
  final Function(int)? showCustHousehold;

  IncomeHouseholdWidget(
      {required this.prospect,
      required this.householdIncomes,
      this.createCustHousehold,
      this.editCustHousehold,
      this.deleteCustHousehold,
      this.showCustHousehold});

  @override
  _IncomeHouseholdWidgetState createState() => _IncomeHouseholdWidgetState();
}

class _IncomeHouseholdWidgetState extends State<IncomeHouseholdWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(
            '7. HH INCOME (${widget.householdIncomes.length})',
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.teal[600]),
          ),
          TextButtonWidget(
            text: "ADD",
            iconData: Icons.add,
            onTap: widget.createCustHousehold,
          )
        ]),
        Divider(
          thickness: 1.5,
        ),
        Expanded(
          child: widget.prospect!['applicationId'] == null
              ? SizedBox()
              : Container(
                  child: ListView.separated(
                    itemCount: widget.householdIncomes.length,
                    separatorBuilder: (context, index) {
                      return Divider();
                    },
                    itemBuilder: (context, i) {
                      return Slidable(
                        child: ListTile(
                          contentPadding: EdgeInsets.zero,
                          dense: true,
                          visualDensity:
                              VisualDensity(horizontal: 0, vertical: -4),
                          title: Text(
                              "${(i + 1).toString()}. ${widget.householdIncomes[i]['householdName']}",
                              style: TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 16),
                            ),
                          subtitle: Padding(
                            padding: EdgeInsets.only(left: 20, top: 5),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Relation: ${ widget.householdIncomes[i]['relationDetail'] ?? '-/-' }",
                                ),
                                Text(
                                  "Income: ${NumberFormat('#,###').format(widget.householdIncomes[i]['incomeAmount'])} MMK",
                                ),
                              ],
                            ),
                          ),
                          trailing: Text(
                            "[${widget.householdIncomes[i]['incomePeriodicity'] == 1 ? 'MONTHLY' : (widget.householdIncomes[i]['incomePeriodicity'] == 3 ? 'QUARTERLY' : 'YEARLY')}]",
                            style: TextStyle(
                                fontSize: 12,
                                color: Colors.blue[800],
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                        endActionPane: ActionPane(
                          motion: const DrawerMotion(),
                          extentRatio: 0.25,
                          children: [
                            SlidableAction(
                              label: 'Info',
                              backgroundColor: Colors.teal,
                              icon: Icons.info,
                              onPressed: (context) {
                                widget.showCustHousehold!(
                                    widget.householdIncomes[i]['householdId']);
                              },
                            ),
                            SlidableAction(
                              label: 'Edit',
                              backgroundColor: Colors.blue,
                              icon: Icons.edit,
                              onPressed: (context) {
                                widget.editCustHousehold!(
                                    widget.householdIncomes[i]['householdId']);
                              },
                            ),
                            SlidableAction(
                              label: 'Delete',
                              backgroundColor: Colors.red,
                              icon: Icons.delete,
                              onPressed: (context) {
                                widget.deleteCustHousehold!(
                                    widget.householdIncomes[i]['householdId']);
                              },
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
        ),
      ]),
    );
  }
}
