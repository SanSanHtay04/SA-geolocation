import 'package:flutter/material.dart';

import '../../../../widgets/deprecated/text_button_widget.dart';
import '../../../../widgets/item_info_widget.dart';

class AppApplicationWidget extends StatefulWidget {
  final Map<String, dynamic>? prospect;
  final Function() createApplication;
  final Function() editApplication;

  AppApplicationWidget(
      { required this.prospect, required this.createApplication, required this.editApplication });

  @override
  _AppApplicationWidgetState createState() => _AppApplicationWidgetState();
}

class _AppApplicationWidgetState extends State<AppApplicationWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(children: [
        SizedBox(
          height: 10,
        ),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(
            '4. APPLICATION',
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.teal[600]),
          ),
          widget.prospect!['applicationId'] == null
              ? TextButtonWidget(
                  text: "CREATE",
                  iconData: Icons.add,
                  onTap: widget.createApplication,
                )
              : TextButtonWidget(
                  text: "EDIT",
                  iconData: Icons.edit,
                  onTap: widget.editApplication,
                ),
        ]),
        widget.prospect!['applicationId'] == null
            ? SizedBox()
            : Column(
                children: [
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  ItemInfoWidget(
                    title: 'Application ID',
                    value: widget.prospect!['applicationId'].toString(),
                  ),
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  ItemInfoWidget(
                    title: 'Designated CA',
                    value: widget.prospect!['personDesignatedToFullName'].toString(),
                  ),
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  SizedBox(
                    height: 10,
                  ),
                ],
              ),
      ]),
    );
  }
}
