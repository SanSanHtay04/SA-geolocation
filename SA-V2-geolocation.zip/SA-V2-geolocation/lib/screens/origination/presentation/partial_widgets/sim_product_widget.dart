import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../../widgets/deprecated/text_button_widget.dart';
import '../../../../widgets/item_info_widget.dart';

class SimProductWidget extends StatefulWidget {
  final Map<String, dynamic>? prospect;
  final List<Map<String, dynamic>> attachedProducts;
  final Function()? chooseProduct;

  SimProductWidget(
      {required this.prospect,
      required this.attachedProducts,
      required this.chooseProduct});

  @override
  _SimProductWidgetState createState() => _SimProductWidgetState();
}

class _SimProductWidgetState extends State<SimProductWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(
            '2. PRODUCT',
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.teal[600]),
          ),
          widget.chooseProduct != null ? TextButtonWidget(
            text: widget.prospect!['packageId'] == null ? "SELECT" : "CHANGE",
            iconData:
                widget.prospect!['packageId'] == null ? Icons.add : Icons.edit,
            onTap: widget.chooseProduct,
          ) : SizedBox(height: 40,),
        ]),
        widget.prospect!['packageId'] == null ||
                widget.prospect!['packageId'] == ""
            ? SizedBox()
            : Divider(
                height: 10,
                thickness: 0.5,
              ),
        widget.prospect!['packageId'] == null
            ? SizedBox()
            : Column(
                children: [
                  ItemInfoWidget(
                    title: 'Category',
                    value: widget.prospect!['productCategoryName'].toString(),
                  ),
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  ItemInfoWidget(
                    title: 'Brand',
                    value: widget.prospect!['brandName'].toString(),
                  ),
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  ItemInfoWidget(
                    title: 'Model',
                    value: widget.prospect!['modelName'].toString(),
                  ),
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  ItemInfoWidget(
                    title: 'Product Code',
                    value: widget.prospect!['productCode'] ?? '-/-',
                  ),
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  ItemInfoWidget(
                    title: 'Product Name',
                    value: widget.prospect!['productName'].toString(),
                  ),
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  ItemInfoWidget(
                    title: 'Quantity',
                    value: widget.prospect!['quantity'].toString(),
                  ),
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),

                  // BUNDLE = 0 //
                  widget.prospect!['isBundle'] == 0
                      ? Column(
                          children: [
                            ItemInfoWidget(
                              title: 'Unit Price',
                              value:
                                  widget.prospect!['primaryUnitPrice'] != null ? "${NumberFormat("#,###").format(widget.prospect!['primaryUnitPrice'])} MMK" : '-/-',
                            ),
                            Divider(
                              height: 10,
                              thickness: 0.5,
                            ),
                            ItemInfoWidget(
                              title: 'Total Price',
                              value:
                                  "${NumberFormat("#,###").format(widget.prospect!['primaryTotalPrice'])} MMK",
                            ),
                            Divider(
                              height: 10,
                              thickness: 0.5,
                            ),
                          ],
                        )
                      : SizedBox(),

                  // BUNDLE = 1 //
                  widget.prospect!['isBundle'] == 1
                      ? Column(
                          children: [
                            ItemInfoWidget(
                              title: "Primary Product's Unit Price",
                              value:
                                  "${ widget.prospect!['primaryUnitPrice'] != null ? NumberFormat("#,###").format(widget.prospect!['primaryUnitPrice']) : '-/-' } MMK",
                            ),
                            Divider(
                              height: 10,
                              thickness: 0.5,
                            ),
                            ItemInfoWidget(
                              title: "Primary Product's Total Price",
                              value:
                                  "${NumberFormat("#,###").format(widget.prospect!['primaryTotalPrice'])} MMK",
                            ),
                            Divider(
                              height: 10,
                              thickness: 0.5,
                            ),
                            ItemInfoWidget(
                              title: "Total Bundle Price",
                              value:
                                  "${NumberFormat("#,###").format(widget.prospect!['packageTotalPrice'])} MMK",
                            ),
                            Divider(
                              height: 10,
                              thickness: 0.5,
                            ),
                          ],
                        )
                      : SizedBox(),

                  ItemInfoWidget(
                    title: 'Self-Registered',
                    value: widget.prospect!['isSelfRegistered'] == 1 ? 'YES' : 'NO',
                  ),
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),
                  ItemInfoWidget(
                    title: 'Second Hand Product',
                    value: widget.prospect!['isSecondHandProduct'] == 1 ? 'YES' : 'NO',
                  ),
                  Divider(
                    height: 10,
                    thickness: 0.5,
                  ),

                  SizedBox(
                    height: 10,
                  ),

                  // ATTACHED PRODUCTS //
                  widget.prospect!['isBundle'] == 1 &&
                          widget.attachedProducts.length > 0
                      ? Align(
                          child: Text("ATTACHED PRODUCTS",
                              style: TextStyle(
                                color: Colors.red,
                                fontWeight: FontWeight.bold,
                              )),
                          alignment: Alignment.centerLeft,
                        )
                      : SizedBox(),
                  widget.prospect!['isBundle'] == 1 &&
                          widget.attachedProducts.length > 0
                      ? Container(
                          child: ListView.separated(
                            shrinkWrap: true,
                            itemCount: widget.attachedProducts.length,
                            separatorBuilder: (context, index) {
                              return Divider(height: 0,);
                            },
                            itemBuilder: (context, i) {
                              return ListTile(
                                dense: true,
                                // isThreeLine: true,
                                contentPadding: EdgeInsets.zero,
                                visualDensity: VisualDensity(
                                    horizontal: 0, vertical: -4),
                                title: Row(
                                  children: [
                                    Text("${i + 1}. "),
                                    Text(
                                      "[${widget.attachedProducts[i]['productType'].toString().toUpperCase()}]",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: Colors.grey[700]),
                                    ),
                                    Text(
                                        " ${widget.attachedProducts[i]['productName']}"),
                                  ],
                                ),
                                subtitle: Padding(
                                  padding: EdgeInsets.only(
                                      left: 15, top: 0, right: 0, bottom: 0),
                                  child: Column(
                                    mainAxisAlignment:
                                        MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      widget.attachedProducts[i]
                                                  ['productTypeDetail'] !=
                                              null
                                          ? Text(widget.attachedProducts[i]
                                                  ['productTypeDetail']
                                              .toString())
                                          : SizedBox(),
                                      Text(
                                          "${NumberFormat('#,###').format(widget.attachedProducts[i]['productPrice'])} x ${widget.attachedProducts[i]['quantity'].toString()} = ${NumberFormat('#,###').format(widget.attachedProducts[i]['productPrice'] * widget.attachedProducts[i]['quantity'])} MMK"),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                        )
                      : SizedBox(),

                  widget.prospect!['isBundle'] == 1 &&
                          widget.attachedProducts.length > 0 ? SizedBox(height: 10,): SizedBox(),
                ],
              ),
      ]),
    );
  }
}
