import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';

import '../../../../widgets/deprecated/text_button_widget.dart';

class ContactDetailWidget extends StatefulWidget {
  final Map<String, dynamic>? prospect;
  final List<dynamic> custContacts;
  final Function() createCustContact;
  final Function(int) editCustContact;
  final Function(int) deleteCustContact;
  final Function(int)? showCustContact;

  ContactDetailWidget(
      {required this.prospect,
      required this.custContacts,
      required this.createCustContact,
      required this.editCustContact,
      required this.deleteCustContact,
      required this.showCustContact});

  @override
  _ContactDetailWidgetState createState() => _ContactDetailWidgetState();
}

class _ContactDetailWidgetState extends State<ContactDetailWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(
            '8. REF., GUARANTOR, BROKER (${widget.custContacts.length})',
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.teal[600]),
          ),
          TextButtonWidget(
            text: "ADD",
            iconData: Icons.add,
            onTap: widget.createCustContact,
          )
        ]),
        Divider(
          thickness: 1.5,
        ),
        Expanded(
          child: widget.prospect!['applicationId'] == null
              ? SizedBox()
              : Container(
                  child: ListView.separated(
                    itemCount: widget.custContacts.length,
                    separatorBuilder: (context, index) {
                      return Divider();
                    },
                    itemBuilder: (context, i) {
                      return Slidable(
                        child: ListTile(
                          contentPadding: EdgeInsets.zero,
                          dense: true,
                          visualDensity:
                              VisualDensity(horizontal: 0, vertical: -4),
                          title: Text(
                            "${(i + 1).toString()}. ${widget.custContacts[i]['relationFullName']}",
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 16),
                          ),
                          subtitle: Padding(
                            padding: EdgeInsets.only(left: 20, top: 10),
                            child: Text(
                                "Phone: ${widget.custContacts[i]['contactValue']}"),
                          ),
                          trailing: Text(
                            "[${widget.custContacts[i]['contactRole'].toString().toUpperCase()}]",
                            style: TextStyle(
                                fontSize: 12,
                                color: Colors.blue[800],
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                        endActionPane: ActionPane(
                          motion: const DrawerMotion(),
                          extentRatio: 0.25,
                          children: [
                            SlidableAction(
                              label: 'Edit',
                              backgroundColor: Colors.blue,
                              icon: Icons.edit,
                              onPressed: (context) {
                                widget.editCustContact(
                                    widget.custContacts[i]['contactDetId']);
                              },
                            ),
                            SlidableAction(
                              label: 'Delete',
                              backgroundColor: Colors.red,
                              icon: Icons.delete,
                              onPressed: (context) {
                                widget.deleteCustContact(
                                    widget.custContacts[i]['contactDetId']);
                              },
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                  // child: ListView.builder(
                  //     itemCount: widget.custContacts.length,
                  //     itemBuilder: (context, i) {
                  //       return Column(
                  //         mainAxisAlignment: MainAxisAlignment.start,
                  //         crossAxisAlignment: CrossAxisAlignment.start,
                  //         children: [
                  //           Row(
                  //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //             children: [
                  //               Text(
                  //                 "${(i + 1).toString()}. ${widget.custContacts[i]['relationFullName']}",
                  //                 style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  //               ),
                  //               Row(
                  //                   children: [
                  //                     Container(
                  //                       child: IconButton(
                  //                           icon: Icon(Icons.edit, color: Colors.blue),
                  //                           onPressed: () {
                  //                             widget.editCustContact(widget.custContacts[i]['contactDetId']);
                  //                           }),
                  //                     ),
                  //                     IconButton(
                  //                         icon: Icon(Icons.delete, color: Colors.red),
                  //                         onPressed: () {
                  //                           widget.deleteCustContact(widget.custContacts[i]['contactDetId']);
                  //                         }),
                  //                   ],
                  //                 ),
                  //             ],
                  //           ),

                  //           Padding(
                  //             padding: const EdgeInsets.only(left: 18, right: 12),
                  //             child: Row(
                  //               mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //               children: [
                  //                 Text("Phone: ${widget.custContacts[i]['contactValue']}"),
                  //                 Text(
                  //                   "[${widget.custContacts[i]['contactRole'].toString().toUpperCase()}]",
                  //                   style: TextStyle(fontSize: 12, color: Colors.grey[700], fontWeight: FontWeight.bold),
                  //                 ),
                  //               ],
                  //             ),
                  //           ),
                  //           Divider(
                  //             thickness: 1.5,
                  //           ),
                  //         ],
                  //       );
                  //     }),
                ),
        ),
      ]),
    );
  }
}
