
import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';

import '../../../../widgets/deprecated/text_button_widget.dart';

class AppUploadWidget extends StatefulWidget {
  final Map<String, dynamic>? prospect;
  final List<Map<String, dynamic>> appUploads;
  final Function() createAppUpload;
  final Function(int) editAppUpload;
  final Function(int) deleteAppUpload;
  final String? connectionType;

  AppUploadWidget(
      {required this.prospect,
      required this.appUploads,
      required this.createAppUpload,
      required this.editAppUpload,
      required this.deleteAppUpload,
      required this.connectionType});

  @override
  _AppUploadWidgetState createState() => _AppUploadWidgetState();
}

class _AppUploadWidgetState extends State<AppUploadWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween, 
          children: [
            Text(
              '9. UPLOAD FILES (${widget.appUploads.length})',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold,color: Colors.teal[600]),
            ),
            TextButtonWidget(
              text: "ADD",
              iconData: Icons.add,
              onTap: widget.createAppUpload,
            )
          ]
        ),
        Divider(
          thickness: 1.5,
        ),
        Expanded(
          child: widget.prospect!['applicationId'] == null
              ? SizedBox()
              : Container(
                  child: ListView.separated(
                      itemCount: widget.appUploads.length,
                      separatorBuilder: (context, index) {
                        return Divider();
                      },
                      itemBuilder: (context, i) {
                        return Slidable(
                          child: ListTile(
                            contentPadding: EdgeInsets.zero,
                            dense: true,
                            visualDensity:
                                VisualDensity(horizontal: 0, vertical: -4),
                            title: Text(
                                "${i + 1}. ${widget.appUploads[i]['documentName'] ?? widget.appUploads[i]['uploadName']}"),
                            subtitle: Padding(
                              padding: EdgeInsets.only(left: 20),
                              child: Text(widget.appUploads[i]['uploadName']),
                            ),
                            trailing: Container(
                              width: 100,
                              height: 120,
                              child :  Image.network(
                                "${widget.appUploads[i]['uploadDomain']}/${widget.appUploads[i]['uploadPath']}",
                                cacheHeight: 100,
                                cacheWidth: 120,
                                fit: BoxFit.contain,
                              )
                            ),
                            // widget.connectionType == 'online'
                            //     ?

                                // : Image.memory(
                                //     base64Decode(
                                //         widget.appUploads[i]['fileData']),
                                //     cacheHeight: 100,
                                //     cacheWidth: 120,
                                //   ),
                          ),
                          endActionPane: ActionPane(
                            motion: const DrawerMotion(),
                            extentRatio: 0.25,
                            children: [
                              SlidableAction(
                                label: 'Edit',
                                backgroundColor: Colors.blue,
                                icon: Icons.edit,
                                onPressed: (context) {
                                  widget.editAppUpload(
                                      widget.appUploads[i]['uploadId']);
                                },
                              ),
                              SlidableAction(
                                label: 'Delete',
                                backgroundColor: Colors.red,
                                icon: Icons.delete,
                                onPressed: (context) {
                                  widget.deleteAppUpload(
                                      widget.appUploads[i]['uploadId']);
                                },
                              ),
                            ],
                          ),
                        );
                      }),
                ),
        ),
      ]),
    );
  }
}
