import 'package:flutter/material.dart';

import '../../prospects/app_upload/app_upload_add_new_widget.dart';
import '../../prospects/app_upload/app_upload_image_widget.dart';

class AppUploadNewWidget extends StatefulWidget {
  final int applicationId;
  final List<Map<String, dynamic>> appDocuments;
  final Function() getAppUploadList;
  final Function() getProspect;

  AppUploadNewWidget({
    required this.applicationId,
    required this.appDocuments,
    required this.getAppUploadList,
    required this.getProspect,
  });

  @override
  State<AppUploadNewWidget> createState() => _AppUploadNewWidgetState();
}

class _AppUploadNewWidgetState extends State<AppUploadNewWidget> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(15, 10, 15, 0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(
            '9. UPLOAD FILES',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.teal[600]),
          ),
        ]),
        Divider(
          thickness: 1.5,
        ),
        Expanded(
          child: Container(
            padding: EdgeInsets.fromLTRB(0, 5, 0, 0),
            child: ListView.builder(
                shrinkWrap: false,
                itemCount: widget.appDocuments.length,
                itemBuilder: (context, i) {
                  final appUploads = widget.appDocuments[i]['appUploads'];
                  final appUploadLength = appUploads != null ? appUploads.length : 0;
                  final appUploadLimited = widget.appDocuments[i]['appMerchantUploadLimited'] ?? 0;
                  return Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          CircleAvatar(
                            child: Text(
                              "${i + 1}",
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                              ),
                              textAlign: TextAlign.center,
                            ),
                            radius: 14,
                            backgroundColor: Colors.teal[500],
                            foregroundColor: Colors.white,
                          ),
                          SizedBox(
                            width: 8,
                          ),
                          Text(
                            '${widget.appDocuments[i]['documentName']} ',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          Text(
                            '${widget.appDocuments[i]['documentRequired'] == 1 ? "*" : ""}',
                            style: TextStyle(color: Colors.red),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 3,
                      ),
                      Container(
                        padding: EdgeInsets.only(left: 20),
                        height: 110,
                        child: ListView.builder(
                            shrinkWrap: true,
                            scrollDirection: Axis.horizontal,
                            itemCount: appUploadLength >= appUploadLimited ? appUploadLength : appUploadLimited,
                            itemBuilder: (BuildContext context, int j) {
                              if (appUploadLength >= appUploadLimited) {
                                return AppUploadImageWidget(
                                  appUpload: appUploads[j],
                                  getAppUploadList: widget.getAppUploadList,
                                  getProspect: widget.getProspect,
                                );
                              } else {
                                if (appUploadLength > 0) {
                                  if (j < appUploadLength) {
                                    return AppUploadImageWidget(
                                      appUpload: appUploads[j],
                                      getAppUploadList: widget.getAppUploadList,
                                      getProspect: widget.getProspect,
                                    );
                                  } else {
                                    return AppUploadAddNewWidget(
                                      applicationId: widget.applicationId,
                                      appDocument: widget.appDocuments[i],
                                      getAppUploadList: widget.getAppUploadList,
                                      getProspect: widget.getProspect,
                                    );
                                  }
                                } else {
                                  return AppUploadAddNewWidget(
                                    applicationId: widget.applicationId,
                                    appDocument: widget.appDocuments[i],
                                    getAppUploadList: widget.getAppUploadList,
                                    getProspect: widget.getProspect,
                                  );
                                }
                              }
                            }),
                      ),
                      Divider(),
                    ],
                  );
                }),
          ),
        ),
      ]),
    );
  }
}
