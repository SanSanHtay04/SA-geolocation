import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:intl/intl.dart';

import '../../../../widgets/deprecated/text_button_widget.dart';

class IncomeCustomerWidget extends StatefulWidget {
  final Map<String, dynamic>? prospect;
  final List<dynamic> incomeSources;
  final Function()? createCustIncomeSource;
  final Function(int)? editCustIncomeSource;
  final Function(int)? deleteCustIncomeSource;
  final Function(int)? showCustIncomeSource;

  IncomeCustomerWidget(
      {required this.prospect,
      required this.incomeSources,
      this.createCustIncomeSource,
      this.editCustIncomeSource,
      this.deleteCustIncomeSource,
      this.showCustIncomeSource});

  @override
  _IncomeCustomerWidgetState createState() => _IncomeCustomerWidgetState();
}

class _IncomeCustomerWidgetState extends State<IncomeCustomerWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(
            '6. CUSTOMER INCOME (${widget.incomeSources.length})',
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.teal[600]),
          ),
          TextButtonWidget(
            text: "ADD",
            iconData: Icons.add,
            onTap: widget.createCustIncomeSource,
          )
        ]),
        Divider(
          thickness: 1.5,
        ),
        Expanded(
          child: widget.prospect!['applicationId'] == null
              ? SizedBox()
              : Container(
                  child: ListView.separated(
                      itemCount: widget.incomeSources.length,
                      separatorBuilder: (context, index) {
                        return Divider();
                      },
                      itemBuilder: (context, i) {
                        return Slidable(
                          child: ListTile(
                            contentPadding: EdgeInsets.zero,
                            dense: true,
                            visualDensity:
                                VisualDensity(horizontal: 0, vertical: -4),
                            title: Text(
                              "${(i + 1).toString()}. ${widget.incomeSources[i]['selfemployed'] == 0 ? 'Employed' : (widget.incomeSources[i]['selfemployed'] == 1 ? 'Self-employed' : 'No job / Un-employed')}",
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            subtitle: Padding(
                              padding: EdgeInsets.only(left: 15, top: 5),
                              child: Text(
                                "Income: ${NumberFormat('#,###').format(widget.incomeSources[i]['incomeAmount'])} MMK",
                              ),
                            ),
                            trailing: Text(
                              "[${widget.incomeSources[i]['incomePeriodicity'] == 1 ? 'MONTHLY' : (widget.incomeSources[i]['incomePeriodicity'] == 3 ? 'QUARTERLY' : 'YEARLY')}]",
                              style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.blue[800],
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                          endActionPane: ActionPane(
                            motion: const DrawerMotion(),
                            extentRatio: 0.25,
                            children: [
                              SlidableAction(
                                label: 'Info',
                                backgroundColor: Colors.teal,
                                icon: Icons.info,
                                onPressed: (context) {
                                  widget.showCustIncomeSource!(widget
                                      .incomeSources[i]['incomeSourceId']);
                                },
                              ),
                              SlidableAction(
                                label: 'Edit',
                                backgroundColor: Colors.blue,
                                icon: Icons.edit,
                                onPressed: (context) {
                                  widget.editCustIncomeSource!(widget
                                      .incomeSources[i]['incomeSourceId']);
                                },
                              ),
                              SlidableAction(
                                label: 'Delete',
                                backgroundColor: Colors.red,
                                icon: Icons.delete,
                                onPressed: (context) {
                                  widget.deleteCustIncomeSource!(widget
                                      .incomeSources[i]['incomeSourceId']);
                                },
                              ),
                            ],
                          ),
                        );
                      }),
                ),
        ),
      ]),
    );
  }
}
