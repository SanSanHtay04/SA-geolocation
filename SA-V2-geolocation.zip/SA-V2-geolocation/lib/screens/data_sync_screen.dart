import 'package:flutter/material.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:provider/provider.dart';
import 'package:sales/providers/providers.dart';
import 'package:sales/data/local/db_sqlite_helper.dart';
import 'package:sales/data/local/models/models.dart';
import 'package:sales/utils/utils.dart';

class DataSyncScreen extends StatefulWidget {
  static const routeName = "/data-sync";
  final String? connectionType;

  DataSyncScreen({required this.connectionType});

  @override
  _DataSyncScreenState createState() => _DataSyncScreenState();
}

class _DataSyncScreenState extends State<DataSyncScreen> with TickerProviderStateMixin {
  bool _isLoading = false;
  bool _isSyncing = false;
  var dbHelper;

  List<AppDataSync> _localDataSyncs = [];
  List<AppDataDetailSync> _localDataDetailSyncs = [];
  List<Map<String, dynamic>> _onlineDataSyncs = [];

  List<Map<String, dynamic>> _maritalStatuses = [];
  List<Map<String, dynamic>> _educations = [];
  List<Map<String, dynamic>> _businessTypes = [];
  List<Map<String, dynamic>> _jobCategories = [];
  List<Map<String, dynamic>> _geoRegions = [];
  List<Map<String, dynamic>> _geoDistricts = [];
  List<Map<String, dynamic>> _geoTownShips = [];
  List<Map<String, dynamic>> _geoTowns = [];
  List<Map<String, dynamic>> _geoWards = [];
  List<Map<String, dynamic>> _geoVillages = [];
  List<Map<String, dynamic>> _nrc1s = [];
  List<Map<String, dynamic>> _nrc2s = [];
  List<Map<String, dynamic>> _poses = [];
  List<Map<String, dynamic>> _merchants = [];
  List<Map<String, dynamic>> _brands = [];
  List<Map<String, dynamic>> _zcBrands = [];
  List<Map<String, dynamic>> _products = [];
  List<Map<String, dynamic>> _zcProducts = [];
  List<Map<String, dynamic>> _productCategories = [];
  List<Map<String, dynamic>> _users = [];
  List<Map<String, dynamic>> _appDocTypes = [];
  List<Map<String, dynamic>> _appDocuments = [];
  List<Map<String, dynamic>> _secondaryProducts = [];
  List<Map<String, dynamic>> _supplierBankAccounts = [];

  List<AppDataDetailSync> _syncDataDetails = [
    AppDataDetailSync(syncDetId: 1, syncId: 2, tableName: 'Brands', syncVersion: null),
    AppDataDetailSync(syncDetId: 2, syncId: 2, tableName: 'Products', syncVersion: null),
    AppDataDetailSync(syncDetId: 3, syncId: 2, tableName: 'Product Categories', syncVersion: null),
    AppDataDetailSync(syncDetId: 4, syncId: 2, tableName: 'Secondary Products', syncVersion: null),
    AppDataDetailSync(syncDetId: 5, syncId: 2, tableName: 'Supplier Bank Accounts', syncVersion: null),
    AppDataDetailSync(syncDetId: 6, syncId: 3, tableName: 'Users', syncVersion: null),
    AppDataDetailSync(syncDetId: 7, syncId: 4, tableName: 'Merchants', syncVersion: null),
    AppDataDetailSync(syncDetId: 8, syncId: 4, tableName: 'POS-es', syncVersion: null),
    AppDataDetailSync(syncDetId: 9, syncId: 5, tableName: 'Geo Regions', syncVersion: null),
    AppDataDetailSync(syncDetId: 10, syncId: 5, tableName: 'Geo Districts', syncVersion: null),
    AppDataDetailSync(syncDetId: 11, syncId: 5, tableName: 'Geo Townships', syncVersion: null),
    AppDataDetailSync(syncDetId: 12, syncId: 5, tableName: 'Geo Towns', syncVersion: null),
    AppDataDetailSync(syncDetId: 13, syncId: 5, tableName: 'Geo Wards', syncVersion: null),
    AppDataDetailSync(syncDetId: 14, syncId: 5, tableName: 'Geo Villages', syncVersion: null),
    AppDataDetailSync(syncDetId: 15, syncId: 5, tableName: 'Nrc1s', syncVersion: null),
    AppDataDetailSync(syncDetId: 16, syncId: 5, tableName: 'Nrc2s', syncVersion: null),
    AppDataDetailSync(syncDetId: 17, syncId: 6, tableName: 'Marital Statuses', syncVersion: null),
    AppDataDetailSync(syncDetId: 18, syncId: 6, tableName: 'Education Levels', syncVersion: null),
    AppDataDetailSync(syncDetId: 19, syncId: 6, tableName: 'Business Types', syncVersion: null),
    AppDataDetailSync(syncDetId: 20, syncId: 6, tableName: 'Job Categories', syncVersion: null),
    AppDataDetailSync(syncDetId: 21, syncId: 6, tableName: 'App Doc Types', syncVersion: null),
    AppDataDetailSync(syncDetId: 22, syncId: 6, tableName: 'App Documents', syncVersion: null),
  ];

  String? _getSyncVersion(int syncId) {
    String? strVersion = "";
    if (_onlineDataSyncs.length > 0) {
      _onlineDataSyncs.forEach((element) {
        if (syncId == element['syncId']) {
          setState(() {
            strVersion = element['syncVersion'];
          });
        }
      });
    }
    return strVersion;
  }

  // DATA SYNC //
  Future<void> _getOnlineDataSyncs() async {
    if (widget.connectionType == 'online') {
      setState(() {
        _isLoading = true;
      });

      try {
        await Provider.of<OriAppDataSyncProvider>(context, listen: false).getRecords().then((value) {
          setState(() {
            _onlineDataSyncs = Provider.of<OriAppDataSyncProvider>(context, listen: false).items;
            _isLoading = false;
          });
        });
      } catch (error) {
        print(error.toString());
        _isLoading = false;
      }

      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _syncAppData() async {
    await _getOnlineDataSyncs();
    if (_onlineDataSyncs.length > 0) {
      List<AppDataSync> _data = [];
      _onlineDataSyncs.forEach((element) {
        _data.add(AppDataSync(syncId: element['syncId'], frequency: element['frequency'], syncName: element['syncName'], syncVersion: null, onlineSyncVersion: element['syncVersion'], syncRemark: element['syncRemark']));
      });
      await DBSqliteHelper().syncAppData(_data);
    }
  }

  // DATA DETAIL SYNC //
  Future<void> _syncAppDataDetail() async {
    if (_syncDataDetails.length > 0) {
      List<AppDataDetailSync> _data = [];
      _syncDataDetails.forEach((element) {
        _data.add(element);
      });
      await DBSqliteHelper().syncAppDataDetail(_data);
    }
  }

  // MARITAL STATUS //
  Future<void> _getMaritalStatuses() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<MaritalStatusProvider>(context, listen: false).getRecords().then((value) {
        setState(() {
          _maritalStatuses = Provider.of<MaritalStatusProvider>(context, listen: false).items;
          _isLoading = false;
        });
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _syncMaritalStatus() async {
    await _getMaritalStatuses();
    if (_maritalStatuses.length > 0) {
      List<MaritalStatus> _data = [];
      _maritalStatuses.forEach((element) {
        _data.add(MaritalStatus(element['maritalStatusId'], element['maritalStatusName'], element['maritalStatusActive']));
      });
      await DBSqliteHelper().syncMaritalStatus(_data);
      await DBSqliteHelper().updateDataDetailSync(AppDataDetailSync(syncDetId: 17, syncId: 6, tableName: 'Marital Statuses', syncVersion: _getSyncVersion(6)));
      await _reloadDataDetail();
    }
  }

  // EDUCATION //
  Future<void> _getEducations() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<EducationProvider>(context, listen: false).getRecords().then((value) {
        setState(() {
          _educations = Provider.of<EducationProvider>(context, listen: false).items;
          _isLoading = false;
        });
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _syncEducation() async {
    await _getEducations();
    if (_educations.length > 0) {
      List<Education> _data = [];
      _educations.forEach((element) {
        _data.add(Education(
          educationId: element['educationId'],
          educationName: element['educationName'],
          educationOrder: element['educationOrder'],
        ));
      });
      await DBSqliteHelper().syncEducation(_data);
      await DBSqliteHelper().updateDataDetailSync(
        AppDataDetailSync(
          syncDetId: 18,
          syncId: 6,
          tableName: 'Education Levels',
          syncVersion: _getSyncVersion(6),
        ),
      );
      await _reloadDataDetail();
    }
  }

  // BUSINESS TYPE //
  Future<void> _getBusinessTypes() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<BusinessTypeProvider>(context, listen: false).getRecords().then((value) {
        setState(() {
          _businessTypes = Provider.of<BusinessTypeProvider>(context, listen: false).items;
          _isLoading = false;
        });
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _syncBusinessType() async {
    await _getBusinessTypes();
    if (_businessTypes.length > 0) {
      List<BusinessType> _data = [];
      _businessTypes.forEach((element) {
        _data.add(BusinessType(
          businessTypeId: element['businessTypeId'],
          businessTypeName: element['businessTypeName'],
          businessTypeActive: element['businessTypeActive'],
          selfEmployedApplied: element['selfEmployedApplied'],
          employedApplied: element['employedApplied'],
          unemployedApplied: element['unemployedApplied'],
        ));
      });
      await DBSqliteHelper().syncBusinessType(_data);
      await DBSqliteHelper().updateDataDetailSync(
        AppDataDetailSync(
          syncDetId: 19,
          syncId: 6,
          tableName: 'Business Types',
          syncVersion: _getSyncVersion(6),
        ),
      );
      await _reloadDataDetail();
    }
  }

  // JOB CATEGORY //
  Future<void> _getJobCategories() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<JobCategoryProvider>(context, listen: false).getRecords().then((value) {
        setState(() {
          _jobCategories = Provider.of<JobCategoryProvider>(context, listen: false).items;
          _isLoading = false;
        });
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _syncJobCategory() async {
    await _getJobCategories();
    if (_jobCategories.length > 0) {
      List<JobCategory> _data = [];
      _jobCategories.forEach((element) {
        _data.add(JobCategory(
          jobCategoryId: element['jobCategoryId'],
          businessTypeId: element['businessTypeId'],
          jobCategoryName: element['jobCategoryName'],
          jobCategoryActive: element['jobCategoryActive'],
          selfemployed: element['selfemployed'],
        ));
      });
      await DBSqliteHelper().syncJobCategory(_data);
      await DBSqliteHelper().updateDataDetailSync(
        AppDataDetailSync(
          syncDetId: 20,
          syncId: 6,
          tableName: 'Job Categories',
          syncVersion: _getSyncVersion(6),
        ),
      );
      await _reloadDataDetail();
    }
  }

  // APP DOC TYPE //
  Future<void> _getAppDocTypes() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<AppDocTypeProvider>(context, listen: false).getRecords().then((value) {
        setState(() {
          _appDocTypes = Provider.of<AppDocTypeProvider>(context, listen: false).items;
          _isLoading = false;
        });
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _syncAppDocType() async {
    await _getAppDocTypes();
    if (_appDocTypes.length > 0) {
      List<AppDocType> _data = [];
      _appDocTypes.forEach((element) {
        _data.add(AppDocType.fromMap(element));
      });
      await DBSqliteHelper().syncAppDocType(_data);
      await DBSqliteHelper().updateDataDetailSync(
        AppDataDetailSync(
          syncDetId: 21,
          syncId: 6,
          tableName: 'App Doc Types',
          syncVersion: _getSyncVersion(6),
        ),
      );
      await _reloadDataDetail();
    }
  }

  // APP DOCUMENT //
  Future<void> _getAppDocuments() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<AppDocumentProvider>(context, listen: false).getRecords().then((value) {
        setState(() {
          _appDocuments = Provider.of<AppDocumentProvider>(context, listen: false).items;
          _isLoading = false;
        });
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _syncAppDocuments() async {
    await _getAppDocuments();
    if (_appDocuments.length > 0) {
      List<AppDocument> _data = [];
      _appDocuments.forEach((element) {
        _data.add(AppDocument.fromMap(element));
      });
      await DBSqliteHelper().syncAppDocument(_data);
      await DBSqliteHelper().updateDataDetailSync(
        AppDataDetailSync(
          syncDetId: 22,
          syncId: 6,
          tableName: 'App Documents',
          syncVersion: _getSyncVersion(6),
        ),
      );
      await _reloadDataDetail();
    }
  }

  // GEO REGION //
  Future<void> _getGeoRegions() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<GeoRegionProvider>(context, listen: false).getRecords().then((value) {
        setState(() {
          _geoRegions = Provider.of<GeoRegionProvider>(context, listen: false).items;
          _isLoading = false;
        });
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _syncGeoRegion() async {
    await _getGeoRegions();
    if (_geoRegions.length > 0) {
      List<GeoRegion> _data = [];
      _geoRegions.forEach((element) {
        _data.add(GeoRegion(
          geoRegionId: element['geoRegionId'],
          geoRegionName: element['geoRegionName'],
        ));
      });
      await DBSqliteHelper().syncGeoRegion(_data);
      await DBSqliteHelper().updateDataDetailSync(
        AppDataDetailSync(
          syncDetId: 9,
          syncId: 5,
          tableName: 'Geo Regions',
          syncVersion: _getSyncVersion(5),
        ),
      );
      await _reloadDataDetail();
    }
  }

  // GEO DISTRICT //
  Future<void> _getGeoDistricts() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<GeoDistrictProvider>(context, listen: false).getAllDistricts().then((value) {
        setState(() {
          _geoDistricts = Provider.of<GeoDistrictProvider>(context, listen: false).items;
          _isLoading = false;
        });
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _syncGeoDistrict() async {
    await _getGeoDistricts();
    if (_geoDistricts.length > 0) {
      List<GeoDistrict> _data = [];
      _geoDistricts.forEach((element) {
        _data.add(GeoDistrict(
          geoDistrictId: element['geoDistrictId'],
          geoRegionId: element['geoRegionId'],
          geoDistrictName: element['geoDistrictName'],
        ));
      });
      await DBSqliteHelper().syncGeoDistrict(_data);
      await DBSqliteHelper().updateDataDetailSync(
        AppDataDetailSync(
          syncDetId: 10,
          syncId: 5,
          tableName: 'Geo Districts',
          syncVersion: _getSyncVersion(5),
        ),
      );
      await _reloadDataDetail();
    }
  }

  // GEO TOWNSHIP //
  Future<void> _getGeoTownShips() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<GeoTownshipProvider>(context, listen: false).getAllTownShips().then((value) {
        setState(() {
          _geoTownShips = Provider.of<GeoTownshipProvider>(context, listen: false).items;
          _isLoading = false;
        });
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _syncGeoTownShip() async {
    await _getGeoTownShips();
    if (_geoTownShips.length > 0) {
      List<GeoTownShip> _data = [];
      _geoTownShips.forEach((element) {
        _data.add(GeoTownShip(
          geoTownShipId: element['geoTownShipId'],
          geoDistrictId: element['geoDistrictId'],
          geoTownShipName: element['geoTownShipName'],
        ));
      });
      await DBSqliteHelper().syncGeoTownShip(_data);
      await DBSqliteHelper().updateDataDetailSync(
        AppDataDetailSync(
          syncDetId: 11,
          syncId: 5,
          tableName: 'Geo Townships',
          syncVersion: _getSyncVersion(5),
        ),
      );
      await _reloadDataDetail();
    }
  }

  // GEO TOWN //
  Future<void> _getGeoTowns() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<GeoTownProvider>(context, listen: false).getAllTowns().then((value) {
        setState(() {
          _geoTowns = Provider.of<GeoTownProvider>(context, listen: false).items;
          _isLoading = false;
        });
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _syncGeoTowns() async {
    await _getGeoTowns();
    if (_geoTowns.length > 0) {
      List<GeoTown> _data = [];
      _geoTowns.forEach((element) {
        _data.add(GeoTown(
          geoTownId: element['geoTownId'],
          geoTownShipId: element['geoTownShipId'],
          geoTownName: element['geoTownName'],
          isVillage: element['isVillage'],
        ));
      });
      await DBSqliteHelper().syncGeoTown(_data);
      await DBSqliteHelper().updateDataDetailSync(
        AppDataDetailSync(
          syncDetId: 12,
          syncId: 5,
          tableName: 'Geo Towns',
          syncVersion: _getSyncVersion(5),
        ),
      );
      await _reloadDataDetail();
    }
  }

  // GEO WARD //
  Future<void> _getGeoWards() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<GeoWardProvider>(context, listen: false).getAllWards().then((value) {
        setState(() {
          _geoWards = Provider.of<GeoWardProvider>(context, listen: false).items;
          _isLoading = false;
        });
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _syncGeoWards() async {
    await _getGeoWards();
    if (_geoWards.length > 0) {
      List<GeoWard> _data = [];
      _geoWards.forEach((element) {
        _data.add(GeoWard(
          geoWardId: element['geoWardId'],
          geoTownId: element['geoTownId'],
          geoWardName: element['geoWardName'],
        ));
      });
      await DBSqliteHelper().syncGeoWard(_data);
      await DBSqliteHelper().updateDataDetailSync(
        AppDataDetailSync(
          syncDetId: 13,
          syncId: 5,
          tableName: 'Geo Wards',
          syncVersion: _getSyncVersion(5),
        ),
      );
      await _reloadDataDetail();
    }
  }

  // GEO VILLAGE //
  Future<void> _getGeoVillages() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<GeoVillageProvider>(context, listen: false).getAllVillages().then((value) {
        setState(() {
          _geoVillages = Provider.of<GeoVillageProvider>(context, listen: false).items;
          _isLoading = false;
        });
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _syncGeoVillages() async {
    await _getGeoVillages();
    if (_geoVillages.length > 0) {
      List<GeoVillage> _data = [];
      _geoVillages.forEach((element) {
        _data.add(GeoVillage(
          geoVillageId: element['geoVillageId'],
          geoTownId: element['geoTownId'],
          geoVillageName: element['geoVillageName'],
        ));
      });
      await DBSqliteHelper().syncGeoVillage(_data);
      await DBSqliteHelper().updateDataDetailSync(
        AppDataDetailSync(
          syncDetId: 14,
          syncId: 5,
          tableName: 'Geo Villages',
          syncVersion: _getSyncVersion(5),
        ),
      );
      await _reloadDataDetail();
    }
  }

  // NRC1 //
  Future<void> _getNrc1s() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<Nrc1Provider>(context, listen: false).getRecords().then((value) {
        setState(() {
          _nrc1s = Provider.of<Nrc1Provider>(context, listen: false).items;
          _isLoading = false;
        });
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _syncNrc1() async {
    await _getNrc1s();
    if (_nrc1s.length > 0) {
      List<Nrc1> _data = [];
      _nrc1s.forEach((element) {
        _data.add(Nrc1(
          nrc1Id: element['nrc1Id'],
          nrc1Name: element['nrc1Name'],
        ));
      });
      await DBSqliteHelper().syncNrc1(_data);
      await DBSqliteHelper().updateDataDetailSync(
        AppDataDetailSync(
          syncDetId: 15,
          syncId: 5,
          tableName: 'Nrc1s',
          syncVersion: _getSyncVersion(5),
        ),
      );
      await _reloadDataDetail();
    }
  }

  // NRC2 //
  Future<void> _getNrc2s() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<Nrc2Provider>(context, listen: false).getAllNrc2s().then((value) {
        setState(() {
          _nrc2s = Provider.of<Nrc2Provider>(context, listen: false).items;
          _isLoading = false;
        });
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _syncNrc2() async {
    await _getNrc2s();
    if (_nrc2s.length > 0) {
      List<Nrc2> _data = [];
      _nrc2s.forEach((element) {
        _data.add(Nrc2(
          nrc2Id: element['nrc2Id'],
          nrc1Id: element['nrc1Id'],
          nrc2Name: element['nrc2Name'],
        ));
      });
      await DBSqliteHelper().syncNrc2(_data);
      await DBSqliteHelper().updateDataDetailSync(
        AppDataDetailSync(
          syncDetId: 16,
          syncId: 5,
          tableName: 'Nrc2s',
          syncVersion: _getSyncVersion(5),
        ),
      );
      await _reloadDataDetail();
    }
  }

  // POS //
  Future<void> _getPOSes() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<OriginationPosProvider>(context, listen: false).getAllAssignedPoses().then((value) {
        setState(() {
          _poses = Provider.of<OriginationPosProvider>(context, listen: false).items;
          _isLoading = false;
        });
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _syncPOS() async {
    await _getPOSes();
    if (_poses.length > 0) {
      List<OriginationPOS> _data = [];
      _poses.forEach((element) {
        _data.add(OriginationPOS(
          posId: element['posId'],
          merchantId: element['merchantId'],
          posCategory: element['posCategory'],
          posProductType: element['posProductType'],
          posName: element['posName'],
          posAddress: element['posAddress'],
        ));
      });
      await DBSqliteHelper().syncPOS(_data);
      await DBSqliteHelper().updateDataDetailSync(
        AppDataDetailSync(
          syncDetId: 8,
          syncId: 4,
          tableName: 'POS-es',
          syncVersion: _getSyncVersion(4),
        ),
      );
      await _reloadDataDetail();
    }
  }

  // MERCHANT //
  Future<void> _getMerchants() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<MerchantProvider>(context, listen: false).getAllAssignedMerchant().then((value) {
        setState(() {
          _merchants = Provider.of<MerchantProvider>(context, listen: false).items;
          _isLoading = false;
        });
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _syncMerchant() async {
    await _getMerchants();
    if (_merchants.length > 0) {
      List<Merchant> _data = [];
      _merchants.forEach((element) {
        _data.add(Merchant(
          merchantId: element['merchantId'],
          merchantName: element['merchantName'],
          merchantAddress: element['merchantAddress'],
        ));
      });
      await DBSqliteHelper().syncMerchant(_data);
      await DBSqliteHelper().updateDataDetailSync(
        AppDataDetailSync(
          syncDetId: 7,
          syncId: 4,
          tableName: 'Merchants',
          syncVersion: _getSyncVersion(4),
        ),
      );
      await _reloadDataDetail();
    }
  }

  // BRAND //
  Future<void> _getBrands() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<BrandProvider>(context, listen: false).getAssignedBrands(0).then((value) {
        setState(() {
          _brands = Provider.of<BrandProvider>(context, listen: false).items;
          _isLoading = false;
        });
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  // BRAND ZC //
  Future<void> _getZCBrands() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<BrandProvider>(context, listen: false).getAssignedBrands(1).then((value) {
        setState(() {
          _zcBrands = Provider.of<BrandProvider>(context, listen: false).items;
          _isLoading = false;
        });
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _syncBrand() async {
    await _getBrands();
    await _getZCBrands();
    List<Brand> _data = [];
    if (_brands.length > 0) {
      _brands.forEach((element) {
        _data.add(Brand(
          brandId: element['brandId'],
          posId: element['posId'],
          brandCode: element['brandCode'],
          brandName: element['brandName'],
          brandCategory: element['brandCategory'],
          isZeroCost: 0,
        ));
      });
    }
    if (_zcBrands.length > 0) {
      _zcBrands.forEach((element) {
        _data.add(Brand(
          brandId: element['brandId'],
          posId: element['posId'],
          brandCode: element['brandCode'],
          brandName: element['brandName'],
          brandCategory: element['brandCategory'],
          isZeroCost: 1,
        ));
      });
    }

    await DBSqliteHelper().syncBrand(_data);

    await DBSqliteHelper().updateDataDetailSync(
      AppDataDetailSync(
        syncDetId: 1,
        syncId: 2,
        tableName: 'Brands',
        syncVersion: _getSyncVersion(2),
      ),
    );
    await _reloadDataDetail();
  }

  // PRODUCT //
  Future<void> _getProducts() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<ProductProvider>(context, listen: false).getAssignedProducts(0).then((value) {
        setState(() {
          _products = Provider.of<ProductProvider>(context, listen: false).items;
          _isLoading = false;
        });
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  // PRODUCT ZC //
  Future<void> _getZCProducts() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<ProductProvider>(context, listen: false).getAssignedProducts(1).then((value) {
        setState(() {
          _zcProducts = Provider.of<ProductProvider>(context, listen: false).items;
          _isLoading = false;
        });
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _syncProduct() async {
    await _getProducts();
    await _getZCProducts();
    List<Product> _data = [];
    List<FinSchemeProductDetail> _finSchemeProducts = [];
    List<InsSchemeProductDetail> _insSchemeProducts = [];
    if (_products.length > 0) {
      _products.forEach((element) async {
        _data.add(Product.fromMap(element));

        // fin_scheme_det //
        if (element['fin_scheme_det'] != null) {
          List<Map<String, dynamic>> finSchemes = List<Map<String, dynamic>>.from(element['fin_scheme_det']);
          finSchemes.forEach((schemeItem) {
            _finSchemeProducts.add(FinSchemeProductDetail.fromMap(schemeItem));
          });
        }

        // ins_scheme_det //
        if (element['ins_scheme_det'] != null) {
          List<Map<String, dynamic>> newInsSchemes = List<Map<String, dynamic>>.from(element['ins_scheme_det']);
          newInsSchemes.forEach((newScheme) {
            _insSchemeProducts.forEach((scheme) {
              if (newScheme['insSchemeProductDetId'] != scheme.insSchemeProductDetId) {
                _insSchemeProducts.add(InsSchemeProductDetail.fromMap(newScheme));
              }
            });
          });
        }
      });
    }
    if (_zcProducts.length > 0) {
      _zcProducts.forEach((element) async {
        _data.add(Product.fromMap(element));

        // fin_scheme_det //
        if (element['fin_scheme_det'] != null) {
          List<Map<String, dynamic>> finSchemes = List<Map<String, dynamic>>.from(element['fin_scheme_det']);
          finSchemes.forEach((schemeItem) {
            _finSchemeProducts.add(FinSchemeProductDetail.fromMap(schemeItem));
          });
        }

        // ins_scheme_det //
        if (element['ins_scheme_det'] != null) {
          List<Map<String, dynamic>> newInsSchemes = List<Map<String, dynamic>>.from(element['ins_scheme_det']);
          newInsSchemes.forEach((newScheme) {
            _insSchemeProducts.forEach((scheme) {
              if (newScheme['insSchemeProductDetId'] != scheme.insSchemeProductDetId) {
                _insSchemeProducts.add(InsSchemeProductDetail.fromMap(newScheme));
              }
            });
          });
        }
      });
    }
    await DBSqliteHelper().syncProduct(_data);
    await DBSqliteHelper().syncFinSchemeDetail(_finSchemeProducts);
    await DBSqliteHelper().syncInsSchemeDetail(_insSchemeProducts);

    await DBSqliteHelper().updateDataDetailSync(
      AppDataDetailSync(
        syncDetId: 2,
        syncId: 2,
        tableName: 'Products',
        syncVersion: _getSyncVersion(2),
      ),
    );
    await _reloadDataDetail();
  }

  // PRODUCT CATEGORY //
  Future<void> _getProductCategories() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<ProductCategoryProvider>(context, listen: false).getRecords().then((value) {
        setState(() {
          _productCategories = Provider.of<ProductCategoryProvider>(context, listen: false).items;
          _isLoading = false;
        });
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _syncProductCategory() async {
    await _getProductCategories();
    if (_productCategories.length > 0) {
      List<ProductCategory> _data = [];
      _productCategories.forEach((element) async {
        _data.add(ProductCategory.fromMap(element));
      });
      await DBSqliteHelper().syncProductCategory(_data);
      await DBSqliteHelper().updateDataDetailSync(
        AppDataDetailSync(
          syncDetId: 3,
          syncId: 2,
          tableName: 'Product Categories',
          syncVersion: _getSyncVersion(2),
        ),
      );
      await _reloadDataDetail();
    }
  }

  // SECONDARY PRODUCT //
  Future<void> _getSecondaryProducts() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<SecondaryProductProvider>(context, listen: false).getRecords().then((value) {
        setState(() {
          _secondaryProducts = Provider.of<SecondaryProductProvider>(context, listen: false).items;
          _isLoading = false;
        });
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _syncSecondaryProducts() async {
    await _getSecondaryProducts();
    if (_secondaryProducts.length > 0) {
      List<SecondaryProduct> _data = [];
      _secondaryProducts.forEach((element) {
        _data.add(SecondaryProduct.fromMap(element));
      });
      await DBSqliteHelper().syncSecondaryProduct(_data);
      await DBSqliteHelper().updateDataDetailSync(
        AppDataDetailSync(
          syncDetId: 4,
          syncId: 2,
          tableName: 'Secondary Products',
          syncVersion: _getSyncVersion(2),
        ),
      );
      await _reloadDataDetail();
    }
  }

  // SUPPLIER BANK ACCOUNT //
  Future<void> _getSupplierBankAccounts() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<SupplierBankAccountProvider>(context, listen: false).getRecords().then((value) {
        setState(() {
          _supplierBankAccounts = Provider.of<SupplierBankAccountProvider>(context, listen: false).items;
          _isLoading = false;
        });
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _syncSupplierBankAccount() async {
    await _getSupplierBankAccounts();
    if (_supplierBankAccounts.length > 0) {
      List<SupplierBankAccount> _data = [];
      _supplierBankAccounts.forEach((element) {
        _data.add(SupplierBankAccount.fromMap(element));
      });
      await DBSqliteHelper().syncSupplierBankAccount(_data);
      await DBSqliteHelper().updateDataDetailSync(
        AppDataDetailSync(
          syncDetId: 5,
          syncId: 2,
          tableName: 'Supplier Bank Accounts',
          syncVersion: _getSyncVersion(2),
        ),
      );
      await _reloadDataDetail();
    }
  }

  // USER //
  Future<void> _getUsers() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<UserProvider>(context, listen: false).getRecords().then((value) {
        setState(() {
          _users = Provider.of<UserProvider>(context, listen: false).items;
          _isLoading = false;
        });
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _syncUser() async {
    await _getUsers();
    if (_users.length > 0) {
      List<User> _data = [];
      _users.forEach((element) async {
        _data.add(User.fromMap(element));
      });
      await DBSqliteHelper().syncUser(_data);
      await DBSqliteHelper().updateDataDetailSync(
        AppDataDetailSync(
          syncDetId: 6,
          syncId: 3,
          tableName: 'Users',
          syncVersion: _getSyncVersion(2),
        ),
      );
      await _reloadDataDetail();
    }
  }

  // RELOAD DATA //
  Future<void> _reloadData() async {
    List<AppDataSync> _tempData = await DBSqliteHelper().getDataSyncs();
    setState(() {
      _localDataSyncs = List<AppDataSync>.from(_tempData);
    });
    await _reloadDataDetail();
  }

  Future<void> _reloadDataDetail() async {
    List<AppDataDetailSync> _tempDataDetail = await DBSqliteHelper().getAllDataDetailSyncs();
    setState(() {
      _localDataDetailSyncs = List<AppDataDetailSync>.from(_tempDataDetail);
    });
  }

  void _initData() async {
    await _reloadData();
    if (_localDataSyncs.length <= 0) {
      await _getOnlineDataSyncs();
      await _syncAppData();
      await _syncAppDataDetail();
    } else {
      await _getOnlineDataSyncs();

      if (_localDataSyncs.length > 0) {
        if (_onlineDataSyncs.length > 0) {
          _onlineDataSyncs.forEach((onlineItem) {
            _localDataSyncs.forEach((localItem) async {
              if (onlineItem['syncId'] == localItem.syncId) {
                await DBSqliteHelper().updateDataSync(AppDataSync(syncId: onlineItem['syncId'], frequency: onlineItem['frequency'], syncName: onlineItem['syncName'], syncVersion: localItem.syncVersion, onlineSyncVersion: onlineItem['syncVersion'], syncRemark: onlineItem['syncRemark']));
              }
            });
          });
        }
      }
    }
    await _reloadData();
  }

  @override
  void initState() {
    super.initState();
    dbHelper = DBSqliteHelper();
    _initData();
    // isUpdating = false;
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(
          'DATA CATEGORIES',
          style: TextStyle(color: Colors.white),
        ),
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: ModalProgressHUD(
        inAsyncCall: _isLoading || _isSyncing,
        opacity: 0.5,
        progressIndicator: CircularProgressIndicator(
          valueColor: new AlwaysStoppedAnimation<Color>(context.getColorScheme().primary),
        ),
        child: Padding(
          padding: EdgeInsets.all(12),
          child: RefreshIndicator(
            onRefresh: () => _reloadData(),
            child: ListView.builder(
                shrinkWrap: true,
                physics: ScrollPhysics(),
                itemCount: _localDataSyncs.length,
                itemBuilder: (context, i) {
                  List<AppDataDetailSync> _dataChildList = [];
                  _localDataDetailSyncs.forEach((dataDet) {
                    if (dataDet.syncId == _localDataSyncs[i].syncId) {
                      _dataChildList.add(dataDet);
                    }
                  });

                  return Container(
                    margin: EdgeInsets.only(bottom: 5),
                    padding: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          "${_localDataSyncs[i].syncName}",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        ListView.separated(
                          separatorBuilder: (context, index) {
                            return Padding(padding: EdgeInsets.zero, child: Divider());
                          },
                          shrinkWrap: true,
                          physics: ScrollPhysics(),
                          itemCount: _dataChildList.length,
                          itemBuilder: (context, j) {
                            return ListTile(
                              contentPadding: EdgeInsets.zero,
                              dense: true,
                              visualDensity: VisualDensity(horizontal: 0, vertical: -4),
                              title: Text("${j + 1}. ${_dataChildList[j].tableName}"),
                              trailing: Text(
                                _dataChildList[j].syncVersion != null ? 'Available' : 'Not Available',
                                style: TextStyle(
                                  fontSize: 13,
                                  color: _dataChildList[j].syncVersion != null ? Colors.blue[800] : Colors.black,
                                ),
                              ),
                            );
                          },
                        ),
                        Divider(color: Colors.teal),
                        Container(
                          height: 32,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                "[${_localDataSyncs[i].frequency.toString().toUpperCase()}]",
                                style: TextStyle(color: Colors.teal, fontWeight: FontWeight.bold, fontSize: 13),
                              ),
                              Row(
                                children: [
                                  Text(
                                    "ONLINE: ${_localDataSyncs[i].onlineSyncVersion ?? '-/-'}",
                                    style: TextStyle(color: Colors.teal, fontWeight: FontWeight.bold, fontSize: 13),
                                  ),
                                  Text(" - "),
                                  Text(
                                    "LOCAL: ${_localDataSyncs[i].syncVersion ?? 'n/a'}",
                                    style: TextStyle(color: Colors.teal, fontWeight: FontWeight.bold, fontSize: 13),
                                  ),
                                ],
                              ),
                              TextButton(
                                child: Text(
                                  "SYNC NOW",
                                  style: TextStyle(color: Colors.blue[800], fontSize: 13, fontWeight: FontWeight.bold),
                                ),
                                onPressed: widget.connectionType == 'offline'
                                    ? null
                                    : () async {
                                        if (_localDataSyncs[i].syncId == 6) {
                                          setState(() {
                                            _isSyncing = true;
                                          });
                                          await _syncMaritalStatus();
                                          await _syncEducation();
                                          await _syncBusinessType();
                                          await _syncJobCategory();
                                          await _syncAppDocType();
                                          await _syncAppDocuments();

                                          await _getOnlineDataSyncs();
                                          if (_onlineDataSyncs.length > 0) {
                                            _onlineDataSyncs.forEach((element) async {
                                              if (element['syncId'] == 6) {
                                                await DBSqliteHelper().updateDataSync(AppDataSync(syncId: element['syncId'], frequency: element['frequency'], syncName: element['syncName'], syncVersion: element['syncVersion'], onlineSyncVersion: element['syncVersion'], syncRemark: element['syncRemark']));
                                              }
                                            });
                                          }
                                        } else if (_localDataSyncs[i].syncId == 5) {
                                          setState(() {
                                            _isSyncing = true;
                                          });
                                          await _syncGeoRegion();
                                          await _syncGeoDistrict();
                                          await _syncGeoTownShip();
                                          await _syncGeoTowns();
                                          await _syncGeoWards();
                                          await _syncGeoVillages();
                                          await _syncNrc1();
                                          await _syncNrc2();

                                          await _getOnlineDataSyncs();
                                          if (_onlineDataSyncs.length > 0) {
                                            _onlineDataSyncs.forEach((element) async {
                                              if (element['syncId'] == 5) {
                                                await DBSqliteHelper().updateDataSync(AppDataSync(syncId: element['syncId'], frequency: element['frequency'], syncName: element['syncName'], syncVersion: element['syncVersion'], onlineSyncVersion: element['syncVersion'], syncRemark: element['syncRemark']));
                                              }
                                            });
                                          }
                                        } else if (_localDataSyncs[i].syncId == 4) {
                                          setState(() {
                                            _isSyncing = true;
                                          });
                                          await _syncMerchant();
                                          await _syncPOS();

                                          await _getOnlineDataSyncs();
                                          if (_onlineDataSyncs.length > 0) {
                                            _onlineDataSyncs.forEach((element) async {
                                              if (element['syncId'] == 4) {
                                                await DBSqliteHelper().updateDataSync(AppDataSync(syncId: element['syncId'], frequency: element['frequency'], syncName: element['syncName'], syncVersion: element['syncVersion'], onlineSyncVersion: element['syncVersion'], syncRemark: element['syncRemark']));
                                              }
                                            });
                                          }
                                        } else if (_localDataSyncs[i].syncId == 3) {
                                          setState(() {
                                            _isSyncing = true;
                                          });

                                          await _syncUser();

                                          await _getOnlineDataSyncs();
                                          if (_onlineDataSyncs.length > 0) {
                                            _onlineDataSyncs.forEach((element) async {
                                              if (element['syncId'] == 3) {
                                                await DBSqliteHelper().updateDataSync(AppDataSync(syncId: element['syncId'], frequency: element['frequency'], syncName: element['syncName'], syncVersion: element['syncVersion'], onlineSyncVersion: element['syncVersion'], syncRemark: element['syncRemark']));
                                              }
                                            });
                                          }
                                        } else if (_localDataSyncs[i].syncId == 2) {
                                          setState(() {
                                            _isSyncing = true;
                                          });

                                          await _syncBrand();
                                          await _syncProduct();
                                          // await _syncInsSchemeProductDetail();
                                          await _syncProductCategory();
                                          await _syncSecondaryProducts();
                                          await _syncSupplierBankAccount();

                                          await _getOnlineDataSyncs();
                                          if (_onlineDataSyncs.length > 0) {
                                            _onlineDataSyncs.forEach((element) async {
                                              if (element['syncId'] == 2) {
                                                await DBSqliteHelper().updateDataSync(AppDataSync(
                                                  syncId: element['syncId'],
                                                  frequency: element['frequency'],
                                                  syncName: element['syncName'],
                                                  syncVersion: element['syncVersion'],
                                                  onlineSyncVersion: element['syncVersion'],
                                                  syncRemark: element['syncRemark'],
                                                ));
                                              }
                                            });
                                          }
                                        }

                                        await _reloadData();

                                        setState(() {
                                          _isSyncing = false;
                                        });
                                      },
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                }),
          ),
        ),
      ),
    );
  }
}
