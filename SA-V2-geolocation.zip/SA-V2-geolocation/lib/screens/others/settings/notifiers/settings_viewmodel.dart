import 'package:flutter/cupertino.dart';
import 'package:sales/utils/utils.dart';

import '../../../auth/data/auth_repository.dart';
import 'logout_status.dart';

class SettingsViewModel extends ChangeNotifier {
  final AuthRepository repo;
  SettingsViewModel({required this.repo});

  LogOutStatus status = LogOutStatus.idle();

  bool get isLoading => status is LogOutStatusLoading;

  void emit(LogOutStatus value) {
    status = value;
    notifyListeners();
  }

  void logout() {
    emit(LogOutStatus.loading());
    repo.logout().then((_) => emit(LogOutStatus.success())).catchError((e, st) => AppLogger.w("logout failed", e, st));
  }
}
