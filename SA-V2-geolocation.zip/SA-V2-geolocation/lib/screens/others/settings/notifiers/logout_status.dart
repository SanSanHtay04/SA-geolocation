import 'package:freezed_annotation/freezed_annotation.dart';

part 'logout_status.freezed.dart';

@freezed
class LogOutStatus with _$LogOutStatus {
  const factory LogOutStatus.idle() = LogOutStatusIdle;

  const factory LogOutStatus.loading() = LogOutStatusLoading;

  const factory LogOutStatus.success() = LogOutStatusSuccess;

  const factory LogOutStatus.failed() = LogOutStatusFailed;
}
