import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/data/local/Database.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/copyright_notice.dart';
import 'package:share_plus/share_plus.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:sales/widgets/simple_toolbar.dart';
import 'package:sales/widgets/work_layout.dart';

import 'notifiers/settings_viewmodel.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  static create() {
    return ChangeNotifierProvider(
      create: (context) => SettingsViewModel(repo: context.read()),
      child: SettingsScreen(),
    );
  }

  _sharedDataFiles() {
    AppDatabase.close().then((dbPath) async {
     await Share.shareXFiles([XFile(dbPath)], text: 'SA-V2 Database').then((value) => AppDatabase.db);
    });
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<PackageInfo>(
        future: PackageInfo.fromPlatform(),
        builder: (context, snapshot) {
          return Consumer<SettingsViewModel>(
            builder: (context, vm, child) {
              Future.delayed(Duration.zero, () {
                vm.status.maybeWhen(
                  success: () => Navigator.pushNamedAndRemoveUntil(
                    context,
                    "/login",
                    (route) => false,
                  ),
                  orElse: () {},
                );
              });
              return WorkLayout(
                appBar: SimpleToolbar(title: "Settings"),
                isBusy: vm.isLoading,
                child: Column(
                  children: [
                    ListTile(
                      title: Text("Export database"),
                      leading: Icon(Icons.upload),
                      onTap: _sharedDataFiles,
                    ),
                    ListTile(
                      title: Text('App Version: ${snapshot.data?.version}'),
                      leading: Icon(Icons.info_outline_rounded),
                    ),
                    Spacer(),
                    Container(
                      padding: kPadding16,
                      width: double.maxFinite,
                      child: OutlinedButton(
                        onPressed: vm.logout,
                        child: Text("LOG OUT"),
                      ),
                    ),
                    CopyrightNotice(),
                  ],
                ),
              );
            },
          );
        });
  }
}
