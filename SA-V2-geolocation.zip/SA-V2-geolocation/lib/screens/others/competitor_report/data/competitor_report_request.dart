import 'package:freezed_annotation/freezed_annotation.dart';

part 'competitor_report_request.freezed.dart';
part 'competitor_report_request.g.dart';

@freezed
class CompetitorReportRequest with _$CompetitorReportRequest {
  const factory CompetitorReportRequest({
    required int posId,
    required int productCategoryId,
    required List<CompetitorReport> competitors,
    required String dtCreated,
    String? journalRemark,
    int? clientsVisited,
  }) = _CompetitorReportRequest;

  factory CompetitorReportRequest.fromJson(Map<String, dynamic> json) => _$CompetitorReportRequestFromJson(json);
}

@freezed
class CompetitorReport with _$CompetitorReport {
  const factory CompetitorReport({
    required int competitorId,
    int? cashDownSales,
  }) = _CompetitorReport;

  factory CompetitorReport.fromJson(Map<String, dynamic> json) => _$CompetitorReportFromJson(json);
}
