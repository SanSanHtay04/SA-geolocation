import 'package:sales/base/data_response.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/data/remote/services/services.dart';
import 'package:sales/base/base_repository.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/models/models.dart';

import 'competitor_report_request.dart';

class CompetitorReportRepo with BaseRepository {
  final CommonService _api;

  CompetitorReportRepo(this._api);

  Future<DataResponse<String>> submit({
    required POS pos,
    required ProductCategory category,
    required Map<Competitor, String> competitors,
    required String? clientsVisited,
    String? remark,
    required DateTime date,
  }) {
    return getData(
      handleDataRequest: () {
        final request = CompetitorReportRequest(
          posId: pos.id,
          productCategoryId: category.id,
          clientsVisited:
              clientsVisited == null ? null : int.tryParse(clientsVisited),
          journalRemark: remark,
          competitors: mapCompetitors(competitors),
          dtCreated: date.format(formatPattern: DATETIME_FORMAT),
        );
        return _api.submitCompetitorReport(request);
      },
      handleDataResponse: (MessageResponse res) => res.messages ?? '',
    );
  }

  List<CompetitorReport> mapCompetitors(Map<Competitor, String> competitors) {
    return competitors.entries
        .map((entry) => CompetitorReport(
              competitorId: entry.key.id,
              cashDownSales: int.tryParse(entry.value),
            ))
        .toList();
  }
}
