import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/app_snack_bar.dart';
import 'package:sales/widgets/save_button.dart';

import '../notifiers/form/competitor_form_notifier.dart';
import '../notifiers/viewmodel/competitor_view_model.dart';
import 'cash_down_sale_inputs.dart';
import 'competitor_form_inputs.dart';

class CompetitorReportForm extends StatefulWidget {
  const CompetitorReportForm({super.key, required this.vm});
  final CompetitorViewModel vm;

  @override
  State<CompetitorReportForm> createState() => _CompetitorReportFormState();
}

class _CompetitorReportFormState extends State<CompetitorReportForm> {
  final _formKey = GlobalKey<FormState>();
  AutovalidateMode _mode = AutovalidateMode.disabled;

  onSubmitButtonClicked() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_formKey.currentState?.validate() ?? false) {
        FocusScope.of(context).unfocus();
        final formState = context.read<CompetitorFormNotifier>().state;
        context.showConfirmDialog(
          message: "Do you want to create competitor report?",
          onConfirmPressed: () => widget.vm.submit(formState),
        );
      } else {
        _mode = AutovalidateMode.onUserInteraction;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Expanded(
          child: Form(
            key: _formKey,
            autovalidateMode: _mode,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  CompetitorFormInputs(vm: widget.vm),
                  kSpaceVertical8,
                  const CashDownSaleInputs(),
                  kSpaceVertical8,
                ],
              ),
            ),
          ),
        ),
        kSpaceVertical8,
        SaveButton(onPressed: onSubmitButtonClicked),
      ],
    );
  }
}
