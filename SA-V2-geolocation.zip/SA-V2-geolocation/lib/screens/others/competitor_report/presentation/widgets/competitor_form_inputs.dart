import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';
import 'package:sales/models/models.dart';
import 'package:sales/models/pos_type.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/form_card.dart';
import 'package:sales/widgets/selected_field/selected_field.dart';
import 'package:sales/widgets/selected_group/single_selected_group.dart';
import 'package:sales/widgets/text_form_field/clearable_text_form_field.dart';
import 'package:sales/widgets/text_form_field/date_picker_field.dart';
import 'package:sales/widgets/text_form_field/text_area_field.dart';

import '../notifiers/form/competitor_form_notifier.dart';
import '../notifiers/viewmodel/competitor_view_model.dart';

class CompetitorFormInputs extends StatelessWidget {
  const CompetitorFormInputs({super.key, required this.vm});

  final CompetitorViewModel vm;

  @override
  Widget build(BuildContext context) {
    final state = context.watch<CompetitorFormNotifier>().state;
    final today = DateTime.now();
    final minDate = state.posType == POSType.sa ? today.subtract(Duration(days: 2)) : today.subtract(Duration(days: 7));

    return FormCard(
      title: 'Competitior Information',
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SingleSelectedGroup<POSType>(
            label: 'POS Type',
            items: POSType.values,
            labelParser: (item) => item.getName(context),
            onSelectChanged: (value) {
              context.read<CompetitorFormNotifier>().onPosTypeUpdate(value);
            },
            selectedItem: state.posType,
          ),
          kSpaceVertical8,
          SelectedField<POS>(
            title: "Merchandise/POS",
            required: true,
            labelParser: (item) => item.name,
            items: vm.getPosList(state.posType == POSType.merchant),
            selectedItem: state.pos,
            onSelected: (value) {
              context.read<CompetitorFormNotifier>().onMerchantPosUpdate(value);
            },
          ),
          kSpaceVertical8,
          SelectedField<ProductCategory>(
            title: "Product Category",
            required: true,
            labelParser: (item) => item.name,
            items: vm.getCategories(),
            selectedItem: state.productCategory,
            onSelected: (value) {
              context.read<CompetitorFormNotifier>().onProductCategoryUpdate(value);
            },
          ),
          kSpaceVertical8,
          DatePickerField(
            labelText: 'Competitor Date',
            required: true,
            minTime: minDate,
            maxTime: today,
            selectedDateTime: state.competitorDate,
            onConfirm: (value) {
              context.read<CompetitorFormNotifier>().onCompetitiorDateUpdate(value);
            },
          ),
          kSpaceVertical8,
          ClearableTextFormField(
            labelText: 'Clients Visited',
            required: true,
            keyboardType: TextInputType.number,
            initialValue: state.clientsVisited,
            onChanged: (value) {
              context.read<CompetitorFormNotifier>().onClientsVisitedUpdate(value);
            },
          ),
          kSpaceVertical8,
          TextAreaField(
            labelText: 'Remark',
            initialValue: state.remark,
            onChanged: (value) {
              context.read<CompetitorFormNotifier>().onRemarkUpdate(value);
            },
          ),
        ],
      ),
    );
  }
}
