import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';
import 'package:sales/models/models.dart';
import 'package:sales/widgets/form_card.dart';
import 'package:sales/widgets/text_form_field/clearable_text_form_field.dart';

import '../notifiers/form/competitor_form_notifier.dart';

class CashDownSaleInputs extends StatelessWidget {
  const CashDownSaleInputs({super.key});

  @override
  Widget build(BuildContext context) {
    final competitorSales = context.watch<CompetitorFormNotifier>().state.competitorSales;

    return FormCard(
        title: 'Cash Down Sales',
        content: Wrap(
          runSpacing: 8,
          runAlignment: WrapAlignment.start,
          children: [
            ...Competitor.getAll()
                .map(
                  (competitor) => ClearableTextFormField(
                    labelText: competitor.competitorName,
                    required: true,
                    keyboardType: TextInputType.number,
                    initialValue: competitorSales[competitor],
                    onChanged: (value) {
                      context.read<CompetitorFormNotifier>().onCompetitorSalesUpdate(competitor, value);
                    },
                  ),
                )
                .toList(growable: false)
          ],
        ));
  }
}
