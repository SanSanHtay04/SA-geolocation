import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/base/error.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/app_snack_bar.dart';
import 'package:sales/widgets/simple_toolbar.dart';
import 'package:sales/widgets/work_layout.dart';
import '../data/competitor_report_repo.dart';
import 'widgets/competitor_report_form.dart';
import 'notifiers/form/competitor_form_notifier.dart';
import 'notifiers/viewmodel/competitor_view_model.dart';

class CompetitorReportScreen extends StatelessWidget {
  const CompetitorReportScreen({super.key});
  static create() {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) => CompetitorViewModel(
            posRepo: context.read(),
            categoryRepo: context.read(),
            repo: CompetitorReportRepo(context.read()),
          ),
        ),
        ChangeNotifierProvider(create: (context) => CompetitorFormNotifier()..loadCompetitorSales()),
      ],
      child: CompetitorReportScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<CompetitorViewModel>(builder: (_, vm, __) {
      /// Handle the callback from submitState
      Future.delayed(Duration.zero, (() {
        vm.submitState.maybeWhen(
          success: (message) => context.showMessageDialog(
            message: message,
            onClosePressed: () {
              vm.resetSubmitState();
              context.read<CompetitorFormNotifier>().resetFormState();
              //=> Navigator.pop(context)
            },
          ),
          failed: (message, error) => context.showErrorDialog(
            error.errorMessage(context, message),
            onClosePressed: vm.resetSubmitState,
          ),
          orElse: () {},
        );
      }));

      return WorkLayout(
        appBar: SimpleToolbar(title: "Competitor Report"),
        isBusy: vm.isLoading,
        child: Padding(
          padding: kPaddingHorizontal8 + kPaddingVertical16,
          child: CompetitorReportForm(vm: vm),
        ),
      );
    });
  }
}
