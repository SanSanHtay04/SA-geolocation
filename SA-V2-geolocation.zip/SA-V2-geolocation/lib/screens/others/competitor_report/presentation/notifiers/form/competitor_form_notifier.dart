import 'package:flutter/foundation.dart';
import 'package:sales/models/models.dart';
import 'package:sales/models/pos_type.dart';
import 'package:sales/utils/utils.dart';
import 'competitor_form_state.dart';

class CompetitorFormNotifier extends ChangeNotifier {
  CompetitorFormState state = const CompetitorFormState();

  emit(CompetitorFormState value) {
    state = value;
    notifyListeners();
  }

  resetFormState() {
    final competitiors = Competitor.getAll();
    final competitorSales = Map<Competitor, String>.fromIterables(
      competitiors,
      List.filled(competitiors.length, '', growable: true),
    );
    emit(CompetitorFormState(competitorSales: competitorSales));
  }

  void loadCompetitorSales() {
    final competitiors = Competitor.getAll();
    final competitorSales = Map<Competitor, String>.fromIterables(
      competitiors,
      List.filled(competitiors.length, '', growable: true),
    );
    emit(state.copyWith(competitorSales: competitorSales));
  }

  onPosTypeUpdate(POSType value) {
    emit(state.copyWith(posType: value, pos:  null, competitorDate: null));
  }

  onMerchantPosUpdate(POS value) {
    AppLogger.i("POS UPDATE : $value");
    emit(state.copyWith(pos: value));
  }

  onProductCategoryUpdate(ProductCategory category) {
    emit(state.copyWith(productCategory: category));
  }

  onCompetitiorDateUpdate(DateTime? date) {
    emit(state.copyWith(competitorDate: date));
  }

  onClientsVisitedUpdate(String count) {
    emit(state.copyWith(clientsVisited: count));
  }

  onRemarkUpdate(String? remark) {
    emit(state.copyWith(remark: remark));
  }

  onCompetitorSalesUpdate(Competitor competitor, String value) {
    final current = state.competitorSales;
    emit(state.copyWith(competitorSales: {...current, competitor: value}));
  }
}
