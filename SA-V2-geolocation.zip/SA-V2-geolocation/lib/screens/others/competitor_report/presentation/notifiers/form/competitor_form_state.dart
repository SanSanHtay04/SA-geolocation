import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/models/models.dart';
import 'package:sales/models/pos_type.dart';
part 'competitor_form_state.freezed.dart';

@freezed
class CompetitorFormState with _$CompetitorFormState {
  const factory CompetitorFormState({
  @Default(POSType.sa) POSType posType,
    POS? pos,
    ProductCategory? productCategory,
    DateTime? competitorDate,
    @Default('') String clientsVisited,
    @Default({}) Map<Competitor, String> competitorSales,
    @Default('') String? remark,
  }) = _CompetitorFormState;
}
