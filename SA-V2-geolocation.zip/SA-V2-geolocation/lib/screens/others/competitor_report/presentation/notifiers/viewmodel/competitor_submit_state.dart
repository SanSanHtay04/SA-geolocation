import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/base/error.dart';

part 'competitor_submit_state.freezed.dart';

@freezed
class CompetitorSubmitState with _$CompetitorSubmitState {
  factory CompetitorSubmitState.idle() = CompetitorSubmitStateIdle;

  factory CompetitorSubmitState.loading() = CompetitorSubmitStateLoading;

  factory CompetitorSubmitState.success(msg) = CompetitorSubmitStateSuccess;

  factory CompetitorSubmitState.failed(msg,{AppError? err}) = CompetitorSubmitStateFailed;
}
