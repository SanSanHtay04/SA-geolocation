import 'package:flutter/cupertino.dart';
import 'package:sales/models/models.dart';
import 'package:sales/data/repositories/repositories.dart';
import 'package:sales/screens/others/competitor_report/data/competitor_report_repo.dart';
import 'package:sales/utils/utils.dart';

import '../form/competitor_form_state.dart';
import 'competitor_data_state.dart';
import 'competitor_submit_state.dart';

/// CompetitorViewModel serves for both DataState and SubmitState
class CompetitorViewModel extends ChangeNotifier {
  final CompetitorReportRepo repo;

  CompetitorViewModel({
    required this.repo,
    required ProductCategoryRepository categoryRepo,
    required POSRepository posRepo,
  }) {
    _init(posRepo, categoryRepo);
  }

  CompetitorDataState dataState = const CompetitorDataState.idle();

  CompetitorDataStateIdle? get data => dataState.mapOrNull(idle: (value) => value);

  List<POS> getPosList(bool isMerchant) {
    return (isMerchant) ? data?.posList.where((element) => element.isMerchant == 1).toList() ?? [] : data?.posList.where((element) => element.isMerchant == 0).toList() ?? [];
  }

  List<ProductCategory> getCategories() => data?.categories ?? [];

  CompetitorSubmitState submitState = CompetitorSubmitState.idle();

  bool get isLoading => (dataState is CompetitorDataStateLoading) || (submitState is CompetitorSubmitStateLoading);

  void _setDataState(state) {
    dataState = state;
    notifyListeners();
  }

  void _setSubmitState(state) {
    submitState = state;
    notifyListeners();
  }

  resetSubmitState() => _setSubmitState(CompetitorSubmitState.idle());

  _init(POSRepository posRepo, ProductCategoryRepository categoryRepo) async {
    _setDataState(const CompetitorDataState.loading());

    final responses = await Future.wait([
      posRepo.getPOSList(), // 0
      categoryRepo.getCategoriesForAll(), // 1
    ]);
    final errors = responses.where((e) => e.hadFailed).map((e) => e.message);

    if (errors.isNotEmpty) {
      final failedState = CompetitorDataState.failed(
        errors.join('\n'),
        error: null,
      );
      _setDataState(failedState);
    } else {
      final data = responses.map((e) => e.data);
      final successState = CompetitorDataState.idle(
        posList: data.elementAt(0) as List<POS>,
        categories: data.elementAt(1) as List<ProductCategory>,
      );
      _setDataState(successState);
    }
  }

  Future<void> submit(CompetitorFormState data) async {
    _setSubmitState(CompetitorSubmitState.loading());

    final res = await repo.submit(
      pos: data.pos!,
      category: data.productCategory!,
      date: data.competitorDate!,
      competitors: data.competitorSales,
      clientsVisited: data.clientsVisited,
      remark: data.remark,
    );
    final newState = res.when(
      success: (data) => CompetitorSubmitState.success(data),
      failed: (msg, err) => CompetitorSubmitState.failed(msg, err: err),
    );

    _setSubmitState(newState);
  }
}
