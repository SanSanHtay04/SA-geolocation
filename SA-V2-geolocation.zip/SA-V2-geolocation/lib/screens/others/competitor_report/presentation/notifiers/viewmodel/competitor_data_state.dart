import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/base/error.dart';
import 'package:sales/models/models.dart';

part 'competitor_data_state.freezed.dart';

@freezed
class CompetitorDataState with _$CompetitorDataState {
  const factory CompetitorDataState.idle({
    @Default([]) List<POS> posList,
    @Default([]) List<ProductCategory> categories,
  }) = CompetitorDataStateIdle;

  const factory CompetitorDataState.loading() = CompetitorDataStateLoading;

  const factory CompetitorDataState.failed(String msg, {AppError? error}) = CompetitorDataStateFailed;
}
