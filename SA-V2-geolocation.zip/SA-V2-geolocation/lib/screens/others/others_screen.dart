import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:sales/routes.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/utils/utils.dart';

final _menuItems = {
  'Competitor Report': OthersBottomTab.competitorReport,
  'Contract Search': OthersBottomTab.contractDocsSearch,
  'Image Upload': OthersBottomTab.imageUpload,
  //'Merchandise Request': OthersBottomTab.merchandiseRequest,
};

class OthersScreen extends StatelessWidget {
  const OthersScreen({super.key});

  _goTo(BuildContext context, String destinationName) {
    SchedulerBinding.instance.addPostFrameCallback((_) {
      Navigator.of(context).pushNamed(destinationName);
    });
  }

  @override
  Widget build(BuildContext context) {
  
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: kPadding16,
          child: Wrap(
            runSpacing: 16,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  IconButton(
                    icon: Icon(Icons.settings),
                    onPressed: () => _goTo(context, OthersBottomTab.settings),
                  )
                ],
              ),
              ..._menuItems.entries.map((e) => OtherTabWidget(
                    text: e.key,
                    onTap: () => _goTo(context, e.value),
                  )),
            ],
          ),
        ),
      ),
    );
  }
}

class OtherTabWidget extends StatelessWidget {
  OtherTabWidget({
    super.key,
    required this.text,
    required this.onTap,
  });

  final String text;
  final GestureTapCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: context.getColorScheme().primary,
      borderRadius: kBorderRadius8,
      child: InkWell(
        onTap: onTap,
        child: Container(
          padding: kPadding16,
          width: double.maxFinite,
          child: Text(
            text,
            style: TextStyle(
              fontSize: 20,
              color: context.getColorScheme().onPrimary,
            ),
          ),
        ),
      ),
    );
  }
}
