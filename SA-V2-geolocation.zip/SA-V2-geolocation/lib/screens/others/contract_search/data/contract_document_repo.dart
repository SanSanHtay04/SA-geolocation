import 'package:sales/base/base_repository.dart';
import 'package:sales/base/data_response.dart';
import 'package:sales/data/remote/models/responses/responses.dart';
import 'package:sales/data/remote/services/services.dart';

class ContractDocumentRepo with BaseRepository {
  final CommonService _api;

  ContractDocumentRepo(this._api);

  Future<DataResponse<List<ContractDocumentResponse>>> getContractDocs(
    String query,
    int contractNoOrNRC,
  ) async {
    return getData(
      handleDataRequest: () => _api.getContractDocs(query, contractNoOrNRC),
      handleDataResponse: (res) => res.data,
    );
  }
}
