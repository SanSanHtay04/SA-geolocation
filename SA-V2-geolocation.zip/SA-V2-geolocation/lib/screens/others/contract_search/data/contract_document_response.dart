import 'package:freezed_annotation/freezed_annotation.dart';

part 'contract_document_response.freezed.dart';
part 'contract_document_response.g.dart';

@freezed
class ContractDocumentResponse with _$ContractDocumentResponse {
  factory ContractDocumentResponse({
    required String contractNo,
    @Default('') String strippedContractNo,
    @Default('') String contractDate,
    @Default('') String customerFullName,
    required String natRegCardNo,
    @Default('') String docUrl,
  }) = _ContractDocumentResponse;

  factory ContractDocumentResponse.fromJson(Map<String, dynamic> json) => _$ContractDocumentResponseFromJson(json);
}
