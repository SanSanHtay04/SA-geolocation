import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/copyright_notice.dart';
import 'package:sales/widgets/simple_toolbar.dart';
import '../data/contract_document_repo.dart';
import 'notifiers/form/contract_doc_form_notifier.dart';
import 'notifiers/viewmodel/contract_doc_view_model.dart';
import 'widgets/contract_doc_form.dart';
import 'widgets/contract_doc_results.dart';

class ContractSearchScreen extends StatelessWidget {
  const ContractSearchScreen({super.key});

  static create() {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) => ContractDocViewModel(
            repo: ContractDocumentRepo(context.read()),
          ),
        ),
        ChangeNotifierProvider(create: (context) => ContractDocFormNotifier()),
      ],
      child: ContractSearchScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: SimpleToolbar(title: "Contract Search"),
        body: Padding(
          padding: kPaddingHorizontal8 + kPaddingVertical16,
          child: Column(
            children: [
              const ContractDocForm(),
              kSpaceVertical8,
              Divider(),
              kSpaceVertical8,
              const ContractDocResults(),
              CopyrightNotice(),
            ],
          ),
        ));
  }
}
