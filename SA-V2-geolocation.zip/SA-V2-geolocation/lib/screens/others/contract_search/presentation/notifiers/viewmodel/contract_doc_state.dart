import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/base/error.dart';
import 'package:sales/data/remote/models/models.dart';
part 'contract_doc_state.freezed.dart';

@freezed
class ContractDocState with _$ContractDocState {
  const factory ContractDocState.idle(List<ContractDocumentResponse> results) = ContractDocStateIdle;

  const factory ContractDocState.loading() = ContractDocStateLoading;

  const factory ContractDocState.failed(message, {AppError? error}) = ContractDocStateFailed;
}
