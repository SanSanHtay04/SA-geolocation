import 'package:flutter/foundation.dart';
import 'package:sales/models/doc_search_type.dart';

import 'contract_doc_form_state.dart';

class ContractDocFormNotifier extends ChangeNotifier {
  ContractDocFormState state = const ContractDocFormState();

  emit(ContractDocFormState value) {
    state = value;
    notifyListeners();
  }

  updateSearchType(DocSearchType type) {
    emit(state.copyWith(type: type));
  }

  updateContractNo(String number) {
    emit(state.copyWith(contractNumber: number));
  }

  updateNrcNo(String number) {
    emit(state.copyWith(nrcNumber: number));
  }
}
