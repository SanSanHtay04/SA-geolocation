import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/models/doc_search_type.dart';
part 'contract_doc_form_state.freezed.dart';

@freezed
class ContractDocFormState with _$ContractDocFormState {
  const factory ContractDocFormState({
    @Default('') contractNumber,
    @Default('') nrcNumber,
    @Default(DocSearchType.contract) type,
  }) = _ContractDocFormState;
}
