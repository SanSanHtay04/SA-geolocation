import 'package:flutter/material.dart';
import 'package:sales/models/doc_search_type.dart';
import 'package:sales/screens/others/contract_search/data/contract_document_repo.dart';
import 'contract_doc_state.dart';

class ContractDocViewModel extends ChangeNotifier {
  final ContractDocumentRepo repo;
  ContractDocViewModel({required this.repo});

  ContractDocState state = const ContractDocState.idle([]);

  bool get isLoading => state is ContractDocStateLoading;

  void emit(ContractDocState value) {
    state = value;
    notifyListeners();
  }

  Future<void> search(String query, DocSearchType type) async {
    emit(ContractDocState.loading());
    final res = await repo.getContractDocs(query, type.value);
    final newState = res.when(
      success: (data) => ContractDocState.idle(data),
      failed: (message, error) => ContractDocState.failed(message),
    );
    emit(newState);
  }
}
