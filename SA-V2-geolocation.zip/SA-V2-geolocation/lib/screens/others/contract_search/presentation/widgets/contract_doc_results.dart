import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/base/error.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/error_message.dart';
import '../notifiers/viewmodel/contract_doc_view_model.dart';
import 'contract_doc_item.dart';

class ContractDocResults extends StatelessWidget {
  const ContractDocResults({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<ContractDocViewModel>(builder: (context, vm, child) {
      return Expanded(
          child: vm.state.when(
        idle: (data) => _SearchResults(data),
        loading: () => Center(child: const CircularProgressIndicator()),
        failed: (message, error) => ErrorMessage(
          error.errorMessage(context, message),
        ),
      ));
    });
  }

  _SearchResults(List<ContractDocumentResponse> results) {
    return Column(
      children: [
        (results.length == 0) ? Text('There is no contract found.') : Text('Successfully found ${results.length} contract(s)'),
        kSpaceVertical8,
        Expanded(
            child: ListView.builder(
          itemCount: results.length,
          shrinkWrap: true,
          itemBuilder: (context, index) => ContractDocItem(
            data: results[index],
          ),
        ))
      ],
    );
  }
}
