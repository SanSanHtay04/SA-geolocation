import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/data_row.dart';
import 'package:sales/widgets/preview_card.dart';
import 'package:url_launcher/url_launcher.dart';

class ContractDocItem extends StatelessWidget {
  const ContractDocItem({super.key, required this.data});
  final ContractDocumentResponse data;

  _copyToClipboard() {
    Clipboard.setData(ClipboardData(text: data.docUrl)).then((value) => Fluttertoast.showToast(msg: "Link copied"));
  }

  _lunchToBrowser() {
    launchUrl(Uri.parse(data.docUrl)).catchError((e, stack) {
      Fluttertoast.showToast(msg: "Cannot launch url: ${data.docUrl}");
    });
  }

  @override
  Widget build(BuildContext context) {
    return PreviewCard(
      buttonLabel: 'View Detail',
      buttonIcon: const Icon(Icons.share),
      onButtonTapped: _lunchToBrowser,
      suffixIcon: const Icon(Icons.copy),
      onIconButtonTapped: _copyToClipboard,
      primaryLabel: data.contractNo,
      primaryContent: Text(data.customerFullName),
      children: [
        DataRowWidget(
          label: 'NRC Number',
          value: data.natRegCardNo,
        ),
        kSpaceVertical8,
        DataRowWidget(
          label: 'Contract Date',
          value: data.contractDate,
        ),
        kSpaceVertical8,
        DataRowWidget(
          label: 'Contract Stripped Number',
          value: data.strippedContractNo,
        ),
      ],
    );
  }
}
