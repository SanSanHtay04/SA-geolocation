import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/models/doc_search_type.dart';
import 'package:sales/screens/others/contract_search/presentation/notifiers/viewmodel/contract_doc_view_model.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/search_text_field.dart';
import 'package:sales/widgets/selected_group/single_selected_group.dart';

import '../notifiers/form/contract_doc_form_notifier.dart';

class ContractDocForm extends StatelessWidget {
  const ContractDocForm({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<ContractDocFormNotifier>().state;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        SingleSelectedGroup<DocSearchType>(
          label: 'Search Type',
          items: DocSearchType.values,
          labelParser: (item) => item.getName(context),
          selectedItem: state.type,
          onSelectChanged: (item) {
            context.read<ContractDocFormNotifier>().updateSearchType(item);
          },
        ),
        kSpaceVertical8,
        (state.type == DocSearchType.contract)
            ? SearchTextField(
                labelText: 'Contract number',
                maxLength: 6,
                keyboardType: TextInputType.number,
                initialValue: state.contractNumber,
                onChanged: (value) {
                  context.read<ContractDocFormNotifier>().updateContractNo(value);
                },
                onSubmitted: (query) {
                  context.read<ContractDocViewModel>().search(
                        query,
                        state.type,
                      );
                },
              )
            : SearchTextField(
                labelText: 'NRC number',
                maxLength: 6,
                keyboardType: TextInputType.number,
                initialValue: state.nrcNumber,
                onChanged: (value) {
                  context.read<ContractDocFormNotifier>().updateNrcNo(value);
                },
                onSubmitted: (query) {
                  context.read<ContractDocViewModel>().search(
                        query,
                        state.type,
                      );
                },
              ),
      ],
    );
  }
}
