import 'package:freezed_annotation/freezed_annotation.dart';

part 'checkup_request.freezed.dart';
part 'checkup_request.g.dart';

@freezed
class CheckupRequest with _$CheckupRequest {
  const CheckupRequest._();
  const factory CheckupRequest({
    required int posId,
    required int productCategoryId,
    required List<MarketingImage> images,
    required String dtCreated,
  }) = _CheckupRequest;

  factory CheckupRequest.fromJson(Map<String, dynamic> json) =>
      _$CheckupRequestFromJson(json);
}

@freezed
class MarketingImage with _$MarketingImage {
  const MarketingImage._();

  const factory MarketingImage({
    required int typeId,
    required String filePath,
   
  }) = _MarketingImage;

  factory MarketingImage.fromJson(Map<String, dynamic> json) =>
      _$MarketingImageFromJson(json);
}

