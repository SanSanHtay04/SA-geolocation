import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/configs.dart';

part 'upload_image_response.freezed.dart';
part 'upload_image_response.g.dart';

@freezed
class UploadImageResponse with _$UploadImageResponse {
  const UploadImageResponse._();
  const factory UploadImageResponse({
     String? domain,
    required String path,
     String? mime,
  }) = _UploadImageResponse;

  String get imageUrl => '${Configs.imageUrl}/$path';

  factory UploadImageResponse.fromJson(Map<String, dynamic> json) =>
      _$UploadImageResponseFromJson(json);
}
