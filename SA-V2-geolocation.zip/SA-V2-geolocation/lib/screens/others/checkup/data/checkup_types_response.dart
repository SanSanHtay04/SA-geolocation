import 'package:freezed_annotation/freezed_annotation.dart';

part 'checkup_types_response.freezed.dart';
part 'checkup_types_response.g.dart';

@freezed
class CheckupTypesResponse with _$CheckupTypesResponse {
  factory CheckupTypesResponse({
    required int caCheckUpTypeId,
    required String typeName,
    String? typeNameBurmese,
    @JsonKey(name: 'for') required String typeFor,
    required int optional,
    required String? posProductType,
    required int? posCat1,
    required int? posCat2,
    required int? posCat3
  }) = _CheckupTypesResponse;

  factory CheckupTypesResponse.fromJson(Map<String, dynamic> json) =>
      _$CheckupTypesResponseFromJson(json);
}
