import 'package:sales/base/data_response.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/data/remote/services/services.dart';
import 'package:sales/base/base_repository.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/models/models.dart';

import '../presentation/notifiers/document_category/document_category_state.dart';
import '../presentation/notifiers/document_category/checkup_category.dart';
import 'checkup_request.dart';
import 'checkup_types_response.dart';

class CheckupRepository with BaseRepository {
  final CommonService _api;

  CheckupRepository(this._api);

  /// For Merchandise
  Future<DataResponse<List<CheckupCategoryMerchandise>>> getMerchandiseCheckupTypes() async {
    return getData(
      handleDataRequest: () => _api.getCheckupTypes("merchandise"),
      handleDataResponse: (ApiResponse<List<CheckupTypesResponse>> res) {
        return res.data
            .map((e) => CheckupCategory.merchandise(
                  id: e.caCheckUpTypeId,
                  description: e.typeName,
                  optional: e.optional == 1,
                  posProductType: e.posProductType ?? '',
                  posCat1: e.posCat1 ?? 0,
                  posCat2: e.posCat2 ?? 0,
                  posCat3: e.posCat3 ?? 0,
                ))
            .cast<CheckupCategoryMerchandise>()
            .toList(growable: false);
      },
    );
  }

  /// For POS 
  Future<DataResponse<List<CheckupCategoryPOS>>> getPOSCheckupTypes() async {
    return getData(
      handleDataRequest: () => _api.getCheckupTypes("pos"),
      handleDataResponse: (ApiResponse<List<CheckupTypesResponse>> res) {
        return res.data
            .map((e) => CheckupCategory.pos(
                  id: e.caCheckUpTypeId,
                  description: e.typeName,
                  optional: e.optional == 1,
                ))
            .cast<CheckupCategoryPOS>()
            .toList(growable: false);
      },
    );
  }

  Future<DataResponse<String>> submit({
    required POS pos,
    required ProductCategory category,
    required Map<CheckupCategory, DocumentCategoryState?> images,
  }) async {
    return getData(
      handleDataRequest: () {
        final files = images.map((key, value) => MapEntry(key.id, value))..removeWhere((key, value) => value == null && value?.docData == null);
        final request = CheckupRequest(
          posId: pos.id,
          productCategoryId: category.id,
          images: files.entries
              .map((entry) => MarketingImage(
                    typeId: entry.key,
                    filePath: entry.value!.docData!.path,
                  ))
              .toList(),
          dtCreated: DateTime.now().format(formatPattern: DATETIME_FORMAT),
        );

        return _api.createCheckUp(request);
      },
      handleDataResponse: (res) => res.message ?? '',
    );
  }
}
