import 'package:dio/dio.dart';
import 'package:sales/base/base_repository.dart';
import 'package:sales/base/data_response.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/data/remote/services/common_service.dart';


import 'upload_image_response.dart';

class UploadImageRepo with BaseRepository {
  final CommonService _api;

  UploadImageRepo(this._api);

  Future<DataResponse<UploadImageResponse>> uploadImage(
      String localPath /*Uint8List fileData*/) async {
    return getData(
      handleDataRequest: () {
        final formData = FormData();
        formData.files.add(
          MapEntry("image", MultipartFile.fromFileSync(localPath)),
        );
        return _api.uploadImage(formData);
      },
      handleDataResponse: (ApiResponse<UploadImageResponse> res) => res.data,
    );
  }
}
