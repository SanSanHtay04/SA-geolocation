import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/base/error.dart';
import 'package:sales/data/repositories/repositories.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/app_snack_bar.dart';
import 'package:sales/widgets/simple_toolbar.dart';
import 'package:sales/widgets/work_layout.dart';
import '../data/checkup_repository.dart';
import '../data/upload_image_repo.dart';
import 'checkup_input_form.dart';
import 'notifiers/document_category/document_category_notifier.dart';
import 'notifiers/form/checkup_form_notifier.dart';
import 'notifiers/viewmodel/checkup_view_model.dart';

class CheckupScreen extends StatelessWidget {
  const CheckupScreen({super.key});

  static create() {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) => CheckupViewModel(
            repo: CheckupRepository(context.read()),
            posRepo: context.read(),
            salesRepo: SalesRepository(context.read()),
            categoryRepo: ProductCategoryRepository(context.read()),
          ),
        ),
        ChangeNotifierProvider(
          create: (context) => CheckupFormNotifier(),
        ),
        ChangeNotifierProvider(
          create: (context) => DocumentCategoryNotifier(
            UploadImageRepo(context.read()),
          ),
        ),
      ],
      child: CheckupScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Consumer2<CheckupViewModel, DocumentCategoryNotifier>(
      builder: (_, vm, imageNf, __) {
        /// To handle call-back of submitState.
        Future.delayed(Duration.zero, (() {
          vm.submitState.maybeWhen(
            success: (message) => context.showMessageDialog(
                message: "Marketing images are successfully saved!",
                onClosePressed: () {
                  //widget.formState.resetFormstate();

                  imageNf.removeAllImages();
                  vm.resetSubmitState();
                }),
            failed: (message, error) => context.showErrorDialog(
              error.errorMessage(context, message),
              onClosePressed: () {
                vm.resetSubmitState();
              },
            ),
            orElse: () {},
          );
        }));

        return WorkLayout(
          appBar: SimpleToolbar(title: "Marketing Image Upload"),
          isBusy: vm.isLoading,
          child: SingleChildScrollView(
            child: Padding(
              padding: kPadding16,
              child: CheckupInputForm(
                vm: vm,
                imagesNotifier: imageNf,
              ),
            ),
          ),
        );
      },
    );
  }
}
