import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/models/pos.dart';
import 'package:sales/models/product_category.dart';
import 'package:sales/models/region.dart';
import 'package:sales/models/sales_area.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/widgets/app_snack_bar.dart';
import 'package:sales/widgets/save_button.dart';
import 'package:sales/widgets/selected_field/selected_field.dart';
import 'notifiers/document_category/document_category_notifier.dart';
import 'notifiers/document_category/document_category_state.dart';
import 'notifiers/document_category/checkup_category.dart';
import 'notifiers/form/checkup_form_notifier.dart';
import 'notifiers/viewmodel/checkup_view_model.dart';
import 'widgets/document_upload_screen.dart';


class CheckupInputForm extends StatefulWidget {
  const CheckupInputForm({
    super.key,
    required this.vm,
    required this.imagesNotifier,
  });

  final CheckupViewModel vm;

  final DocumentCategoryNotifier imagesNotifier;

  @override
  State<CheckupInputForm> createState() => _CheckupInputFormState();
}

class _CheckupInputFormState extends State<CheckupInputForm> {
  final _formKey = GlobalKey<FormState>();
  AutovalidateMode _mode = AutovalidateMode.disabled;

  @override
  Widget build(BuildContext context) {
    return Consumer<CheckupFormNotifier>(builder: (context, form, child) {
      return Form(
        key: _formKey,
        autovalidateMode: _mode,
        child: Wrap(   
          runSpacing: 16,
          runAlignment: WrapAlignment.start,
          children: [
            SelectedField<ProductCategory>(
              title: "Type of product",
              required: true,
              items: widget.vm.getProductCategories(),
              labelParser: (item) => item.name,
              selectedItem: form.state.productCategory,
              onSelected: form.onProductCategoryUpdate,
            ),
            SelectedField<SalesRegion>(
              title: "Sales Region",
              required: true,
              items: widget.vm.getSalesRegion(),
              labelParser: (item) => item.name,
              selectedItem: form.state.region,
              onSelected: form.onSalesRegionUpdate,
            ),
            SelectedField<SalesArea>(
              title: "Sales Area",
              required: true,
              items: widget.vm.getSalesArea(form.state.region),
              labelParser: (item) => item.name,
              selectedItem: form.state.area,
              onSelected: form.onSalesAreaUpdate,
            ),
            SelectedField<POS>(
              title: "Merchandise/POS",
              required: true,
              items: widget.vm.getPosList(form.state.area),
              labelParser: (item) => item.name,
              selectedItem: form.state.pos,
              onSelected: form.onMerchantPosUpdate,
            ),
            DocumentUploadScreen(
              documentTitle: "POS Pictures *",
              documentCategories: widget.vm.getPosImagesToUpload(),
              notifier: widget.imagesNotifier,
            ),
            form.state.pos == null
                ? Text(
                    "There is no POS selected.",
                    style: context.getTextTheme().labelLarge,
                  )
                : DocumentUploadScreen(
                    documentTitle: "Merchandise Pictures *",
                    documentCategories: widget.vm.getMerchandiseImagesToUpload(form.state.pos),
                    notifier: widget.imagesNotifier,
                  ),
            SaveButton(
              label: 'Submit',
              onPressed: () {
                if (_formKey.currentState?.validate() ?? false) {
                  final documentCategories = <CheckupCategory>[
                    ...widget.vm.getPosImagesToUpload(),
                    ...widget.vm.getMerchandiseImagesToUpload(form.state.pos),
                  ];

                  Map<CheckupCategory, DocumentCategoryState?> documents = {};

                  documentCategories.forEach((element) {
                    documents[element] = null;
                  });
                  documents.addAll(widget.imagesNotifier.images);
                  form.onDocumentCategoriesUpdate(documents);

                  if (form.checkIsFulFill()) {

                    final state = form.state;
                    context.showConfirmDialog(
                      message: 'Are you sure you want to save this?',
                      onConfirmPressed: () => widget.vm.submit(
                        pos:state.pos!,
                        category: state.productCategory!,
                        images: state.documents,
                      ),
                    );
                    
                  } else {
                    context.showErrorDialog("Some additional images are required to upload");
                  }
                } else {
                  setState(() {
                    _mode = AutovalidateMode.onUserInteraction;
                  });
                }
              },
            ),
          ],
        ),
      );
    });
  }
}
