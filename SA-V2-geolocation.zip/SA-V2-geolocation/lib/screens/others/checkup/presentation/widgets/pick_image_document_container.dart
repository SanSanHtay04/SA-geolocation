import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';

const double kCaptureImageDocumentBoxHeight = 100;
const double kCaptureImageDocumentPaddingSize = 10;

/// Caculated height of the [PickImageDocumentContainer], for convenient to
/// display [UploadCategoryRowDelegate] 's height.
const double kCaptureImageDocumentRowHeight = kCaptureImageDocumentBoxHeight + kCaptureImageDocumentPaddingSize * 2 + 8;

/// Base container for Pick Image action.
/// Usage by [CaptureImageDocument], [AddImageDocument], [PickedImageDocument]
/// widgest.
class PickImageDocumentContainer extends StatelessWidget {
  const PickImageDocumentContainer({
    Key? key,
    this.child,
  }) : super(key: key);

  final Widget? child;

  @override
  Widget build(BuildContext context) {
    return DottedBorder(
      borderType: BorderType.RRect,
      radius: const Radius.circular(16),
      dashPattern: const [5, 5],
      strokeCap: StrokeCap.round,
      color: Theme.of(context).colorScheme.primary,
      child: Padding(
        padding: const EdgeInsets.all(kCaptureImageDocumentPaddingSize),
        child: Container(
          // width: double.infinity,
          width: kCaptureImageDocumentBoxHeight,
          height: kCaptureImageDocumentBoxHeight,
          decoration: BoxDecoration(color: Colors.blue.shade50.withOpacity(.3), borderRadius: BorderRadius.circular(10)),
          child: child,
        ),
      ),
    );
  }
}
