import 'package:flutter/material.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/widgets/container_with_border.dart';
import '../notifiers/document_category/document_category_notifier.dart';
import '../notifiers/document_category/checkup_category.dart';
import 'pick_and_upload_image.dart';

class DocumentUploadScreen<T extends CheckupCategory> extends StatefulWidget {
  const DocumentUploadScreen({
    super.key,
    required this.documentTitle,
    required this.documentCategories,
    required this.notifier,
  });

  final String documentTitle;
  final List<T> documentCategories;
  final DocumentCategoryNotifier<T> notifier;

  @override
  State<DocumentUploadScreen> createState() => _DocumentUploadScreenState();
}

class _DocumentUploadScreenState extends State<DocumentUploadScreen> {
  late final ScrollController _controller = ScrollController();

  List<Widget> _getEffectiveStepperChildren(List<CheckupCategory> documentCategories) {
    final children = <Widget>[];
    for (int i = 0; i < documentCategories.length; i++) {
      final category = documentCategories[i];

      children.add(Padding(
        padding: kPadding8,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                kSpaceHorizontal12,
                Container(
                  height: 28,
                  width: 28,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: context.getColorScheme().primary,
                  ),
                  child: Center(
                    child: Text(
                      '${i + 1}',
                      style: context.getTextTheme().bodySmall?.copyWith(
                            color: context.getColorScheme().onPrimary,
                          ),
                    ),
                  ),
                ),
                kSpaceHorizontal12,
                Expanded(
                  child: RichText(
                    text: TextSpan(
                        children: [
                          TextSpan(
                            text: category.description,
                          ),
                          if (!category.optional)
                            const TextSpan(
                              text: ' *',
                              style: TextStyle(color: Colors.red),
                            )
                        ],
                        style: TextStyle(
                          color: context.getColorScheme().onSurface,
                        )),
                  ),
                ),
              ],
            ),
            kSpaceVertical8,
            Container(
              margin: const EdgeInsets.only(left: 30),
              alignment: Alignment.centerLeft,
              child: PickAndUploadImage(
                documentCategory: category,
                documentCategoryNotifier: widget.notifier,
              ),
            ),
          ],
        ),
      ));
    }
    return children;
  }

  @override
  Widget build(BuildContext context) {
    final steps = _getEffectiveStepperChildren(widget.documentCategories);

    return SingleChildScrollView(
      controller: _controller,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            widget.documentTitle,
            style: context.getTextTheme().labelLarge,
          ),
          kSpaceVertical8,
          ContainerWithBorder(
            width: double.infinity,
            child: Padding(
              padding: kPaddingVertical12,
              child: Column(
                children: [...steps],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
