
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/widgets/app_snack_bar.dart';
import '../notifiers/document_category/document_category_notifier.dart';
import '../notifiers/document_category/checkup_category.dart';
import 'capture_image_document.dart';
import 'picked_image_document_overview.dart';
import 'uploaded_document_overview_fullscreen_page.dart';

class PickAndUploadImage extends StatelessWidget {
  const PickAndUploadImage({
    Key? key,
    required this.documentCategory,
    required this.documentCategoryNotifier,
  }) : super(key: key);

  final CheckupCategory documentCategory;
  final DocumentCategoryNotifier documentCategoryNotifier;

  void _handlePickImage(BuildContext context) async {
    XFile? pickedFile;
    pickedFile = await takePhoto();

    if (pickedFile != null) {
      documentCategoryNotifier.pickedImage(documentCategory, pickedFile.path);
    }
  }

  void _clearPickedImage(BuildContext context) async {
    final result = await context.showConfirmDialog(type: LogType.warning, message: 'Are you sure to remove uploaded document?');

    if (result) {
      // ignore: use_build_context_synchronously
      documentCategoryNotifier.removePickedImage(documentCategory);
    }
  }

  void _openOverviewPickedImage(BuildContext context) {
    int indexThisImage = 0;

    final currentImageFile = documentCategoryNotifier.images[documentCategory];
    final imageResources = currentImageFile!.overviewImageSource;
    final elementsLabels = currentImageFile.documentPartLabel;

    Navigator.of(context).push(MaterialPageRoute(builder: (context) {
      return UploadedDocumentOverviewFullScreenPage(
        overviewLabel: documentCategory.description,
        initializePage: indexThisImage,
        imageResouces: [imageResources],
        elementLabels: [elementsLabels],
      );
    }));
  }

  void _tryReloadPickedImage() {
    documentCategoryNotifier.reUploadPickedImage(documentCategory);
  }

  @override
  Widget build(BuildContext context) {
    final currentImageFile = documentCategoryNotifier.images[documentCategory];

    if (currentImageFile == null || !currentImageFile.imagePicked) {
      return CaptureImageDocument(
        label: documentCategory.description,
        handlePickImage: () => _handlePickImage(context),
      );
    }
    return PickedImageDocumentOverview(
      partState: currentImageFile,
      clearPickedImage: () => _clearPickedImage(context),
      openOverviewPickedImage: () => _openOverviewPickedImage(context),
      tryReloadPickedImage: _tryReloadPickedImage,
    );
  }
}
