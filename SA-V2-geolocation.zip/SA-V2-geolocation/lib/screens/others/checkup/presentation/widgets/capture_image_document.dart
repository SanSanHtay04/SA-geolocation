// ignore_for_file: use_build_context_synchronously

import 'package:flutter/material.dart';

import 'pick_image_document_container.dart';


class CaptureImageDocument extends StatelessWidget {
  const CaptureImageDocument({
    Key? key,
    required this.label,
    this.isLoadMore = false,
    required this.handlePickImage,
  }) : super(key: key);

  final String label;
  final bool isLoadMore;
  final VoidCallback handlePickImage;

  @override
  Widget build(BuildContext context) {
    final iconData = isLoadMore ? Icons.note_add : Icons.file_open;

    return GestureDetector(
      onTap: handlePickImage,
      child: PickImageDocumentContainer(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              iconData,
              color: Theme.of(context).colorScheme.primary,
              size: 50,
            ),
            const SizedBox(
              height: 15,
            ),
            Text(
             "upload",
              style:  Theme.of(context).textTheme
                  .bodySmall
                  ?.copyWith(fontWeight: FontWeight.w500),
            )
          ],
        ),
      ),
    );
  }
}
