import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';


import '../notifiers/document_category/document_category_state.dart';
import 'pick_image_document_container.dart';

class PickedImageDocumentOverview extends StatelessWidget {
  const PickedImageDocumentOverview({
    Key? key,
    required this.partState,
    required this.clearPickedImage,
    required this.openOverviewPickedImage,
    required this.tryReloadPickedImage,
  }) : super(key: key);

  final DocumentCategoryState partState;

  final VoidCallback clearPickedImage;

  final VoidCallback openOverviewPickedImage;

  final VoidCallback tryReloadPickedImage;

  @override
  Widget build(BuildContext context) {
    return PickImageDocumentContainer(
      child: Stack(
        alignment: Alignment.topRight,
        children: [
          Positioned.fill(
            child: GestureDetector(
              onTap: partState.uploading ? null : openOverviewPickedImage,
              child: ClipRRect(
                borderRadius:  BorderRadius.all(Radius.circular(8)),
                child: OverviewImageBaseOnResource(
                  resource: partState.overviewImageSource,
                ),
              ),
            ),
          ),
          if (partState.errorMessage != null) ...[
            Positioned.fill(
              child: ClipRRect(
                borderRadius:  BorderRadius.all(Radius.circular(8)),
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    color: Colors.grey.withOpacity(0.7),
                  ),
                ),
              ),
            ),
            Positioned.fill(
              child: Center(
                child: InkWell(
                  onTap: tryReloadPickedImage,
                  child: const Icon(
                    CupertinoIcons.restart,
                    size: 32,
                    color: Colors.orange,
                  ),
                ),
              ),
            ),
          ],
          if (!partState.uploading)
            Positioned(
              top: 4,
              right: 4,
              child: InkWell(
                onTap: clearPickedImage,
                child: const Icon(
                  CupertinoIcons.clear_circled_solid,
                  size: 24,
                  color: Colors.red,
                ),
              ),
            ),
          if (partState.uploading) ...[
            Positioned.fill(
              child: ClipRRect(
                borderRadius:  BorderRadius.all(Radius.circular(8)),
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    color: Colors.grey.withOpacity(0.7),
                  ),
                ),
              ),
            ),
            const Positioned.fill(
                child: Center(
              child: SizedBox(
                height: 32,
                width: 32,
                child: CircularProgressIndicator(),
              ),
            )),
          ],
        ],
      ),
    );
  }
}

class OverviewImageBaseOnResource extends StatelessWidget {
  const OverviewImageBaseOnResource({
    Key? key,
    required this.resource,
    this.boxFit,
  }) : super(key: key);

  final OverviewImageResource resource;
  final BoxFit? boxFit;

  @override
  Widget build(BuildContext context) {
    if (resource.localImagePicked != null) {
      return Image.file(
        File(resource.localImagePicked!),
        fit: boxFit ?? BoxFit.cover,
        alignment: Alignment.center,
      );
    } else if (resource.remoteImagePicked != null) {
      return CachedNetworkImage(
        imageUrl: resource.remoteImagePicked!,
        fit: boxFit ?? BoxFit.cover,
        alignment: Alignment.center,
      );
    } else {
      return const SizedBox();
    }
  }
}
