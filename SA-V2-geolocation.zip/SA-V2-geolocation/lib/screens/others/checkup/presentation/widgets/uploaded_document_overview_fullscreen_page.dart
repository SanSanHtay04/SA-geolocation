import 'package:flutter/material.dart';
import '../notifiers/document_category/document_category_state.dart';
import 'picked_image_document_overview.dart';

class UploadedDocumentOverviewFullScreenPage extends StatefulWidget {
  const UploadedDocumentOverviewFullScreenPage({
    Key? key,
    required this.imageResouces,
    required this.initializePage,
    required this.overviewLabel,
    this.elementLabels,
  })  : assert(elementLabels == null ||
            (elementLabels.length == imageResouces.length)),
        super(key: key);

  final int initializePage;
  final List<OverviewImageResource> imageResouces;
  final List<String>? elementLabels;
  final String overviewLabel;

  @override
  State<UploadedDocumentOverviewFullScreenPage> createState() =>
      _UploadedDocumentOverviewFullScreenPageState();
}

class _UploadedDocumentOverviewFullScreenPageState
    extends State<UploadedDocumentOverviewFullScreenPage> {
  late final PageController _pageController;

  @override
  void initState() {
    super.initState();
    _pageController = PageController(
      initialPage: widget.initializePage,
      keepPage: true,
    );
  }

  List<OverviewImageResource> get _imageResouces => widget.imageResouces;

  List<String>? get _elementLabels => widget.elementLabels;

  List<Widget> _effectiveChildrenBuilder() {
    final children = <Widget>[];

    for (var i = 0; i < _imageResouces.length; i++) {
      children.add(_SingleFullScreenOverviewImagePage(
        imageResource: _imageResouces[i],
        label: _elementLabels?[i],
      ));
    }

    return children;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: const BackButton(
          color: Colors.white,
        ),
        backgroundColor: Colors.black,
        excludeHeaderSemantics: true,
        centerTitle: true,
        title: Text(
          widget.overviewLabel,
          style: const TextStyle(color: Colors.white),
        ),
      ),
      backgroundColor: Colors.black,
      body: SafeArea(
        child: SizedBox.expand(
          child: PageView(
            scrollDirection: Axis.horizontal,
            pageSnapping: true,
            controller: _pageController,
            children: _effectiveChildrenBuilder(),
          ),
        ),
      ),
    );
  }
}

class _SingleFullScreenOverviewImagePage extends StatelessWidget {
  const _SingleFullScreenOverviewImagePage({
    Key? key,
    required this.imageResource,
    this.label,
  }) : super(key: key);
  final OverviewImageResource imageResource;
  final String? label;

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.bottomCenter,
      children: [
        Positioned.fill(
          child: OverviewImageBaseOnResource(
            resource: imageResource,
            boxFit: BoxFit.contain,
          ),
        ),
      ],
    );
  }
}
