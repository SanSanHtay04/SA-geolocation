import 'package:flutter/material.dart';
import 'package:sales/data/repositories/repositories.dart';
import 'package:sales/models/models.dart';
import 'package:sales/screens/others/checkup/data/checkup_repository.dart';
import '../document_category/document_category_state.dart';
import '../document_category/checkup_category.dart';
import 'checkup_data_state.dart';
import 'checkup_submit_state.dart';

class CheckupViewModel extends ChangeNotifier {
  final CheckupRepository repo;

  CheckupViewModel({
    required this.repo,
    required POSRepository posRepo,
    required SalesRepository salesRepo,
    required ProductCategoryRepository categoryRepo,
  }) {
    _init(posRepo, salesRepo, categoryRepo);
  }

  CheckupDataState dataState = const CheckupDataState.idle();
  CheckupSubmitState submitState = const CheckupSubmitState.idle();

  CheckupDataStateIdle? get _data => dataState is CheckupDataStateIdle ? dataState as CheckupDataStateIdle : null;

  bool get isLoading => (dataState is CheckupDataStateLoading) || (submitState is CheckupSubmitStateLoading);

  List<SalesRegion> getSalesRegion() => _data?.salesRegion ?? [];

  List<SalesArea> getSalesArea(SalesRegion? region) {
    return _data?.salesArea.where((area) => area.regionId == region?.id).toList() ?? [];
  }

  List<POS> getPosList(SalesArea? salesArea) {
    return _data?.posList.where((pos) => pos.salesAreaId == salesArea?.id).toList() ?? [];
  }

  List<ProductCategory> getProductCategories() => _data?.categories ?? [];

  List<CheckupCategoryPOS> getPosImagesToUpload() => _data?.posImagesToUpload ?? [];

  List<CheckupCategoryMerchandise> getMerchandiseImagesToUpload(POS? pos) {
    List<CheckupCategoryMerchandise> CheckupCategorys = [];

    if (pos != null)
      CheckupCategorys = _data?.merchandiseImagesToUpload
              .where(
                (item) => pos.posProductType == item.posProductType,
              )
              .where(
                (item) => (pos.posCategory?.toLowerCase() == 'cat1' && item.posCat1 == 1 || pos.posCategory?.toLowerCase() == 'cat2' && item.posCat2! == 1 || (pos.posCategory?.toLowerCase() == 'cat3' || pos.posCategory?.toLowerCase() == 'n/a') && item.posCat3! == 1),
              )
              .toList(growable: false) ??
          [];
    return CheckupCategorys;
  }

  // END SELECTABLE FORM DATA LISTS

  void _setDataState(CheckupDataState state) {
    dataState = state;
    notifyListeners();
  }

  void _setSubmitState(CheckupSubmitState state) {
    submitState = state;
    notifyListeners();
  }

  void resetSubmitState() => _setSubmitState(const CheckupSubmitState.idle());

  Future<void> _init(
    POSRepository posRepo,
    SalesRepository salesRepo,
    ProductCategoryRepository categoryRepo,
  ) async {
    _setDataState(const CheckupDataState.loading());

    final responses = await Future.wait([
      posRepo.getPOSList(), //0
      categoryRepo.getCategoriesForAll(), //1
      salesRepo.getSalesRegion(), //2
      salesRepo.getSalesArea(), //3
      repo.getPOSCheckupTypes(), //4
      repo.getMerchandiseCheckupTypes(), //5
    ]);
    final errors = responses.where((e) => e.hadFailed).map((e) => e.message);

    if (errors.isNotEmpty) {
      final failedState = CheckupDataState.failed(
        errors.join('\n'),
        error: null,
      );
      _setDataState(failedState);
    } else {
      final data = responses.map((e) => e.data);
      final successState = CheckupDataState.idle(
        posList: data.elementAt(0) as List<POS>,
        categories: data.elementAt(1) as List<ProductCategory>,
        salesRegion: data.elementAt(2) as List<SalesRegion>,
        salesArea: data.elementAt(3) as List<SalesArea>,
        posImagesToUpload: data.elementAt(4) as List<CheckupCategoryPOS>,
        merchandiseImagesToUpload: data.elementAt(5) as List<CheckupCategoryMerchandise>,
      );
      _setDataState(successState);
    }
  }

  Future<void> submit({
    required POS pos,
    required ProductCategory category,
    required Map<CheckupCategory, DocumentCategoryState?> images,
  }) async {
    _setSubmitState(const CheckupSubmitState.loading());

    final res = await repo.submit(
      pos: pos,
      category: category,
      images: images,
    );
    final newState = res.when(
      success: (data) => CheckupSubmitState.success(data),
      failed: (msg, error) => CheckupSubmitState.failed(msg, error: error),
    );
    _setSubmitState(newState);
  }
}
