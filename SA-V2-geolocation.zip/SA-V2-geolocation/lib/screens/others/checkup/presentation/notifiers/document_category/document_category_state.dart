import 'package:freezed_annotation/freezed_annotation.dart';
import '../../../data/upload_image_response.dart';
part 'document_category_state.freezed.dart';

@freezed
class DocumentCategoryState with _$DocumentCategoryState {
  const DocumentCategoryState._();

  const factory DocumentCategoryState({
    @Default(false) bool uploading,
    String? errorMessage,
    String? localImagePath,
    @Default('') String documentPartLabel,
    UploadImageResponse? docData,
  }) = _DocumentCategoryState;

  bool isFulfill(bool required) {
    return ((required && docData != null) || (!required)) && !uploading;
  }

  bool get imagePicked => localImagePath != null || docData != null;

  bool get haveLocalPath => localImagePath != null;

  OverviewImageResource get overviewImageSource => OverviewImageResource(
        localImagePicked: localImagePath,
        remoteImagePicked: docData?.imageUrl,
      );
}

@freezed
class OverviewImageResource with _$OverviewImageResource {
  const OverviewImageResource._();
  const factory OverviewImageResource({
    String? localImagePicked,
    String? remoteImagePicked,
  }) = _OverviewImageLocal;
}
