import 'package:flutter/foundation.dart';

import '../../../data/upload_image_repo.dart';
import 'document_category_state.dart';
import 'checkup_category.dart';

class DocumentCategoryNotifier<T extends CheckupCategory> extends ChangeNotifier {
  DocumentCategoryNotifier(this.repo);
  final UploadImageRepo repo;

  final Map<T, DocumentCategoryState> _images = {};
  Map<T, DocumentCategoryState> get images => _images;

  Future<void> pickedImage(T documentCategory, String localPath) async {
    updateState(
      documentCategory,
      DocumentCategoryState(
        docData: null,
        documentPartLabel: documentCategory.description,
        errorMessage: null,
        localImagePath: localPath,
        uploading: false,
      ),
    );

    final result = await repo.uploadImage(localPath /*File(localPath).readAsBytesSync()*/);
    final VoidCallback callBack = result.map(
      success: (successResult) => () {
        updateState(
            documentCategory,
            DocumentCategoryState(
              docData: successResult.data,
              documentPartLabel: documentCategory.description,
              localImagePath: localPath,
              uploading: false,
            ));
      },
      failed: (failedResult) => () {
        updateState(
            documentCategory,
            DocumentCategoryState(
              errorMessage: failedResult.message,
              documentPartLabel: documentCategory.description,
              localImagePath: localPath,
              uploading: false,
            ));
      },
    );
    callBack.call();
  }

  /// Remove picked image.
  void removePickedImage(T documentCategory) {
    final state = _images[documentCategory];
    if (state == null) return;
    updateState(
        documentCategory,
        DocumentCategoryState(
          docData: null,
          documentPartLabel: state.documentPartLabel,
          errorMessage: state.errorMessage,
          localImagePath: null,
          uploading: state.uploading,
        ));
  }

  void removeAllImages() {
    _images.clear();
    notifyListeners();
  }

  void reUploadPickedImage(T documentCategory) {
    final state = _images[documentCategory];
    if (state == null) return;

    if (state.errorMessage != null && state.localImagePath != null) {
      pickedImage(documentCategory, state.localImagePath!);
    }
  }

  void updateState(T documentCategory, DocumentCategoryState currentState) {
    _images[documentCategory] = currentState;
    notifyListeners();
  }
}
