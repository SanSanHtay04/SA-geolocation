
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/models/pos.dart';
import 'package:sales/models/product_category.dart';
import 'package:sales/models/region.dart';
import 'package:sales/models/sales_area.dart';

import '../document_category/document_category_state.dart';
import '../document_category/checkup_category.dart';

part 'checkup_form_state.freezed.dart';

@freezed
class CheckupFormState with _$CheckupFormState {
  const factory CheckupFormState({
    POS? pos,
    ProductCategory? productCategory,
    SalesRegion? region,
    SalesArea? area,
    @Default({}) Map<CheckupCategory, DocumentCategoryState?> documents,

  }) = _CheckupFormState;
}
