import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/base/error.dart';

part 'checkup_submit_state.freezed.dart';

@freezed
class CheckupSubmitState with _$CheckupSubmitState {
  const factory CheckupSubmitState.idle() = CheckupSubmitStateIdle;

  const factory CheckupSubmitState.loading() = CheckupSubmitStateLoading;

  const factory CheckupSubmitState.failed(String message,{AppError? error}) = CheckupSubmitStateFalied;

  const factory CheckupSubmitState.success(String message) = CheckupSubmitStateSuccess;
}
