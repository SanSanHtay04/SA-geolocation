
import 'package:flutter/material.dart';
import 'package:sales/models/pos.dart';
import 'package:sales/models/product_category.dart';
import 'package:sales/models/region.dart';
import 'package:sales/models/sales_area.dart';


import '../document_category/document_category_state.dart';
import '../document_category/checkup_category.dart';
import 'checkup_form_state.dart';

class CheckupFormNotifier extends ChangeNotifier {
  CheckupFormState state = const CheckupFormState();

  loadData(
    List<CheckupCategoryPOS> posImages,
    List<CheckupCategoryMerchandise> merchandiseImages,
  ) {
    // state = CheckupInputData(
    //   posImages: posImages.asMap().map((key, value) => MapEntry(value, null)),
    //   merchandiseImages: merchandiseImages.asMap().map((key, value) => MapEntry(value, null)),
    // );
  }


  void emit(CheckupFormState inputData) {
    state = inputData;
    notifyListeners();
  }

  onSalesRegionUpdate(SalesRegion region) {
    emit(
      state.copyWith(
        region: region,
        area: null,
        pos: null,
      ),
    );
  }

  onSalesAreaUpdate(SalesArea area) {
    emit(state.copyWith(area: area, pos: null));
  }

  onMerchantPosUpdate(POS pos) {
    emit(state.copyWith(pos: pos));
  }

  onProductCategoryUpdate(ProductCategory category) {
    emit(state.copyWith(productCategory: category));
  }

  onDocumentCategoriesUpdate(
    Map<CheckupCategory, DocumentCategoryState?> documents,
  ) {
    emit(state.copyWith(documents: documents));
  }

  bool checkIsFulFill() {
    bool isFulFill = true;

    state.documents.forEach((key, value) {
      if (value == null) {
        isFulFill = isFulFill && key.optional;
      } else {
        isFulFill = isFulFill && value.isFulfill(!key.optional);
      }
    });

    return isFulFill;
  }

  resetFormstate() {
    emit(CheckupFormState(
      documents: state.documents.map((key, value) => MapEntry(key, null)),
    ));
  }
}
