import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/base/error.dart';
import 'package:sales/models/models.dart';

import '../document_category/checkup_category.dart';

part 'checkup_data_state.freezed.dart';

@freezed
class CheckupDataState with _$CheckupDataState {
  const factory CheckupDataState.idle({
    @Default([]) List<POS> posList,
    @Default([]) List<ProductCategory> categories,
    @Default([]) List<SalesRegion> salesRegion,
    @Default([]) List<SalesArea> salesArea,
    @Default([]) List<CheckupCategoryPOS> posImagesToUpload,
    @Default([]) List<CheckupCategoryMerchandise> merchandiseImagesToUpload,
  }) = CheckupDataStateIdle;

  const factory CheckupDataState.loading() = CheckupDataStateLoading;

  const factory CheckupDataState.failed(String message, {AppError? error}) = CheckupDataStateFailed;
}
