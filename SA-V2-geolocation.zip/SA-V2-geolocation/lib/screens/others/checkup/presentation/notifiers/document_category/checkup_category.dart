import 'package:freezed_annotation/freezed_annotation.dart';

part 'checkup_category.freezed.dart';

@freezed
class CheckupCategory with _$CheckupCategory {
  factory CheckupCategory.pos({
    required int id,
    required String description,
    required bool optional,
  }) = CheckupCategoryPOS;

  factory CheckupCategory.merchandise({
    required int id,
    required String description,
    required bool optional,
    String? posProductType,
    int? posCat1,
    int? posCat2,
    int? posCat3,
  }) = CheckupCategoryMerchandise;
}
