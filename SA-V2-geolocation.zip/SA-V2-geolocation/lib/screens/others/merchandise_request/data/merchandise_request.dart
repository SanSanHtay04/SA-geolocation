import 'package:freezed_annotation/freezed_annotation.dart';

part 'merchandise_request.freezed.dart';
part 'merchandise_request.g.dart';

@freezed
class MerchandiseRequest with _$MerchandiseRequest {
  const factory MerchandiseRequest({
    required int posId,
    required int productCategoryId,
    required List<MerchandiseData> merchandises,
    required String dtCreated,
  }) = _MerchandiseRequest;

  factory MerchandiseRequest.fromJson(Map<String, dynamic> json) =>
      _$MerchandiseRequestFromJson(json);
}

@freezed
class MerchandiseData with _$MerchandiseData {
  const factory MerchandiseData({
    required int merchandiseId,
    @Default(0) int quantity,
  }) = _MerchandiseData;

  factory MerchandiseData.fromJson(Map<String, dynamic> json) =>
      _$MerchandiseDataFromJson(json);
}
