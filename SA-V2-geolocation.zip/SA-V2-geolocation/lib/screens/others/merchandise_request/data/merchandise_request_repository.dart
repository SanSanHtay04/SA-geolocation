import 'package:sales/base/data_response.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/data/remote/services/services.dart';
import 'package:sales/base/base_repository.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/models/models.dart';

class MerchandiseRequestRepository with BaseRepository {
  final CommonService _api;

  MerchandiseRequestRepository(this._api);

  Future<DataResponse<String>> submit({
    required POS pos,
    required ProductCategory category,
    required Map<Merchandise, String> merchandises,
    String? remark,
  }) async {
    return getData(
      handleDataRequest: () {
        final request = MerchandiseRequest(
          posId: pos.id,
          productCategoryId: category.id,
          merchandises: mapMerchandises(merchandises),
          dtCreated: DateTime.now().format(formatPattern: DATETIME_FORMAT),
        );
        return _api.submitMerchandiseRequest(request);
      },
      handleDataResponse: (res) => res.messages ?? '',
    );
  }

  List<MerchandiseData> mapMerchandises(Map<Merchandise, String> merchandises) {
    List<MerchandiseData> list = [];
    merchandises.forEach((m, value) {
      list.add(MerchandiseData(
        merchandiseId: m.id,
        quantity: int.tryParse(value) ?? 0,
      ));
    });
    return list;
  }
}
