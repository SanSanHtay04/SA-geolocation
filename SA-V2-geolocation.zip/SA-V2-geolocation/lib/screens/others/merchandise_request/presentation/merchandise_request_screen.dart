import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/base/error.dart';
import 'package:sales/screens/others/merchandise_request/presentation/notifiers/viewmodel/merchandise_view_model.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/app_snack_bar.dart';
import 'package:sales/widgets/simple_toolbar.dart';
import 'package:sales/widgets/work_layout.dart';

import '../data/merchandise_request_repository.dart';
import 'notifiers/form/merchandise_form_notifier.dart';
import 'widgets/merchandise_request_form.dart';

class MerchandiseRequestScreen extends StatelessWidget {
  const MerchandiseRequestScreen({super.key});
  static create() {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) => MerchandiseViewModel(
            posRepo: context.read(),
            categoryRepo: context.read(),
            repo: MerchandiseRequestRepository(context.read()),
          ),
        ),
        ChangeNotifierProvider(create: (context) => MerchandiseFormNotifier()),
      ],
      child: MerchandiseRequestScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<MerchandiseViewModel>(builder: (_, vm, __) {
      /// Handle the callback from submitState
      Future.delayed(Duration.zero, (() {
        vm.submitState.maybeWhen(
          success: (message) => context.showMessageDialog(
            message: message,
            onClosePressed: () => Navigator.pop(context),
          ),
          failed: (message, error) => context.showErrorDialog(
            error.errorMessage(context, message),
            onClosePressed: vm.resetSubmitState,
          ),
          orElse: () {},
        );
      }));

      return WorkLayout(
        appBar: SimpleToolbar(title: "Merchandise Request"),
        isBusy: vm.isLoading,
        child: Padding(
          padding: kPaddingHorizontal8 + kPaddingVertical16,
          child: MerchandiseRequestForm(vm: vm),
        ),
      );
    });
  }
}
