import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';
import 'package:sales/screens/others/merchandise_request/presentation/notifiers/form/merchandise_form_notifier.dart';
import 'package:sales/widgets/form_card.dart';
import 'package:sales/widgets/text_form_field/clearable_text_form_field.dart';
import '../notifiers/viewmodel/merchandise_view_model.dart';

class MerchandiseQuantityInputs extends StatelessWidget {
  const MerchandiseQuantityInputs({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<MerchandiseFormNotifier>().state;
    final _merchandises = context.read<MerchandiseViewModel>().getMerchandise(state.productCategory);

    return FormCard(
        title: 'Merchandise Quantities',
        content: (_merchandises.isEmpty)
            ? Text('There is no product category selected.')
            : Wrap(
                runSpacing: 8,
                runAlignment: WrapAlignment.start,
                children: [
                  ..._merchandises
                      .map(
                        (data) => ClearableTextFormField(
                          labelText: data.name,
                          required: true,
                          keyboardType: TextInputType.number,
                          initialValue: state.merchandiseQuantities[data],
                          validator: ((value) {
                            final number = (int.tryParse(value ?? '0') ?? 0);
                            if (number > data.limit) {
                              return 'Cannot be greater than ${data.limit}';
                            }

                            return null;
                          }),
                          onChanged: (value) {
                            context.read<MerchandiseFormNotifier>().updateMerchandiseQuantities(data, value);
                          },
                        ),
                      )
                      .toList(growable: false)
                ],
              ));
  }
}
