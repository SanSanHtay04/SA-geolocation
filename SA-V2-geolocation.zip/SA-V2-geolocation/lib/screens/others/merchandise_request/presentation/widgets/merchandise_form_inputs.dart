import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';
import 'package:sales/models/models.dart';
import 'package:sales/screens/others/merchandise_request/presentation/notifiers/form/merchandise_form_notifier.dart';
import 'package:sales/screens/others/merchandise_request/presentation/notifiers/viewmodel/merchandise_view_model.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/form_card.dart';
import 'package:sales/widgets/selected_field/selected_field.dart';
import 'package:sales/widgets/text_form_field/text_area_field.dart';

class MerchandiseFormInputs extends StatelessWidget {
  const MerchandiseFormInputs({super.key, required this.vm});

  final MerchandiseViewModel vm;

  @override
  Widget build(BuildContext context) {
    final state = context.watch<MerchandiseFormNotifier>().state;
    return FormCard(
      title: 'Merchandise Information',
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SelectedField<POS>(
            title: "Merchandise/POS",
            required: true,
            labelParser: (item) => item.name,
            items: vm.getPosList(),
            selectedItem: state.pos,
            onSelected: (value) {
              context.read<MerchandiseFormNotifier>().updateMerchantPos(value);
            },
          ),
          kSpaceVertical8,
          SelectedField<ProductCategory>(
            title: "Product Category",
            required: true,
            labelParser: (item) => item.name,
            items: vm.getCategories(),
            selectedItem: state.productCategory,
            onSelected: (value) {
              context.read<MerchandiseFormNotifier>().updateProductCategory(value);
            },
          ),
          kSpaceVertical8,
          TextAreaField(
            labelText: 'Remark',
            initialValue: state.remark,
            onChanged: (value) {
              context.read<MerchandiseFormNotifier>().updateRemark(value);
            },
          ),
        ],
      ),
    );
  }
}
