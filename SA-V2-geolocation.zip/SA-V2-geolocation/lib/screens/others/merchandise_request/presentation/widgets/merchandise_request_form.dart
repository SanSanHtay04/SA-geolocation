import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/screens/others/merchandise_request/presentation/notifiers/viewmodel/merchandise_view_model.dart';
import 'package:sales/screens/others/merchandise_request/presentation/widgets/merchandise_quantity_inputs.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/app_snack_bar.dart';
import 'package:sales/widgets/save_button.dart';

import '../notifiers/form/merchandise_form_notifier.dart';
import 'merchandise_form_inputs.dart';

class MerchandiseRequestForm extends StatefulWidget {
  const MerchandiseRequestForm({super.key, required this.vm});
  final MerchandiseViewModel vm;

  @override
  State<MerchandiseRequestForm> createState() => _MerchandiseRequestFormState();
}

class _MerchandiseRequestFormState extends State<MerchandiseRequestForm> {
  final _formKey = GlobalKey<FormState>();
  AutovalidateMode _mode = AutovalidateMode.disabled;

  onSubmitButtonClicked() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_formKey.currentState?.validate() ?? false) {
        FocusScope.of(context).unfocus();
        final formState = context.read<MerchandiseFormNotifier>().state;
        context.showConfirmDialog(
          message: "Do you want to create save merchandise request?",
          onConfirmPressed: () => widget.vm.submit(formState),
        );
      } else {
        _mode = AutovalidateMode.onUserInteraction;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Expanded(
          child: Form(
            key: _formKey,
            autovalidateMode: _mode,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  MerchandiseFormInputs(vm: widget.vm),
                  kSpaceVertical8,
                  const MerchandiseQuantityInputs(),
                  kSpaceVertical8,
                ],
              ),
            ),
          ),
        ),
        kSpaceVertical8,
        SaveButton(onPressed: onSubmitButtonClicked),
      ],
    );
  }
}
