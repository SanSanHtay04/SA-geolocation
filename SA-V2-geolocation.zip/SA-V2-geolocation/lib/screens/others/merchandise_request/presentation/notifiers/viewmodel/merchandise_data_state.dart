import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/base/error.dart';
import 'package:sales/models/models.dart';

part 'merchandise_data_state.freezed.dart';

@freezed
class MerchandiseDataState with _$MerchandiseDataState {
  const factory MerchandiseDataState.idle({
    @Default([]) List<POS> posList,
    @Default([]) List<ProductCategory> categories,
    @Default([]) List<Merchandise> merchandises,
  }) = MerchandiseDataStateIdle;

  const factory MerchandiseDataState.loading() = MerchandiseDataStateLoading;

  const factory MerchandiseDataState.failed(String msg, {AppError? error}) = MerchandiseDataStateFailed;
}
