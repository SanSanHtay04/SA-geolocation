import 'package:flutter/foundation.dart';
import 'package:sales/models/models.dart';

import 'merchandise_form_state.dart';

class MerchandiseFormNotifier extends ChangeNotifier {
  MerchandiseFormState state = const MerchandiseFormState();

  emit(MerchandiseFormState value) {
    state = value;
    notifyListeners();
  }

  resetFormState() => emit(const MerchandiseFormState());

  // void loadCompetitorSales() {
  //   final competitiors = Competitor.getAll();
  //   final competitorSales = Map<Competitor, String>.fromIterables(
  //     competitiors,
  //     List.filled(competitiors.length, '0', growable: true),
  //   );
  //   emit(state.copyWith(competitorSales: competitorSales));
  // }

  updateMerchantPos(POS value) {
    emit(state.copyWith(pos: value));
  }

  updateProductCategory(ProductCategory category) {
    emit(state.copyWith(productCategory: category));
  }

  updateRemark(String remark) {
    emit(state.copyWith(remark: remark));
  }

  updateMerchandiseQuantities(Merchandise key, String value) {
    final current = state.merchandiseQuantities;
    emit(state.copyWith(merchandiseQuantities: {...current, key: value}));
  }
}
