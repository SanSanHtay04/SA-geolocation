import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/models/models.dart';

part 'merchandise_form_state.freezed.dart';

@freezed
class MerchandiseFormState with _$MerchandiseFormState {
  const factory MerchandiseFormState({
    POS? pos,
    ProductCategory? productCategory,
    @Default({}) Map<Merchandise, String> merchandiseQuantities,
    @Default('') String remark,
  }) = _MerchandiseFormState;
}
