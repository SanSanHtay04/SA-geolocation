import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/base/error.dart';

part 'merchandise_submit_state.freezed.dart';

@freezed
class MerchandiseSubmitState with _$MerchandiseSubmitState {
  factory MerchandiseSubmitState.idle() = MerchandiseSubmitStateIdle;

  factory MerchandiseSubmitState.loading() = MerchandiseSubmitStateLoading;

  factory MerchandiseSubmitState.success(msg) = MerchandiseSubmitStateSuccess;

  factory MerchandiseSubmitState.failed(msg,{AppError? err}) = MerchandiseSubmitStateFailed;
}
