import 'package:flutter/cupertino.dart';
import 'package:sales/models/models.dart';
import 'package:sales/data/repositories/repositories.dart';

import '../../../data/merchandise_request_repository.dart';
import '../form/merchandise_form_state.dart';
import 'merchandise_data_state.dart';
import 'merchandise_submit_state.dart';

class MerchandiseViewModel extends ChangeNotifier {
  final MerchandiseRequestRepository repo;

  MerchandiseViewModel({
    required this.repo,
    required ProductCategoryRepository categoryRepo,
    required POSRepository posRepo,
  }) {
    _init(posRepo, categoryRepo);
  }

  MerchandiseDataState dataState = const MerchandiseDataState.idle();

  MerchandiseDataStateIdle? get data => dataState.mapOrNull(idle: (value) => value);

  List<POS> getPosList() => data?.posList ?? [];
  List<ProductCategory> getCategories() => data?.categories ?? [];
  List<Merchandise> getMerchandise(ProductCategory? category) {
    switch (category?.id) {
      case 1: // motocycle
      case 2: // tricycle
      case 5: // furniture
      case 23: // ebike
        return Merchandise.getAll().where((e) => [1, 2, 8].contains(e.id)).toList(growable: false);
      case 3: // car
        return Merchandise.getAll().where((merchandise) => merchandise.id != 6).toList(growable: false);
      case 4: // white good
      case 22: // black good
        return Merchandise.getAll();
      default:
        return [];
    }
  }

  MerchandiseSubmitState submitState = MerchandiseSubmitState.idle();

  bool get isLoading => (dataState is MerchandiseDataStateLoading) || (submitState is MerchandiseSubmitStateLoading);

  void _setDataState(state) {
    dataState = state;
    notifyListeners();
  }

  void _setSubmitState(state) {
    submitState = state;
    notifyListeners();
  }

  resetSubmitState() => _setSubmitState(MerchandiseSubmitState.idle());

  _init(POSRepository posRepo, ProductCategoryRepository categoryRepo) async {
    _setDataState(const MerchandiseDataState.loading());

    final responses = await Future.wait([
      posRepo.getPOSList(), // 0
      categoryRepo.getCategoriesForAll(), // 1
    ]);
    final errors = responses.where((e) => e.hadFailed).map((e) => e.message);

    if (errors.isNotEmpty) {
      final failedState = MerchandiseDataState.failed(
        errors.join('\n'),
        error: null,
      );
      _setDataState(failedState);
    } else {
      final data = responses.map((e) => e.data);
      final successState = MerchandiseDataState.idle(
        posList: data.elementAt(0) as List<POS>,
        categories: data.elementAt(1) as List<ProductCategory>,
      );
      _setDataState(successState);
    }
  }

  Future<void> submit(MerchandiseFormState data) async {
    _setSubmitState(MerchandiseSubmitState.loading());

    final res = await repo.submit(
      pos: data.pos!,
      category: data.productCategory!,
      merchandises: data.merchandiseQuantities,
    );
    final newState = res.when(
      success: (data) => MerchandiseSubmitState.success(data),
      failed: (msg, err) => MerchandiseSubmitState.failed(msg, err: err),
    );

    _setSubmitState(newState);
  }
}
