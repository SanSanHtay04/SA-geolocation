import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:provider/provider.dart';
import 'package:sales/data/local/db_sqlite_helper.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/widgets/copyright_notice.dart';
import 'package:sales/widgets/simple_toolbar.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sales/providers/providers.dart';

class ChooseCurrentPosScreen extends StatefulWidget {
  ChooseCurrentPosScreen({super.key, required this.connectionType});

  final String? connectionType;

  @override
  State<ChooseCurrentPosScreen> createState() => _ChooseCurrentPosScreenState();
}

class _ChooseCurrentPosScreenState extends State<ChooseCurrentPosScreen> {
  bool _isLoading = false;
  List<Map<String, dynamic>> _assignedPoses = [];

  TextEditingController searchController = new TextEditingController();
  String? filter;

  Future<void> _getAllAssignedPoses() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<OriginationPosProvider>(context, listen: false).getAllAssignedPoses().then((value) {
        setState(() {
          _assignedPoses = Provider.of<OriginationPosProvider>(context, listen: false).items;
          print('assignedPoses length ${_assignedPoses.length}');
          _isLoading = false;
        });
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _getAllAssignedPOSes_offline() async {
    setState(() {
      _isLoading = true;
    });

    try {
      List<Map<String, dynamic>> _newPOSList = await DBSqliteHelper().getAllPOS();
      setState(() {
        _assignedPoses = _newPOSList;
        print('_assignedPoses length ${_assignedPoses.length}');
        _isLoading = false;
      });
    } catch (error) {
      print(error.toString());
      _isLoading = false;
    }

    setState(() {
      _isLoading = false;
    });
  }

  void _onTapSelectPOS(Map<String, dynamic> _pos) async {
    final prefs = await SharedPreferences.getInstance();
    final _currentPos = json.encode({
      'posId': _pos['posId'],
      'posName': _pos['posName'],
      'posAddress': _pos['posAddress'],
    });
    await prefs.setString('rto_origination_pos', _currentPos);
    Navigator.of(context).pop();
  }

  void initData() async {
    if (widget.connectionType == 'online') {
      await _getAllAssignedPoses();
    } else {
      await _getAllAssignedPOSes_offline();
    }
  }

  @override
  void initState() {
    initData();
    searchController.addListener(() {
      setState(() {
        filter = searchController.text;
      });
    });
    super.initState();
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.getColorScheme().background,
      appBar: SimpleToolbar(title: 'CHOOSE CURRENT POS'),
      body: ModalProgressHUD(
        inAsyncCall: _isLoading,
        opacity: 0.5,
        progressIndicator: CircularProgressIndicator(
          valueColor: new AlwaysStoppedAnimation<Color>(context.getColorScheme().primary),
        ),
        child: Padding(
          padding: EdgeInsets.all(5),
          child: Column(
            children: <Widget>[
              new Padding(
                padding: new EdgeInsets.all(8.0),
                child: new TextField(
                  controller: searchController,
                  decoration: InputDecoration(
                    hintText: 'Search POS',
                    prefixIcon: Icon(
                      Icons.search,
                    ),
                    contentPadding: EdgeInsets.fromLTRB(20.0, 15.0, 20.0, 15.0),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(32.0),
                    ),
                    suffixIcon: IconButton(
                      icon: Icon(Icons.clear),
                      onPressed: () => searchController.clear(),
                    ),
                  ),
                ),
              ),
              Divider(),
              new Expanded(
                child: Container(
                  child: RefreshIndicator(
                    onRefresh: () => widget.connectionType == 'online' ? _getAllAssignedPoses() : _getAllAssignedPOSes_offline(),
                    child: ListView.builder(
                        itemCount: _assignedPoses.length,
                        itemBuilder: (context, i) {
                          return filter == null || filter == ""
                              ? ListTile(
                                  isThreeLine: true,
                                  title: Text(
                                    // '${_assignedPoses[i].posCode} :: ${_assignedPoses[i]['posName']}',
                                    '${_assignedPoses[i]['posName']}',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.grey[800],
                                    ),
                                  ),
                                  subtitle: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        '${_assignedPoses[i]['merchantName']}',
                                        style: TextStyle(fontWeight: FontWeight.bold),
                                      ),
                                      Text('${_assignedPoses[i]['posAddress']}'),
                                      Divider(),
                                    ],
                                  ),
                                  leading: new CircleAvatar(
                                    backgroundColor: Colors.blue,
                                    child: Text('${_assignedPoses[i]['posName'].toString().substring(0, 1)}'),
                                  ),
                                  onTap: () {
                                    _onTapSelectPOS(_assignedPoses[i]);
                                  },
                                )
                              : '${_assignedPoses[i]['posName']}'.toLowerCase().contains(filter!.toLowerCase())
                                  ? ListTile(
                                      isThreeLine: true,
                                      title: Text(
                                        // '${_assignedPoses[i].po} :: ${_assignedPoses[i]['posName']}',
                                        '${_assignedPoses[i]['posName']}',
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: Colors.grey[800],
                                        ),
                                      ),
                                      subtitle: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            '${_assignedPoses[i]['merchantName']}',
                                            style: TextStyle(fontWeight: FontWeight.bold),
                                          ),
                                          Text('${_assignedPoses[i]['posAddress']}'),
                                          Divider(),
                                        ],
                                      ),
                                      leading: new CircleAvatar(
                                        backgroundColor: Colors.blue,
                                        child: Text('${_assignedPoses[i]['posName'].toString().substring(0, 1)}'),
                                      ),
                                      onTap: () {
                                        _onTapSelectPOS(_assignedPoses[i]);
                                      },
                                    )
                                  : new Container();
                        }),
                  ),
                ),
              ),
              kSpaceVertical8,
              CopyrightNotice(),
            ],
          ),
        ),
      ),
    );
  }
}
