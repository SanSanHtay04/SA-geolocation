import 'package:flutter/material.dart';
import 'package:sales/models/models.dart';
import 'package:sales/themes/dimensions.dart';

class POSWithoutLocationList extends StatelessWidget {
  const POSWithoutLocationList({super.key, required this.data});

  final List<POS> data;

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: Icon(Icons.info_outline_rounded),
      color: Colors.red,
      onPressed: () => _showPOSWithoutLocationList(context, data),
    );
  }
}

void _showPOSWithoutLocationList(BuildContext context, List<POS> data) {
  showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        title: const Text("POS List with invalid location"),
        content: Container(
          width: double.maxFinite,
          child: ListView.separated(
            separatorBuilder: (context, index) => Divider(),
            scrollDirection: Axis.vertical,
            itemCount: data.length,
            itemBuilder: (context, index) {
              final pos = data[index];

              return ListTile(
                title: Text(pos.name),
                subtitle: Wrap(
                  textDirection: TextDirection.ltr,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: kPadding2,
                          color: Colors.yellow,
                          child: const Text("lat"),
                        ),
                        Text(pos.location?.lat.toString() ?? ""),
                      ],
                    ),
                    Row(
                      children: [
                        Container(
                          padding: kPadding2,
                          color: Colors.yellow,
                          child: const Text("lng"),
                        ),
                        Text(pos.location?.lat.toString() ?? "")
                      ],
                    ),
                  ],
                ),
              );
            },
          ),
        ),
        actions: [
          TextButton(
            child: const Text("Cancel"),
            onPressed: () => Navigator.pop(context),
          )
        ],
      );
    },
  );
}
