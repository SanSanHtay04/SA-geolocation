import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:sales/models/models.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/utils/utils.dart';

import 'pos_without_location_list.dart';

class CheckinMapView extends StatefulWidget {
  final List<POS> posList;
  final List<POS> posWithoutLocationList;
  final LatLng? myLocation;
  final GestureTapCallback onMyLocationClick;

  const CheckinMapView({
    super.key,
    required this.posList,
    required this.posWithoutLocationList,
    required this.myLocation,
    required this.onMyLocationClick,
  });

  @override
  State<CheckinMapView> createState() => _CheckinMapViewState();
}

class _CheckinMapViewState extends State<CheckinMapView> {
  late MapOptions _mapOptions;
  MapController mapController = MapController();

  @override
  Widget build(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      if (widget.myLocation != null) {
        mapController.move(widget.myLocation!, 17.0);
      }
    });
    return Column(
      children: [
        SizedBox(
          height: 250,
          child: FlutterMap(
            mapController: mapController,
            options: MapOptions(
              cameraConstraint: CameraConstraint.contain(
                bounds: LatLngBounds(
                  const LatLng(-90, -180),
                  const LatLng(90, 180),
                ),
              ),
            ),
            children: [
              TileLayer(
                urlTemplate: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                subdomains: ['a', 'b', 'c'],
              ),
              MarkerLayer(markers: [
                if (widget.myLocation != null) ...{
                  _userMarker(widget.myLocation!),
                },
                ..._posMarkers(widget.posList),
              ])
            ],
            nonRotatedChildren: [
              _myLocationButton(widget.onMyLocationClick),
              if (widget.posWithoutLocationList.isNotEmpty) ...{
                Align(
                  alignment: Alignment.topRight,
                  child: POSWithoutLocationList(
                    data: widget.posWithoutLocationList,
                  ),
                ),
              },
            ],
          ),
        ),
      ],
    );
  }

  Marker _userMarker(LatLng mylocation) {
    return Marker(
      point: mylocation,
      child: Icon(
        Icons.location_on,
        color: Theme.of(context).primaryColor,
      ),
    );
  }

  Iterable<Marker> _posMarkers(List<POS> posList) {
    return posList.map((pos) {
      return Marker(
        width: 100,
        point: LatLng(
          pos.location!.lat,
          pos.location!.lng,
        ),
        // Use this if this is not enough https://pub.dev/packages/flutter_map_marker_popup
        child: Tooltip(
          verticalOffset: 15,
          child: Icon(
            Icons.location_on,
            color: Colors.deepOrangeAccent,
          ),
          message: pos.name,
          triggerMode: TooltipTriggerMode.tap,
        ),
      );
    });
  }

  Widget _myLocationButton(VoidCallback onPress) {
    return Padding(
      padding: kPaddingHorizontal4 + kPaddingVertical16,
      child: Align(
        alignment: Alignment.bottomRight,
        child: ElevatedButton(
          child: Icon(
            Icons.my_location,
            color: Theme.of(context).primaryColor,
          ),
          onPressed: onPress,
          style: ElevatedButton.styleFrom(
            shape: CircleBorder(),
            backgroundColor: context.getColorScheme().background,
          ),
        ),
      ),
    );
  }
}
