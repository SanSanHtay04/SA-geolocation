import 'package:flutter/material.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/utils/utils.dart';
import '../notifiers/data/checkin_notifier.dart';
import '../notifiers/submit/checkin_submit_notifier.dart';
import 'checkin_history_table.dart';
import 'pos_selector_widget.dart';
import 'checkin_map_view.dart';
import 'other_functions_widget.dart';

class CheckinComponentWidget extends StatelessWidget {
  const CheckinComponentWidget({
    super.key,
    required this.data,
    required this.submit,
  });

  final CheckinNotifier data;
  final CheckinSubmitNotifier submit;

  @override
  Widget build(BuildContext context) {
    final state = data.state;

    return Container(
      child: Column(children: [
        ConstrainedBox(
          constraints: BoxConstraints(minHeight: 250),
          child: CheckinMapView(
            posList: state.posList,
            posWithoutLocationList: state.posWithoutLocationList,
            myLocation: state.currentPosition,
            onMyLocationClick: data.getCurrentPosition,
          ),
        ),
        const PosSelectorWidget(),
        const OtherFunctionsWidget(),
        Divider(),
        Padding(
          padding: kPaddingHorizontal8,
          child: Text(
            "History",
            style: context.getTextTheme().bodySmall,
          ),
        ),
        CheckinHistoryTable(),
      ]),
    );
  }
}
