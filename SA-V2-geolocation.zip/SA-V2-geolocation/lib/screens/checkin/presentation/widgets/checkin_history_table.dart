import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:sales/widgets/error_message.dart';

import '../notifiers/data/checkin_notifier.dart';

class CheckinHistoryTable extends StatelessWidget {
  const CheckinHistoryTable({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final state = context.watch<CheckinNotifier>().historyState;

    return state.when(
      idle: (history) => DataTable(
        columns: const [
          DataColumn(label: Text("Time")),
          DataColumn(label: Text("POS")),
          DataColumn(label: Text("Type")),
        ],
        rows: history.data
            .map(
              (entry) => DataRow(
                cells: [
                  DataCell(Text(entry.dateTime)),
                  DataCell(Text(entry.posName)),
                  DataCell(Text(entry.type)),
                ],
              ),
            )
            .toList(),
      ),
      failed: (message, error) => ErrorMessage(message),
      loading: () => CircularProgressIndicator(),
    );
  }
}
