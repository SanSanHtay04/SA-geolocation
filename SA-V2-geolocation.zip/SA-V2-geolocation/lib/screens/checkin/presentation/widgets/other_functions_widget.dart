import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/base/error.dart';

import 'package:sales/themes/dimensions.dart';

import '../../../../widgets/error_message.dart';
import '../notifiers/break_time/break_time_notifier.dart';
import '../notifiers/work_hour/work_hour_notifier.dart';

class OtherFunctionsWidget extends StatelessWidget {
  const OtherFunctionsWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        _toggleWorkHour(context),
        kSpaceVertical8,
        _toggleBreakTime(context)
      ],
    );
  }

  Widget _toggleBreakTime(BuildContext context) {
    final state = context.watch<BreakTimeNotifier>().state;

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text("Break"),
        state.when(
          loading: () => CircularProgressIndicator(),
          failed: (message, error) =>
              ErrorMessage(error.errorMessage(context, message)),
          idle: (status) => Switch(
            value: status,
            onChanged: context.read<BreakTimeNotifier>().switchBreakTime,
          ),
        ),
      ],
    );
  }

  Widget _toggleWorkHour(BuildContext context) {
    final state = context.watch<WorkHourNotifier>().state;

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text("Work"),
        state.when(
          idle: (status) => Switch(
            value: status,
            onChanged: context.read<WorkHourNotifier>().switchWorkHour,
          ),
          loading: () => CircularProgressIndicator(),
          failed: (message, error) =>
              ErrorMessage(error.errorMessage(context, message)),
        ),
      ],
    );
  }
}
