import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/models/models.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/app_snack_bar.dart';
import 'package:sales/widgets/selected_field/selected_field.dart';

import '../notifiers/data/checkin_data_state.dart';
import '../notifiers/data/checkin_notifier.dart';
import '../notifiers/submit/checkin_submit_notifier.dart';

class PosSelectorWidget extends StatelessWidget {
  const PosSelectorWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<CheckinNotifier>().state;

    return Padding(
      padding: kPadding16,
      child: state.isVisiblePosSelector ? _PosSelector(context, state) : _NoNearbyPOSError(context),
    );
  }

  Widget _PosSelector(BuildContext context, CheckinDataState state) {
    return Column(
      children: [
        SelectedField<POS>(
          title: "Merchandise/POS",
          required: true,
          items: state.nearByPOSList,
          labelParser: (item) => item.name,
          selectedItem: state.currentPOS,
          onSelected: (value) {
            context.read<CheckinNotifier>().onPosSelected(value);
          },
        ),
        Row(
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: state.enablePosCheckinButton
                    ? () => context.showConfirmDialog(
                        message: 'Are you sure want to check out?',
                        onConfirmPressed: () {
                          context.read<CheckinSubmitNotifier>().checkOut(
                                pos: state.currentPOS,
                                latlng: state.currentPosition,
                              );
                        })
                    : null,
                child: Text("Check out"),
              ),
            ),
            kSpaceHorizontal8,
            Expanded(
                child: ElevatedButton(
              onPressed: state.enablePosCheckinButton
                  ? () => context.showConfirmDialog(
                      message: 'Are you sure want to check in?',
                      onConfirmPressed: () {
                        context.read<CheckinSubmitNotifier>().checkIn(
                              pos: state.currentPOS,
                              latlng: state.currentPosition,
                            );
                      })
                  : null,
              child: Text("Check in"),
            )),
          ],
        )
      ],
    );
  }

  Widget _NoNearbyPOSError(BuildContext context) {
    return Column(
      children: [
        Text("This operation is not permitted because there is no POS nearby."),
        MaterialButton(
          onPressed: () {
            context.read<CheckinNotifier>().getCurrentPosition();
          },
          child: Text("Try again"),
        )
      ],
    );
  }
}
