import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/base/error.dart';
import 'package:sales/data/local/tables/checkin_table.dart';

import 'package:sales/widgets/app_snack_bar.dart';
import '../../../widgets/work_layout.dart';

import '../data/break_time_repository.dart';
import '../data/check_pos_repository.dart';
import '../data/work_hour_repository.dart';
import 'notifiers/break_time/break_time_notifier.dart';
import 'notifiers/data/checkin_notifier.dart';
import 'notifiers/submit/checkin_submit_notifier.dart';
import 'notifiers/work_hour/work_hour_notifier.dart';
import 'widgets/checkin_component_widget.dart';

class CheckinScreen extends StatelessWidget {
  const CheckinScreen({super.key});

  static Widget create() {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) => CheckinNotifier(
            context.read(),
            repo: context.read(),
          ),
        ),
        ChangeNotifierProvider(
          create: (context) => CheckinSubmitNotifier(repo: context.read()),
        ),
        ChangeNotifierProvider(
          create: (context) =>
              BreakTimeNotifier(repo: BreakTimeRepository(context.read()))
                ..getStatus(),
        ),
        ChangeNotifierProvider(
          create: (context) =>
              WorkHourNotifier(repo: WorkHourRepository(context.read()))
                ..getStatus(),
        ),
      ],
      child: CheckinScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Consumer2<CheckinNotifier, CheckinSubmitNotifier>(
        builder: (context, dataNotifier, submitNotifier, widget) {
      /// TODO: we need to handle the dataState as well in later tasks.

      /// To handle the call-back from submitState
      Future.delayed(Duration.zero, () async {
        submitNotifier.state.maybeWhen(
            failed: (message, error) => context.showErrorDialog(
                  error.errorMessage(context, message),
                  onClosePressed: () {
                    dataNotifier.onPosSelected(null);
                    submitNotifier.resetSubmitState();
                  },
                ),
            success: (message) => context.showMessageDialog(
                  message: message,
                  onClosePressed: () {
                    dataNotifier.onPosSelected(null);
                    dataNotifier.getCheckedHistory();
                    submitNotifier.resetSubmitState();
                  },
                ),
            orElse: () {});
      });

      return WorkLayout(
          isBusy: dataNotifier.isLoading || submitNotifier.isLoading,
          child: SingleChildScrollView(
            child: CheckinComponentWidget(
              data: dataNotifier,
              submit: submitNotifier,
            ),
          ));
    });
  }
}
