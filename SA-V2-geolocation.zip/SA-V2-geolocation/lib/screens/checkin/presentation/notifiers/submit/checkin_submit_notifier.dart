import 'package:flutter/cupertino.dart';
import 'package:latlong2/latlong.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/models/models.dart';

import '../../../data/check_pos_repository.dart';
import 'checkin_history_state.dart';
import 'checkin_submit_state.dart';

class CheckinSubmitNotifier extends ChangeNotifier {
  CheckinSubmitNotifier({required this.repo});

  CheckPosRepository repo;

  CheckinSubmitState state = const CheckinSubmitState.idle();

  bool get isLoading => (state is CheckinSubmitStateLoading);

  void emit(CheckinSubmitState value) {
    state = value;
    notifyListeners();
  }

  void resetSubmitState() => emit(const CheckinSubmitState.idle());

  checkOut({POS? pos, LatLng? latlng}) async {
    if (pos == null || latlng == null) return;
    emit(CheckinSubmitState.loading());
    final res = await repo.checkOut(pos.id, latlng);
    final newState = res.when(
      success: (data) => CheckinSubmitState.success(data),
      failed: (msg, err) => CheckinSubmitState.failed(msg, error: err),
    );
    emit(newState);
  }

  checkIn({POS? pos, LatLng? latlng}) async {
    if (pos == null || latlng == null) return;
    emit(CheckinSubmitState.loading());
    final res = await repo.checkIn(pos.id, latlng);

    final newState = res.when(
      success: (data) => CheckinSubmitState.success(data),
      failed: (msg, err) => CheckinSubmitState.failed(msg, error: err),
    );
    emit(newState);
  }


}
