import "package:freezed_annotation/freezed_annotation.dart";
import 'package:sales/base/error.dart';

part "checkin_submit_state.freezed.dart";

@freezed
class CheckinSubmitState with _$CheckinSubmitState {
  const factory CheckinSubmitState.idle() = CheckinSubmitStateIdle;

  const factory CheckinSubmitState.loading() = CheckinSubmitStateLoading;

  const factory CheckinSubmitState.failed(String message, {AppError? error}) = CheckinSubmitStateFailed;

  const factory CheckinSubmitState.success(String message) = CheckinSubmitStateSuccess;
}
