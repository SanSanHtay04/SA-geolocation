import "package:freezed_annotation/freezed_annotation.dart";
import 'package:sales/base/error.dart';
import 'package:sales/models/models.dart';

part "checkin_history_state.freezed.dart";

@freezed
class CheckinHistoryState with _$CheckinHistoryState {
  const factory CheckinHistoryState.idle(
          {@Default(CheckinHistory()) CheckinHistory history}) =
      CheckinHistoryStateIdle;

  const factory CheckinHistoryState.loading() = CheckinHistoryStateLoading;

  const factory CheckinHistoryState.failed(String message, {AppError? error}) =
      CheckinHistoryStateFailed;

}
