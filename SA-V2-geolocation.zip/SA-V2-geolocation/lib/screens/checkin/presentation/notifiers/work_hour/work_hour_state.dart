import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/base/error.dart';

part 'work_hour_state.freezed.dart';

@freezed
class WorkHourState with _$WorkHourState {
  const factory WorkHourState.idle({@Default(false) bool status}) = WorkHourStateIdle;

  const factory WorkHourState.loading() = WorkHourStateLoading;

  const factory WorkHourState.failed(String message, {AppError? error}) =
      WorkHourStateFailed;
}
