import 'package:flutter/widgets.dart';

import '../../../data/work_hour_repository.dart';
import 'work_hour_state.dart';

class WorkHourNotifier extends ChangeNotifier {
  late WorkHourRepository repo;

  WorkHourNotifier({required this.repo});

  WorkHourState state = const WorkHourState.idle();

  void emit(WorkHourState data) {
    state = data;
    notifyListeners();
  }

  Future<void> getStatus() async {
    emit(const WorkHourState.loading());

    final res = await repo.getWorkHourState();
    final newState = res.when(
      success: (data) => WorkHourState.idle(status: data),
      failed: (msg, error) => WorkHourState.failed(msg, error: error),
    );
    emit(newState);
  }

  Future<void> switchWorkHour( bool isActive) async {
    emit(const WorkHourState.loading());

    final res = await repo.toggleWorkHour(isActive);
    final newState = res.when(
      success: (data) => WorkHourState.idle(status: data),
      failed: (message, error) => WorkHourState.failed(message, error: error),
    );
    emit(newState);
  }
}
