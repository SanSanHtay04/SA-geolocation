import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/base/error.dart';

part 'break_time_state.freezed.dart';

@freezed
class BreakTimeState with _$BreakTimeState {
  const factory BreakTimeState.idle({@Default(false) bool status}) =
      BreakTimeStatusIdle;

  const factory BreakTimeState.loading() = BreakTimeStatusLoading;

  const factory BreakTimeState.failed(String message, {AppError? error}) =
      BreakTimeStatusFailed;
}
