import 'package:flutter/widgets.dart';
import 'package:sales/utils/utils.dart';

import '../../../data/break_time_repository.dart';
import 'break_time_state.dart';

class BreakTimeNotifier extends ChangeNotifier {
  BreakTimeRepository repo;

  BreakTimeNotifier({required this.repo}) {
    AppLogger.i("Initializing BreakTimeNotifier");
    getStatus();

  }

  BreakTimeState state = const BreakTimeState.idle();

  void emit(BreakTimeState data) {
    state = data;
    notifyListeners();
  }

  Future<void> getStatus() async {
    AppLogger.i("Initializing BreakTimeStatus");
    emit(const BreakTimeState.loading());

    final res = await repo.getBreakTimeState();
    final newState = res.when(
      success: (data) => BreakTimeState.idle(status: data),
      failed: (msg, error) => BreakTimeState.failed(msg, error: error),
    );
    emit(newState);
  }

  switchBreakTime(bool isActive) async {
    emit(const BreakTimeState.loading());

    final res = await repo.toggleBreakTime(isActive);
    final newState = res.when(
      success: (data) => BreakTimeState.idle(status: data),
      failed: (message, error) => BreakTimeState.failed(message, error: error),
    );
    emit(newState);
  }
}
