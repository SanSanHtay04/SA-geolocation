import "package:freezed_annotation/freezed_annotation.dart";
import 'package:latlong2/latlong.dart';
import 'package:sales/base/error.dart';
import 'package:sales/models/models.dart';


part "checkin_data_state.freezed.dart";

enum CheckiPosStatus { loading, loaded, failed }

@freezed
class CheckinDataState with _$CheckinDataState {
  const CheckinDataState._();

  const factory CheckinDataState({
    @Default(CheckiPosStatus.loaded) CheckiPosStatus status,
    String? message,
    AppError? error,
    @Default([]) List<POS> posList,
    @Default([]) List<POS> posWithoutLocationList,
    LatLng? currentPosition,
    POS? currentPOS,
    @Default([]) List<POS> nearByPOSList,
  }) = _CheckinDataState;

  bool get isVisiblePosSelector => nearByPOSList.isNotEmpty;

  bool get enablePosCheckinButton =>
      currentPOS != null && currentPosition != null;
}

