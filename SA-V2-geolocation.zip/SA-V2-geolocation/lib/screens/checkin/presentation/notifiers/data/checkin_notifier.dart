import 'package:flutter/cupertino.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';

import 'package:sales/data/repositories/repositories.dart';
import 'package:sales/screens/checkin/data/check_pos_repository.dart';
import 'package:sales/utils/utils.dart';
import 'package:sales/models/models.dart';

import '../submit/checkin_history_state.dart';
import 'checkin_data_state.dart';

class CheckinNotifier extends ChangeNotifier {
  CheckinNotifier(this.checkPosRepo, {required POSRepository repo}) {
    getPOSList(repo).then(
      // We need to do this only after getting the pos list because we want to calculate nearby pos
      (_) {
        getCurrentPosition();

      },
    );
    getCheckedHistory();

  }

  final CheckPosRepository checkPosRepo;

  CheckinDataState state = const CheckinDataState();
  CheckinHistoryState historyState = CheckinHistoryState.idle();

  bool get isLoading =>
      (state.status == CheckiPosStatus.loading) ||
      (historyState is CheckinHistoryStateLoading);

  void emit(CheckinDataState value) {
    state = value;
    notifyListeners();
  }

  void emitCheckPosHistory(CheckinHistoryState value) {
    historyState = value;
    notifyListeners();
  }

  onPosSelected(POS? value) {
    emit(state.copyWith(currentPOS: value));
  }

  Future<void> getPOSList(POSRepository posRepo) async {
    emit(state.copyWith(status: CheckiPosStatus.loading));
    final res = await posRepo.getPOSList();
    final newState = res.when(
        success: filteredPOSList,
        failed: (msg, err) => state.copyWith(
              status: CheckiPosStatus.failed,
              message: msg,
              error: err,
            ));
    emit(newState);
  }

  filteredPOSList(List<POS> data) {
    List<POS> _posList = [], _posWithoutLocation = [];

    for (var pos in data) {
      if (pos.location == null || pos.location!.lat < 10) {
        _posWithoutLocation.add(pos);
      } else {
        _posList.add(pos);
      }
      _posList.add(pos);
    }
    return state.copyWith(
        status: CheckiPosStatus.loaded,
        posList: _posList,
        posWithoutLocationList: _posWithoutLocation);
  }

  void getCurrentPosition() {
    // emit(state.copyWith(status: CheckinStatus.loading));

    try {
      Geolocator.getCurrentPosition().then((value) {
        final nearByPOSList = filterPOS(value, state.posList);

        emit(state.copyWith(
          status: CheckiPosStatus.loaded,
          currentPosition: LatLng(value.latitude, value.longitude),
          nearByPOSList: nearByPOSList,
        ));
      });
    } catch (error) {
      emit(state.copyWith(
        status: CheckiPosStatus.failed,
        message: error.toString(),
        error: null,
        currentPosition: null,
        nearByPOSList: [],
      ));
    }
  }

  void getCheckedHistory() {
    emitCheckPosHistory(CheckinHistoryState.loading());

    AppLogger.i("GET CHECK HISTORY");
    checkPosRepo.getHistory().then((data) {
      AppLogger.i("GET CHECK HISTORY ${data.data.length}");

      emitCheckPosHistory(CheckinHistoryState.idle(history: data));
    }).catchError((e, stackTrace) {
      emitCheckPosHistory(CheckinHistoryState.failed(e.toString()));
      AppLogger.w("Failed to get checkin history", e, stackTrace);
    });
  }
}
