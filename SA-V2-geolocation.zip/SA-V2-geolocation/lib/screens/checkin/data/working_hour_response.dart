import 'package:freezed_annotation/freezed_annotation.dart';

part 'working_hour_response.freezed.dart';
part 'working_hour_response.g.dart';

@freezed
class WorkingHourResponse with _$WorkingHourResponse {
  const factory WorkingHourResponse({
    required String status,
    @Default('') String message,
  }) = _WorkingHourResponse;

  factory WorkingHourResponse.fromJson(Map<String, dynamic> json) =>
      _$WorkingHourResponseFromJson(json);
}
