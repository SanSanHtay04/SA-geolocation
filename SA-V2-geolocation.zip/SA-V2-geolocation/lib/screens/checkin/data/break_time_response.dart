import 'package:freezed_annotation/freezed_annotation.dart';

part 'break_time_response.freezed.dart';
part 'break_time_response.g.dart';

@freezed
class BreakTimeResponse with _$BreakTimeResponse {
  const factory BreakTimeResponse({
    required String status,
    @Default('') String message,
  }) = _BreakTimeResponse;

  factory BreakTimeResponse.fromJson(Map<String, dynamic> json) =>
      _$BreakTimeResponseFromJson(json);
}
