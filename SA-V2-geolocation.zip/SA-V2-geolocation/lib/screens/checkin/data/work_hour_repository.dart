import 'package:sales/base/data_response.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/data/remote/services/services.dart';
import 'package:sales/base/base_repository.dart';
import 'package:sales/utils/utils.dart';

class WorkHourRepository with BaseRepository {
  final CommonService _api;

  WorkHourRepository(this._api);

  /**
   * returns the status of work hour on=true or off=false
   */

  Future<DataResponse<bool>> toggleWorkHour(bool shouldTurnOn) {
    return getData(
      handleDataRequest: () => _api.switchWorkHour({
        'working': shouldTurnOn ? 1 : 0,
        'dtCreated': DateTime.now().format(formatPattern: DATETIME_FORMAT),
      }),
      handleDataResponse: (WorkingHourResponse res) => res.status == "on",
    );
  }

  Future<DataResponse<bool>> getWorkHourState() {
    return getData(
      handleDataRequest: () => _api.getWorkHourState(),
      handleDataResponse: (WorkingHourResponse res) => res.status == "on",
    );
  }
}
