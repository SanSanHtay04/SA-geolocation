import 'package:freezed_annotation/freezed_annotation.dart';

part 'check_pos_request.freezed.dart';
part 'check_pos_request.g.dart';

@Freezed(unionKey: 'checkType')
class CheckPosRequest with _$CheckPosRequest {
  @FreezedUnionValue('in')
  const factory CheckPosRequest.checkIn({
    @JsonKey(name: 'userLongitude') required double lng,
    @JsonKey(name: 'userLatitude') required double lat,
    required int posId,
    required String datetime,
  }) = _CheckIn;

  @FreezedUnionValue('out')
  const factory CheckPosRequest.checkOut({
    @JsonKey(name: 'userLongitude') required double lng,
    @JsonKey(name: 'userLatitude') required double lat,
    required int posId,
    required String datetime,
  }) = _CheckOut;

  factory CheckPosRequest.fromJson(Map<String, dynamic> json) =>
      _$CheckPosRequestFromJson(json);
}
