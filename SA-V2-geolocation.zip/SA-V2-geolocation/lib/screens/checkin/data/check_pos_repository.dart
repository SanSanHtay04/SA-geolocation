import 'package:latlong2/latlong.dart';
import 'package:sales/base/data_response.dart';
import 'package:sales/data/local/tables/checkin_table.dart';
import 'package:sales/data/remote/models/models.dart';
import 'package:sales/data/remote/services/services.dart';
import 'package:sales/base/base_repository.dart';
import 'package:sales/models/models.dart';
import 'package:sales/utils/utils.dart';



class CheckPosRepository with BaseRepository {
  final CommonService api;
  final CheckinDao dao;

  CheckPosRepository({required this.api, required this.dao});

  String get currentDateTime =>
      DateTime.now().format(formatPattern: DATETIME_FORMAT);

  Future<DataResponse<String>> checkOut(int posId, LatLng position) {
    return getData(handleDataRequest: () {
      final request = CheckPosRequest.checkOut(
        posId: posId,
        lat: position.latitude,
        lng: position.longitude,
        datetime: currentDateTime,
      );
      return api.checkInOutPos(request);
    }, handleDataResponse: (MessageResponse res) async {
      await dao.insert(CheckinCache(
        posId: posId,
        latitude: position.latitude,
        longitude: position.longitude,
        type: 'out',
        createdAt: currentDateTime,
      ));
      return res.messages ?? 'Successfully Check-out!';
    });
  }

  Future<DataResponse<String>> checkIn(int posId, LatLng position) {
    return getData(handleDataRequest: () {
      final request = CheckPosRequest.checkIn(
        posId: posId,
        lat: position.latitude,
        lng: position.longitude,
        datetime: currentDateTime,
      );
      return api.checkInOutPos(request);
    }, handleDataResponse: (MessageResponse res) async {
      await dao.insert(CheckinCache(
        posId: posId,
        latitude: position.latitude,
        longitude: position.longitude,
        type: 'in',
        createdAt: currentDateTime,
      ));
      return res.messages ?? 'Successfully Check-in!';
    });
  }

  Future<CheckinHistory> getHistory() async {
    final caches = await dao.selectAll();
    return CheckinHistory(
      data: caches
          .map((data) => Checkin(
                id: data.id,
                posId: data.posId,
                posName: data.posName,
                lat: data.latitude,
                lng: data.longitude,
                type: data.type,
                dateTime: data.createdAt,
              ))
          .toList(),
    );
  }
}
