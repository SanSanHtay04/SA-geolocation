import 'package:sales/base/data_response.dart';
import 'package:sales/data/remote/services/services.dart';
import 'package:sales/base/base_repository.dart';
import 'package:sales/utils/utils.dart';

class BreakTimeRepository with BaseRepository {
  final CommonService _api;

  BreakTimeRepository(this._api);

  /**
   * returns the status of work hour on=true or off=false
   */

  Future<DataResponse<bool>> toggleBreakTime(bool shouldTurnOn) {
    return getData(
      handleDataRequest: () => _api.switchBreakTime({
        'breakTime': shouldTurnOn ? 1 : 0,
        'dtCreated': DateTime.now().format(formatPattern: DATETIME_FORMAT),
      }),
      handleDataResponse: (res) => res.status == "on",
    );
  }

  Future<DataResponse<bool>> getBreakTimeState() {
    return getData(
      handleDataRequest: () => _api.getBreakTimeState(),
      handleDataResponse: (res) => res.status == "on",
    );
  }
}
