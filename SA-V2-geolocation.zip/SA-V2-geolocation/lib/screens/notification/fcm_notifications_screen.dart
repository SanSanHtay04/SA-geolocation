import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sales/providers/fcm_push_notification_provider.dart';
import 'package:sales/screens/notification/fcm_notification_widget.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/widgets/copyright_notice.dart';
import 'package:sales/widgets/waiting_modal_bottom_widget.dart';

class FcmNotificationsScreen extends StatefulWidget {
  FcmNotificationsScreen({super.key});

  @override
  _FcmNotificationsScreenState createState() => _FcmNotificationsScreenState();
}

class _FcmNotificationsScreenState extends State<FcmNotificationsScreen> {
  bool _isLoading = false;

  String? filter;
  TextEditingController searchController = new TextEditingController();

  List<Map<String, dynamic>> _fcmNotifications = [];

  Future<void> _getNotifications() async {
    showWaitingModal(
        context: context,
        message: "List of notifications are loading...",
        onWaiting: () async {
          try {
            await Provider.of<FcmPushNotificationProvider>(context, listen: false).getFcmNotifications().then((value) {
              setState(() {
                _fcmNotifications = Provider.of<FcmPushNotificationProvider>(context, listen: false).items;
              });
            });
          } catch (error) {
            print(error.toString());
          }
        });
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    _getNotifications();
    searchController.addListener(() {
      setState(() {
        filter = searchController.text;
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('NOTIFICATIONS (${_fcmNotifications.length})'),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.refresh_rounded),
            onPressed: () async {
              await this._getNotifications();
            },
          ),
        ],
      ),
      body: Padding(
        padding: EdgeInsets.fromLTRB(5, 10, 5, 5),
        child: Column(children: <Widget>[
          new Padding(
            padding: new EdgeInsets.fromLTRB(10, 0, 10, 5),
            child: new TextField(
              controller: searchController,
              decoration: InputDecoration(
                hintText: 'Search Notification',
                prefixIcon: Icon(
                  Icons.search,
                ),
                contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 15.0, 20.0),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15.0),
                ),
                suffixIcon: IconButton(
                  icon: Icon(Icons.clear),
                  onPressed: () => searchController.clear(),
                ),
              ),
            ),
          ),
          Divider(),
          Expanded(
            child: _fcmNotifications.length > 0
                ? Container(
                    child: RefreshIndicator(
                      onRefresh: () => _getNotifications(),
                      child: ListView.builder(
                          itemCount: _fcmNotifications.length,
                          itemBuilder: (context, i) {
                            return filter == null || filter == ""
                                ? FcmNotificationWidget(fcmNotification: _fcmNotifications[i])
                                : ('${_fcmNotifications[i]['messageType']}'.toLowerCase().contains(filter!.toLowerCase()) || '${_fcmNotifications[i]['customerName']}'.toLowerCase().contains(filter!.toLowerCase()) || '${_fcmNotifications[i]['messageTitle']}'.toLowerCase().contains(filter!.toLowerCase()) || '${_fcmNotifications[i]['applicationId']}'.toLowerCase().contains(filter!.toLowerCase()) ? FcmNotificationWidget(fcmNotification: _fcmNotifications[i]) : SizedBox());
                          }),
                    ),
                  )
                : Text(
                    "There is no notification found.",
                    style: TextStyle(color: Colors.grey),
                  ),
          ),
          kSpaceVertical8,
          CopyrightNotice(),
        ]),
      ),
    );
  }
}
