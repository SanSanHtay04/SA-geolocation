import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class FcmNotificationWidget extends StatefulWidget {
  final Map<String, dynamic> fcmNotification;

  FcmNotificationWidget({Key? key, required this.fcmNotification});

  @override
  State<FcmNotificationWidget> createState() => _FcmNotificationWidgetState();
}

class _FcmNotificationWidgetState extends State<FcmNotificationWidget> {
  @override
  Widget build(BuildContext context) {
    return ListTile(
      // isThreeLine: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            '[${widget.fcmNotification['messageType'] != null ? widget.fcmNotification['messageType'].toString().toUpperCase() : 'n/a'}]',
            style: TextStyle(color: Colors.blue[800], fontSize: 12, fontWeight: FontWeight.bold),
          ),
          Text(
            'App ID: ${widget.fcmNotification['applicationId'] ?? '-/-'} | ${widget.fcmNotification['customerName'] ?? '-/-'}',
            style: TextStyle(color: Colors.blue[800], fontSize: 12, fontWeight: FontWeight.bold),
          ),
        ],
      ),
      subtitle: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text(
                '- Title:',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
              ),
              SizedBox(
                width: 5,
              ),
              Text(
                '${widget.fcmNotification['messageTitle']}',
                style: TextStyle(fontSize: 13),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text(
                '- Sent:',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
              ),
              SizedBox(
                width: 5,
              ),
              Text('${DateFormat('dd/MM/yyyy HH:mm').format(DateTime.parse(widget.fcmNotification['dtCreated'].toString()))}'),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '- Content:',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                ),
              ),
              SizedBox(
                width: 5,
              ),
              Expanded(
                child: Text(
                  '${widget.fcmNotification['messageContent']}',
                  style: TextStyle(fontSize: 13),
                ),
              ),
            ],
          ),
          Divider(),
        ],
      ),
    );
  }
}
