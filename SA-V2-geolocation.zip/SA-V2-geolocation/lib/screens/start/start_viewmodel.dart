import 'package:flutter/cupertino.dart';
import 'package:sales/utils/utils.dart';

import 'start_state.dart';

class StartViewModel extends ChangeNotifier {
  StartState state = StartState.busy("");
  late UpdatesChecker _updatesChecker;
  String appDownloadUrl = "";
  String lastVersion = "";

  StartViewModel(UpdatesChecker updatesChecker) {
    _updatesChecker = updatesChecker;
    checkForUpdates();
  }

  void setState(StartState state) {
    this.state = state;
    notifyListeners();
  }

  void checkForUpdates() async {
    setState(StartState.busy("Checking for updates..."));
    try {
      final update = await _updatesChecker.checkForUpdates();
      setState(
        StartState.success(
          update: update,
          downloadURL: _updatesChecker.downloadUrl,
          currentVersion: _updatesChecker.latestVersion,
        ),
      );
    } catch (e, stackTrace) {
      setState(StartState.error("Failed to check for updates.\n$e"));
      AppLogger.e("Failed to check for updates.", e, stackTrace);
    }
  }

  Future<void> skipThisVersion() async {
    _updatesChecker.skipUpdate();
  }
}
