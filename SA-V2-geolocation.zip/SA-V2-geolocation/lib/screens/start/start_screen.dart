import 'dart:async';
import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import 'package:sales/themes/dimensions.dart';
import 'package:sales/utils/utils.dart';
import 'package:url_launcher/url_launcher_string.dart';

import '../../widgets/error_message.dart';
import 'start_viewmodel.dart';

class StartScreen extends StatefulWidget {
  const StartScreen({Key? key}) : super(key: key);

  @override
  State<StartScreen> createState() => _StartScreenState();
}

class _StartScreenState extends State<StartScreen> {
  bool _granted = false;
  // Only check for storage < Android 13
  _requestPermissions() async {
    bool isAndroid33 = false;
    DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
    if (Platform.isAndroid) {
      AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
      isAndroid33 = androidInfo.version.sdkInt >= 33;
    }
    [
      Permission.camera,
      isAndroid33 ? Permission.photos : Permission.storage,
      Permission.notification,
      Permission.contacts,
      Permission.sms,
      Permission.locationWhenInUse,
    ].request().then(
      (statuses) {
        if (statuses.values.every((status) => status.isGranted)) {
          setState(() {
            _granted = true;
          });
        } else {
          openAppSettings();
        }
      },
    );
  }

  @override
  void initState() {
    _requestPermissions();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Consumer<StartViewModel>(
          builder: (context, vm, _) {
            return vm.state.when(
              busy: (task) => Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(32.0),
                    child: Center(
                      child: Image.asset('assets/images/r2o_logo.png'),
                    ),
                  ),
                  kSpaceVertical32,
                  Text(task),
                  kSpaceVertical16,
                  CircularProgressIndicator(),
                ],
              ),
              error: (msg) => ErrorMessage(msg),
              success: (update, downloadUrl, version) {
                if (update == Update.None) {
                  Future.delayed(
                    Duration.zero,
                    () => navigateToLogin(context),
                  );
                } else {
                  Future.delayed(Duration.zero, () {
                    showDialog(
                        context: context,
                        builder: (_) {
                          return _updateDialog(
                            update == Update.Mandatory,
                            version: version,
                            onSkipTap: () => vm.skipThisVersion().then((_) => navigateToLogin(context)),
                            onUpdateTap: () async {
                              Navigator.pop(context);
                              launchUrlString(downloadUrl);
                            },
                          );
                        });
                  });
                }
                return Padding(
                  padding: const EdgeInsets.all(32.0),
                  child: Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Image.asset('assets/images/r2o_logo.png'),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }

  void navigateToLogin(BuildContext context) {
    Navigator.pushNamedAndRemoveUntil(
      context,
      "/login",
      (_) => false,
    );
  }

  Widget _updateDialog(
    bool mustUpdate, {
    required String version,
    required VoidCallback onUpdateTap,
    required VoidCallback onSkipTap,
  }) {
    return Center(
      child: Card(
        margin: EdgeInsets.symmetric(horizontal: 32),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                "Update available!!",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 30,
                ),
              ),
              SizedBox(height: 16),
              Text(
                'Version: $version',
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: 20,
                ),
              ),
              SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  mustUpdate
                      ? Container()
                      : OutlinedButton(
                          onPressed: onSkipTap,
                          child: Text("Skip"),
                        ),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: onUpdateTap,
                      child: Text("Download"),
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
