import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:sales/utils/utils.dart';

part 'start_state.freezed.dart';

@freezed
class StartState with _$StartState {
  const factory StartState.busy(String task) = StartStateBusy;

  const factory StartState.error(String msg) = StartStateError;

  const factory StartState.success({
    required Update update,
    required String downloadURL,
    required String currentVersion,
  }) = StartStateSuccess;
}
